import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        long long2 = org.apache.commons.math.util.FastMath.max(1072693248L, 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1), 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        double double2 = org.apache.commons.math.util.FastMath.pow(7.105427357601002E-15d, (double) 8.6196912E7f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.180265029949426E20d + "'", double1 == 8.180265029949426E20d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (-2.0d));
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray20 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray26 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray31 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray37 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray31);
        double[] doubleArray43 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray49 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray49);
        double[] doubleArray54 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray60 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray54);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray54);
        double[] doubleArray67 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray73 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray73);
        double[] doubleArray78 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray84 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray78, doubleArray84);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, 0.5840734641020676d);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray87);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray87);
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) 2146959360L);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 199825137 + "'", int15 == 199825137);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0123299393632377d + "'", double16 == 2.0123299393632377d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 5763.986698182558d + "'", double88 == 5763.986698182558d);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 2.1733506339476385E9d + "'", double92 == 2.1733506339476385E9d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.0099010138502609d, 81.55795945611504d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 82.6913100071849d + "'", double2 == 82.6913100071849d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1072693248, (-1.5707963263016567d), (double) 163567370392L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-2027411098L), (-169836288016831040L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.6273359298413054d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2033138522880173d + "'", double1 == 1.2033138522880173d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(2146959360, (-39));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2146959399 + "'", int2 == 2146959399);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(13101930472L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 2146959399, 464589719, (-2027411098));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 2, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 393877977);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.432892215913483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8572715198453926d) + "'", double1 == (-0.8572715198453926d));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.5574077246549023d), 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5574077246549023d) + "'", double2 == (-1.5574077246549023d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1024.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1024.0000000000002d + "'", double1 == 1024.0000000000002d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        int int1 = org.apache.commons.math.util.FastMath.abs(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 260L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        int int2 = org.apache.commons.math.util.MathUtils.pow(526528081, 6324257797542248449L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 660745809 + "'", int2 == 660745809);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        double double1 = org.apache.commons.math.util.FastMath.atan(5962.577951308233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5706286141043808d + "'", double1 == 1.5706286141043808d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.0779393487549d + "'", double1 == 21.0779393487549d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        double double1 = org.apache.commons.math.util.FastMath.rint(92.13617560368711d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 92.0d + "'", double1 == 92.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection9, false);
        boolean boolean12 = nonMonotonousSequenceException11.getStrict();
        int int13 = nonMonotonousSequenceException11.getIndex();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException11.getSuppressed();
        java.lang.Number number15 = nonMonotonousSequenceException11.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection16, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5711292852277063d, number1, (int) (byte) 10, orderDirection16, true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-1.5707963267948966d) + "'", number15.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 207520192, 0, 199825137);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(199825137, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1072693118));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        long long1 = org.apache.commons.math.util.MathUtils.sign(260L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.2557975993373345d, (double) 1087120128);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 91.3496729311403d + "'", double2 == 91.3496729311403d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 51L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(100.0d, (double) (-1074790400));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.791759469228055d + "'", double1 == 1.791759469228055d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-471924971), 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-2147483647), (-169836288016831040L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-169836290164314687L) + "'", long2 == (-169836290164314687L));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5706286141043808d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-2027411098), (-1762048500));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) -1, 1565427057);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1565427057) + "'", int2 == (-1565427057));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5707963267945448d, (java.lang.Number) 264.2352765143147d, (int) (short) 100);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1599221199, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        double double1 = org.apache.commons.math.util.FastMath.acosh(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.248291097914389d + "'", double1 == 4.248291097914389d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-2), 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.5405824507740068d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        double double2 = org.apache.commons.math.util.MathUtils.round(9999.999999999998d, 197);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9999.999999999998d + "'", double2 == 9999.999999999998d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 52);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 52);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger20);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (short) 1);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 52);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) 52);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger33);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 0L);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 52);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger38);
        java.math.BigInteger bigInteger42 = null;
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0L);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, (long) 52);
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, 0L);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (long) 52);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, bigInteger51);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, bigInteger52);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger52);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, (long) 1932168908);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger56);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray4 = new double[] { 2146959360, 100.0d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection9, false);
        boolean boolean12 = nonMonotonousSequenceException11.getStrict();
        int int13 = nonMonotonousSequenceException11.getIndex();
        boolean boolean14 = nonMonotonousSequenceException11.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection18, false);
        java.lang.String str21 = nonMonotonousSequenceException20.toString();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection23, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection32, false);
        boolean boolean35 = nonMonotonousSequenceException34.getStrict();
        int int36 = nonMonotonousSequenceException34.getIndex();
        boolean boolean37 = nonMonotonousSequenceException34.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection41, false);
        java.lang.String str44 = nonMonotonousSequenceException43.toString();
        nonMonotonousSequenceException34.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = nonMonotonousSequenceException34.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.473814720414451d, (java.lang.Number) 7.105427357601002E-15d, 112, orderDirection46, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection46, false);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str44.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertTrue("'" + orderDirection46 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection46.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-2027411098L), 1.1006299075696573d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.5840734641020676d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray23);
        double[] doubleArray28 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray34 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray28);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (5,729.578 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5763.986698182558d + "'", double24 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 5729.684851727662d + "'", double36 == 5729.684851727662d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(10, (-49));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection6, false);
        boolean boolean9 = nonMonotonousSequenceException8.getStrict();
        int int10 = nonMonotonousSequenceException8.getIndex();
        boolean boolean11 = nonMonotonousSequenceException8.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection15, false);
        java.lang.String str18 = nonMonotonousSequenceException17.toString();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.230201256551786d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection20, false);
        java.lang.String str23 = nonMonotonousSequenceException22.toString();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str18.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 4.23)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 4.23)"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.0726932455606842E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number8, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection19, false);
        boolean boolean22 = nonMonotonousSequenceException21.getStrict();
        int int23 = nonMonotonousSequenceException21.getIndex();
        java.lang.Throwable[] throwableArray24 = nonMonotonousSequenceException21.getSuppressed();
        java.lang.Number number25 = nonMonotonousSequenceException21.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = nonMonotonousSequenceException21.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection26, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection33, false);
        boolean boolean36 = nonMonotonousSequenceException35.getStrict();
        int int37 = nonMonotonousSequenceException35.getIndex();
        java.lang.Number number38 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number38, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        nonMonotonousSequenceException35.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException41);
        java.lang.String str43 = nonMonotonousSequenceException41.toString();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException41);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-1.5707963267948966d) + "'", number25.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)" + "'", str43.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-762742594), (long) 360339393);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 274846203337205442L + "'", long2 == 274846203337205442L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.791759469228055d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03127210214181558d + "'", double1 == 0.03127210214181558d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.1452583854692583E75d, 0.9873536182198484d, 4.193665588479839E58d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-2147483647), (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.14748365E9f) + "'", float2 == (-2.14748365E9f));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        long long1 = org.apache.commons.math.util.MathUtils.sign(159922109932L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1762048500));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1762048512) + "'", int1 == (-1762048512));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 101L, 0.0d, 4.193665588479839E58d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1024.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 52);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 52);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger20);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (short) 1);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 52);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) 52);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger33);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 0L);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 52);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger38);
        java.math.BigInteger bigInteger42 = null;
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0L);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, (long) 52);
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, 0L);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (long) 52);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, bigInteger51);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, bigInteger52);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger52);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger54, (java.lang.Number) 9968, (int) (short) -1);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger54);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        int int2 = org.apache.commons.math.util.MathUtils.pow(2146959399, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-314166815) + "'", int2 == (-314166815));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        float float3 = org.apache.commons.math.util.MathUtils.round(100.0f, 199825137, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 35.0d, (java.lang.Number) (-0.7246553734784749d), 205);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.22533514313954892d, (double) (-1.05201009E11f), 1.2301171011410834E11d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.718281828459045d, (java.lang.Number) 10000L, 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-35L), 274846203337205442L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3612377783854550071L) + "'", long2 == (-3612377783854550071L));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 198.0f, 1.5707961256570546d, (-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        float float2 = org.apache.commons.math.util.FastMath.min((-1.0f), (float) (-818408495));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-8.1840851E8f) + "'", float2 == (-8.1840851E8f));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection6, false);
        boolean boolean9 = nonMonotonousSequenceException8.getStrict();
        int int10 = nonMonotonousSequenceException8.getIndex();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException8.getSuppressed();
        java.lang.Number number12 = nonMonotonousSequenceException8.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection13, false);
        boolean boolean16 = nonMonotonousSequenceException15.getStrict();
        int int17 = nonMonotonousSequenceException15.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.5707963267948966d) + "'", number12.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9030861493754311d, (java.lang.Number) 1.2626272556789118d, (-938056529));
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 9.3805651E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        int[] intArray2 = new int[] { (short) 100, (short) 100 };
        int[] intArray5 = new int[] { 197, (byte) 10 };
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray5);
        int[] intArray13 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray13);
        int[] intArray21 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray21);
        int[] intArray26 = new int[] { 3, (short) -1, 100 };
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray26);
        int[] intArray30 = new int[] { (short) 100, (short) 100 };
        int[] intArray33 = new int[] { 197, (byte) 10 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray33);
        int[] intArray41 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray41);
        int[] intArray49 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray49);
        int[] intArray53 = new int[] { (short) 100, (short) 100 };
        int[] intArray56 = new int[] { 197, (byte) 10 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray56);
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray56);
        int[] intArray62 = new int[] { (short) 100, (short) 100 };
        int[] intArray65 = new int[] { 197, (byte) 10 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray62, intArray65);
        int[] intArray73 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray62, intArray73);
        int[] intArray81 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int82 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray81);
        int[] intArray86 = new int[] { 3, (short) -1, 100 };
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray86);
        int[] intArray90 = new int[] { (short) 100, (short) 100 };
        int[] intArray93 = new int[] { 197, (byte) 10 };
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray90, intArray93);
        int int95 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray90);
        int int96 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray62);
        int[] intArray97 = null;
        try {
            int int98 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 132.32157798333574d + "'", double6 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.04454463255303d + "'", double14 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 198 + "'", int27 == 198);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 132.32157798333574d + "'", double34 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.04454463255303d + "'", double42 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 3 + "'", int50 == 3);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 132.32157798333574d + "'", double57 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 132.32157798333574d + "'", double58 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 97 + "'", int59 == 97);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 132.32157798333574d + "'", double66 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 101.04454463255303d + "'", double74 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 3 + "'", int82 == 3);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 198 + "'", int87 == 198);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 132.32157798333574d + "'", double94 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (-2.0d));
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray20 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray26 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray31 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray37 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray31);
        double[] doubleArray43 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray49 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray49);
        double[] doubleArray54 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray60 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray54);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray54);
        double[] doubleArray67 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray73 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray73);
        double[] doubleArray78 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray84 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray78, doubleArray84);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, 0.5840734641020676d);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray87);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray87);
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) 2146959360L);
        double double92 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray54);
        double double93 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 199825137 + "'", int15 == 199825137);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0123299393632377d + "'", double16 == 2.0123299393632377d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 5763.986698182558d + "'", double88 == 5763.986698182558d);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 5731.590243702963d + "'", double92 == 5731.590243702963d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 5729.684851727662d + "'", double93 == 5729.684851727662d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (-1824669988200L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1824669988200L) + "'", long2 == (-1824669988200L));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 5729.5779513082325d + "'", number5.equals(5729.5779513082325d));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.0661452869115475d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.0099010138502609d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.190537109001971d + "'", double1 == 1.190537109001971d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) 'a', 464589906);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.1452583854692583E75d, 9999.999999999998d, 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray12.getClass();
        double[] doubleArray18 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray24 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 0.5840734641020676d);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray27);
        double[] doubleArray30 = null;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1599221199 + "'", int13 == 1599221199);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1599221199 + "'", int28 == 1599221199);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 560, (float) (-762742594));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-7.6274259E8f) + "'", float2 == (-7.6274259E8f));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100, (float) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1762048512));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 2146959360L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-40), 464589906);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.5707963267945448d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.2626272556789118d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        long long2 = org.apache.commons.math.util.MathUtils.pow(900L, 660745809);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(273623559, (-450022657));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 723646216 + "'", int2 == 723646216);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9.733308079048062d, (java.lang.Number) 4.547473508864641E-13d, (-2147483647));
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 5729.5779513082325d + "'", number5.equals(5729.5779513082325d));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-2.6616273797759626E18d), 0.8941496661860572d, (double) 197);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 159922109932L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.59922109932E11d + "'", double1 == 1.59922109932E11d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        float float2 = org.apache.commons.math.util.MathUtils.round((-1.69836287E17f), (-471924971));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        long long2 = org.apache.commons.math.util.MathUtils.pow(176992988855400L, 393877977);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-938056528), (long) (-2027411098));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 30, 97.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2999471564969417d + "'", double2 == 0.2999471564969417d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.2999471564969417d, (double) 101.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1565427057));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 197.2561786104557d + "'", double11 == 197.2561786104557d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-8934108775301215359L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-33171351720L), 3395L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 22523347817880L + "'", long2 == 22523347817880L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1, (-2147483648));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483647) + "'", int2 == (-2147483647));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        double double1 = org.apache.commons.math.util.FastMath.tanh(8.693425907335698d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999999943763772d + "'", double1 == 0.999999943763772d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        long long1 = org.apache.commons.math.util.FastMath.abs(1074266113L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1074266113L + "'", long1 == 1074266113L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        long long1 = org.apache.commons.math.util.FastMath.abs(9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 5729.5779513082325d + "'", number5.equals(5729.5779513082325d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 5729.5779513082325d + "'", number7.equals(5729.5779513082325d));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 163567370392L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.213696671755475d + "'", double1 == 11.213696671755475d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        double double1 = org.apache.commons.math.util.FastMath.cos(41.47212690861747d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8071886846276505d) + "'", double1 == (-0.8071886846276505d));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 6324257797542248449L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.98407153791888d + "'", double1 == 43.98407153791888d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 159922109984L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.59922109984E11d + "'", double1 == 1.59922109984E11d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        double double2 = org.apache.commons.math.util.FastMath.max(1.7988002500903407E85d, 1.076101121E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7988002500903407E85d + "'", double2 == 1.7988002500903407E85d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 10000, 0.0d, 264.2352765143147d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.20523325552E11d, 1.2464946689549945d, (double) (-68719476704L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-169836290164314687L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.22533514313954894d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2216334135082517d + "'", double1 == 0.2216334135082517d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection10, false);
        boolean boolean13 = nonMonotonousSequenceException12.getStrict();
        int int14 = nonMonotonousSequenceException12.getIndex();
        boolean boolean15 = nonMonotonousSequenceException12.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection19, false);
        java.lang.String str22 = nonMonotonousSequenceException21.toString();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        boolean boolean25 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 5729.5779513082325d + "'", number5.equals(5729.5779513082325d));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.718281828459045d, (java.lang.Number) 10000L, 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1074790400), 0, 207520192);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(13.099558749772557d, (-54.107294423447755d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.099558749772555d + "'", double2 == 13.099558749772555d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        double double2 = org.apache.commons.math.util.MathUtils.log(7.105427357601002E-15d, 3628800.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.4636395981854671d) + "'", double2 == (-0.4636395981854671d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-40));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6981317007977318d) + "'", double1 == (-0.6981317007977318d));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(163567370392L, (long) 560);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 163567370952L + "'", long2 == 163567370952L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        long long2 = org.apache.commons.math.util.MathUtils.pow(30L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 1072693148L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4620L, (java.lang.Number) (-1.5707963263016567d), (-2147483648));
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,147,483,647 and -2,147,483,648 are not strictly increasing (-1.571 >= 4,620)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,147,483,647 and -2,147,483,648 are not strictly increasing (-1.571 >= 4,620)"));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (-145));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        double double1 = org.apache.commons.math.util.FastMath.asin((-54.107294423447755d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-2027411098L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.7453292519943295d, 3628800.577670083d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3628798.8708230574d + "'", double2 == 3628798.8708230574d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3628798.8708230574d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 153.66948385933907d + "'", double1 == 153.66948385933907d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) '4', (double) 103.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.00000000000001d + "'", double2 == 52.00000000000001d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.4636395981854671d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-737658795) + "'", int1 == (-737658795));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1733246502868709E93d, (java.lang.Number) 4.9E-324d, (int) (short) 10, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection12, false);
        boolean boolean15 = nonMonotonousSequenceException14.getStrict();
        int int16 = nonMonotonousSequenceException14.getIndex();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException14.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException14.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException14.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection19, false);
        java.lang.Number number22 = nonMonotonousSequenceException21.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        java.lang.Number number24 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number25 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1.5707963267948966d) + "'", number18.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) 100 + "'", number22.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 4.9E-324d + "'", number24.equals(4.9E-324d));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.1733246502868709E93d + "'", number25.equals(1.1733246502868709E93d));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(37.213113347607305d, (double) (byte) 100, 6.146079582258013E10d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-187));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(560);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.072693248E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((-1.0f), (-1762048500), 393877977);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1), (-40));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (-450022657));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-450022657) + "'", int2 == (-450022657));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (short) 1);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 52);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 207520192);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.7598554821324757d, 1.5707960484932504d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7598554821324752d + "'", double2 == 2.7598554821324752d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        double double1 = org.apache.commons.math.util.FastMath.log(2.2124676738864985E30d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 69.87166127694181d + "'", double1 == 69.87166127694181d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        int[] intArray2 = new int[] { (short) 100, (short) 100 };
        int[] intArray5 = new int[] { 197, (byte) 10 };
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray5);
        int[] intArray9 = new int[] { (short) 100, (short) 100 };
        int[] intArray12 = new int[] { 197, (byte) 10 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray12);
        int[] intArray17 = new int[] { (short) 100, (short) 100 };
        int[] intArray20 = new int[] { 197, (byte) 10 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray20);
        int[] intArray28 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray17);
        int[] intArray33 = new int[] { (short) 100, (short) 100 };
        int[] intArray36 = new int[] { 197, (byte) 10 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray36);
        int[] intArray41 = new int[] { (short) 100, (short) 100 };
        int[] intArray44 = new int[] { 197, (byte) 10 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray44);
        int[] intArray48 = new int[] { (short) 100, (short) 100 };
        int[] intArray51 = new int[] { 197, (byte) 10 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray51);
        int[] intArray56 = new int[] { (short) 100, (short) 100 };
        int[] intArray59 = new int[] { 197, (byte) 10 };
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray56, intArray59);
        int[] intArray67 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray56, intArray67);
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray56);
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray36, intArray56);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 132.32157798333574d + "'", double6 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 132.32157798333574d + "'", double13 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 132.32157798333574d + "'", double21 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 101.04454463255303d + "'", double29 == 101.04454463255303d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 187 + "'", int30 == 187);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 132.32157798333574d + "'", double37 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 187 + "'", int38 == 187);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 132.32157798333574d + "'", double45 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 132.32157798333574d + "'", double52 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 132.32157798333574d + "'", double60 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 101.04454463255303d + "'", double68 == 101.04454463255303d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 187 + "'", int69 == 187);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 132.32157798333574d + "'", double70 == 132.32157798333574d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 199825137);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-9223372036854775808L), (float) (-1565427057));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.223372E18f) + "'", float2 == (-9.223372E18f));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(5.0238805208462765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 76.0032894736842d + "'", double1 == 76.0032894736842d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.7165256995489035d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2678770990191837d + "'", double1 == 1.2678770990191837d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 52);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 52);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger20);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (short) 1);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 52);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) 52);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger33);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 0L);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 52);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger38);
        java.math.BigInteger bigInteger42 = null;
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0L);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, (long) 52);
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, 0L);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (long) 52);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, bigInteger51);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, (int) (short) 1);
        java.math.BigInteger bigInteger55 = null;
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, 0L);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger57, (long) 52);
        java.math.BigInteger bigInteger60 = null;
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, 0L);
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, (long) 52);
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger57, bigInteger64);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, bigInteger57);
        java.math.BigInteger bigInteger67 = null;
        java.math.BigInteger bigInteger69 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, 0L);
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger69, (long) 52);
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, bigInteger69);
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger54);
        java.math.BigInteger bigInteger75 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 10L);
        java.math.BigInteger bigInteger76 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger69);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(bigInteger75);
        org.junit.Assert.assertNotNull(bigInteger76);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        int int1 = org.apache.commons.math.util.FastMath.abs(199825137);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 199825137 + "'", int1 == 199825137);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(8.693425907335698d, 2.432892215913483d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4102406001561114d + "'", double2 == 2.4102406001561114d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1072693249L, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray10 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, 0.5840734641020676d);
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray20 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray26 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray31 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray37 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray31);
        double[] doubleArray43 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray49 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray49);
        double[] doubleArray54 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray60 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray54);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray54);
        double[] doubleArray67 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray73 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray73);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray54);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, 15.104412573075516d);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1599221199 + "'", int14 == 1599221199);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.587674259300095d + "'", double15 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.587674259300095d + "'", double16 == 0.587674259300095d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 5962.5779513082325d + "'", double75 == 5962.5779513082325d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        java.lang.Class<?> wildcardClass14 = doubleArray3.getClass();
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, number16, (int) (short) -1);
        int int19 = nonMonotonousSequenceException18.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException18.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection20, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (5,729.578 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2027411098) + "'", int13 == (-2027411098));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-0.8071886846276505d), (-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8071886846276505d) + "'", double2 == (-0.8071886846276505d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 560);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(205, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 205 + "'", int2 == 205);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1.07269325E9f, (double) 2148794369L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.148794369E9d + "'", double2 == 2.148794369E9d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 207520192L, (java.lang.Number) 132L, (-2027411098));
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 132L + "'", number4.equals(132L));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-2027411098), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        int int2 = org.apache.commons.math.util.FastMath.max((-818408495), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1762048512));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.7165256995489035d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(9968, (-35));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.2557975993373345d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6128943887066545d + "'", double1 == 1.6128943887066545d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.584967478670572d + "'", double1 == 4.584967478670572d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-2L), 0.9873536182198484d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1122200539506655d) + "'", double2 == (-1.1122200539506655d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 171.88733853924697d, (-0.6214083129159854d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.05838313109537149d), (-1.7620484999999998E9d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray4 = new double[] { 2146959360, 100.0d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-86196911));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-737658795), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        int[] intArray2 = new int[] { (short) 100, (short) 100 };
        int[] intArray5 = new int[] { 197, (byte) 10 };
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray5);
        int[] intArray13 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray13);
        int[] intArray21 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray21);
        int[] intArray26 = new int[] { 3, (short) -1, 100 };
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray26);
        int[] intArray28 = new int[] {};
        try {
            int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 132.32157798333574d + "'", double6 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.04454463255303d + "'", double14 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 198 + "'", int27 == 198);
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.7571734891002406d, 2.2540686788122044d, (double) (-3612377783854550071L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 900L, (double) (-36L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 899.9999999999999d + "'", double2 == 899.9999999999999d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        int[] intArray2 = new int[] { (short) 100, (short) 100 };
        int[] intArray5 = new int[] { 197, (byte) 10 };
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray5);
        int[] intArray13 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray13);
        int[] intArray21 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray21);
        int[] intArray25 = new int[] { (short) 100, (short) 100 };
        int[] intArray28 = new int[] { 197, (byte) 10 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray28);
        try {
            int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 132.32157798333574d + "'", double6 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.04454463255303d + "'", double14 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 132.32157798333574d + "'", double29 == 132.32157798333574d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.7571734891002406d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (short) 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 52);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 52);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 52);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger27);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 360339392);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 52);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 3L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-9223372036854775808L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.1474838449999995E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7774339050475337d + "'", double1 == 0.7774339050475337d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9030861493754311d, (java.lang.Number) 1.2626272556789118d, (-938056529));
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number4, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        int int9 = nonMonotonousSequenceException7.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.7615941559557649d, (java.lang.Number) (byte) 0, 197);
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        int int15 = nonMonotonousSequenceException7.getIndex();
        java.lang.String str16 = nonMonotonousSequenceException7.toString();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (short) 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 52);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 52);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 52);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger27);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 0L);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (long) 52);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 0L);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 52);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger40);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (int) (short) 1);
        java.math.BigInteger bigInteger44 = null;
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 0L);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (long) 52);
        java.math.BigInteger bigInteger49 = null;
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, 0L);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, (long) 52);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, bigInteger53);
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger46);
        java.math.BigInteger bigInteger56 = null;
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, 0L);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger58, (long) 52);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger58);
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger43);
        java.math.BigInteger bigInteger63 = null;
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, 0L);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, (long) 52);
        java.math.BigInteger bigInteger68 = null;
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger68, 0L);
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger70, (long) 52);
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, bigInteger72);
        java.math.BigInteger bigInteger75 = org.apache.commons.math.util.MathUtils.pow(bigInteger72, (int) (short) 1);
        java.math.BigInteger bigInteger76 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger75);
        java.math.BigInteger bigInteger78 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, 35L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(bigInteger75);
        org.junit.Assert.assertNotNull(bigInteger76);
        org.junit.Assert.assertNotNull(bigInteger78);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        int int1 = org.apache.commons.math.util.FastMath.abs(393877977);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 393877977 + "'", int1 == 393877977);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.0000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4436354751788105d + "'", double1 == 1.4436354751788105d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        int int10 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number11 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.5707963267948966d) + "'", number9.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (short) 10 + "'", number11.equals((short) 10));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 526528081, (long) (-1072693118));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-546165037L) + "'", long2 == (-546165037L));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-9.223372E18f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(938056512, 2146959360);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-35), (-818408495));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 818408460 + "'", int2 == 818408460);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.8768393613128505d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7915523550971639d) + "'", double1 == (-0.7915523550971639d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.8189894035458565E-12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(197, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 152L, 0, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 153.0f + "'", float3 == 153.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1599221199, (-145));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        long long1 = org.apache.commons.math.util.FastMath.round(1.0E-323d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        double double1 = org.apache.commons.math.util.FastMath.sinh(81.5579594561d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3156541846486755E35d + "'", double1 == 1.3156541846486755E35d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(197, (-2147483647));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (double) 560);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1932168908, (long) 2146959361);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 464589719, 260.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.570795767161333d + "'", double2 == 1.570795767161333d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1087120128, 2146959360);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 4.584967478670572d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.283185307179586d + "'", double2 == 6.283185307179586d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray12.getClass();
        double[] doubleArray18 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray24 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        double[] doubleArray29 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray35 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray29);
        double[] doubleArray41 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray47 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        double[] doubleArray52 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray58 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray52);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray52);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray52);
        double[] doubleArray63 = new double[] {};
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        double[] doubleArray67 = new double[] { 2146959360, 100.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray67);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray63);
        java.lang.Class<?> wildcardClass70 = doubleArray12.getClass();
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double72 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1599221199 + "'", int13 == 1599221199);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 5729.097177468362d + "'", double62 == 5729.097177468362d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.587674259300095d + "'", double71 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.587674259300095d + "'", double72 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.587674259300095d + "'", double73 == 0.587674259300095d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 132.32157798333577d + "'", double1 == 132.32157798333577d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.570795767161333d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.509177190774344d + "'", double1 == 2.509177190774344d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.5840734641020676d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7933286322891901d + "'", double1 == 0.7933286322891901d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, number1, (int) (short) -1);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-637910610));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.759185314422266d + "'", double1 == 1.759185314422266d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.1733246502868709E93d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        double double2 = org.apache.commons.math.util.FastMath.atan2(8.526417023433696d, 173.97441983879477d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0489704187686197d + "'", double2 == 0.0489704187686197d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        long long2 = org.apache.commons.math.util.MathUtils.pow(52L, 205);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-7.6274259E8f), 3628798.8708230574d, 0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 284858279);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 2146959361);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.4436354751788103d, (-2147483648), 938056512);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.6061093801777693d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (short) 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 52);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 52);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 52);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger27);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 0L);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (long) 52);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 0L);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 52);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger40);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (int) (short) 1);
        java.math.BigInteger bigInteger44 = null;
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 0L);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (long) 52);
        java.math.BigInteger bigInteger49 = null;
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, 0L);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, (long) 52);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, bigInteger53);
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger46);
        java.math.BigInteger bigInteger56 = null;
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, 0L);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger58, (long) 52);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger58);
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger43);
        try {
            java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, (-818408495));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger62);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1076101131);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.489757462747576d + "'", double1 == 21.489757462747576d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.193665588479839E58d, (java.lang.Number) 2.7598554821324757d, 284858279);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-7.6274259E8f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.05994653947723986d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0617797817258474d + "'", double1 == 1.0617797817258474d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 464589719L, (float) 1076101121);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07610112E9f + "'", float2 == 1.07610112E9f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.6525285981219316E32d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) -1, (-35L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { (short) 100, (short) 100 };
        int[] intArray6 = new int[] { 197, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray6);
        int[] intArray10 = new int[] { (short) 100, (short) 100 };
        int[] intArray13 = new int[] { 197, (byte) 10 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int[] intArray18 = new int[] { (short) 100, (short) 100 };
        int[] intArray21 = new int[] { 197, (byte) 10 };
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray21);
        int[] intArray29 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray29);
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray18);
        int[] intArray34 = new int[] { (short) 100, (short) 100 };
        int[] intArray37 = new int[] { 197, (byte) 10 };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray37);
        int[] intArray42 = new int[] { (short) 100, (short) 100 };
        int[] intArray45 = new int[] { 197, (byte) 10 };
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray45);
        int[] intArray53 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray53);
        int[] intArray57 = new int[] { (short) 100, (short) 100 };
        int[] intArray60 = new int[] { 197, (byte) 10 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray60);
        int[] intArray68 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray68);
        int[] intArray76 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray76);
        int[] intArray81 = new int[] { 3, (short) -1, 100 };
        int int82 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray81);
        int[] intArray85 = new int[] { (short) 100, (short) 100 };
        int[] intArray88 = new int[] { 197, (byte) 10 };
        double double89 = org.apache.commons.math.util.MathUtils.distance(intArray85, intArray88);
        int int90 = org.apache.commons.math.util.MathUtils.distanceInf(intArray57, intArray85);
        int int91 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray85);
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray42);
        try {
            int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 132.32157798333574d + "'", double7 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 132.32157798333574d + "'", double14 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 132.32157798333574d + "'", double22 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 101.04454463255303d + "'", double30 == 101.04454463255303d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 187 + "'", int31 == 187);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 132.32157798333574d + "'", double38 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 187 + "'", int39 == 187);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 132.32157798333574d + "'", double46 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 101.04454463255303d + "'", double54 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 132.32157798333574d + "'", double61 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 101.04454463255303d + "'", double69 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 3 + "'", int77 == 3);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 198 + "'", int82 == 198);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 132.32157798333574d + "'", double89 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 187 + "'", int92 == 187);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-450022657));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        int[] intArray2 = new int[] { (short) 100, (short) 100 };
        int[] intArray5 = new int[] { 197, (byte) 10 };
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray5);
        int[] intArray13 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray13);
        int[] intArray17 = new int[] { (short) 100, (short) 100 };
        int[] intArray20 = new int[] { 197, (byte) 10 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray20);
        int[] intArray28 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray28);
        int[] intArray36 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray36);
        int[] intArray41 = new int[] { 3, (short) -1, 100 };
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray41);
        int[] intArray45 = new int[] { (short) 100, (short) 100 };
        int[] intArray48 = new int[] { 197, (byte) 10 };
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray48);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray45);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray45);
        int[] intArray54 = new int[] { (short) 100, (short) 100 };
        int[] intArray57 = new int[] { 197, (byte) 10 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray57);
        int[] intArray61 = new int[] { (short) 100, (short) 100 };
        int[] intArray64 = new int[] { 197, (byte) 10 };
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray64);
        int[] intArray69 = new int[] { (short) 100, (short) 100 };
        int[] intArray72 = new int[] { 197, (byte) 10 };
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray69, intArray72);
        int[] intArray80 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray69, intArray80);
        int int82 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray69);
        int[] intArray85 = new int[] { (short) 100, (short) 100 };
        int[] intArray88 = new int[] { 197, (byte) 10 };
        double double89 = org.apache.commons.math.util.MathUtils.distance(intArray85, intArray88);
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray69, intArray85);
        int int91 = org.apache.commons.math.util.MathUtils.distanceInf(intArray45, intArray85);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 132.32157798333574d + "'", double6 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.04454463255303d + "'", double14 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 132.32157798333574d + "'", double21 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 101.04454463255303d + "'", double29 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 3 + "'", int37 == 3);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 198 + "'", int42 == 198);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 132.32157798333574d + "'", double49 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 132.32157798333574d + "'", double58 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 132.32157798333574d + "'", double65 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 132.32157798333574d + "'", double73 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 101.04454463255303d + "'", double81 == 101.04454463255303d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 187 + "'", int82 == 187);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 132.32157798333574d + "'", double89 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.190537109001971d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4923946472760856d + "'", double1 == 1.4923946472760856d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        double double1 = org.apache.commons.math.util.FastMath.log10(4.248291097914389d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6282142674628933d + "'", double1 == 0.6282142674628933d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray14);
        double[] doubleArray26 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray32 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray37 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray43 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray37);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray37);
        double[] doubleArray50 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray56 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        double[] doubleArray61 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray67 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, 0.5840734641020676d);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray70);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray70);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray70);
        java.lang.Class<?> wildcardClass74 = doubleArray70.getClass();
        double[] doubleArray78 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray84 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray78, doubleArray84);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, 0.5840734641020676d);
        int int88 = org.apache.commons.math.util.MathUtils.hash(doubleArray87);
        java.lang.Class<?> wildcardClass89 = doubleArray87.getClass();
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray70, doubleArray87);
        java.lang.Class<?> wildcardClass91 = doubleArray87.getClass();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 5763.986698182558d + "'", double71 == 5763.986698182558d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.587674259300095d + "'", double73 == 0.587674259300095d);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1599221199 + "'", int88 == 1599221199);
        org.junit.Assert.assertNotNull(wildcardClass89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass91);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-450022657));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.36620409622270317d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9336932828028368d + "'", double1 == 0.9336932828028368d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        long long1 = org.apache.commons.math.util.FastMath.round(0.3082320158843422d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 1, 1072693248);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '4', 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        int[] intArray2 = new int[] { (short) 100, (short) 100 };
        int[] intArray5 = new int[] { 197, (byte) 10 };
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray5);
        int[] intArray13 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray13);
        int[] intArray21 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray21);
        int[] intArray26 = new int[] { 3, (short) -1, 100 };
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray26);
        int[] intArray30 = new int[] { '4', 1072693248 };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray30);
        int[] intArray34 = new int[] { (short) 100, (short) 100 };
        int[] intArray37 = new int[] { 197, (byte) 10 };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray37);
        int[] intArray45 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray45);
        int[] intArray53 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray53);
        int[] intArray58 = new int[] { 3, (short) -1, 100 };
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray58);
        int[] intArray62 = new int[] { '4', 1072693248 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray62);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray34);
        int[] intArray67 = new int[] { (short) 100, (short) 100 };
        int[] intArray70 = new int[] { 197, (byte) 10 };
        double double71 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray70);
        int[] intArray78 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray78);
        int[] intArray86 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray86);
        int[] intArray91 = new int[] { 3, (short) -1, 100 };
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray91);
        int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray67);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 132.32157798333574d + "'", double6 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.04454463255303d + "'", double14 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 198 + "'", int27 == 198);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1072693148 + "'", int31 == 1072693148);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 132.32157798333574d + "'", double38 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 101.04454463255303d + "'", double46 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 3 + "'", int54 == 3);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 198 + "'", int59 == 198);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1072693148 + "'", int63 == 1072693148);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 132.32157798333574d + "'", double71 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 101.04454463255303d + "'", double79 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 3 + "'", int87 == 3);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 198 + "'", int92 == 198);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.17765852281583172d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7504139532571152d) + "'", double1 == (-0.7504139532571152d));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.5309649148733797d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (-818408495));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.5707960484932504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1624472828584536d + "'", double1 == 1.1624472828584536d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.36787944117144233d, (java.lang.Number) 1.7988002500903407E85d, 10, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        int int7 = nonMonotonousSequenceException5.getIndex();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        int int2 = org.apache.commons.math.util.MathUtils.pow(187, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.037396450599555d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5881183531598448d + "'", double1 == 1.5881183531598448d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-737658795), (long) (-938056512));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 691965636283823040L + "'", long2 == 691965636283823040L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.9016777586372893d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4348106505389466d + "'", double1 == 1.4348106505389466d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 100, (int) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.993498045565198d + "'", double2 == 11.993498045565198d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.017453292519943295d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) 2.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        long long2 = org.apache.commons.math.util.FastMath.max(1074266113L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074266113L + "'", long2 == 1074266113L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.1624472828584536d, 12.0d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 112);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.583005244258363d + "'", double1 == 10.583005244258363d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(51L, 284858279L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14527772229L + "'", long2 == 14527772229L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        long long2 = org.apache.commons.math.util.FastMath.max(159922109984L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 159922109984L + "'", long2 == 159922109984L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-86196911), 1087120128);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.5840734641020676d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray23);
        double[] doubleArray28 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray34 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.5840734641020676d);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray28);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 0.0d);
        double[] doubleArray44 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray50 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray50);
        double[] doubleArray55 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray61 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray61);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray55);
        double[] doubleArray67 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray73 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray73);
        double[] doubleArray78 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray84 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray78, doubleArray84);
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray78);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray78);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray78);
        double[] doubleArray94 = new double[] { 0.015603607662981848d, (byte) 10, 0.8130227804211657d, 2.2250738585072014E-308d, 1.7182818284590453d };
        double[] doubleArray96 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray94, 0.6108652381980153d);
        double double97 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray96);
        java.lang.Class<?> wildcardClass98 = doubleArray96.getClass();
        double double99 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray78, doubleArray96);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5763.986698182558d + "'", double24 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.49558410655746776d + "'", double97 == 0.49558410655746776d);
        org.junit.Assert.assertNotNull(wildcardClass98);
        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 5729.091086155754d + "'", double99 == 5729.091086155754d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1072693148, (float) 159922119900L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.59922127E11f + "'", float2 == 1.59922127E11f);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.4865266288709784d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.968128529565356d + "'", double1 == 5.968128529565356d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray10 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double[] doubleArray15 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray21 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.5840734641020676d);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray24);
        double[] doubleArray29 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray35 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.5840734641020676d);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray29);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 0.0d);
        double[] doubleArray45 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray51 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray51);
        double[] doubleArray56 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray62 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray56);
        double[] doubleArray68 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray74 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray74);
        double[] doubleArray79 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray85 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray79, doubleArray85);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray79);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray79);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray79);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 5763.986698182558d + "'", double25 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1076101121);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1076101121L + "'", long1 == 1076101121L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        double double1 = org.apache.commons.math.util.FastMath.log10(349.9541180407703d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.544011108384825d + "'", double1 == 2.544011108384825d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1069449216));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1069449216 + "'", int1 == 1069449216);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1072693118));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        int int2 = org.apache.commons.math.util.FastMath.min(560, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 207520192, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1152921504606846976L + "'", long2 == 1152921504606846976L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-9.223372036854776E18d), 7.935491707525615d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.190537109001971d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07574293689638885d + "'", double1 == 0.07574293689638885d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-450022657));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 450022657L + "'", long1 == 450022657L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 198.0f, 560, (-447362047));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.5840734641020676d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray23);
        double[] doubleArray28 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray34 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.5840734641020676d);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray37);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 3.2302012565517866d);
        double[] doubleArray46 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray52 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray52);
        double[] doubleArray57 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray63 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 0.5840734641020676d);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray66);
        double[] doubleArray71 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray77 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray77);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, 0.5840734641020676d);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray71);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5763.986698182558d + "'", double24 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.587674259300095d + "'", double38 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1599221199 + "'", int40 == 1599221199);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 5763.986698182558d + "'", double67 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray12.getClass();
        double[] doubleArray18 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray24 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        double[] doubleArray29 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray35 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray29);
        double[] doubleArray41 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray47 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        double[] doubleArray52 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray58 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray52);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray52);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray52);
        double[] doubleArray63 = new double[] {};
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        double[] doubleArray67 = new double[] { 2146959360, 100.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray67);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray63);
        java.lang.Class<?> wildcardClass70 = doubleArray12.getClass();
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double72 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray76 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray82 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray76, doubleArray82);
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, 0.5840734641020676d);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1599221199 + "'", int13 == 1599221199);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 5729.097177468362d + "'", double62 == 5729.097177468362d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.587674259300095d + "'", double71 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.587674259300095d + "'", double72 == 0.587674259300095d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.718281828459045d, (java.lang.Number) 10000L, 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection10, false);
        boolean boolean13 = nonMonotonousSequenceException12.getStrict();
        int int14 = nonMonotonousSequenceException12.getIndex();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException12.getSuppressed();
        java.lang.Number number16 = nonMonotonousSequenceException12.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection17, false);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        java.lang.Number number21 = nonMonotonousSequenceException19.getPrevious();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-1.5707963267948966d) + "'", number16.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (short) 100 + "'", number20.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 2.0d + "'", number21.equals(2.0d));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double double1 = org.apache.commons.math.util.FastMath.asinh(7.569397566060481d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7215957021000174d + "'", double1 == 2.7215957021000174d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(2146959361);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 187);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.7915523550971639d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5468591864427408d) + "'", double1 == (-0.5468591864427408d));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.718281828459045d, (java.lang.Number) 10000L, 1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection9, false);
        java.lang.String str12 = nonMonotonousSequenceException11.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number14, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        java.lang.String str18 = nonMonotonousSequenceException17.toString();
        java.lang.Number number19 = nonMonotonousSequenceException17.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException17.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        java.lang.String str22 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (10,000 >= 2.718)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (10,000 >= 2.718)"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)" + "'", str18.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)"));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 5729.5779513082325d + "'", number19.equals(5729.5779513082325d));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (10,000 >= 2.718)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (10,000 >= 2.718)"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.2557975993373345d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.230201256551786d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9995767159100878d + "'", double1 == 0.9995767159100878d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 163567370952L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.213696673242355d + "'", double1 == 11.213696673242355d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-2027411098), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 10000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(723646216, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 723646215 + "'", int2 == 723646215);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-447362047), 1072693148);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 625331101 + "'", int2 == 625331101);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.762747174039086d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.828427124746191d + "'", double1 == 5.828427124746191d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.9075712110370514d, 0.881084187153127d, 0.999999943763772d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1762048512), (-19137318300L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 36L + "'", long2 == 36L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(4.248291097914389d, (double) 2L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2027411098), 2146959360);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.4102406001561114d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5524949597844468d + "'", double1 == 1.5524949597844468d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) (-1.03397965999E11d), (int) '4', orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 78.20287967163418d, 560, orderDirection6, true);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 559 and 560 are not strictly decreasing (78.203 <= null)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 559 and 560 are not strictly decreasing (78.203 <= null)"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.5256198019480943d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5501590460159071d + "'", double1 == 0.5501590460159071d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        double double1 = org.apache.commons.math.util.FastMath.acos(5.702764598448685E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5702260503041414d + "'", double1 == 1.5702260503041414d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, number1, (int) (short) -1);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection8, false);
        boolean boolean11 = nonMonotonousSequenceException10.getStrict();
        int int12 = nonMonotonousSequenceException10.getIndex();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number13, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException16.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-145L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        double double1 = org.apache.commons.math.util.FastMath.sin(8.653313236643557d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6971860325793503d + "'", double1 == 0.6971860325793503d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 2, (long) (-86196911));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 86196913L + "'", long2 == 86196913L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) '4', (-2027411098));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2027411046) + "'", int2 == (-2027411046));
    }
}

