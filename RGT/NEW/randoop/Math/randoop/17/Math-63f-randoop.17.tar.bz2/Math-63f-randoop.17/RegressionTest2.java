import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042695E42d + "'", double1 == 1.3383347192042695E42d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-990352295), (long) (-1963152000));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1944212088633840000L + "'", long2 == 1944212088633840000L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-308865033));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 308865033L + "'", long1 == 308865033L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        java.lang.String str11 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNull(orderDirection9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) -1 + "'", number10.equals((short) -1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)"));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        int int2 = org.apache.commons.math.util.FastMath.max(410401601, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 410401601 + "'", int2 == 410401601);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(416, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5705136013288645d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.944105723815846d + "'", double1 == 0.944105723815846d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double double1 = org.apache.commons.math.util.FastMath.expm1(5.267831587699267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 192.9948452238572d + "'", double1 == 192.9948452238572d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(24669.773504249122d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.84754625994806E9d, (java.lang.Number) 1.5370267529837607d, 990353647);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double1 = org.apache.commons.math.util.FastMath.sinh(35370.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double2 = org.apache.commons.math.util.FastMath.pow(34.16814692820414d, (double) (-48L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4331649634011087E-74d + "'", double2 == 2.4331649634011087E-74d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9.619275968248924E151d, (java.lang.Number) 1.0f, 100);
        int int4 = nonMonotonousSequenceException3.getIndex();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 3628800L, 1963152000, 350);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (short) -1, (int) '4');
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        double double1 = org.apache.commons.math.util.MathUtils.sign(92.13617560368711d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 1, (-1963152018));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1963152018 + "'", int2 == 1963152018);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.147483647E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.147483647E9d + "'", double1 == 2.147483647E9d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) Float.NaN, 0.5454487991429904d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.05445723044217712d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.054457230442177124d + "'", double1 == 0.054457230442177124d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-447361687L), (long) 990352347);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 613073835459848121L + "'", long2 == 613073835459848121L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.1102230246251565E-16d, (double) 100, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        int int2 = org.apache.commons.math.util.FastMath.min(100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-102083903636L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-308865033), (-990352296));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 2147483647, 1704.1247472748323d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707955332499728d + "'", double2 == 1.5707955332499728d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-447362047));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-447362048) + "'", int1 == (-447362048));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double double1 = org.apache.commons.math.util.FastMath.ulp(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(53.0d, (-0.4991311460098435d), 104);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.0d, 0.5454487991429904d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8207286053333909d + "'", double2 == 1.8207286053333909d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 32, Float.NaN);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        double double1 = org.apache.commons.math.util.FastMath.tanh(8.065817517094494E67d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-3.093102195050827d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 1, 1963152000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        long long2 = org.apache.commons.math.util.MathUtils.pow(410401601L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        int int2 = org.apache.commons.math.util.FastMath.max(35, (-990352295));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int int1 = org.apache.commons.math.util.MathUtils.sign(97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(12.566370614359172d, (double) 447362047L, 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(7.896296018267969E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42901.69723267129d + "'", double1 == 42901.69723267129d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(95.24777960769379d, (double) 980797963336773136L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        float float3 = org.apache.commons.math.util.MathUtils.round(100.0f, (int) (byte) 100, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double2 = org.apache.commons.math.util.FastMath.min(1.9988763193113157d, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        long long2 = org.apache.commons.math.util.FastMath.max(881330726850118847L, 8108519702544185345L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8108519702544185345L + "'", long2 == 8108519702544185345L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 447362037L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double double1 = org.apache.commons.math.util.FastMath.floor(50.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 50.0d + "'", double1 == 50.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1963152000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.292953926806126d + "'", double1 == 9.292953926806126d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(8407224849895527163L, 4425221512301963509L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3982003337593563654L + "'", long2 == 3982003337593563654L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double double1 = org.apache.commons.math.util.FastMath.tanh(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 95397607310873712L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        double[] doubleArray6 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray9 = new double[] { 1.0f, '4' };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 1);
        double[] doubleArray13 = null;
        double[] doubleArray20 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray23 = new double[] { 1.0f, '4' };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray20);
        double[] doubleArray32 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray35 = new double[] { 1.0f, '4' };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 100);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray32);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray32);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 1.0f);
        double[] doubleArray43 = null;
        double[] doubleArray50 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray53 = new double[] { 1.0f, '4' };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray50);
        double[] doubleArray62 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray65 = new double[] { 1.0f, '4' };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray65);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) 1);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray68);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray68);
        try {
            double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray68);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        int int1 = org.apache.commons.math.util.MathUtils.sign(890242921);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        long long1 = org.apache.commons.math.util.FastMath.round(5.0354544351403985E151d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray7 = new int[] { (byte) 100, 1, ' ', (byte) 10, (byte) 100 };
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray15 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray15);
        int[] intArray18 = new int[] {};
        int[] intArray24 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray32 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray32);
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray32);
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray24);
        try {
            int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1.963152018E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.4852598849257133d) + "'", double1 == (-3.4852598849257133d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        long long1 = org.apache.commons.math.util.FastMath.abs(95397608301226056L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 95397608301226056L + "'", long1 == 95397608301226056L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.9884153105589384d, 67.15064491944298d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (-1963152028));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        double double1 = org.apache.commons.math.util.FastMath.acos(67.15064491944298d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.84754625994806E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        double double1 = org.apache.commons.math.util.FastMath.log(4.10401601E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.83264675288535d + "'", double1 == 19.83264675288535d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 1, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double2 = org.apache.commons.math.util.FastMath.min(23552.0d, 77.90322580645159d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 77.90322580645159d + "'", double2 == 77.90322580645159d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (-308865033));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.9977655523399481d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5421811783782413d + "'", double1 == 0.5421811783782413d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(416);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        int int11 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number12 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNull(orderDirection9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) -1 + "'", number10.equals((short) -1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) -1 + "'", number12.equals((short) -1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 35, (long) (-990352344));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-990352309L) + "'", long2 == (-990352309L));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 2226184571297855489L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.34756116852212d + "'", double1 == 18.34756116852212d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 410401601);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray10 = new double[] { 1.0f, '4' };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray7);
        double[] doubleArray19 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray22 = new double[] { 1.0f, '4' };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 100);
        double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray7, doubleArray19);
        double[] doubleArray33 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray36 = new double[] { 1.0f, '4' };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 100);
        java.lang.Class<?> wildcardClass40 = doubleArray39.getClass();
        double[] doubleArray41 = null;
        double[] doubleArray48 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray51 = new double[] { 1.0f, '4' };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray48);
        double[] doubleArray60 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray63 = new double[] { 1.0f, '4' };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) 100);
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray60);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray48);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray48);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 4.9E-324d);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 410401601 + "'", int72 == 410401601);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 410401601);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 410401600 + "'", int1 == 410401600);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(410401612L, (long) (-1963152028));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2373553640L + "'", long2 == 2373553640L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.5370267529837607d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 10.0d, 350, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-990352334), (java.lang.Number) (short) 0, 2060654451, orderDirection6, true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1963152028L), 3982003337593563654L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3982003339556715682L) + "'", long2 == (-3982003339556715682L));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double double1 = org.apache.commons.math.util.FastMath.acos(143375.6565665829d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(2060654347, 1963152000);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 144555105949057024L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3725986534119411d + "'", double1 == 0.3725986534119411d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.0992098640220962d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.6239661660357751d, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.67991427693416E9d + "'", double2 == 2.67991427693416E9d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '#', (-1963151966L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1963151966L) + "'", long2 == (-1963151966L));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 104.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.338311150777212E44d + "'", double1 == 7.338311150777212E44d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        long long2 = org.apache.commons.math.util.MathUtils.pow(11L, 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5193120973630518667L + "'", long2 == 5193120973630518667L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1095062989), 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 980797963336773136L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.4331649634011087E-74d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4331649634011087E-74d + "'", double1 == 2.4331649634011087E-74d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-447362037), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-447362037) + "'", int2 == (-447362037));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3628800L + "'", long1 == 3628800L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1963152125L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        double[] doubleArray6 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray9 = new double[] { 1.0f, '4' };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 52.009614495783374d + "'", double12 == 52.009614495783374d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.0d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        int int2 = org.apache.commons.math.util.MathUtils.pow(2060654451, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2060654451 + "'", int2 == 2060654451);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.821637045374455E-17d) + "'", double1 == (-4.821637045374455E-17d));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double double1 = org.apache.commons.math.util.FastMath.asin(3.744918542441353d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(3104);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-990352295), (double) 881330726850118847L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 2147483647);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (short) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger11);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        try {
            java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (-30886503300L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5271796258079011d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9990489424874822d + "'", double1 == 0.9990489424874822d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 3104);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number11 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1 + "'", number11.equals(1));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 308865032L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (-1095062989));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1095062989 + "'", int2 == 1095062989);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 32, (-990352344), 990352444);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        long long2 = org.apache.commons.math.util.MathUtils.pow(8108519702544185345L, 1095062989);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-813437983372044287L) + "'", long2 == (-813437983372044287L));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-308865032), 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 3628800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2639223226749517d + "'", double1 == 0.2639223226749517d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) (byte) 100);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.3978952727983707d, (java.lang.Number) bigInteger12, (int) (byte) 10);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger12);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (short) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 1963152000);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 2147483647);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (short) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger11);
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        long long2 = org.apache.commons.math.util.FastMath.max(11L, 308865033L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 308865033L + "'", long2 == 308865033L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1963151976L), (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1963152076L) + "'", long2 == (-1963152076L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.0510655643417088d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray10 = new double[] { 1.0f, '4' };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 100);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray13);
        try {
            double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 11013.232920103324d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double1 = org.apache.commons.math.util.MathUtils.sign(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        long long2 = org.apache.commons.math.util.MathUtils.pow(102083904936L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(8407224849895527163L, (long) (-2147483648));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        long long2 = org.apache.commons.math.util.FastMath.max(11L, 1944212088633840000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1944212088633840000L + "'", long2 == 1944212088633840000L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        int int2 = org.apache.commons.math.util.FastMath.max((-308865033), (-99158567));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-99158567) + "'", int2 == (-99158567));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-1963152028), (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.4885908466334658E39d) + "'", double2 == (-2.4885908466334658E39d));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        int int9 = nonMonotonousSequenceException5.getIndex();
        int int10 = nonMonotonousSequenceException5.getIndex();
        java.lang.Class<?> wildcardClass11 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray8 = null;
        try {
            int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1780538303479458d + "'", double1 == 3.1780538303479458d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double1 = org.apache.commons.math.util.FastMath.expm1(34.16814692820414d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.902996731886964E14d + "'", double1 == 6.902996731886964E14d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        int int1 = org.apache.commons.math.util.MathUtils.sign(416);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.9732324798502845d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5626301559728387d + "'", double1 == 0.5626301559728387d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) (byte) 100);
        java.lang.Class<?> wildcardClass7 = bigInteger4.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1095062989), 416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-97012095) + "'", int2 == (-97012095));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray10 = new double[] { 1.0f, '4' };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray7);
        double[] doubleArray19 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray22 = new double[] { 1.0f, '4' };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 100);
        double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray7, doubleArray19);
        double[] doubleArray33 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray36 = new double[] { 1.0f, '4' };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 100);
        java.lang.Class<?> wildcardClass40 = doubleArray39.getClass();
        double[] doubleArray41 = null;
        double[] doubleArray48 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray51 = new double[] { 1.0f, '4' };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray48);
        double[] doubleArray60 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray63 = new double[] { 1.0f, '4' };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) 100);
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray60);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray48);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray48);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 4.9E-324d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray71);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double[] doubleArray6 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray9 = new double[] { 1.0f, '4' };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 100);
        java.lang.Class<?> wildcardClass13 = doubleArray12.getClass();
        double[] doubleArray14 = null;
        double[] doubleArray21 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray24 = new double[] { 1.0f, '4' };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray21);
        double[] doubleArray33 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray36 = new double[] { 1.0f, '4' };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 1);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) (-1));
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray42);
        double[] doubleArray44 = null;
        double[] doubleArray51 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray54 = new double[] { 1.0f, '4' };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray51);
        double[] doubleArray63 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray66 = new double[] { 1.0f, '4' };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 1);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray69);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray51);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 1.7453292519943295d);
        double[] doubleArray80 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray83 = new double[] { 1.0f, '4' };
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray80, doubleArray83);
        double[] doubleArray91 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray94 = new double[] { 1.0f, '4' };
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray91, doubleArray94);
        double[] doubleArray97 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray94, (double) 1);
        boolean boolean98 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray80, doubleArray94);
        boolean boolean99 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(doubleArray97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + true + "'", boolean99 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1095062989, (-97012095));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 998050894 + "'", int2 == 998050894);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(2226184571297855489L, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4452369142595710978L + "'", long2 == 4452369142595710978L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.3625517538551688d, 1.3383347192042695E42d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3383347192042695E42d + "'", double2 == 1.3383347192042695E42d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray10 = new double[] { 1.0f, '4' };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray7);
        double[] doubleArray19 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray22 = new double[] { 1.0f, '4' };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 100);
        double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray7, doubleArray19);
        double[] doubleArray33 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray36 = new double[] { 1.0f, '4' };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 100);
        java.lang.Class<?> wildcardClass40 = doubleArray39.getClass();
        double[] doubleArray41 = null;
        double[] doubleArray48 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray51 = new double[] { 1.0f, '4' };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray48);
        double[] doubleArray60 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray63 = new double[] { 1.0f, '4' };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) 100);
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray60);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray48);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray48);
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 32.046840717924134d + "'", double70 == 32.046840717924134d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.019302711892630914d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.019302711892630914d + "'", double1 == 0.019302711892630914d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-990352296), (java.lang.Number) (-972799671L), (-1557370719), orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1963152018L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.963152018E9d + "'", double1 == 1.963152018E9d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1095062989), 890242921);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray10 = new double[] { 1.0f, '4' };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray7);
        double[] doubleArray19 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray22 = new double[] { 1.0f, '4' };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 1);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray25);
        double[] doubleArray27 = null;
        double[] doubleArray34 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray37 = new double[] { 1.0f, '4' };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray34);
        double[] doubleArray46 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray49 = new double[] { 1.0f, '4' };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) 1);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray52);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) 2147483647L);
        try {
            double double56 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(3982003337593563654L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double2 = org.apache.commons.math.util.MathUtils.log(4.10401601E8d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1161007464956262d + "'", double2 == 0.1161007464956262d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 2, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.718281828459045d + "'", double2 == 2.718281828459045d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double[] doubleArray6 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray9 = new double[] { 1.0f, '4' };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 1);
        double[] doubleArray13 = null;
        double[] doubleArray20 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray23 = new double[] { 1.0f, '4' };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray20);
        double[] doubleArray32 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray35 = new double[] { 1.0f, '4' };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 100);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray32);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray32);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        double[] doubleArray48 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray51 = new double[] { 1.0f, '4' };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray51);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) 100);
        java.lang.Class<?> wildcardClass55 = doubleArray54.getClass();
        double[] doubleArray62 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray65 = new double[] { 1.0f, '4' };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray62);
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray54);
        double[] doubleArray75 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray78 = new double[] { 1.0f, '4' };
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray75, doubleArray78);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) 100);
        double[] doubleArray88 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray91 = new double[] { 1.0f, '4' };
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray88, doubleArray91);
        double[] doubleArray94 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray88, (double) 100);
        double double95 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray81, doubleArray88);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray88);
        double double97 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray99 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 4.104016E8f);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 77.90322580645159d + "'", double67 == 77.90322580645159d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 4.206938527084601d + "'", double68 == 4.206938527084601d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 71.2258064516129d + "'", double95 == 71.2258064516129d);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.9813134810525165d + "'", double97 == 0.9813134810525165d);
        org.junit.Assert.assertNotNull(doubleArray99);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-1400753935L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(11.0f, 1300, 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection14, false);
        boolean boolean17 = nonMonotonousSequenceException16.getStrict();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException16.getDirection();
        java.lang.Number number21 = nonMonotonousSequenceException16.getArgument();
        java.lang.String str22 = nonMonotonousSequenceException16.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        boolean boolean24 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNull(orderDirection9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) -1 + "'", number10.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) -1 + "'", number18.equals((short) -1));
        org.junit.Assert.assertNull(orderDirection19);
        org.junit.Assert.assertNull(orderDirection20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (short) -1 + "'", number21.equals((short) -1));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-308865032), (long) (-308865033));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray10 = new double[] { 1.0f, '4' };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 100);
        double[] doubleArray20 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray23 = new double[] { 1.0f, '4' };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 100);
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        double[] doubleArray34 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray37 = new double[] { 1.0f, '4' };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) 100);
        java.lang.Class<?> wildcardClass41 = doubleArray40.getClass();
        double[] doubleArray42 = null;
        double[] doubleArray49 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray52 = new double[] { 1.0f, '4' };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray52);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray49);
        double[] doubleArray61 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray64 = new double[] { 1.0f, '4' };
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray64);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, (double) 100);
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray61);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray49);
        double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray49);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 71.2258064516129d + "'", double27 == 71.2258064516129d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 613073835459848121L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 100, (int) (short) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        int int9 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100 + "'", number6.equals(100));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(100, (-447362037));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-447361687));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.47361687E8d) + "'", double1 == (-4.47361687E8d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 104);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        int int1 = org.apache.commons.math.util.FastMath.abs((-308865032));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 308865032 + "'", int1 == 308865032);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray10 = new double[] { 1.0f, '4' };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray7);
        double[] doubleArray19 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray22 = new double[] { 1.0f, '4' };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 1);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray25);
        double[] doubleArray33 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray36 = new double[] { 1.0f, '4' };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 100);
        java.lang.Class<?> wildcardClass40 = doubleArray39.getClass();
        double[] doubleArray47 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray50 = new double[] { 1.0f, '4' };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray50);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray47);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray7, doubleArray47);
        double[] doubleArray60 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray63 = new double[] { 1.0f, '4' };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray47, doubleArray60);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 77.90322580645159d + "'", double52 == 77.90322580645159d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 410401601 + "'", int66 == 410401601);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2.718281828459045d, (int) 'a', 416);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.3383347192042695E42d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double double1 = org.apache.commons.math.util.FastMath.log1p(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1963152000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5596601626286404d) + "'", double1 == (-1.5596601626286404d));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        long long1 = org.apache.commons.math.util.FastMath.round(6.0330862217988015d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6L + "'", long1 == 6L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray10 = new double[] { 1.0f, '4' };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray7);
        double[] doubleArray19 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray22 = new double[] { 1.0f, '4' };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 1);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray25);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-99158567) + "'", int28 == (-99158567));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.9813134810525165d + "'", double29 == 0.9813134810525165d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-0.4991311460098435d), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.24956557300492174d) + "'", double2 == (-0.24956557300492174d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (int) ' ');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        double double1 = org.apache.commons.math.util.FastMath.acos(92.13617560368711d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 1300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(990352347, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 1.5700376015990605d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        double double2 = org.apache.commons.math.util.FastMath.max(1.3440585709080678E43d, (double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double2 = org.apache.commons.math.util.MathUtils.round(4.0453777397135222E18d, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0453777397135222E18d + "'", double2 == 4.0453777397135222E18d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 2147483647);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (short) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger11);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) (short) 0);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (int) (byte) 100);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) 0);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.3978952727983707d, (java.lang.Number) bigInteger27, (int) (byte) 10);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger27);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger30);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 104);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.7253825588523148d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection14, false);
        boolean boolean17 = nonMonotonousSequenceException16.getStrict();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException16.getDirection();
        java.lang.Number number21 = nonMonotonousSequenceException16.getArgument();
        java.lang.String str22 = nonMonotonousSequenceException16.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNull(orderDirection9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) -1 + "'", number10.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) -1 + "'", number18.equals((short) -1));
        org.junit.Assert.assertNull(orderDirection19);
        org.junit.Assert.assertNull(orderDirection20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (short) -1 + "'", number21.equals((short) -1));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)"));
        org.junit.Assert.assertNull(orderDirection24);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.530276473092606d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray10 = new double[] { 1.0f, '4' };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray7);
        double[] doubleArray19 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray22 = new double[] { 1.0f, '4' };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 1);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1));
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-99158567) + "'", int29 == (-99158567));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 0, 447362037L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double double1 = org.apache.commons.math.util.FastMath.ulp(382.2585887730602d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.6843418860808015E-14d + "'", double1 == 5.6843418860808015E-14d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.3383347192042695E42d, 3.0711455624582693d, 0.0337631557961708d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-2147483595), (-32L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) (byte) 100);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.3978952727983707d, (java.lang.Number) bigInteger12, (int) (byte) 10);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger12);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) (short) 0);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (byte) 100);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) 0);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger25);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger25);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (int) (short) 100);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-11));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.0059176395764746d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.30231309747215485d + "'", double1 == 0.30231309747215485d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(32.046840717924134d, (double) 890242921, 3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 447362037L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2499638870072177d) + "'", double1 == (-0.2499638870072177d));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) (byte) 100);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (-308865033));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(206.00106396475758d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        double[] doubleArray6 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray9 = new double[] { 1.0f, '4' };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 100);
        double[] doubleArray19 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray22 = new double[] { 1.0f, '4' };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 100);
        java.lang.Class<?> wildcardClass26 = doubleArray25.getClass();
        double[] doubleArray27 = null;
        double[] doubleArray34 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray37 = new double[] { 1.0f, '4' };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray34);
        double[] doubleArray46 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray49 = new double[] { 1.0f, '4' };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) 1);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray52);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) (-1));
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray55);
        double[] doubleArray57 = null;
        double[] doubleArray64 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray67 = new double[] { 1.0f, '4' };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray64, doubleArray67);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray64);
        double[] doubleArray76 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray79 = new double[] { 1.0f, '4' };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray79);
        double[] doubleArray82 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray79, (double) 1);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray64, doubleArray82);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray64);
        try {
            double double85 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 990352347);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.406718524393924d + "'", double1 == 21.406718524393924d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-990352309L), (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-990352341L) + "'", long2 == (-990352341L));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-308865032), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        double double1 = org.apache.commons.math.util.FastMath.acos(382.2585887730602d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(66029.68354481233d, (double) 144555105949057024L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 66029.68354481235d + "'", double2 == 66029.68354481235d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray10 = new double[] { 1.0f, '4' };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray7);
        double[] doubleArray19 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray22 = new double[] { 1.0f, '4' };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 1);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 2147483647L);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.1073546531409235E9d + "'", double29 == 2.1073546531409235E9d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1963152000, 4.755250792540576E198d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.963152E9d + "'", double2 == 1.963152E9d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        long long2 = org.apache.commons.math.util.FastMath.min((-972799671L), 410401612L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-972799671L) + "'", long2 == (-972799671L));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-990352296), (long) (-308865033));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.9640202563306055d, 205.32051097873608d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9640202563306056d + "'", double2 == 0.9640202563306056d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) (byte) 100);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.3978952727983707d, (java.lang.Number) bigInteger12, (int) (byte) 10);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger12);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 350);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 350L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2.1474836502258067E9d, (-97012095), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.2737367544323206E-13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        float float1 = org.apache.commons.math.util.MathUtils.sign(Float.NaN);
        org.junit.Assert.assertEquals((float) float1, Float.NaN, 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-447362048));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.967139412938516d) + "'", double1 == (-0.967139412938516d));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double2 = org.apache.commons.math.util.MathUtils.log(12.566370614359172d, 1.5707955332499728d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.17841875700861967d + "'", double2 == 0.17841875700861967d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection11, false);
        boolean boolean14 = nonMonotonousSequenceException13.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException13.getDirection();
        java.lang.Number number17 = nonMonotonousSequenceException13.getArgument();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(orderDirection16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (short) -1 + "'", number17.equals((short) -1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1963151976L), 2.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7621956910836314d + "'", double1 == 3.7621956910836314d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double1 = org.apache.commons.math.util.FastMath.cos(3.61087557804198E28d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.993790507404988d) + "'", double1 == (-0.993790507404988d));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-447362037), (float) 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-4.47362048E8f) + "'", float2 == (-4.47362048E8f));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 3104, (int) '4', (int) (byte) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 1095062989);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.2499638870072177d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.968921355576235d + "'", double1 == 0.968921355576235d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 308865033L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 308865033L + "'", long2 == 308865033L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int int2 = org.apache.commons.math.util.FastMath.max(32, (-990352334));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 8.489768742652142d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.560297780119885d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1598517894570428d + "'", double1 == 1.1598517894570428d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double[] doubleArray6 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray9 = new double[] { 1.0f, '4' };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 100);
        java.lang.Class<?> wildcardClass13 = doubleArray12.getClass();
        double[] doubleArray14 = null;
        double[] doubleArray21 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray24 = new double[] { 1.0f, '4' };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray21);
        double[] doubleArray33 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray36 = new double[] { 1.0f, '4' };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 1);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) (-1));
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray42);
        double[] doubleArray44 = null;
        double[] doubleArray51 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray54 = new double[] { 1.0f, '4' };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray51);
        double[] doubleArray63 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray66 = new double[] { 1.0f, '4' };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 1);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray69);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray51);
        double[] doubleArray78 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray81 = new double[] { 1.0f, '4' };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray78, doubleArray81);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray78);
        int int84 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 410401601 + "'", int84 == 410401601);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 100, 1300);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 100, (int) (short) 0, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800L, (java.lang.Number) 0.0337631557961708d, 32, orderDirection6, false);
        java.lang.Class<?> wildcardClass11 = nonMonotonousSequenceException10.getClass();
        boolean boolean12 = nonMonotonousSequenceException10.getStrict();
        java.lang.Number number13 = nonMonotonousSequenceException10.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0337631557961708d + "'", number13.equals(0.0337631557961708d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double[] doubleArray6 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray9 = new double[] { 1.0f, '4' };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 100);
        java.lang.Class<?> wildcardClass13 = doubleArray12.getClass();
        double[] doubleArray20 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray23 = new double[] { 1.0f, '4' };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 100, (int) (short) 0, orderDirection35, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800L, (java.lang.Number) 0.0337631557961708d, 32, orderDirection35, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.7253825588523148d, (java.lang.Number) 1317.8029288008934d, 52, orderDirection35, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection35, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly decreasing (-1 <= 32)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 77.90322580645159d + "'", double25 == 77.90322580645159d);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 100, (int) (short) 0, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800L, (java.lang.Number) 0.0337631557961708d, 32, orderDirection6, false);
        java.lang.Class<?> wildcardClass11 = nonMonotonousSequenceException10.getClass();
        boolean boolean12 = nonMonotonousSequenceException10.getStrict();
        java.lang.String str13 = nonMonotonousSequenceException10.toString();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not decreasing (0.034 < 3,628,800)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not decreasing (0.034 < 3,628,800)"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(4.605170185988092d, (-5.0965176232603844E-297d), 0.3182350451634822d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1963152018));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1963152000) + "'", int1 == (-1963152000));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9.619275968248924E151d, (java.lang.Number) 1.0f, 100);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number9 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 10.0d, 350, orderDirection14, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8813735870195429d, number9, 2, orderDirection14, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.5510823758534835d, (java.lang.Number) (-0.9773570236070704d), (-1095062989), orderDirection14, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 3104);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3104.0d + "'", double1 == 3104.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 990352444);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963257851552d + "'", double1 == 1.5707963257851552d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 2147483647);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (short) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger11);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.3978952727983707d, (java.lang.Number) bigInteger20, (int) (byte) 10);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger20);
        try {
            java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (-308865033L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-990352344), (-3982003339556715682L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.1598517894570428d, (-990352334));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.264182058529981E-294d + "'", double2 == 7.264182058529981E-294d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1963151976L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9912895364027091d + "'", double1 == 0.9912895364027091d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 998050894);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        double double1 = org.apache.commons.math.util.FastMath.log1p(5.545454545454547d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8787708462176849d + "'", double1 == 1.8787708462176849d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        int int2 = org.apache.commons.math.util.FastMath.max(100, 990352444);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 990352444 + "'", int2 == 990352444);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        double double1 = org.apache.commons.math.util.FastMath.log(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.874591382923689d + "'", double1 == 0.874591382923689d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        int int2 = org.apache.commons.math.util.FastMath.max((-990352344), 1300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1300 + "'", int2 == 1300);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0337631557961708d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9994300787985999d + "'", double1 == 0.9994300787985999d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.004425697988050785d, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9912895364027091d, (double) 1963152053L, 205.32051097873608d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1963152018), (-990352344));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        double double1 = org.apache.commons.math.util.FastMath.tan(24669.773504249126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.256273465253723d) + "'", double1 == (-2.256273465253723d));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        long long2 = org.apache.commons.math.util.FastMath.max((-3982003339556715682L), 990352444L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 990352444L + "'", long2 == 990352444L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.84754626E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570796326443717d + "'", double1 == 1.570796326443717d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        long long2 = org.apache.commons.math.util.FastMath.max(308865033L, 1944212088633840000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1944212088633840000L + "'", long2 == 1944212088633840000L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 100, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48 + "'", int2 == 48);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-447362047), (-990352296));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1437714343) + "'", int2 == (-1437714343));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 144555105949057024L, 48, (-990352295));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-680860671), (-1963152028));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-308865032), 990352444);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (byte) 100, 1, ' ', (byte) 10, (byte) 100 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray14 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray14);
        int[] intArray17 = new int[] {};
        int[] intArray23 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray23);
        int[] intArray25 = new int[] {};
        int[] intArray31 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray31);
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray23);
        int[] intArray38 = new int[] { 990352347, (-308865032), 890242921 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray38);
        int[] intArray40 = new int[] {};
        int[] intArray46 = new int[] { (byte) 100, 1, ' ', (byte) 10, (byte) 100 };
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray46);
        int[] intArray48 = new int[] {};
        int[] intArray54 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray54);
        int[] intArray57 = new int[] {};
        int[] intArray63 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray57, intArray63);
        int[] intArray65 = new int[] {};
        int[] intArray71 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray65, intArray71);
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray63, intArray71);
        int int74 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray63);
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray63);
        int[] intArray76 = null;
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray76);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double[] doubleArray6 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray9 = new double[] { 1.0f, '4' };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 1);
        double[] doubleArray13 = null;
        double[] doubleArray20 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray23 = new double[] { 1.0f, '4' };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray20);
        double[] doubleArray32 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray35 = new double[] { 1.0f, '4' };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 100);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray32);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray32);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        double[] doubleArray48 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray51 = new double[] { 1.0f, '4' };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray51);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) 100);
        java.lang.Class<?> wildcardClass55 = doubleArray54.getClass();
        double[] doubleArray62 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray65 = new double[] { 1.0f, '4' };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray62);
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray54);
        double[] doubleArray69 = null;
        double[] doubleArray76 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray79 = new double[] { 1.0f, '4' };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray79);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray69, doubleArray76);
        double[] doubleArray88 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray91 = new double[] { 1.0f, '4' };
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray88, doubleArray91);
        double[] doubleArray94 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray91, (double) 1);
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equals(doubleArray76, doubleArray94);
        double[] doubleArray97 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray94, (double) 2147483647L);
        double double98 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray97);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray97);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 77.90322580645159d + "'", double67 == 77.90322580645159d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 4.206938527084601d + "'", double68 == 4.206938527084601d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(doubleArray97);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 2.10735465215961E9d + "'", double98 == 2.10735465215961E9d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double double1 = org.apache.commons.math.util.FastMath.tan(42436.438354612146d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1977280891147248d) + "'", double1 == (-0.1977280891147248d));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 10, (-1095062989));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9867717342662448d + "'", double1 == 1.9867717342662448d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-2147483648));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-1.5707963262855118d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.02741556777191333d) + "'", double1 == (-0.02741556777191333d));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        double[] doubleArray6 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray9 = new double[] { 1.0f, '4' };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 1);
        double[] doubleArray13 = null;
        double[] doubleArray20 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray23 = new double[] { 1.0f, '4' };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray20);
        double[] doubleArray32 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray35 = new double[] { 1.0f, '4' };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 100);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray32);
        double[] doubleArray46 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray49 = new double[] { 1.0f, '4' };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 100);
        java.lang.Class<?> wildcardClass53 = doubleArray52.getClass();
        double[] doubleArray54 = null;
        double[] doubleArray61 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray64 = new double[] { 1.0f, '4' };
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray61);
        double[] doubleArray73 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray76 = new double[] { 1.0f, '4' };
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray73, doubleArray76);
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, (double) 100);
        double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray61, doubleArray73);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray61);
        double double82 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray61);
        double[] doubleArray84 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 4.9E-324d);
        double double85 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray32);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 53.0d + "'", double85 == 53.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000018d + "'", double1 == 1.0000000000000018d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) -1, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        double double2 = org.apache.commons.math.util.FastMath.min(4.47362037E8d, 4.13748174430796E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.47362037E8d + "'", double2 == 4.47362037E8d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(7807940.494078696d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.47362037E8d + "'", double1 == 4.47362037E8d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1963152000), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-813437983372044287L), 0.004425697988050785d, 0.2023177513951919d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.605170185988091d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 95397608301226056L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 39.78997708339285d + "'", double1 == 39.78997708339285d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 95397607310873712L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.5397606E16f + "'", float1 == 9.5397606E16f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.Throwable throwable7 = null;
        try {
            nonMonotonousSequenceException5.addSuppressed(throwable7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) -1 + "'", number6.equals((short) -1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.206938527084601d, 0.968921355576235d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        int int8 = nonMonotonousSequenceException5.getIndex();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1944212088633840000L, (-1.5707963262855118d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963262855118d) + "'", double2 == (-1.5707963262855118d));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 998050894, 2.354878881270658d, (double) 410401612L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(71.2258064516129d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.2849397069683626E30d + "'", double1 == 4.2849397069683626E30d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1944212088633840000L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1 + "'", number7.equals(1));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) -1 + "'", number8.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) -1 + "'", number9.equals((short) -1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-308865032L), 97.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 96.81737345457077d + "'", double2 == 96.81737345457077d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 100, 2226184571297855489L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.9990489424874822d, (double) 48);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 44.98134609274459d + "'", double2 == 44.98134609274459d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.5707963267948966d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 2060654451);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.927707212223637d) + "'", double1 == (-0.927707212223637d));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1L, (float) (-990352344));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.9035232E8f) + "'", float2 == (-9.9035232E8f));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        int int1 = org.apache.commons.math.util.FastMath.abs((-990352334));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 990352334 + "'", int1 == 990352334);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 100, (int) (short) 0, orderDirection18, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800L, (java.lang.Number) 0.0337631557961708d, 32, orderDirection18, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.7253825588523148d, (java.lang.Number) 1317.8029288008934d, 52, orderDirection18, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection28, false);
        boolean boolean31 = nonMonotonousSequenceException30.getStrict();
        boolean boolean32 = nonMonotonousSequenceException30.getStrict();
        java.lang.String str33 = nonMonotonousSequenceException30.toString();
        nonMonotonousSequenceException24.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        java.lang.Number number36 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)" + "'", str33.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)"));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + (short) -1 + "'", number36.equals((short) -1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        double double1 = org.apache.commons.math.util.MathUtils.sign(103.37690554169075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.5421811783782413d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6072397615281054d + "'", double1 == 0.6072397615281054d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.4497974559678966d, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.9910707072527372d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9910707072527372d + "'", double1 == 0.9910707072527372d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-2147483648));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        double[] doubleArray6 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray9 = new double[] { 1.0f, '4' };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 1);
        double[] doubleArray13 = null;
        double[] doubleArray20 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray23 = new double[] { 1.0f, '4' };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray20);
        double[] doubleArray32 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray35 = new double[] { 1.0f, '4' };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 100);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray32);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray32);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection41, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 81.55795945611504d + "'", double1 == 81.55795945611504d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 2060654451, (long) 410401600);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2471056051L + "'", long2 == 2471056051L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(35, (-447362048));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number11 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number12 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1 + "'", number11.equals(1));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) -1 + "'", number12.equals((short) -1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-447362037), (float) (-1963152028));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.963152E9f) + "'", float2 == (-1.963152E9f));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 11L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.3166247903554d + "'", double1 == 3.3166247903554d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.560297780119885d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.485156022340614d + "'", double1 == 2.485156022340614d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-308865032L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray10 = new double[] { 1.0f, '4' };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray7);
        double[] doubleArray19 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray22 = new double[] { 1.0f, '4' };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 1);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 2147483647L);
        double[] doubleArray35 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray38 = new double[] { 1.0f, '4' };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray38);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 100);
        java.lang.Class<?> wildcardClass42 = doubleArray41.getClass();
        double[] doubleArray43 = null;
        double[] doubleArray50 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray53 = new double[] { 1.0f, '4' };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray50);
        double[] doubleArray62 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray65 = new double[] { 1.0f, '4' };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray65);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) 1);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray68);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) (-1));
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray41);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= -3.226)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 2.1474836502258067E9d + "'", double73 == 2.1474836502258067E9d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.2737367544323206E-13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-12.64325981788721d) + "'", double1 == (-12.64325981788721d));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 1318L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1318L + "'", long2 == 1318L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.58351893845611d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1171879159) + "'", int1 == (-1171879159));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 11L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 11.0f + "'", float1 == 11.0f);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.3625517538551688d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.023781014333596036d + "'", double1 == 0.023781014333596036d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.5596601626286404d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-990352296), (-102083903636L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-103074255932L) + "'", long2 == (-103074255932L));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) 1, (-1963152076L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1963152077L + "'", long2 == 1963152077L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        double double2 = org.apache.commons.math.util.FastMath.pow(10.000000000000002d, (-3.088650330265132E8d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 104, (double) 2373553640L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3735536403289437E9d + "'", double2 == 2.3735536403289437E9d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-680860671));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2226184571297855489L, (float) 104);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 104.0f + "'", float2 == 104.0f);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.02741556777191333d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        double double1 = org.apache.commons.math.util.FastMath.floor(77.90322580645159d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 77.0d + "'", double1 == 77.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1024.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1083179008 + "'", int1 == 1083179008);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        int int2 = org.apache.commons.math.util.FastMath.max(2060654451, (-680860671));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2060654451 + "'", int2 == 2060654451);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.9126520600660508d, 5729.5779513082325d, 0.9990489424874822d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1963152000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1437714343), (long) (-990352296));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1400753935L), 44736203700L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-46136957635L) + "'", long2 == (-46136957635L));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        java.lang.Class<?> wildcardClass10 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNull(orderDirection9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-990352296), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-990352296) + "'", int2 == (-990352296));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        double double2 = org.apache.commons.math.util.FastMath.max(95.24777960769379d, (double) (-97012095));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 95.24777960769379d + "'", double2 == 95.24777960769379d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 10, (double) 1963152018);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-447362047), (-8668169252041819643L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-447362048));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        int int2 = org.apache.commons.math.util.MathUtils.pow(350, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.6843418860808015E-14d, 66029.68354481233d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray14 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray14);
        int[] intArray17 = new int[] {};
        int[] intArray23 = new int[] { (byte) 100, 1, ' ', (byte) 10, (byte) 100 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray23);
        int[] intArray25 = new int[] {};
        int[] intArray31 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray31);
        int[] intArray34 = new int[] {};
        int[] intArray40 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray40);
        int[] intArray42 = new int[] {};
        int[] intArray48 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray48);
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray48);
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray40);
        int[] intArray52 = new int[] {};
        int[] intArray58 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray58);
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray52);
        try {
            int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1963152053L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 990352444);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 308865032, 990352334);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.3182350451634822d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3238671606481592d + "'", double1 == 0.3238671606481592d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray10 = new double[] { 1.0f, '4' };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray7);
        double[] doubleArray19 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray22 = new double[] { 1.0f, '4' };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 1);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 410401601 + "'", int27 == 410401601);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1171879159));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        int int2 = org.apache.commons.math.util.FastMath.max((-447362037), 1963152000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1963152000 + "'", int2 == 1963152000);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        int int1 = org.apache.commons.math.util.MathUtils.sign(308865032);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-447362037), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 2060654347L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4754188971735789d) + "'", double1 == (-0.4754188971735789d));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 48, 980797963336773136L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16L + "'", long2 == 16L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1318L, (long) (-308865032));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-97012095));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.26379700556016206d + "'", double1 == 0.26379700556016206d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.5700376015990605d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0226008841185656d + "'", double1 == 1.0226008841185656d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        double double1 = org.apache.commons.math.util.FastMath.exp(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        double double1 = org.apache.commons.math.util.FastMath.log(3.58351893845611d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2763452613426045d + "'", double1 == 1.2763452613426045d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.718281828459045d, (-0.6167738642765214d), 0.2639223226749517d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        double double2 = org.apache.commons.math.util.FastMath.atan2(5.0354544351403985E151d, 1.3156541846684752E35d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        double double1 = org.apache.commons.math.util.FastMath.asinh(382.2585887730602d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.639246205010033d + "'", double1 == 6.639246205010033d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray10 = new double[] { 1.0f, '4' };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 100);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray13);
        double[] doubleArray15 = null;
        try {
            double double16 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm(6L, 5193120973630518667L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 10.0d, 350, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0d + "'", number6.equals(10.0d));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(350L, 990352444L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 173311677700L + "'", long2 == 173311677700L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.2639223226749517d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.004606313500188796d + "'", double1 == 0.004606313500188796d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(4452369142595710978L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        int int10 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException5.getSuppressed();
        int int12 = nonMonotonousSequenceException5.getIndex();
        boolean boolean13 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) -1 + "'", number9.equals((short) -1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 980797963336773136L, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(3982003337593563654L, (-102083903636L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3982003439677467290L + "'", long2 == 3982003439677467290L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0337631557961708d, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.520557358624868E14d + "'", double2 == 1.520557358624868E14d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 2147483647, (long) (-990352296));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        double double2 = org.apache.commons.math.util.MathUtils.log(11013.232920103324d, 1.8207286053333909d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.06438661544033046d + "'", double2 == 0.06438661544033046d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3.1780538303479458d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray14 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray14);
        int[] intArray17 = new int[] {};
        int[] intArray23 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray23);
        int[] intArray25 = new int[] {};
        int[] intArray31 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray31);
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray23);
        int[] intArray35 = new int[] {};
        int[] intArray36 = new int[] {};
        int[] intArray42 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray36, intArray42);
        int[] intArray44 = new int[] {};
        int[] intArray50 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray50);
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray35, intArray42);
        try {
            int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1437714343), 2.67991427693416E9d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.10735465215961E9d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-959098394) + "'", int1 == (-959098394));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(67.15064491944298d, (-2.4321899572024774d), 205.3205109787361d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) -1, 990353647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(980797963336773136L, 173311677700L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 990352444L + "'", long2 == 990352444L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1437714343));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-813437983372044287L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-959098394), 8108519702544185345L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8108519702544185345L + "'", long2 == 8108519702544185345L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        int int2 = org.apache.commons.math.util.MathUtils.pow(410401600, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray7 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray15 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray15);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int[] intArray26 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray26);
        int[] intArray28 = new int[] {};
        int[] intArray34 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray34);
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray26);
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray19);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int[] intArray46 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray46);
        int[] intArray48 = new int[] {};
        int[] intArray54 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray54);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray46);
        int[] intArray58 = new int[] {};
        int[] intArray59 = new int[] {};
        int[] intArray65 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray65);
        int[] intArray67 = new int[] {};
        int[] intArray73 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray67, intArray73);
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray73);
        int int76 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray65);
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray58);
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray39);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) (byte) 100);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (-959098394));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-972799671L), (float) 2060654347L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.06065434E9f + "'", float2 == 2.06065434E9f);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) '4', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 97);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0523779637351338d + "'", double1 == 1.0523779637351338d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 1, (-308865033));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 2.06065434E9f, (-0.6321205588285577d), 416);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.017453292519943295d, (-307.6526555685888d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.017453292519943292d + "'", double2 == 0.017453292519943292d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 2060654451, (-308865033L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 212154701669903961L + "'", long2 == 212154701669903961L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        int int2 = org.apache.commons.math.util.FastMath.max(410401601, (-990352334));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 410401601 + "'", int2 == 410401601);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double double2 = org.apache.commons.math.util.FastMath.max(1317.8029288008934d, 2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1317.8029288008934d + "'", double2 == 1317.8029288008934d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 32);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        double double1 = org.apache.commons.math.util.FastMath.expm1(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.140692632779267d + "'", double1 == 22.140692632779267d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.3127600831788684d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1457574277214477d + "'", double1 == 1.1457574277214477d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-959098394), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 10L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        float float2 = org.apache.commons.math.util.FastMath.max(Float.NaN, (float) (-3982003339556715682L));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 2226184571297855489L, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.22618463E18f + "'", float2 == 2.22618463E18f);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.11827639714183447d) + "'", double1 == (-0.11827639714183447d));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(100, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 10.0f, (-959098394));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.997919072202235E147d + "'", double2 == 1.997919072202235E147d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.04323229440977d) + "'", double1 == (-1.04323229440977d));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.060654451E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 45394.43193828953d + "'", double1 == 45394.43193828953d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1437714343));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.437714343E9d + "'", double1 == 1.437714343E9d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1963152018), 2471056051L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1963152000, 1083179008);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.874591382923689d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6413104360234688d + "'", double1 == 0.6413104360234688d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-447362048), 11L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.8408206933405562d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8408206933405561d) + "'", double1 == (-0.8408206933405561d));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double double1 = org.apache.commons.math.util.FastMath.atanh(71.2258064516129d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 2471056051L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.312806409127892E7d + "'", double1 == 4.312806409127892E7d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.7621956910836314d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5552986459319043d + "'", double1 == 1.5552986459319043d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        double[] doubleArray1 = new double[] { 1963152018L };
        double double2 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray9 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray12 = new double[] { 1.0f, '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 100);
        java.lang.Class<?> wildcardClass16 = doubleArray15.getClass();
        double[] doubleArray17 = null;
        double[] doubleArray24 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray27 = new double[] { 1.0f, '4' };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray24);
        double[] doubleArray36 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray39 = new double[] { 1.0f, '4' };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 100);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray36);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray24);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray24);
        double[] doubleArray47 = new double[] { 1963152018L };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double[] doubleArray55 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray58 = new double[] { 1.0f, '4' };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray55, doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) 100);
        java.lang.Class<?> wildcardClass62 = doubleArray61.getClass();
        double[] doubleArray63 = null;
        double[] doubleArray70 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray73 = new double[] { 1.0f, '4' };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray70, doubleArray73);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray70);
        double[] doubleArray82 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray85 = new double[] { 1.0f, '4' };
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray82, doubleArray85);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray82, (double) 100);
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray70, doubleArray82);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray70);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray70);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.963152018E9d + "'", double2 == 1.963152018E9d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.963152018E9d + "'", double48 == 1.963152018E9d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 1.963152018E9d + "'", double92 == 1.963152018E9d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-990352296), 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-990352286) + "'", int2 == (-990352286));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-447362037), (double) (-103074255932L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.5596601626286404d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        long long1 = org.apache.commons.math.util.MathUtils.sign(2147483647L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-308865032));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-675.9629836295279d) + "'", double1 == (-675.9629836295279d));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        double double2 = org.apache.commons.math.util.FastMath.min(0.06438661544033046d, 3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.06438661544033046d + "'", double2 == 0.06438661544033046d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(35, 1963152018);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 3982003337593563654L, (double) 10.0f, (-225.95084645419513d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1963152077L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.96315213E9f + "'", float1 == 1.96315213E9f);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.7642275036163778d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3796077390275217d + "'", double1 == 0.3796077390275217d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        double double1 = org.apache.commons.math.util.FastMath.acos(6.902996731886964E14d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(35L, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-97012095));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-46136957635L), (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(5558.0d, 10.91392883061106d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.947373760425762d + "'", double2 == 9.947373760425762d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        double double1 = org.apache.commons.math.util.FastMath.expm1(3.78560328552961E-42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.78560328552961E-42d + "'", double1 == 3.78560328552961E-42d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 881330726850118847L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-990352344));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.9035232E8f + "'", float1 == 9.9035232E8f);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(7.432911501989891d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-11));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.884825774580939d) + "'", double1 == (-0.884825774580939d));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) ' ', 1963152018);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection11, false);
        boolean boolean14 = nonMonotonousSequenceException13.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        boolean boolean16 = nonMonotonousSequenceException13.getStrict();
        java.lang.Number number17 = nonMonotonousSequenceException13.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1 + "'", number17.equals(1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        double[] doubleArray6 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray9 = new double[] { 1.0f, '4' };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 100);
        java.lang.Class<?> wildcardClass13 = doubleArray12.getClass();
        double[] doubleArray14 = null;
        double[] doubleArray21 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray24 = new double[] { 1.0f, '4' };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray21);
        double[] doubleArray33 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray36 = new double[] { 1.0f, '4' };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 1);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) (-1));
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray42);
        double[] doubleArray44 = null;
        double[] doubleArray51 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray54 = new double[] { 1.0f, '4' };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray51);
        double[] doubleArray63 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray66 = new double[] { 1.0f, '4' };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 1);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray69);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray51);
        double[] doubleArray72 = null;
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray72);
        double[] doubleArray74 = null;
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 212154701669903961L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.326652660833574d + "'", double1 == 17.326652660833574d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(67.15064491944298d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.279885507183992E28d + "'", double1 == 7.279885507183992E28d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        double[] doubleArray2 = new double[] { 1.1059639246047328d, 1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray4 = null;
        double[] doubleArray11 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray14 = new double[] { 1.0f, '4' };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray11);
        double[] doubleArray23 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray26 = new double[] { 1.0f, '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray29);
        double[] doubleArray37 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray40 = new double[] { 1.0f, '4' };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray40);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) 100);
        java.lang.Class<?> wildcardClass44 = doubleArray43.getClass();
        double[] doubleArray51 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray54 = new double[] { 1.0f, '4' };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray51);
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray51);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-308865032) + "'", int3 == (-308865032));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 77.90322580645159d + "'", double56 == 77.90322580645159d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 2.0d + "'", double58 == 2.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) (byte) 100);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.3978952727983707d, (java.lang.Number) bigInteger12, (int) (byte) 10);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger12);
        try {
            java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (-447362047));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(5729.5779513082325d, 1.6143166348566882d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.6870488395497887d) + "'", double2 == (-0.6870488395497887d));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 410401601L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 100, (int) (short) 0, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800L, (java.lang.Number) 0.0337631557961708d, 32, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.7253825588523148d, (java.lang.Number) 1317.8029288008934d, 52, orderDirection9, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1, 0, orderDirection19, false);
        boolean boolean22 = nonMonotonousSequenceException21.getStrict();
        boolean boolean23 = nonMonotonousSequenceException21.getStrict();
        java.lang.String str24 = nonMonotonousSequenceException21.toString();
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        java.lang.Number number26 = nonMonotonousSequenceException21.getPrevious();
        java.lang.Number number27 = nonMonotonousSequenceException21.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < -1)"));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1 + "'", number26.equals(1));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (short) -1 + "'", number27.equals((short) -1));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1095062989), 1300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1612602065 + "'", int2 == 1612602065);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(92.13617560368711d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5279.014002567491d + "'", double1 == 5279.014002567491d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.5700376015990605d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-959098394));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-986.1759063895867d) + "'", double1 == (-986.1759063895867d));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-46136957635L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8713854021053514d + "'", double1 == 0.8713854021053514d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.0000000000000018d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000018d + "'", double1 == 1.0000000000000018d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 44736203700L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray2 = new int[] {};
        int[] intArray8 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray16 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray16);
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray8);
        int[] intArray20 = new int[] {};
        int[] intArray21 = new int[] {};
        int[] intArray27 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray27);
        int[] intArray29 = new int[] {};
        int[] intArray35 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray35);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray35);
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray27);
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray20);
        int[] intArray40 = new int[] {};
        int[] intArray41 = new int[] {};
        int[] intArray47 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray47);
        int[] intArray49 = new int[] {};
        int[] intArray55 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray49, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray55);
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray47);
        int[] intArray59 = new int[] {};
        int[] intArray60 = new int[] {};
        int[] intArray66 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray60, intArray66);
        int[] intArray68 = new int[] {};
        int[] intArray74 = new int[] { (byte) 1, 'a', ' ', (byte) 100, (byte) 100 };
        int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray68, intArray74);
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray74);
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray66);
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray59);
        int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray40);
        try {
            double double80 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(6.639246205010033d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        double double1 = org.apache.commons.math.util.FastMath.expm1(40.733995701988135d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9039898117321024E17d + "'", double1 == 4.9039898117321024E17d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-308865033), 350);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79718321 + "'", int2 == 79718321);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        double[] doubleArray6 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray9 = new double[] { 1.0f, '4' };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 100);
        java.lang.Class<?> wildcardClass13 = doubleArray12.getClass();
        double[] doubleArray14 = null;
        double[] doubleArray21 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray24 = new double[] { 1.0f, '4' };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray21);
        double[] doubleArray33 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray36 = new double[] { 1.0f, '4' };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 1);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) (-1));
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray42);
        double[] doubleArray44 = null;
        double[] doubleArray51 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray54 = new double[] { 1.0f, '4' };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray51);
        double[] doubleArray63 = new double[] { 0, (byte) -1, ' ', (byte) 1, 0.0d, (short) -1 };
        double[] doubleArray66 = new double[] { 1.0f, '4' };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 1);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray69);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray51);
        double[] doubleArray72 = null;
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 990353647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 990353647 + "'", int2 == 990353647);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(205.32051097873608d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.388137066130193E88d + "'", double1 == 7.388137066130193E88d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.61087557804198E28d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-661382120) + "'", int1 == (-661382120));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.6931471805599453d, 0.874591382923689d, 29937.070865949758d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.9910707072527372d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.1059639246047328d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9543527521610631d + "'", double1 == 0.9543527521610631d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.927707212223637d), (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        int int1 = org.apache.commons.math.util.MathUtils.hash(34.16814692820414d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1762930137) + "'", int1 == (-1762930137));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}

