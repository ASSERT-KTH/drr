import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException6 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable1, objArray5);
        org.apache.commons.math.exception.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 100L, (short) 0, (short) 100, 10.0f };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException6, localizable7, objArray12);
        org.apache.commons.math.optimization.OptimizationException optimizationException14 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException13);
        double[] doubleArray21 = new double[] { (byte) 0, 100, ' ', 0, 'a', 100.0d };
        java.lang.Object[] objArray27 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException28 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray27);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException29 = new org.apache.commons.math.linear.MatrixIndexException("", objArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException14, doubleArray21, "hi!", objArray27);
        java.lang.Object[] objArray36 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException37 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray36);
        org.apache.commons.math.exception.Localizable localizable38 = null;
        org.apache.commons.math.exception.Localizable localizable41 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable41, objArray45);
        java.util.ConcurrentModificationException concurrentModificationException47 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray45);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException37, localizable38, objArray45);
        java.io.IOException iOException49 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException37);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException50 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException49);
        double[] doubleArray52 = new double[] { 100.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) iOException49, doubleArray52);
        java.lang.Object[] objArray58 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException59 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray58);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException60 = new org.apache.commons.math.linear.MatrixIndexException("", objArray58);
        double[] doubleArray67 = new double[] { (short) 0, (short) -1, (byte) 1, 52, 0L, (-1L) };
        java.lang.Object[] objArray74 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException75 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray74);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException76 = new org.apache.commons.math.linear.MatrixIndexException("", objArray74);
        org.apache.commons.math.optimization.OptimizationException optimizationException77 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray74);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException78 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException60, doubleArray67, "hi!", objArray74);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair80 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray52, doubleArray67, false);
        double[] doubleArray81 = vectorialPointValuePair80.getPoint();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException82 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException30, doubleArray81);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(eOFException37);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(concurrentModificationException47);
        org.junit.Assert.assertNotNull(iOException49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(doubleArray81);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray7 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray11 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray15 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray19 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        int int23 = blockRealMatrix22.getRowDimension();
        double[] doubleArray28 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray32 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray36 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray40 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray44 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray45 = new double[][] { doubleArray28, doubleArray32, doubleArray36, doubleArray40, doubleArray44 };
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray46);
        blockRealMatrix22.setRowMatrix(0, blockRealMatrix47);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix22.scalarAdd(0.0d);
        double[] doubleArray54 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray58 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray62 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray66 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray70 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray71 = new double[][] { doubleArray54, doubleArray58, doubleArray62, doubleArray66, doubleArray70 };
        double[][] doubleArray72 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray71);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix73 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray72);
        double double74 = blockRealMatrix73.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix22.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix73);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor76 = null;
        try {
            double double81 = blockRealMatrix75.walkInRowOrder(realMatrixPreservingVisitor76, (int) (byte) 1, (int) '4', 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 223.61797781037194d + "'", double74 == 223.61797781037194d);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        java.lang.Object[] objArray5 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException6 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray5);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException7 = new org.apache.commons.math.linear.MatrixIndexException("", objArray5);
        org.apache.commons.math.exception.Localizable localizable8 = matrixIndexException7.getLocalizablePattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException13 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray12);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException14 = new org.apache.commons.math.linear.MatrixIndexException(localizable8, objArray12);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException20 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray19);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray19);
        org.apache.commons.math.exception.Localizable localizable22 = matrixIndexException21.getLocalizablePattern();
        java.lang.Object[] objArray29 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException30 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray29);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException31 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray29);
        java.io.EOFException eOFException32 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable22, objArray29);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException33 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, localizable8, objArray29);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(localizable22);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(eOFException30);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException31);
        org.junit.Assert.assertNotNull(eOFException32);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        int int2 = levenbergMarquardtOptimizer0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.apache.commons.math.linear.SingularMatrixException singularMatrixException1 = new org.apache.commons.math.linear.SingularMatrixException();
        java.lang.String str2 = singularMatrixException1.getPattern();
        org.apache.commons.math.exception.Localizable localizable8 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable8, objArray12);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException14 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "", objArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) singularMatrixException1, (double) (byte) -1, "hi!", objArray12);
        java.lang.Object[] objArray22 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException23 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray22);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException24 = new org.apache.commons.math.linear.MatrixIndexException("", objArray22);
        org.apache.commons.math.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.MathRuntimeException("", objArray22);
        java.lang.Object[] objArray26 = mathRuntimeException25.getArguments();
        java.lang.Object[] objArray27 = mathRuntimeException25.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) singularMatrixException1, "", objArray27);
        java.lang.IllegalStateException illegalStateException29 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.optimization.OptimizationException: hi!", objArray27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "matrix is singular" + "'", str2.equals("matrix is singular"));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(illegalStateException29);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        int int2 = levenbergMarquardtOptimizer0.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSingular();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[] doubleArray6 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray10 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray14 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray18 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray22 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray23 = new double[][] { doubleArray6, doubleArray10, doubleArray14, doubleArray18, doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray24);
        int int26 = blockRealMatrix25.getRowDimension();
        double[] doubleArray31 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray35 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray39 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray43 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray47 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray48 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43, doubleArray47 };
        double[][] doubleArray49 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray48);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray49);
        blockRealMatrix25.setRowMatrix(0, blockRealMatrix50);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix25.scalarAdd(0.0d);
        double double54 = blockRealMatrix25.getNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix55 = array2DRowRealMatrix0.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix25);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 100.0d + "'", double54 == 100.0d);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException9 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable13, objArray17);
        java.util.ConcurrentModificationException concurrentModificationException19 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException9, localizable10, objArray17);
        java.io.IOException iOException21 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException22 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1.0f), invalidMatrixException22, 1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "matrix is singular", objArray24);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable27, objArray31);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 100L, (short) 0, (short) 100, 10.0f };
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException32, localizable33, objArray38);
        org.apache.commons.math.optimization.OptimizationException optimizationException40 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException39);
        double[] doubleArray47 = new double[] { (byte) 0, 100, ' ', 0, 'a', 100.0d };
        java.lang.Object[] objArray53 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException54 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray53);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException55 = new org.apache.commons.math.linear.MatrixIndexException("", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException40, doubleArray47, "hi!", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException25, doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        int int59 = array2DRowRealMatrix58.getColumnDimension();
        double double60 = array2DRowRealMatrix58.getFrobeniusNorm();
        java.lang.Object[] objArray68 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException69 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray68);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "hi!", objArray68);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException71 = new org.apache.commons.math.FunctionEvaluationException(223.61797781037194d, "", objArray68);
        double[] doubleArray72 = functionEvaluationException71.getArgument();
        double[] doubleArray73 = array2DRowRealMatrix58.operate(doubleArray72);
        org.apache.commons.math.linear.RealMatrix realMatrix74 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix75 = array2DRowRealMatrix58.solve(realMatrix74);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 6x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(eOFException9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(concurrentModificationException19);
        org.junit.Assert.assertNotNull(iOException21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 174.4505660638566d + "'", double60 == 174.4505660638566d);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException7 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray6);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException8 = new org.apache.commons.math.linear.MatrixIndexException("", objArray6);
        org.apache.commons.math.exception.Localizable localizable9 = matrixIndexException8.getLocalizablePattern();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException14 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray13);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException15 = new org.apache.commons.math.linear.MatrixIndexException(localizable9, objArray13);
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable9, objArray16);
        double[] doubleArray21 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray25 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray29 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray33 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray37 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray38 = new double[][] { doubleArray21, doubleArray25, doubleArray29, doubleArray33, doubleArray37 };
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        org.apache.commons.math.optimization.OptimizationException optimizationException40 = new org.apache.commons.math.optimization.OptimizationException(localizable9, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException42 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("{0}", (java.lang.Object[]) doubleArray38);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException42);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSingular();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        java.lang.Class<?> wildcardClass4 = doubleArray3.getClass();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) 0.0f);
        int int3 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        levenbergMarquardtOptimizer0.setMaxIterations(100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray7 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray11 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray15 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray19 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        int int23 = blockRealMatrix22.getRowDimension();
        double[] doubleArray28 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray32 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray36 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray40 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray44 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray45 = new double[][] { doubleArray28, doubleArray32, doubleArray36, doubleArray40, doubleArray44 };
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray46);
        blockRealMatrix22.setRowMatrix(0, blockRealMatrix47);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix22.scalarAdd(0.0d);
        double[] doubleArray57 = new double[] { ' ', (-1L), ' ', 0.0f, (-1) };
        double[][] doubleArray58 = new double[][] { doubleArray57 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58);
        java.util.ConcurrentModificationException concurrentModificationException61 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.optimization.OptimizationException: hi!", (java.lang.Object[]) doubleArray58);
        try {
            blockRealMatrix50.setSubMatrix(doubleArray58, (int) (short) 1, 15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(concurrentModificationException61);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException9 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable13, objArray17);
        java.util.ConcurrentModificationException concurrentModificationException19 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException9, localizable10, objArray17);
        java.io.IOException iOException21 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException22 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1.0f), invalidMatrixException22, 1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "matrix is singular", objArray24);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable27, objArray31);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 100L, (short) 0, (short) 100, 10.0f };
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException32, localizable33, objArray38);
        org.apache.commons.math.optimization.OptimizationException optimizationException40 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException39);
        double[] doubleArray47 = new double[] { (byte) 0, 100, ' ', 0, 'a', 100.0d };
        java.lang.Object[] objArray53 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException54 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray53);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException55 = new org.apache.commons.math.linear.MatrixIndexException("", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException40, doubleArray47, "hi!", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException25, doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        java.lang.Object[] objArray63 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException64 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray63);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException65 = new org.apache.commons.math.linear.MatrixIndexException("", objArray63);
        double[] doubleArray72 = new double[] { (short) 0, (short) -1, (byte) 1, 52, 0L, (-1L) };
        java.lang.Object[] objArray79 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException80 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray79);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException81 = new org.apache.commons.math.linear.MatrixIndexException("", objArray79);
        org.apache.commons.math.optimization.OptimizationException optimizationException82 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray79);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException83 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException65, doubleArray72, "hi!", objArray79);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray72);
        org.apache.commons.math.linear.RealMatrix realMatrix85 = array2DRowRealMatrix58.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix84);
        double[][] doubleArray86 = array2DRowRealMatrix58.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix87 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray86);
        try {
            array2DRowRealMatrix87.multiplyEntry(15, 52, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (15, 52) in a 6x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(eOFException9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(concurrentModificationException19);
        org.junit.Assert.assertNotNull(iOException21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(realMatrix85);
        org.junit.Assert.assertNotNull(doubleArray86);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray7 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray11 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray15 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray19 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        boolean boolean24 = blockRealMatrix23.isSquare();
        double[] doubleArray28 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray32 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray36 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray40 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray44 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray45 = new double[][] { doubleArray28, doubleArray32, doubleArray36, doubleArray40, doubleArray44 };
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray46);
        double double48 = blockRealMatrix47.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix23.add(blockRealMatrix47);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix49.scalarAdd(10.0d);
        int int52 = blockRealMatrix51.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor53 = null;
        try {
            double double58 = blockRealMatrix51.walkInColumnOrder(realMatrixPreservingVisitor53, 10, 0, (int) '#', 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 223.61797781037194d + "'", double48 == 223.61797781037194d);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 15 + "'", int52 == 15);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) ' ');
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray7 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray11 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray15 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray19 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        boolean boolean24 = blockRealMatrix23.isSquare();
        double[] doubleArray28 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray32 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray36 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray40 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray44 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray45 = new double[][] { doubleArray28, doubleArray32, doubleArray36, doubleArray40, doubleArray44 };
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray46);
        double double48 = blockRealMatrix47.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix23.add(blockRealMatrix47);
        org.apache.commons.math.linear.RealMatrix realMatrix51 = blockRealMatrix49.scalarMultiply(100.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 223.61797781037194d + "'", double48 == 223.61797781037194d);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray7 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray11 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray15 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray19 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        org.apache.commons.math.linear.BigMatrix bigMatrix23 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray21);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21, false);
        double double28 = array2DRowRealMatrix25.getEntry(0, 0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(bigMatrix23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.0d + "'", double28 == 100.0d);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray7 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray11 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray15 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray19 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        boolean boolean24 = blockRealMatrix23.isSquare();
        double[] doubleArray28 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray32 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray36 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray40 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray44 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray45 = new double[][] { doubleArray28, doubleArray32, doubleArray36, doubleArray40, doubleArray44 };
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray46);
        double double48 = blockRealMatrix47.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix23.add(blockRealMatrix47);
        try {
            double[] doubleArray51 = blockRealMatrix49.getRow((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 223.61797781037194d + "'", double48 == 223.61797781037194d);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        double[] doubleArray5 = new double[] { ' ', (-1L), ' ', 0.0f, (-1) };
        double[][] doubleArray6 = new double[][] { doubleArray5 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.String str9 = array2DRowRealMatrix8.toString();
        double[] doubleArray11 = array2DRowRealMatrix8.getRow(0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Array2DRowRealMatrix{{32.0,-1.0,32.0,0.0,-1.0}}" + "'", str9.equals("Array2DRowRealMatrix{{32.0,-1.0,32.0,0.0,-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray7 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray11 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray15 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray19 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        int int23 = blockRealMatrix22.getRowDimension();
        double[] doubleArray28 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray32 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray36 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray40 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray44 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray45 = new double[][] { doubleArray28, doubleArray32, doubleArray36, doubleArray40, doubleArray44 };
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray46);
        blockRealMatrix22.setRowMatrix(0, blockRealMatrix47);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix22.scalarAdd(0.0d);
        double[] doubleArray54 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray58 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray62 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray66 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray70 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray71 = new double[][] { doubleArray54, doubleArray58, doubleArray62, doubleArray66, doubleArray70 };
        double[][] doubleArray72 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray71);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix73 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray72);
        double double74 = blockRealMatrix73.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix22.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix73);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor76 = null;
        try {
            double double81 = blockRealMatrix73.walkInColumnOrder(realMatrixPreservingVisitor76, (int) (byte) 10, (int) (short) -1, 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 223.61797781037194d + "'", double74 == 223.61797781037194d);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray7 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray11 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray15 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray19 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        int int23 = blockRealMatrix22.getRowDimension();
        double[] doubleArray28 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray32 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray36 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray40 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray44 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray45 = new double[][] { doubleArray28, doubleArray32, doubleArray36, doubleArray40, doubleArray44 };
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray46);
        blockRealMatrix22.setRowMatrix(0, blockRealMatrix47);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix22.scalarAdd(0.0d);
        double[] doubleArray54 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray58 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray62 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray66 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray70 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray71 = new double[][] { doubleArray54, doubleArray58, doubleArray62, doubleArray66, doubleArray70 };
        double[][] doubleArray72 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray71);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix73 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray72);
        double double74 = blockRealMatrix73.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix22.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix73);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix22.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix78 = blockRealMatrix76.scalarAdd(0.0d);
        double[][] doubleArray85 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) -1, (int) (byte) -1);
        try {
            blockRealMatrix78.copySubMatrix((int) (short) 1, 0, 100, (int) '#', doubleArray85);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 223.61797781037194d + "'", double74 == 223.61797781037194d);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertNotNull(blockRealMatrix78);
        org.junit.Assert.assertNotNull(doubleArray85);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray7 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray11 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray15 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray19 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = blockRealMatrix22.scalarMultiply((double) 97);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = blockRealMatrix22.scalarMultiply((double) 100L);
        try {
            org.apache.commons.math.linear.RealVector realVector28 = blockRealMatrix22.getColumnVector((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, 14]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable2, objArray6);
        java.lang.IllegalStateException illegalStateException8 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.MathRuntimeException$4: ", objArray6);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(illegalStateException8);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray7 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray11 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray15 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray19 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        double double25 = blockRealMatrix22.getEntry((int) (short) 0, 1);
        int int26 = blockRealMatrix22.getColumnDimension();
        double[] doubleArray30 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray34 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray38 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray42 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray46 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray47 = new double[][] { doubleArray30, doubleArray34, doubleArray38, doubleArray42, doubleArray46 };
        double[][] doubleArray48 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray47);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray48);
        int int50 = blockRealMatrix49.getRowDimension();
        double[] doubleArray55 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray59 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray63 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray67 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray71 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray72 = new double[][] { doubleArray55, doubleArray59, doubleArray63, doubleArray67, doubleArray71 };
        double[][] doubleArray73 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray72);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix74 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray73);
        blockRealMatrix49.setRowMatrix(0, blockRealMatrix74);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix74.transpose();
        double double77 = blockRealMatrix74.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix78 = blockRealMatrix22.add(blockRealMatrix74);
        org.apache.commons.math.linear.RealMatrix realMatrix80 = blockRealMatrix74.getColumnMatrix((int) (byte) 10);
        org.apache.commons.math.linear.RealMatrix realMatrix82 = blockRealMatrix74.scalarAdd(0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 100.0d + "'", double77 == 100.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix78);
        org.junit.Assert.assertNotNull(realMatrix80);
        org.junit.Assert.assertNotNull(realMatrix82);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSingular();
        boolean boolean2 = array2DRowRealMatrix0.isSquare();
        boolean boolean3 = array2DRowRealMatrix0.isSingular();
        int int4 = array2DRowRealMatrix0.getRowDimension();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSingular();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        int int3 = array2DRowRealMatrix0.getRowDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor4, (int) '#', 2147483647, 52, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 35 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        double[] doubleArray5 = new double[] { ' ', (-1L), ' ', 0.0f, (-1) };
        double[][] doubleArray6 = new double[][] { doubleArray5 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        java.lang.Object[] objArray13 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException14 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray13);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException15 = new org.apache.commons.math.linear.MatrixIndexException("", objArray13);
        org.apache.commons.math.exception.Localizable localizable16 = matrixIndexException15.getLocalizablePattern();
        java.lang.Object[] objArray25 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException26 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray25);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        org.apache.commons.math.exception.Localizable localizable30 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable30, objArray34);
        java.util.ConcurrentModificationException concurrentModificationException36 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException26, localizable27, objArray34);
        java.io.IOException iOException38 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException26);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException39 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException38);
        java.lang.Object[] objArray41 = new java.lang.Object[] { (-1.0f), invalidMatrixException39, 1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "matrix is singular", objArray41);
        org.apache.commons.math.exception.Localizable localizable44 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable44, objArray48);
        org.apache.commons.math.exception.Localizable localizable50 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { 100L, (short) 0, (short) 100, 10.0f };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException49, localizable50, objArray55);
        org.apache.commons.math.optimization.OptimizationException optimizationException57 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException56);
        double[] doubleArray64 = new double[] { (byte) 0, 100, ' ', 0, 'a', 100.0d };
        java.lang.Object[] objArray70 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException71 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray70);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException72 = new org.apache.commons.math.linear.MatrixIndexException("", objArray70);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException73 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException57, doubleArray64, "hi!", objArray70);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException42, doubleArray64);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException75 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException15, doubleArray64);
        org.apache.commons.math.linear.RealVector realVector76 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray64);
        try {
            double[] doubleArray77 = array2DRowRealMatrix8.operate(doubleArray64);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(eOFException26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(concurrentModificationException36);
        org.junit.Assert.assertNotNull(iOException38);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(realVector76);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        java.lang.Object[] objArray4 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException5 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray4);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException6 = new org.apache.commons.math.linear.MatrixIndexException("", objArray4);
        org.apache.commons.math.exception.Localizable localizable7 = matrixIndexException6.getLocalizablePattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException12 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray11);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException13 = new org.apache.commons.math.linear.MatrixIndexException(localizable7, objArray11);
        java.lang.Object[] objArray18 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException19 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException20 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        org.apache.commons.math.exception.Localizable localizable21 = matrixIndexException20.getLocalizablePattern();
        java.lang.Object[] objArray25 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException26 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray25);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException27 = new org.apache.commons.math.linear.MatrixIndexException(localizable21, objArray25);
        java.lang.Object[] objArray33 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException34 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray33);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException35 = new org.apache.commons.math.linear.MatrixIndexException("", objArray33);
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException("", objArray33);
        java.lang.Object[] objArray37 = mathRuntimeException36.getArguments();
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable21, objArray37);
        java.lang.Object[] objArray43 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException44 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray43);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException45 = new org.apache.commons.math.linear.MatrixIndexException("", objArray43);
        org.apache.commons.math.exception.Localizable localizable46 = matrixIndexException45.getLocalizablePattern();
        java.lang.Object[] objArray50 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException51 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray50);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException(localizable46, objArray50);
        java.lang.Object[] objArray59 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException60 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray59);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException61 = new org.apache.commons.math.linear.MatrixIndexException("", objArray59);
        org.apache.commons.math.exception.Localizable localizable62 = matrixIndexException61.getLocalizablePattern();
        java.lang.Object[] objArray71 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException72 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray71);
        org.apache.commons.math.exception.Localizable localizable73 = null;
        org.apache.commons.math.exception.Localizable localizable76 = null;
        java.lang.Object[] objArray80 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException81 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable76, objArray80);
        java.util.ConcurrentModificationException concurrentModificationException82 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray80);
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException72, localizable73, objArray80);
        java.io.IOException iOException84 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException72);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException85 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException84);
        java.lang.Object[] objArray87 = new java.lang.Object[] { (-1.0f), invalidMatrixException85, 1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException88 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "matrix is singular", objArray87);
        java.text.ParseException parseException89 = org.apache.commons.math.MathRuntimeException.createParseException(36, localizable62, objArray87);
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException("matrix is singular", objArray87);
        org.apache.commons.math.optimization.OptimizationException optimizationException91 = new org.apache.commons.math.optimization.OptimizationException(localizable46, objArray87);
        java.lang.IllegalArgumentException illegalArgumentException92 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable21, objArray87);
        org.apache.commons.math.MathRuntimeException mathRuntimeException93 = new org.apache.commons.math.MathRuntimeException(localizable7, objArray87);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(localizable46);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(localizable62);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(eOFException72);
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(concurrentModificationException82);
        org.junit.Assert.assertNotNull(iOException84);
        org.junit.Assert.assertNotNull(objArray87);
        org.junit.Assert.assertNotNull(parseException89);
        org.junit.Assert.assertNotNull(illegalArgumentException92);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException9 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable13, objArray17);
        java.util.ConcurrentModificationException concurrentModificationException19 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException9, localizable10, objArray17);
        java.io.IOException iOException21 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException22 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1.0f), invalidMatrixException22, 1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "matrix is singular", objArray24);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable27, objArray31);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 100L, (short) 0, (short) 100, 10.0f };
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException32, localizable33, objArray38);
        org.apache.commons.math.optimization.OptimizationException optimizationException40 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException39);
        double[] doubleArray47 = new double[] { (byte) 0, 100, ' ', 0, 'a', 100.0d };
        java.lang.Object[] objArray53 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException54 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray53);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException55 = new org.apache.commons.math.linear.MatrixIndexException("", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException40, doubleArray47, "hi!", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException25, doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        java.lang.Object[] objArray63 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException64 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray63);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException65 = new org.apache.commons.math.linear.MatrixIndexException("", objArray63);
        double[] doubleArray72 = new double[] { (short) 0, (short) -1, (byte) 1, 52, 0L, (-1L) };
        java.lang.Object[] objArray79 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException80 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray79);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException81 = new org.apache.commons.math.linear.MatrixIndexException("", objArray79);
        org.apache.commons.math.optimization.OptimizationException optimizationException82 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray79);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException83 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException65, doubleArray72, "hi!", objArray79);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray72);
        org.apache.commons.math.linear.RealMatrix realMatrix85 = array2DRowRealMatrix58.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix84);
        double[][] doubleArray86 = array2DRowRealMatrix58.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix87 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray86);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(eOFException9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(concurrentModificationException19);
        org.junit.Assert.assertNotNull(iOException21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(realMatrix85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(realMatrix87);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray7 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray11 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray15 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray19 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        int int23 = blockRealMatrix22.getRowDimension();
        double[] doubleArray28 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray32 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray36 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray40 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray44 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray45 = new double[][] { doubleArray28, doubleArray32, doubleArray36, doubleArray40, doubleArray44 };
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray46);
        blockRealMatrix22.setRowMatrix(0, blockRealMatrix47);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix22.scalarAdd(0.0d);
        double[] doubleArray54 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray58 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray62 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray66 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray70 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray71 = new double[][] { doubleArray54, doubleArray58, doubleArray62, doubleArray66, doubleArray70 };
        double[][] doubleArray72 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray71);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix73 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray72);
        double double74 = blockRealMatrix73.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix22.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix73);
        java.lang.String str76 = blockRealMatrix22.toString();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 223.61797781037194d + "'", double74 == 223.61797781037194d);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "BlockRealMatrix{{100.0,0.0,-1.0,100.0,0.0,-1.0,100.0,0.0,-1.0,100.0,0.0,-1.0,100.0,0.0,-1.0}}" + "'", str76.equals("BlockRealMatrix{{100.0,0.0,-1.0,100.0,0.0,-1.0,100.0,0.0,-1.0,100.0,0.0,-1.0,100.0,0.0,-1.0}}"));
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        double[] doubleArray4 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray8 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray12 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray16 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray20 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray21 = new double[][] { doubleArray4, doubleArray8, doubleArray12, doubleArray16, doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException23 = new org.apache.commons.math.linear.MatrixIndexException("", (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realMatrix24);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 100, 97);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        java.lang.Object[] objArray4 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException5 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray4);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException6 = new org.apache.commons.math.linear.MatrixIndexException("", objArray4);
        double[] doubleArray13 = new double[] { (short) 0, (short) -1, (byte) 1, 52, 0L, (-1L) };
        java.lang.Object[] objArray20 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException21 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray20);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException22 = new org.apache.commons.math.linear.MatrixIndexException("", objArray20);
        org.apache.commons.math.optimization.OptimizationException optimizationException23 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException6, doubleArray13, "hi!", objArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray13);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray13);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable4, objArray8);
        java.lang.IllegalArgumentException illegalArgumentException10 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray8);
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException(throwable0, "hi!", objArray8);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(illegalArgumentException10);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray7 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray11 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray15 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray19 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        org.apache.commons.math.linear.BigMatrix bigMatrix23 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray21);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21, false);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = array2DRowRealMatrix25.copy();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(bigMatrix23);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable2, objArray6);
        org.apache.commons.math.exception.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 100L, (short) 0, (short) 100, 10.0f };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException7, localizable8, objArray13);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException15 = new org.apache.commons.math.linear.InvalidMatrixException("Array2DRowRealMatrix{{32.0,-1.0,32.0,0.0,-1.0}}", objArray13);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException(10.0d);
        org.apache.commons.math.exception.Localizable localizable2 = functionEvaluationException1.getLocalizablePattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.EVALUATION_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.LocalizedFormats.EVALUATION_FAILED));
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException6 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable1, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException6);
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        double[][] doubleArray2 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 1, (int) (byte) 100);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        java.lang.Object[] objArray4 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException5 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray4);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException6 = new org.apache.commons.math.linear.MatrixIndexException("", objArray4);
        org.apache.commons.math.exception.Localizable localizable7 = matrixIndexException6.getLocalizablePattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException12 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray11);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException13 = new org.apache.commons.math.linear.MatrixIndexException(localizable7, objArray11);
        java.lang.String str14 = matrixIndexException13.getPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException9 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable13, objArray17);
        java.util.ConcurrentModificationException concurrentModificationException19 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException9, localizable10, objArray17);
        java.io.IOException iOException21 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException22 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1.0f), invalidMatrixException22, 1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "matrix is singular", objArray24);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable27, objArray31);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 100L, (short) 0, (short) 100, 10.0f };
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException32, localizable33, objArray38);
        org.apache.commons.math.optimization.OptimizationException optimizationException40 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException39);
        double[] doubleArray47 = new double[] { (byte) 0, 100, ' ', 0, 'a', 100.0d };
        java.lang.Object[] objArray53 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException54 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray53);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException55 = new org.apache.commons.math.linear.MatrixIndexException("", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException40, doubleArray47, "hi!", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException25, doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        java.lang.Object[] objArray63 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException64 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray63);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException65 = new org.apache.commons.math.linear.MatrixIndexException("", objArray63);
        double[] doubleArray72 = new double[] { (short) 0, (short) -1, (byte) 1, 52, 0L, (-1L) };
        java.lang.Object[] objArray79 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException80 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray79);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException81 = new org.apache.commons.math.linear.MatrixIndexException("", objArray79);
        org.apache.commons.math.optimization.OptimizationException optimizationException82 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray79);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException83 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException65, doubleArray72, "hi!", objArray79);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray72);
        org.apache.commons.math.linear.RealMatrix realMatrix85 = array2DRowRealMatrix58.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix84);
        try {
            org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl87 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix58, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 6x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(eOFException9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(concurrentModificationException19);
        org.junit.Assert.assertNotNull(iOException21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(realMatrix85);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        java.lang.String[] strArray4 = new java.lang.String[] { "a {0}x{1} matrix was provided instead of a square matrix", "a {0}x{1} matrix was provided instead of a square matrix", "org.apache.commons.math.MathRuntimeException: ", "Array2DRowRealMatrix{{0.0},{100.0},{32.0},{0.0},{97.0},{100.0}}" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix5 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        org.apache.commons.math.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.checkRowIndex(anyMatrix0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSingular();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        int int3 = array2DRowRealMatrix0.getRowDimension();
        java.lang.Object[] objArray12 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException13 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray12);
        org.apache.commons.math.exception.Localizable localizable14 = null;
        org.apache.commons.math.exception.Localizable localizable17 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable17, objArray21);
        java.util.ConcurrentModificationException concurrentModificationException23 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException13, localizable14, objArray21);
        java.io.IOException iOException25 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException13);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException26 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException25);
        java.lang.Object[] objArray28 = new java.lang.Object[] { (-1.0f), invalidMatrixException26, 1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "matrix is singular", objArray28);
        org.apache.commons.math.exception.Localizable localizable31 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable31, objArray35);
        org.apache.commons.math.exception.Localizable localizable37 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { 100L, (short) 0, (short) 100, 10.0f };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException36, localizable37, objArray42);
        org.apache.commons.math.optimization.OptimizationException optimizationException44 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException43);
        double[] doubleArray51 = new double[] { (byte) 0, 100, ' ', 0, 'a', 100.0d };
        java.lang.Object[] objArray57 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException58 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray57);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException59 = new org.apache.commons.math.linear.MatrixIndexException("", objArray57);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException44, doubleArray51, "hi!", objArray57);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException61 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException29, doubleArray51);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51);
        int int63 = array2DRowRealMatrix62.getColumnDimension();
        double double64 = array2DRowRealMatrix62.getFrobeniusNorm();
        java.lang.Object[] objArray72 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException73 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray72);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "hi!", objArray72);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException75 = new org.apache.commons.math.FunctionEvaluationException(223.61797781037194d, "", objArray72);
        double[] doubleArray76 = functionEvaluationException75.getArgument();
        double[] doubleArray77 = array2DRowRealMatrix62.operate(doubleArray76);
        java.lang.String str78 = array2DRowRealMatrix62.toString();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = array2DRowRealMatrix0.add(array2DRowRealMatrix62);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(eOFException13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(concurrentModificationException23);
        org.junit.Assert.assertNotNull(iOException25);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 174.4505660638566d + "'", double64 == 174.4505660638566d);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "Array2DRowRealMatrix{{0.0},{100.0},{32.0},{0.0},{97.0},{100.0}}" + "'", str78.equals("Array2DRowRealMatrix{{0.0},{100.0},{32.0},{0.0},{97.0},{100.0}}"));
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray7 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray11 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray15 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray19 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        int int23 = blockRealMatrix22.getRowDimension();
        double[] doubleArray28 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray32 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray36 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray40 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray44 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray45 = new double[][] { doubleArray28, doubleArray32, doubleArray36, doubleArray40, doubleArray44 };
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray46);
        blockRealMatrix22.setRowMatrix(0, blockRealMatrix47);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix22.scalarAdd(0.0d);
        double[] doubleArray54 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray58 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray62 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray66 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray70 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray71 = new double[][] { doubleArray54, doubleArray58, doubleArray62, doubleArray66, doubleArray70 };
        double[][] doubleArray72 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray71);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix73 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray72);
        double double74 = blockRealMatrix73.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix22.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix73);
        org.apache.commons.math.linear.RealVector realVector77 = blockRealMatrix75.getRowVector(0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor78 = null;
        try {
            double double79 = blockRealMatrix75.walkInOptimizedOrder(realMatrixChangingVisitor78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 223.61797781037194d + "'", double74 == 223.61797781037194d);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
        org.junit.Assert.assertNotNull(realVector77);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        java.lang.Object[] objArray5 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException6 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray5);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException7 = new org.apache.commons.math.linear.MatrixIndexException("", objArray5);
        org.apache.commons.math.optimization.OptimizationException optimizationException8 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray5);
        java.lang.Object[] objArray15 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException16 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray15);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException17 = new org.apache.commons.math.linear.MatrixIndexException("", objArray15);
        org.apache.commons.math.exception.Localizable localizable18 = matrixIndexException17.getLocalizablePattern();
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException28 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray27);
        org.apache.commons.math.exception.Localizable localizable29 = null;
        org.apache.commons.math.exception.Localizable localizable32 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable32, objArray36);
        java.util.ConcurrentModificationException concurrentModificationException38 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException28, localizable29, objArray36);
        java.io.IOException iOException40 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException40);
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1.0f), invalidMatrixException41, 1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "matrix is singular", objArray43);
        java.text.ParseException parseException45 = org.apache.commons.math.MathRuntimeException.createParseException(36, localizable18, objArray43);
        java.lang.Object[] objArray50 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException51 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray50);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray50);
        org.apache.commons.math.exception.Localizable localizable53 = matrixIndexException52.getLocalizablePattern();
        java.lang.Object[] objArray57 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException58 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray57);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException59 = new org.apache.commons.math.linear.MatrixIndexException(localizable53, objArray57);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException8, 1.0d, localizable18, objArray57);
        java.lang.Object[] objArray64 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException65 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray64);
        java.lang.Object[] objArray71 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException72 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray71);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException73 = new org.apache.commons.math.linear.MatrixIndexException("", objArray71);
        org.apache.commons.math.exception.Localizable localizable74 = matrixIndexException73.getLocalizablePattern();
        java.lang.Object[] objArray80 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException81 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray80);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "hi!", objArray80);
        java.lang.IllegalStateException illegalStateException83 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable74, objArray80);
        double[][] doubleArray86 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) -1, (int) (byte) -1);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException87 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException65, (double) 6, localizable74, (java.lang.Object[]) doubleArray86);
        java.lang.UnsupportedOperationException unsupportedOperationException88 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable18, (java.lang.Object[]) doubleArray86);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(eOFException28);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(concurrentModificationException38);
        org.junit.Assert.assertNotNull(iOException40);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(parseException45);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(localizable53);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(localizable74);
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(illegalStateException83);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(unsupportedOperationException88);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor((double) 97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix(0, (int) (short) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSingular();
        boolean boolean2 = array2DRowRealMatrix0.isSquare();
        boolean boolean3 = array2DRowRealMatrix0.isSingular();
        java.lang.Object[] objArray12 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException13 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray12);
        org.apache.commons.math.exception.Localizable localizable14 = null;
        org.apache.commons.math.exception.Localizable localizable17 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable17, objArray21);
        java.util.ConcurrentModificationException concurrentModificationException23 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException13, localizable14, objArray21);
        java.io.IOException iOException25 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException13);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException26 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException25);
        java.lang.Object[] objArray28 = new java.lang.Object[] { (-1.0f), invalidMatrixException26, 1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "matrix is singular", objArray28);
        org.apache.commons.math.exception.Localizable localizable31 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable31, objArray35);
        org.apache.commons.math.exception.Localizable localizable37 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { 100L, (short) 0, (short) 100, 10.0f };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException36, localizable37, objArray42);
        org.apache.commons.math.optimization.OptimizationException optimizationException44 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException43);
        double[] doubleArray51 = new double[] { (byte) 0, 100, ' ', 0, 'a', 100.0d };
        java.lang.Object[] objArray57 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException58 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray57);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException59 = new org.apache.commons.math.linear.MatrixIndexException("", objArray57);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException44, doubleArray51, "hi!", objArray57);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException61 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException29, doubleArray51);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51);
        int int63 = array2DRowRealMatrix62.getColumnDimension();
        double double64 = array2DRowRealMatrix62.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix67 = array2DRowRealMatrix62.createMatrix((int) (byte) 100, (int) '#');
        int int68 = array2DRowRealMatrix62.getRowDimension();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix62);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(eOFException13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(concurrentModificationException23);
        org.junit.Assert.assertNotNull(iOException25);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 174.4505660638566d + "'", double64 == 174.4505660638566d);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 6 + "'", int68 == 6);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        double[] doubleArray6 = new double[] { ' ', (-1L), ' ', 0.0f, (-1) };
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        java.util.ConcurrentModificationException concurrentModificationException10 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.optimization.OptimizationException: hi!", (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        java.lang.Object[] objArray20 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException21 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray20);
        org.apache.commons.math.exception.Localizable localizable22 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable25, objArray29);
        java.util.ConcurrentModificationException concurrentModificationException31 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException21, localizable22, objArray29);
        java.io.IOException iOException33 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException21);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException34 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException33);
        java.lang.Object[] objArray36 = new java.lang.Object[] { (-1.0f), invalidMatrixException34, 1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "matrix is singular", objArray36);
        org.apache.commons.math.exception.Localizable localizable39 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable39, objArray43);
        org.apache.commons.math.exception.Localizable localizable45 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { 100L, (short) 0, (short) 100, 10.0f };
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException44, localizable45, objArray50);
        org.apache.commons.math.optimization.OptimizationException optimizationException52 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException51);
        double[] doubleArray59 = new double[] { (byte) 0, 100, ' ', 0, 'a', 100.0d };
        java.lang.Object[] objArray65 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException66 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray65);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException67 = new org.apache.commons.math.linear.MatrixIndexException("", objArray65);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException68 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException52, doubleArray59, "hi!", objArray65);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException37, doubleArray59);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59);
        double double71 = array2DRowRealMatrix70.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix72 = array2DRowRealMatrix70.copy();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix73 = array2DRowRealMatrix11.add(realMatrix72);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(concurrentModificationException10);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(eOFException21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(concurrentModificationException31);
        org.junit.Assert.assertNotNull(iOException33);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 174.4505660638566d + "'", double71 == 174.4505660638566d);
        org.junit.Assert.assertNotNull(realMatrix72);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException9 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable13, objArray17);
        java.util.ConcurrentModificationException concurrentModificationException19 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException9, localizable10, objArray17);
        java.io.IOException iOException21 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException22 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1.0f), invalidMatrixException22, 1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "matrix is singular", objArray24);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable27, objArray31);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 100L, (short) 0, (short) 100, 10.0f };
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException32, localizable33, objArray38);
        org.apache.commons.math.optimization.OptimizationException optimizationException40 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException39);
        double[] doubleArray47 = new double[] { (byte) 0, 100, ' ', 0, 'a', 100.0d };
        java.lang.Object[] objArray53 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException54 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray53);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException55 = new org.apache.commons.math.linear.MatrixIndexException("", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException40, doubleArray47, "hi!", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException25, doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        int int59 = array2DRowRealMatrix58.getColumnDimension();
        double double60 = array2DRowRealMatrix58.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix63 = array2DRowRealMatrix58.createMatrix((int) (byte) 100, (int) '#');
        int int64 = array2DRowRealMatrix58.getRowDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor65 = null;
        try {
            double double66 = array2DRowRealMatrix58.walkInColumnOrder(realMatrixPreservingVisitor65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(eOFException9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(concurrentModificationException19);
        org.junit.Assert.assertNotNull(iOException21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 174.4505660638566d + "'", double60 == 174.4505660638566d);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.MathRuntimeException(localizable0, objArray1);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException3 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "Array2DRowRealMatrix{{0.0},{100.0},{32.0},{0.0},{97.0},{100.0}}", objArray2);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException9 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable13, objArray17);
        java.util.ConcurrentModificationException concurrentModificationException19 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException9, localizable10, objArray17);
        java.io.IOException iOException21 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException22 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1.0f), invalidMatrixException22, 1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "matrix is singular", objArray24);
        double[] doubleArray26 = functionEvaluationException25.getArgument();
        double[] doubleArray27 = functionEvaluationException25.getArgument();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(eOFException9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(concurrentModificationException19);
        org.junit.Assert.assertNotNull(iOException21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test58");
        double[] doubleArray6 = new double[] { ' ', (-1L), ' ', 0.0f, (-1) };
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        java.util.ConcurrentModificationException concurrentModificationException10 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.optimization.OptimizationException: hi!", (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix11.copy();
        try {
            array2DRowRealMatrix11.luDecompose();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 1x5 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(concurrentModificationException10);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        java.lang.Object[] objArray9 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException10 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray9);
        org.apache.commons.math.exception.Localizable localizable11 = null;
        org.apache.commons.math.exception.Localizable localizable14 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable14, objArray18);
        java.util.ConcurrentModificationException concurrentModificationException20 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException10, localizable11, objArray18);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException22 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.MathRuntimeException("org.apache.commons.math.FunctionEvaluationException: matrix is singular", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("matrix is singular", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException24);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(eOFException10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(concurrentModificationException20);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        java.lang.Object[] objArray4 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException5 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray4);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException6 = new org.apache.commons.math.linear.MatrixIndexException("", objArray4);
        double[] doubleArray13 = new double[] { (short) 0, (short) -1, (byte) 1, 52, 0L, (-1L) };
        java.lang.Object[] objArray20 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException21 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray20);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException22 = new org.apache.commons.math.linear.MatrixIndexException("", objArray20);
        org.apache.commons.math.optimization.OptimizationException optimizationException23 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException6, doubleArray13, "hi!", objArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray13);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray13);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor((double) 1L);
        levenbergMarquardtOptimizer0.setMaxEvaluations((int) '#');
        levenbergMarquardtOptimizer0.setMaxIterations(1);
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) (byte) -1);
        int int9 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        double[] doubleArray4 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray8 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray12 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray16 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray20 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray21 = new double[][] { doubleArray4, doubleArray8, doubleArray12, doubleArray16, doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException23 = new org.apache.commons.math.linear.MatrixIndexException("", (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22, false);
        int int26 = array2DRowRealMatrix25.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        org.apache.commons.math.exception.Localizable localizable5 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable5, objArray9);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException11 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "", objArray9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException12 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray9);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathRuntimeException$10: ", objArray9);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test64");
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray7 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray11 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray15 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray19 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        double double23 = blockRealMatrix22.getNorm();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test65");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException7 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray6);
        org.apache.commons.math.exception.Localizable localizable8 = null;
        org.apache.commons.math.exception.Localizable localizable11 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable11, objArray15);
        java.util.ConcurrentModificationException concurrentModificationException17 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException7, localizable8, objArray15);
        java.io.IOException iOException19 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException7);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException20 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException19);
        double[] doubleArray22 = new double[] { 100.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) iOException19, doubleArray22);
        java.lang.Object[] objArray28 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException29 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray28);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException30 = new org.apache.commons.math.linear.MatrixIndexException("", objArray28);
        double[] doubleArray37 = new double[] { (short) 0, (short) -1, (byte) 1, 52, 0L, (-1L) };
        java.lang.Object[] objArray44 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException45 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray44);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException46 = new org.apache.commons.math.linear.MatrixIndexException("", objArray44);
        org.apache.commons.math.optimization.OptimizationException optimizationException47 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException30, doubleArray37, "hi!", objArray44);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair50 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray22, doubleArray37, false);
        double[] doubleArray51 = vectorialPointValuePair50.getPoint();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray51);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math.linear.RealMatrix realMatrix55 = array2DRowRealMatrix53.scalarAdd((double) 10);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(eOFException7);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(concurrentModificationException17);
        org.junit.Assert.assertNotNull(iOException19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realMatrix55);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test66");
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray7 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray11 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray15 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray19 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        double double25 = blockRealMatrix22.getEntry((int) (short) 0, 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix22.copy();
        try {
            double[] doubleArray28 = blockRealMatrix22.getRow((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test67");
        java.lang.Object[] objArray9 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException10 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "hi!", objArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(223.61797781037194d, "", objArray9);
        java.text.ParseException parseException13 = org.apache.commons.math.MathRuntimeException.createParseException((int) '4', "", objArray9);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(parseException13);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test68");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4');
        java.io.IOException iOException2 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) maxEvaluationsExceededException1);
        org.junit.Assert.assertNotNull(iOException2);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test69");
        java.lang.Object[] objArray5 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException6 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray5);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException7 = new org.apache.commons.math.linear.MatrixIndexException("", objArray5);
        org.apache.commons.math.exception.Localizable localizable8 = matrixIndexException7.getLocalizablePattern();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException16 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray15);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException17 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray15);
        java.io.EOFException eOFException18 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable8, objArray15);
        java.lang.Object[] objArray23 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException24 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray23);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException25 = new org.apache.commons.math.linear.MatrixIndexException("", objArray23);
        double[] doubleArray32 = new double[] { (short) 0, (short) -1, (byte) 1, 52, 0L, (-1L) };
        java.lang.Object[] objArray39 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException40 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray39);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException41 = new org.apache.commons.math.linear.MatrixIndexException("", objArray39);
        org.apache.commons.math.optimization.OptimizationException optimizationException42 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException25, doubleArray32, "hi!", objArray39);
        java.lang.IllegalArgumentException illegalArgumentException44 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable8, objArray39);
        java.lang.Object[] objArray50 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException51 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray50);
        org.apache.commons.math.exception.Localizable localizable52 = null;
        org.apache.commons.math.exception.Localizable localizable55 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable55, objArray59);
        java.util.ConcurrentModificationException concurrentModificationException61 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray59);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException51, localizable52, objArray59);
        java.lang.UnsupportedOperationException unsupportedOperationException63 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable8, objArray59);
        java.lang.Object[] objArray68 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException69 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray68);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException70 = new org.apache.commons.math.linear.MatrixIndexException("", objArray68);
        org.apache.commons.math.exception.Localizable localizable71 = matrixIndexException70.getLocalizablePattern();
        java.lang.Object[] objArray78 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException79 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray78);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException80 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray78);
        java.io.EOFException eOFException81 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable71, objArray78);
        org.apache.commons.math.optimization.OptimizationException optimizationException82 = new org.apache.commons.math.optimization.OptimizationException(localizable8, objArray78);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException83 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.MathRuntimeException: ", objArray78);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(eOFException16);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException17);
        org.junit.Assert.assertNotNull(eOFException18);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(illegalArgumentException44);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(eOFException51);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(concurrentModificationException61);
        org.junit.Assert.assertNotNull(unsupportedOperationException63);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(localizable71);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(eOFException79);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException80);
        org.junit.Assert.assertNotNull(eOFException81);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test70");
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray7 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray11 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray15 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray19 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray21);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = blockRealMatrix22.scalarMultiply((double) 97);
        try {
            double[] doubleArray26 = blockRealMatrix22.getColumn(97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 97 out of allowed range [0, 14]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix24);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test71");
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException9 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable13, objArray17);
        java.util.ConcurrentModificationException concurrentModificationException19 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException9, localizable10, objArray17);
        java.io.IOException iOException21 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException22 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1.0f), invalidMatrixException22, 1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "matrix is singular", objArray24);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable27, objArray31);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 100L, (short) 0, (short) 100, 10.0f };
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException32, localizable33, objArray38);
        org.apache.commons.math.optimization.OptimizationException optimizationException40 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException39);
        double[] doubleArray47 = new double[] { (byte) 0, 100, ' ', 0, 'a', 100.0d };
        java.lang.Object[] objArray53 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException54 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray53);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException55 = new org.apache.commons.math.linear.MatrixIndexException("", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException40, doubleArray47, "hi!", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException25, doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        int int59 = array2DRowRealMatrix58.getColumnDimension();
        double double60 = array2DRowRealMatrix58.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix63 = array2DRowRealMatrix58.createMatrix((int) (byte) 100, (int) '#');
        int int64 = array2DRowRealMatrix58.getRowDimension();
        double[] doubleArray68 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray72 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray76 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray80 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray84 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray85 = new double[][] { doubleArray68, doubleArray72, doubleArray76, doubleArray80, doubleArray84 };
        double[][] doubleArray86 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray85);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix87 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray86);
        org.apache.commons.math.linear.BigMatrix bigMatrix88 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray86);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix90 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray86, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix91 = array2DRowRealMatrix58.multiply(array2DRowRealMatrix90);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(eOFException9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(concurrentModificationException19);
        org.junit.Assert.assertNotNull(iOException21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 174.4505660638566d + "'", double60 == 174.4505660638566d);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(bigMatrix88);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix91);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test72");
        double[] doubleArray6 = new double[] { ' ', (-1L), ' ', 0.0f, (-1) };
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        java.util.ConcurrentModificationException concurrentModificationException10 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.optimization.OptimizationException: hi!", (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix11.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix13 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix11.subtract(realMatrix13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(concurrentModificationException10);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test73");
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException9 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        org.apache.commons.math.exception.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable13, objArray17);
        java.util.ConcurrentModificationException concurrentModificationException19 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException9, localizable10, objArray17);
        java.io.IOException iOException21 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException9);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException22 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1.0f), invalidMatrixException22, 1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "matrix is singular", objArray24);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable27, objArray31);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 100L, (short) 0, (short) 100, 10.0f };
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException32, localizable33, objArray38);
        org.apache.commons.math.optimization.OptimizationException optimizationException40 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException39);
        double[] doubleArray47 = new double[] { (byte) 0, 100, ' ', 0, 'a', 100.0d };
        java.lang.Object[] objArray53 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException54 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray53);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException55 = new org.apache.commons.math.linear.MatrixIndexException("", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException40, doubleArray47, "hi!", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException25, doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        int int59 = array2DRowRealMatrix58.getColumnDimension();
        double double60 = array2DRowRealMatrix58.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix62 = array2DRowRealMatrix58.scalarMultiply((double) (byte) 0);
        java.lang.Object[] objArray67 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException68 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray67);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException69 = new org.apache.commons.math.linear.MatrixIndexException("", objArray67);
        double[] doubleArray76 = new double[] { (short) 0, (short) -1, (byte) 1, 52, 0L, (-1L) };
        java.lang.Object[] objArray83 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException84 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray83);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException85 = new org.apache.commons.math.linear.MatrixIndexException("", objArray83);
        org.apache.commons.math.optimization.OptimizationException optimizationException86 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray83);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException87 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException69, doubleArray76, "hi!", objArray83);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix88 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray76);
        double[][] doubleArray89 = array2DRowRealMatrix88.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix91 = array2DRowRealMatrix88.getRowMatrix((int) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix92 = array2DRowRealMatrix58.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix88);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor93 = null;
        try {
            double double98 = array2DRowRealMatrix88.walkInColumnOrder(realMatrixPreservingVisitor93, (int) (short) 10, 1, (int) (short) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 5]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(eOFException9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(concurrentModificationException19);
        org.junit.Assert.assertNotNull(iOException21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 174.4505660638566d + "'", double60 == 174.4505660638566d);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(realMatrix91);
        org.junit.Assert.assertNotNull(realMatrix92);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test74");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor((double) 1L);
        levenbergMarquardtOptimizer0.setMaxEvaluations((int) '#');
        levenbergMarquardtOptimizer0.setMaxIterations(1);
        try {
            double[] doubleArray7 = levenbergMarquardtOptimizer0.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.optimization.OptimizationException; message: no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.optimization.OptimizationException e) {
        }
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test75");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair2 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray1);
        double[] doubleArray3 = vectorialPointValuePair2.getValueRef();
        double[] doubleArray4 = vectorialPointValuePair2.getValue();
        double[] doubleArray5 = vectorialPointValuePair2.getValueRef();
        double[] doubleArray6 = vectorialPointValuePair2.getPoint();
        org.junit.Assert.assertNull(doubleArray3);
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertNull(doubleArray5);
        org.junit.Assert.assertNull(doubleArray6);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test76");
        double[] doubleArray4 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray8 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray12 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray16 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray20 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray21 = new double[][] { doubleArray4, doubleArray8, doubleArray12, doubleArray16, doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", (java.lang.Object[]) doubleArray22);
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test77");
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException3 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) -1, (-1));
        java.lang.RuntimeException runtimeException4 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) nonSquareMatrixException3);
        java.lang.Object[] objArray10 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException11 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray10);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException12 = new org.apache.commons.math.linear.MatrixIndexException("", objArray10);
        org.apache.commons.math.exception.Localizable localizable13 = matrixIndexException12.getLocalizablePattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException18 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray17);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException19 = new org.apache.commons.math.linear.MatrixIndexException(localizable13, objArray17);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException26 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray25);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException27 = new org.apache.commons.math.linear.MatrixIndexException("", objArray25);
        org.apache.commons.math.exception.Localizable localizable28 = matrixIndexException27.getLocalizablePattern();
        java.lang.Object[] objArray34 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException35 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray34);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException36 = new org.apache.commons.math.linear.MatrixIndexException("", objArray34);
        org.apache.commons.math.optimization.OptimizationException optimizationException37 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray34);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException38 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, localizable28, objArray34);
        java.lang.Object[] objArray39 = null;
        java.util.NoSuchElementException noSuchElementException40 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable28, objArray39);
        java.lang.Object[] objArray46 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException47 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray46);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException48 = new org.apache.commons.math.linear.MatrixIndexException("", objArray46);
        org.apache.commons.math.exception.Localizable localizable49 = matrixIndexException48.getLocalizablePattern();
        java.lang.Object[] objArray53 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException54 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray53);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException55 = new org.apache.commons.math.linear.MatrixIndexException(localizable49, objArray53);
        java.lang.Object[] objArray56 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable49, objArray56);
        double[] doubleArray61 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray65 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray69 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray73 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[] doubleArray77 = new double[] { 100.0f, (short) 0, (short) -1 };
        double[][] doubleArray78 = new double[][] { doubleArray61, doubleArray65, doubleArray69, doubleArray73, doubleArray77 };
        double[][] doubleArray79 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray78);
        org.apache.commons.math.optimization.OptimizationException optimizationException80 = new org.apache.commons.math.optimization.OptimizationException(localizable49, (java.lang.Object[]) doubleArray78);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray78);
        java.lang.NullPointerException nullPointerException82 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable28, (java.lang.Object[]) doubleArray78);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException83 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) runtimeException4, (double) (short) -1, localizable13, (java.lang.Object[]) doubleArray78);
        java.lang.IllegalStateException illegalStateException84 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.optimization.OptimizationException: hi!", (java.lang.Object[]) doubleArray78);
        org.junit.Assert.assertNotNull(runtimeException4);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(localizable28);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(noSuchElementException40);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(localizable49);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(nullPointerException82);
        org.junit.Assert.assertNotNull(illegalStateException84);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test78");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException8 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray7);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException("", objArray7);
        org.apache.commons.math.exception.Localizable localizable10 = matrixIndexException9.getLocalizablePattern();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException20 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray19);
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.exception.Localizable localizable24 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable24, objArray28);
        java.util.ConcurrentModificationException concurrentModificationException30 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException20, localizable21, objArray28);
        java.io.IOException iOException32 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException20);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException33 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException32);
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1.0f), invalidMatrixException33, 1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "matrix is singular", objArray35);
        java.text.ParseException parseException37 = org.apache.commons.math.MathRuntimeException.createParseException(36, localizable10, objArray35);
        java.lang.Object[] objArray45 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException46 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray45);
        org.apache.commons.math.exception.Localizable localizable47 = null;
        org.apache.commons.math.exception.Localizable localizable50 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable50, objArray54);
        java.util.ConcurrentModificationException concurrentModificationException56 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException46, localizable47, objArray54);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException58 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", objArray54);
        java.util.ConcurrentModificationException concurrentModificationException59 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException(localizable10, objArray54);
        java.lang.Object[] objArray65 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException66 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray65);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "hi!", objArray65);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException68 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable10, objArray65);
        org.apache.commons.math.MathRuntimeException mathRuntimeException69 = new org.apache.commons.math.MathRuntimeException("{0}", objArray65);
        java.util.ConcurrentModificationException concurrentModificationException70 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray65);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(eOFException20);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(concurrentModificationException30);
        org.junit.Assert.assertNotNull(iOException32);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(parseException37);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(eOFException46);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(concurrentModificationException56);
        org.junit.Assert.assertNotNull(concurrentModificationException59);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException68);
        org.junit.Assert.assertNotNull(concurrentModificationException70);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test79");
        double[][] doubleArray2 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) 'a', 52);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test80");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 100, 97);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix((int) (byte) 1, 52);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract(realMatrix5);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test81");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException7 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray6);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException8 = new org.apache.commons.math.linear.MatrixIndexException("", objArray6);
        org.apache.commons.math.exception.Localizable localizable9 = matrixIndexException8.getLocalizablePattern();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException14 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray13);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException15 = new org.apache.commons.math.linear.MatrixIndexException(localizable9, objArray13);
        java.lang.Object[] objArray23 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException24 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray23);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException25 = new org.apache.commons.math.linear.MatrixIndexException("", objArray23);
        org.apache.commons.math.exception.Localizable localizable26 = matrixIndexException25.getLocalizablePattern();
        java.lang.Object[] objArray35 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException36 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray35);
        org.apache.commons.math.exception.Localizable localizable37 = null;
        org.apache.commons.math.exception.Localizable localizable40 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] { 0L, 10L, 10.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException((double) ' ', localizable40, objArray44);
        java.util.ConcurrentModificationException concurrentModificationException46 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException36, localizable37, objArray44);
        java.io.IOException iOException48 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException36);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException49 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException48);
        java.lang.Object[] objArray51 = new java.lang.Object[] { (-1.0f), invalidMatrixException49, 1 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "matrix is singular", objArray51);
        java.text.ParseException parseException53 = org.apache.commons.math.MathRuntimeException.createParseException(36, localizable26, objArray51);
        java.lang.Object[] objArray58 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException59 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray58);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException60 = new org.apache.commons.math.linear.MatrixIndexException("", objArray58);
        org.apache.commons.math.exception.Localizable localizable61 = matrixIndexException60.getLocalizablePattern();
        java.lang.Object[] objArray65 = new java.lang.Object[] { 1 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException66 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4', "", objArray65);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException67 = new org.apache.commons.math.linear.MatrixIndexException(localizable61, objArray65);
        java.io.EOFException eOFException68 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable26, objArray65);
        java.lang.Object[] objArray76 = new java.lang.Object[] { 100, "hi!", (short) -1, '#' };
        java.io.EOFException eOFException77 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray76);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException78 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray76);
        org.apache.commons.math.MathRuntimeException mathRuntimeException79 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) eOFException68, "org.apache.commons.math.optimization.OptimizationException: hi!", objArray76);
        org.apache.commons.math.optimization.OptimizationException optimizationException80 = new org.apache.commons.math.optimization.OptimizationException("org.apache.commons.math.FunctionEvaluationException: matrix is singular", objArray76);
        java.lang.IllegalArgumentException illegalArgumentException81 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray76);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException82 = new org.apache.commons.math.linear.MatrixIndexException(localizable9, objArray76);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException83 = new org.apache.commons.math.FunctionEvaluationException((double) 15, "org.apache.commons.math.optimization.OptimizationException: hi!", objArray76);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException84 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) functionEvaluationException83);
        java.lang.Object[] objArray85 = invalidMatrixException84.getArguments();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(eOFException36);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(concurrentModificationException46);
        org.junit.Assert.assertNotNull(iOException48);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(parseException53);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(localizable61);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(eOFException68);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(eOFException77);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException78);
        org.junit.Assert.assertNotNull(illegalArgumentException81);
        org.junit.Assert.assertNotNull(objArray85);
    }
}

