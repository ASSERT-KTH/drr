import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 'a');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.special.Erf.erf(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            java.lang.String str2 = randomDataImpl0.nextSecureHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test004");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4485633290585931d + "'", double0 == 0.4485633290585931d);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (-1): permutation size (97) exceeds permuation domain (-1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267831587699267d + "'", double1 == 5.267831587699267d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 105L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 105.0d + "'", double1 == 105.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextGamma(0.8813735870195429d, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) 10, 0.0d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.8813735870195429d, 105.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3296798906723511E-46d + "'", double2 == 1.3296798906723511E-46d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 1.0f, 0.8813735870195429d, (double) 10, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.3650768932609182d + "'", double4 == 0.3650768932609182d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.1622776601683795d, 1.3296798906723511E-46d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 1, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextInt(100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (10): lower bound (100) must be strictly less than upper bound (10)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextF(0.0d, 1.107943536736182d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000003E-9d + "'", double1 == 1.0000000000000003E-9d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextPascal((int) (byte) -1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        try {
            int int5 = randomDataImpl0.nextPascal((int) (byte) -1, (double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.41032129904824216d) + "'", double1 == (-0.41032129904824216d));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 94L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0d, number1, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.41032129904824216d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) ' ');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1), (float) 105L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        try {
            int int8 = randomDataImpl0.nextPascal((int) (byte) 0, (double) 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 105L, (java.lang.Number) 104L, (java.lang.Number) 3.1622776601683795d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 104L + "'", number4.equals(104L));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.0d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        try {
            double double5 = randomDataImpl0.nextWeibull((double) 104L, (-57.29577951308232d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -57.296 is smaller than, or equal to, the minimum (0): scale (-57.296)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (byte) 100, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        try {
//            int[] intArray5 = randomDataImpl0.nextPermutation(0, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (0): permutation size (97) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 105L + "'", long2 == 105L);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 104L, 104.39390890801062d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 104.39390890801062d + "'", double2 == 104.39390890801062d);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 96L + "'", long2 == 96L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5772156677920679d) + "'", double1 == (-0.5772156677920679d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.977787856101637d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.00975536087541375d) + "'", double1 == (-0.00975536087541375d));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        float float2 = org.apache.commons.math.util.FastMath.max((float) ' ', (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        try {
            java.lang.String str4 = randomDataImpl0.nextHexString((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        try {
            double double8 = randomDataImpl1.nextUniform(1.107943536736182d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1.108 is larger than, or equal to, the maximum (0): lower bound (1.108) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        try {
            int int5 = randomDataImpl0.nextSecureInt(52, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (0): lower bound (52) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        java.lang.String str7 = convergenceException6.toString();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.ConvergenceException: " + "'", str7.equals("org.apache.commons.math.ConvergenceException: "));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.107943536736182d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        java.lang.String str2 = convergenceException1.getPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-1.0d), 3.1622776601683795d, (double) (byte) -1, (int) (short) 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure((long) (short) 100);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        try {
            java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
        java.lang.Throwable throwable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, "hi!", objArray11);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, "org.apache.commons.math.ConvergenceException: ", objArray11);
        java.lang.String str14 = convergenceException3.getPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        int int5 = randomDataImpl0.nextSecureInt(0, (int) (short) 1);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution6 = null;
//        try {
//            int int7 = randomDataImpl0.nextInversionDeviate(integerDistribution6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 102L + "'", long2 == 102L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        double double4 = randomDataImpl0.nextChiSquare((double) 45L);
//        try {
//            int int7 = randomDataImpl0.nextZipf((int) (short) 0, 1.0000000000000003E-9d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 88L + "'", long2 == 88L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 59.508033826730056d + "'", double4 == 59.508033826730056d);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.41032129904824216d), (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5557.690612768985d + "'", double1 == 5557.690612768985d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7949577687638787d + "'", double1 == 0.7949577687638787d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        randomDataImpl0.reSeedSecure((long) ' ');
        try {
            double double12 = randomDataImpl0.nextUniform(0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 118L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 118.0d + "'", double1 == 118.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) -1, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math.util.FastMath.asinh(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.741450291257945d + "'", double1 == 4.741450291257945d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextF((-0.00975536087541375d), (double) 105L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.01 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.01)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '#', 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 82L, 4.741450291257945d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5130380755642154d + "'", double2 == 1.5130380755642154d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.678982327128295d + "'", double1 == 4.678982327128295d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 27);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.332204510175204d + "'", double1 == 3.332204510175204d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 10, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int2 = org.apache.commons.math.util.FastMath.min(35, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 100L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.util.FastMath.log(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5495393129816448d) + "'", double1 == (-0.5495393129816448d));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 101L, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        long long4 = randomDataImpl0.nextPoisson((double) 104L);
        try {
            int[] intArray7 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.107943536736182d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        double double7 = randomDataImpl0.nextUniform(0.0d, (double) 1L);
//        try {
//            int int11 = randomDataImpl0.nextHypergeometric((int) (short) 1, (int) (short) 100, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (1): number of successes (100) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 91L + "'", long2 == 91L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5028120040581779d + "'", double7 == 0.5028120040581779d);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 4.524514827724147d, (java.lang.Number) 5.298292365610485d, number2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.4026737725800021d, (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.40267377258000214d + "'", double2 == 0.40267377258000214d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5604874136486533d + "'", double1 == 1.5604874136486533d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 0, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextWeibull(4.678982327128295d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): scale (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.4026737725800021d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0000000000000003E-9d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-9d + "'", double2 == 1.0E-9d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 94L, (double) 97L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3667424245079105d + "'", double2 == 0.3667424245079105d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.40267377258000214d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 32, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 118L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10L, (java.lang.Number) 0L, false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 94L, (java.lang.Number) 116L, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6574544541530771d + "'", double1 == 1.6574544541530771d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 105L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        java.lang.Throwable throwable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(throwable7, "hi!", objArray9);
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException10, "", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        java.lang.Throwable throwable15 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(throwable15, "hi!", objArray17);
        java.lang.Throwable throwable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(throwable19, "hi!", objArray21);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        convergenceException18.addSuppressed((java.lang.Throwable) convergenceException22);
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, "org.apache.commons.math.ConvergenceException: hi!", objArray26);
        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable14, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathException31);
        java.lang.Throwable throwable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable33, "hi!", objArray35);
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException36, "", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = convergenceException36.getGeneralPattern();
        java.lang.Throwable throwable41 = null;
        java.lang.Throwable throwable43 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(throwable43, "hi!", objArray45);
        java.lang.Object[] objArray48 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException46, "", objArray48);
        org.apache.commons.math.exception.util.Localizable localizable50 = convergenceException49.getGeneralPattern();
        java.lang.Throwable throwable51 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(throwable51, "hi!", objArray53);
        java.lang.Throwable throwable55 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(throwable55, "hi!", objArray57);
        java.lang.Throwable[] throwableArray59 = convergenceException58.getSuppressed();
        convergenceException54.addSuppressed((java.lang.Throwable) convergenceException58);
        java.lang.Object[] objArray62 = null;
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException58, "org.apache.commons.math.ConvergenceException: hi!", objArray62);
        java.lang.Throwable[] throwableArray64 = convergenceException63.getSuppressed();
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(localizable50, (java.lang.Object[]) throwableArray64);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException(throwable41, "", (java.lang.Object[]) throwableArray64);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, localizable40, (java.lang.Object[]) throwableArray64);
        java.lang.Number number68 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException69 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number68);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) notStrictlyPositiveException69);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 105L + "'", number6.equals(105L));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(localizable50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertNotNull(throwableArray64);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double2 = org.apache.commons.math.util.FastMath.min(3.332204510175204d, 0.7949577687638787d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7949577687638787d + "'", double2 == 0.7949577687638787d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.9502747595439502d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3991949460826119d) + "'", double1 == (-1.3991949460826119d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException(throwable1, "hi!", objArray3);
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException(throwable5, "hi!", objArray7);
        java.lang.Throwable[] throwableArray9 = convergenceException8.getSuppressed();
        convergenceException4.addSuppressed((java.lang.Throwable) convergenceException8);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "org.apache.commons.math.ConvergenceException: hi!", objArray12);
        java.lang.Throwable[] throwableArray14 = convergenceException13.getSuppressed();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", (java.lang.Object[]) throwableArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = mathException15.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNull(localizable16);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        try {
            int[] intArray10 = randomDataImpl0.nextPermutation((int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '#', 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '#', (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '4', (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextCauchy((double) (-1L), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.220446049250313E-16d, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 5557.690612768985d, (java.lang.Number) (-1.0f), (java.lang.Number) 118.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 117L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) (short) 100);
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
//        long long8 = randomDataImpl1.nextSecureLong((long) 0, (long) (short) 10);
//        try {
//            int int12 = randomDataImpl1.nextHypergeometric((int) (short) 10, (int) (short) -1, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 7L + "'", long8 == 7L);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        double double8 = randomDataImpl1.nextGaussian((double) 45L, (double) 1L);
        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution9 = null;
        try {
            double double10 = randomDataImpl1.nextInversionDeviate(continuousDistribution9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 44.68930991492643d + "'", double8 == 44.68930991492643d);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) (short) 100);
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
//        long long8 = randomDataImpl1.nextSecureLong((long) 0, (long) (short) 10);
//        try {
//            double double11 = randomDataImpl1.nextGamma(0.5772156649015329d, (double) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) 1, (double) 116L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        long long8 = randomDataImpl1.nextLong(94L, 100L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 95L + "'", long8 == 95L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double2 = org.apache.commons.math.util.FastMath.min(2.220446049250313E-16d, 0.7949577687638787d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.220446049250313E-16d + "'", double2 == 2.220446049250313E-16d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 4.741450291257945d, (java.lang.Number) 94L, (java.lang.Number) (-57.29577951308232d));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        randomDataImpl0.reSeedSecure((long) ' ');
        try {
            randomDataImpl0.setSecureAlgorithm("51e095b11819b59807101a48841667d3ddd2b26d60bf1de0ad4cfa1752fc514561ee86931125e6fcbe2b2624b7f23b601859", "{0}");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: {0}");
        } catch (java.security.NoSuchProviderException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.600161852571429d + "'", double1 == 4.600161852571429d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double1 = org.apache.commons.math.special.Erf.erf((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8427007929497151d) + "'", double1 == (-0.8427007929497151d));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        double double7 = randomDataImpl0.nextBeta(0.009784837054594254d, (double) 10L);
//        try {
//            randomDataImpl0.setSecureAlgorithm("47525d14781e16cd70ba1bde46604edb69faf07887dca405aea1875acfe1358de5cad9bde972b53ac23d02c21bf0b7b2596b", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 102L + "'", long2 == 102L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0762046836668282E-9d + "'", double7 == 1.0762046836668282E-9d);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 116L, (double) (byte) 0, 0.0d, (-1));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 105L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.347084854209185d + "'", double1 == 5.347084854209185d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        double double8 = randomDataImpl1.nextWeibull((double) '4', (double) (byte) 1);
        randomDataImpl1.reSeedSecure((long) 10);
        try {
            java.lang.String str12 = randomDataImpl1.nextSecureHexString((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.977787856101637d + "'", double8 == 0.977787856101637d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.154262241479262d + "'", double1 == 15.154262241479262d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.0f, (java.lang.Number) 100, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100 + "'", number4.equals(100));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 35);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 105L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.994759785273608E45d + "'", double1 == 1.994759785273608E45d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 5.298292365610485d, (java.lang.Number) 116L);
        numberIsTooSmallException11.addSuppressed((java.lang.Throwable) outOfRangeException15);
        java.lang.Number number17 = numberIsTooSmallException11.getMin();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100.0d + "'", number17.equals(100.0d));
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        int int5 = randomDataImpl0.nextSecureInt(0, (int) (short) 1);
//        java.lang.String str7 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double10 = randomDataImpl0.nextGaussian((double) 97, 11013.232920103323d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 102L + "'", long2 == 102L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "48660e36d2fddeaffc0521face2d6e27fe6e3cdb8fbab5573166154e22acf0c88ea899d4d9abebba3ff785c92e0ed183b0f3" + "'", str7.equals("48660e36d2fddeaffc0521face2d6e27fe6e3cdb8fbab5573166154e22acf0c88ea899d4d9abebba3ff785c92e0ed183b0f3"));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-9335.99058474676d) + "'", double10 == (-9335.99058474676d));
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(118.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 118.00000000000001d + "'", double1 == 118.00000000000001d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 94L, (java.lang.Number) 116L, (java.lang.Number) 100L);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100L + "'", number4.equals(100L));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(82.93979543186188d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.447572511216542d + "'", double1 == 1.447572511216542d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        double double7 = randomDataImpl0.nextBeta(0.009784837054594254d, (double) 10L);
//        try {
//            double double10 = randomDataImpl0.nextGamma((-0.5495393129816448d), (double) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.55 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.00975536087541375d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.009755051424170096d) + "'", double1 == (-0.009755051424170096d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 104.39390890801062d, (java.lang.Number) (-1.0f), true);
        java.lang.Throwable throwable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(throwable4, "hi!", objArray6);
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException10.getGeneralPattern();
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Throwable throwable16 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(throwable16, "hi!", objArray18);
        java.lang.Throwable[] throwableArray20 = convergenceException19.getSuppressed();
        convergenceException15.addSuppressed((java.lang.Throwable) convergenceException19);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException19, "org.apache.commons.math.ConvergenceException: hi!", objArray23);
        java.lang.Throwable[] throwableArray25 = convergenceException24.getSuppressed();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable11, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException26);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException27);
        org.apache.commons.math.exception.util.Localizable localizable29 = convergenceException27.getGeneralPattern();
        java.lang.Throwable throwable30 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(throwable30, "hi!", objArray32);
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException33, "", objArray35);
        org.apache.commons.math.exception.util.Localizable localizable37 = convergenceException36.getGeneralPattern();
        java.lang.Throwable throwable38 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(throwable38, "hi!", objArray40);
        java.lang.Throwable throwable42 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(throwable42, "hi!", objArray44);
        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
        convergenceException41.addSuppressed((java.lang.Throwable) convergenceException45);
        java.lang.Object[] objArray49 = null;
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException45, "org.apache.commons.math.ConvergenceException: hi!", objArray49);
        java.lang.Throwable[] throwableArray51 = convergenceException50.getSuppressed();
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException(localizable37, (java.lang.Object[]) throwableArray51);
        java.lang.Throwable throwable53 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException(throwable53, "hi!", objArray55);
        java.lang.Object[] objArray58 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, "", objArray58);
        org.apache.commons.math.exception.util.Localizable localizable60 = convergenceException59.getGeneralPattern();
        java.lang.Throwable throwable61 = null;
        java.lang.Object[] objArray63 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(throwable61, "hi!", objArray63);
        java.lang.Throwable throwable65 = null;
        java.lang.Object[] objArray67 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException(throwable65, "hi!", objArray67);
        java.lang.Throwable[] throwableArray69 = convergenceException68.getSuppressed();
        convergenceException64.addSuppressed((java.lang.Throwable) convergenceException68);
        java.lang.Object[] objArray72 = null;
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException68, "org.apache.commons.math.ConvergenceException: hi!", objArray72);
        java.lang.Throwable[] throwableArray74 = convergenceException73.getSuppressed();
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException(localizable60, (java.lang.Object[]) throwableArray74);
        java.lang.Throwable throwable76 = null;
        java.lang.Object[] objArray78 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException(throwable76, "hi!", objArray78);
        java.lang.Throwable[] throwableArray80 = convergenceException79.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, localizable60, (java.lang.Object[]) throwableArray80);
        java.lang.Throwable throwable82 = null;
        java.lang.Object[] objArray84 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException(throwable82, "hi!", objArray84);
        java.lang.Throwable throwable86 = null;
        java.lang.Object[] objArray88 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException(throwable86, "hi!", objArray88);
        java.lang.Throwable[] throwableArray90 = convergenceException89.getSuppressed();
        convergenceException85.addSuppressed((java.lang.Throwable) convergenceException89);
        java.lang.Object[] objArray93 = null;
        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException89, "org.apache.commons.math.ConvergenceException: hi!", objArray93);
        java.lang.Throwable[] throwableArray95 = convergenceException94.getSuppressed();
        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException(localizable37, (java.lang.Object[]) throwableArray95);
        org.apache.commons.math.ConvergenceException convergenceException97 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, localizable29, (java.lang.Object[]) throwableArray95);
        java.lang.Object[] objArray98 = convergenceException97.getArguments();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(localizable60);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(throwableArray69);
        org.junit.Assert.assertNotNull(throwableArray74);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(throwableArray80);
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNotNull(throwableArray90);
        org.junit.Assert.assertNotNull(throwableArray95);
        org.junit.Assert.assertNotNull(objArray98);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644483341943245d + "'", double1 == 4.644483341943245d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 100L, (double) 10.0f);
        try {
            double[] doubleArray4 = normalDistributionImpl2.sample((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        long long9 = randomDataImpl0.nextPoisson((double) 118L);
        try {
            java.lang.String str11 = randomDataImpl0.nextSecureHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 117L + "'", long9 == 117L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double1 = org.apache.commons.math.util.FastMath.log(5.267831587699267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.66161881444429d + "'", double1 == 1.66161881444429d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 5.347084854209185d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.347084854209185d + "'", double2 == 5.347084854209185d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        double double7 = randomDataImpl0.nextUniform(0.0d, (double) 1L);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double11 = randomDataImpl0.nextBeta((-0.00975536087541375d), 0.6264011299651113d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.784");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 118L + "'", long2 == 118L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.49722759870207545d + "'", double7 == 0.49722759870207545d);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        int int8 = randomDataImpl1.nextBinomial(0, 0.977787856101637d);
        try {
            int[] intArray11 = randomDataImpl1.nextPermutation(0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than the maximum (0): permutation size (52) exceeds permuation domain (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 155.74607629780772d + "'", double1 == 155.74607629780772d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException(throwable1, "hi!", objArray3);
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException4, "", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, number9, (java.lang.Number) 100.0d, false);
        java.lang.Throwable throwable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(throwable13, "hi!", objArray15);
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException16, "", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        java.lang.Throwable throwable21 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(throwable21, "hi!", objArray23);
        java.lang.Throwable throwable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(throwable25, "hi!", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        convergenceException24.addSuppressed((java.lang.Throwable) convergenceException28);
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException28, "org.apache.commons.math.ConvergenceException: hi!", objArray32);
        java.lang.Throwable[] throwableArray34 = convergenceException33.getSuppressed();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable20, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable8, (java.lang.Object[]) throwableArray34);
        java.lang.Throwable throwable37 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(throwable37, "hi!", objArray39);
        java.lang.Throwable throwable41 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(throwable41, "hi!", objArray43);
        java.lang.Throwable[] throwableArray45 = convergenceException44.getSuppressed();
        convergenceException40.addSuppressed((java.lang.Throwable) convergenceException44);
        java.lang.Object[] objArray48 = null;
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException44, "org.apache.commons.math.ConvergenceException: hi!", objArray48);
        java.lang.Throwable[] throwableArray50 = convergenceException49.getSuppressed();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(localizable8, (java.lang.Object[]) throwableArray50);
        java.lang.Throwable throwable52 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(throwable52, "hi!", objArray54);
        java.lang.Throwable[] throwableArray56 = convergenceException55.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, (java.lang.Object[]) throwableArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray56);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(throwableArray56);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 105.0d, (java.lang.Number) (byte) 100, false);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.009784837054594254d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.621351742195683d + "'", double1 == 4.621351742195683d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.977787856101637d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6143583690369782d) + "'", double1 == (-0.6143583690369782d));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double2 = org.apache.commons.math.util.FastMath.max(0.4026737725800021d, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.24197072451914334d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        try {
//            java.lang.String str6 = randomDataImpl0.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(11013.232920103323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.080398176981344E-5d + "'", double1 == 9.080398176981344E-5d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        long long4 = randomDataImpl0.nextPoisson((double) 104L);
        long long7 = randomDataImpl0.nextLong(0L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(4.621351742195683d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.665672727543436d + "'", double1 == 1.665672727543436d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) (short) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double6 = normalDistributionImpl4.cumulativeProbability((double) 97.0f);
//        double double7 = normalDistributionImpl4.sample();
//        double double8 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        try {
//            double double11 = normalDistributionImpl4.cumulativeProbability(105.0d, (-0.8474827660881417d));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.30911490712300166d) + "'", double7 == (-0.30911490712300166d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5888219938221677d + "'", double8 == 0.5888219938221677d);
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        int int5 = randomDataImpl0.nextSecureInt(0, (int) (short) 1);
//        java.lang.String str7 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double9 = randomDataImpl0.nextT(5557.690612768985d);
//        try {
//            double double12 = randomDataImpl0.nextBeta((-2.8305302825148724d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.052");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 108L + "'", long2 == 108L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "54aed1f50e587c4389e304d3e6b212c4fe183c3e8b6db044b5342f96f53c49a51700173a0a8045eec1b74452b5090965c8d2" + "'", str7.equals("54aed1f50e587c4389e304d3e6b212c4fe183c3e8b6db044b5342f96f53c49a51700173a0a8045eec1b74452b5090965c8d2"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.7441843430122691d + "'", double9 == 0.7441843430122691d);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextCauchy(0.0d, 1.5130380755642154d);
        long long8 = randomDataImpl0.nextLong((long) (short) -1, (long) 52);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.3375619403500054d + "'", double5 == 1.3375619403500054d);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.3667424245079105d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.36674242450791045d + "'", double2 == 0.36674242450791045d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.505149978319906d + "'", double1 == 1.505149978319906d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double2 = org.apache.commons.math.util.FastMath.max(0.3667424245079105d, (double) 94L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 94.0d + "'", double2 == 94.0d);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        try {
//            int int6 = randomDataImpl0.nextHypergeometric(1, (int) '#', (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than the maximum (1): number of successes (35) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107L + "'", long2 == 107L);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 116L, 68.51230874435387d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999998903978647d + "'", double2 == 0.9999998903978647d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.4428584349276598E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        randomDataImpl0.reSeedSecure((long) ' ');
        java.lang.String str11 = randomDataImpl0.nextHexString(10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3035ea3a17" + "'", str11.equals("3035ea3a17"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        java.lang.Throwable throwable20 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(throwable20, "hi!", objArray22);
        java.lang.Throwable throwable24 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(throwable24, "hi!", objArray26);
        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
        convergenceException23.addSuppressed((java.lang.Throwable) convergenceException27);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException27, "org.apache.commons.math.ConvergenceException: hi!", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable19, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable7, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) 100.0d);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray33);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.012950048341456726d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.339317855293556d + "'", double1 == 4.339317855293556d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int2 = org.apache.commons.math.util.FastMath.max(52, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.3991949460826119d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17076042790120838d + "'", double1 == 0.17076042790120838d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0174532925199433d + "'", double1 == 0.0174532925199433d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int2 = org.apache.commons.math.util.FastMath.max(10, 88);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 88 + "'", int2 == 88);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextUniform((-0.5495393129816448d), (double) 94L);
        double double7 = randomDataImpl0.nextExponential(4.339317855293556d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 68.51230874435387d + "'", double5 == 68.51230874435387d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 5.8822072909201655d + "'", double7 == 5.8822072909201655d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.180678914967459E-9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, number4, (java.lang.Number) 105L, false);
        java.lang.Number number8 = numberIsTooSmallException7.getArgument();
        java.lang.Number number9 = numberIsTooSmallException7.getMin();
        java.lang.Throwable throwable10 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(throwable10, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException13, "", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        java.lang.Throwable throwable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(throwable18, "hi!", objArray20);
        java.lang.Throwable throwable22 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(throwable22, "hi!", objArray24);
        java.lang.Throwable[] throwableArray26 = convergenceException25.getSuppressed();
        convergenceException21.addSuppressed((java.lang.Throwable) convergenceException25);
        java.lang.Object[] objArray29 = null;
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException25, "org.apache.commons.math.ConvergenceException: hi!", objArray29);
        java.lang.Throwable[] throwableArray31 = convergenceException30.getSuppressed();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable17, (java.lang.Object[]) throwableArray31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException32);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException33);
        numberIsTooSmallException7.addSuppressed((java.lang.Throwable) mathException34);
        java.lang.Throwable throwable36 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, "hi!", objArray38);
        java.lang.Object[] objArray41 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException39, "", objArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = convergenceException39.getGeneralPattern();
        java.lang.Throwable throwable44 = null;
        java.lang.Throwable throwable46 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(throwable46, "hi!", objArray48);
        java.lang.Object[] objArray51 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException49, "", objArray51);
        org.apache.commons.math.exception.util.Localizable localizable53 = convergenceException52.getGeneralPattern();
        java.lang.Throwable throwable54 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(throwable54, "hi!", objArray56);
        java.lang.Throwable throwable58 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(throwable58, "hi!", objArray60);
        java.lang.Throwable[] throwableArray62 = convergenceException61.getSuppressed();
        convergenceException57.addSuppressed((java.lang.Throwable) convergenceException61);
        java.lang.Object[] objArray65 = null;
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException61, "org.apache.commons.math.ConvergenceException: hi!", objArray65);
        java.lang.Throwable[] throwableArray67 = convergenceException66.getSuppressed();
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException(localizable53, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(throwable44, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException7, localizable43, (java.lang.Object[]) throwableArray67);
        java.lang.Object[] objArray72 = null;
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException70, "", objArray72);
        java.lang.Object[] objArray74 = convergenceException70.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "org.apache.commons.math.ConvergenceException: hi!", objArray74);
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException("6020526d7399881473f8118dca386917a5c070eb9ab0875432dad9ef18025bd0c073fb00ccbdde3c70b20c1c05a2b1ea8f76", objArray74);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 105L + "'", number9.equals(105L));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(localizable53);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(objArray74);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.600161852571429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1119916940226243d) + "'", double1 == (-0.1119916940226243d));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        long long1 = org.apache.commons.math.util.FastMath.abs(101L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 101L + "'", long1 == 101L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 32, (long) 88);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.6264011299651113d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.388796649142697d + "'", double1 == 3.388796649142697d);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString(10);
//        try {
//            long long4 = randomDataImpl0.nextPoisson((-0.5063656411097588d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.506 is smaller than, or equal to, the minimum (0): mean (-0.506)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13c52e0c87" + "'", str2.equals("13c52e0c87"));
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 93L, 1.5130380755642154d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 93.0d + "'", double2 == 93.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Throwable[] throwableArray4 = convergenceException3.getSuppressed();
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(throwable6, "hi!", objArray8);
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException12.getGeneralPattern();
        java.lang.Throwable throwable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(throwable14, "hi!", objArray16);
        java.lang.Throwable throwable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(throwable18, "hi!", objArray20);
        java.lang.Throwable[] throwableArray22 = convergenceException21.getSuppressed();
        convergenceException17.addSuppressed((java.lang.Throwable) convergenceException21);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21, "org.apache.commons.math.ConvergenceException: hi!", objArray25);
        java.lang.Throwable[] throwableArray27 = convergenceException26.getSuppressed();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable13, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, "", (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException3.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(localizable30);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 101L, true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.4026737725800021d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4136443391590922d + "'", double1 == 0.4136443391590922d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100, (java.lang.Number) (-1.0d), (java.lang.Number) Double.NEGATIVE_INFINITY);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, "org.apache.commons.math.ConvergenceException: hi!", objArray5);
        java.lang.Number number7 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + Double.NEGATIVE_INFINITY + "'", number7.equals(Double.NEGATIVE_INFINITY));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        randomDataImpl1.reSeedSecure((long) 'a');
        double double8 = randomDataImpl1.nextCauchy(1.6574544541530771d, (double) 97L);
        try {
            int int12 = randomDataImpl1.nextHypergeometric(0, 1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 82.93979543186188d + "'", double8 == 82.93979543186188d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.6264011299651113d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6264011299651113d + "'", double1 == 0.6264011299651113d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.5604874136486533d, (java.lang.Number) (-9335.99058474676d), (java.lang.Number) (-0.8427007929497151d));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 52, (java.lang.Number) 101L, (java.lang.Number) 1.0000000000000003E-9d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0000000000000003E-9d + "'", number4.equals(1.0000000000000003E-9d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 83L, (double) 88, (double) 105L, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 88 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, number3, (java.lang.Number) 105L, false);
        java.lang.Number number7 = numberIsTooSmallException6.getArgument();
        java.lang.Number number8 = numberIsTooSmallException6.getMin();
        java.lang.Throwable throwable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, "hi!", objArray11);
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException12, "", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        java.lang.Throwable throwable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(throwable17, "hi!", objArray19);
        java.lang.Throwable throwable21 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(throwable21, "hi!", objArray23);
        java.lang.Throwable[] throwableArray25 = convergenceException24.getSuppressed();
        convergenceException20.addSuppressed((java.lang.Throwable) convergenceException24);
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException24, "org.apache.commons.math.ConvergenceException: hi!", objArray28);
        java.lang.Throwable[] throwableArray30 = convergenceException29.getSuppressed();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable16, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException31);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32);
        numberIsTooSmallException6.addSuppressed((java.lang.Throwable) mathException33);
        java.lang.Throwable throwable35 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(throwable35, "hi!", objArray37);
        java.lang.Object[] objArray40 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException38, "", objArray40);
        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException38.getGeneralPattern();
        java.lang.Throwable throwable43 = null;
        java.lang.Throwable throwable45 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(throwable45, "hi!", objArray47);
        java.lang.Object[] objArray50 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException48, "", objArray50);
        org.apache.commons.math.exception.util.Localizable localizable52 = convergenceException51.getGeneralPattern();
        java.lang.Throwable throwable53 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException(throwable53, "hi!", objArray55);
        java.lang.Throwable throwable57 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException(throwable57, "hi!", objArray59);
        java.lang.Throwable[] throwableArray61 = convergenceException60.getSuppressed();
        convergenceException56.addSuppressed((java.lang.Throwable) convergenceException60);
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException60, "org.apache.commons.math.ConvergenceException: hi!", objArray64);
        java.lang.Throwable[] throwableArray66 = convergenceException65.getSuppressed();
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException(localizable52, (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException(throwable43, "", (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException6, localizable42, (java.lang.Object[]) throwableArray66);
        java.lang.Object[] objArray71 = null;
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException69, "", objArray71);
        java.lang.Object[] objArray73 = convergenceException69.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "org.apache.commons.math.ConvergenceException: hi!", objArray73);
        org.apache.commons.math.exception.util.Localizable localizable75 = maxIterationsExceededException74.getGeneralPattern();
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 105L + "'", number8.equals(105L));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(localizable42);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(localizable52);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(localizable75);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 104L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.338311150777212E44d + "'", double1 == 7.338311150777212E44d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 83L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        double double8 = randomDataImpl1.nextWeibull((double) '4', (double) (byte) 1);
        randomDataImpl1.reSeedSecure((long) 10);
        try {
            java.lang.String str12 = randomDataImpl1.nextHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.977787856101637d + "'", double8 == 0.977787856101637d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(27);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27 + "'", int2 == 27);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 105L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        java.lang.Throwable throwable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(throwable7, "hi!", objArray9);
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException10, "", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        java.lang.Throwable throwable15 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(throwable15, "hi!", objArray17);
        java.lang.Throwable throwable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(throwable19, "hi!", objArray21);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        convergenceException18.addSuppressed((java.lang.Throwable) convergenceException22);
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, "org.apache.commons.math.ConvergenceException: hi!", objArray26);
        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable14, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathException31);
        java.lang.Throwable throwable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable33, "hi!", objArray35);
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException36, "", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = convergenceException36.getGeneralPattern();
        java.lang.Throwable throwable41 = null;
        java.lang.Throwable throwable43 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(throwable43, "hi!", objArray45);
        java.lang.Object[] objArray48 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException46, "", objArray48);
        org.apache.commons.math.exception.util.Localizable localizable50 = convergenceException49.getGeneralPattern();
        java.lang.Throwable throwable51 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(throwable51, "hi!", objArray53);
        java.lang.Throwable throwable55 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(throwable55, "hi!", objArray57);
        java.lang.Throwable[] throwableArray59 = convergenceException58.getSuppressed();
        convergenceException54.addSuppressed((java.lang.Throwable) convergenceException58);
        java.lang.Object[] objArray62 = null;
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException58, "org.apache.commons.math.ConvergenceException: hi!", objArray62);
        java.lang.Throwable[] throwableArray64 = convergenceException63.getSuppressed();
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(localizable50, (java.lang.Object[]) throwableArray64);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException(throwable41, "", (java.lang.Object[]) throwableArray64);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, localizable40, (java.lang.Object[]) throwableArray64);
        java.lang.Number number70 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException(localizable40, (java.lang.Number) 118L, (java.lang.Number) 1.180678914967459E-9d, number70);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 4.600161852571429d, (java.lang.Number) 155.74607629780772d, true);
        boolean boolean76 = numberIsTooSmallException75.getBoundIsAllowed();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 105L + "'", number6.equals(105L));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(localizable50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException(throwable2, "hi!", objArray4);
        java.lang.Throwable[] throwableArray6 = convergenceException5.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(52, "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041", (java.lang.Object[]) throwableArray6);
        int int8 = maxIterationsExceededException7.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double2 = org.apache.commons.math.util.FastMath.pow(5.347084854209185d, 5.551115123125783E-17d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5234978164981341d + "'", double1 == 0.5234978164981341d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.031743366520231894d + "'", double1 == 0.031743366520231894d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.8427007929497151d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1217129806834838d) + "'", double1 == (-1.1217129806834838d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(118.00000000000001d, 0.999875764595612d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 118.0d + "'", double2 == 118.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7913031001334778d) + "'", double1 == (-0.7913031001334778d));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException(throwable1, "hi!", objArray3);
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException4, "", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        java.lang.Throwable throwable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, "hi!", objArray11);
        java.lang.Throwable throwable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(throwable13, "hi!", objArray15);
        java.lang.Throwable[] throwableArray17 = convergenceException16.getSuppressed();
        convergenceException12.addSuppressed((java.lang.Throwable) convergenceException16);
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException16, "org.apache.commons.math.ConvergenceException: hi!", objArray20);
        java.lang.Throwable[] throwableArray22 = convergenceException21.getSuppressed();
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException(localizable8, (java.lang.Object[]) throwableArray22);
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable8, objArray24);
        int int26 = maxIterationsExceededException25.getMaxIterations();
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(throwable27, "hi!", objArray29);
        java.lang.Object[] objArray32 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException30, "", objArray32);
        java.lang.String str34 = convergenceException30.toString();
        maxIterationsExceededException25.addSuppressed((java.lang.Throwable) convergenceException30);
        java.lang.String str36 = maxIterationsExceededException25.getPattern();
        java.lang.String str37 = maxIterationsExceededException25.getPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32 + "'", int26 == 32);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.apache.commons.math.ConvergenceException: hi!" + "'", str34.equals("org.apache.commons.math.ConvergenceException: hi!"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        double double7 = randomDataImpl0.nextUniform(0.0d, (double) 1L);
//        try {
//            randomDataImpl0.setSecureAlgorithm("51e095b11819b59807101a48841667d3ddd2b26d60bf1de0ad4cfa1752fc514561ee86931125e6fcbe2b2624b7f23b601859", "47525d14781e16cd70ba1bde46604edb69faf07887dca405aea1875acfe1358de5cad9bde972b53ac23d02c21bf0b7b2596b");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 47525d14781e16cd70ba1bde46604edb69faf07887dca405aea1875acfe1358de5cad9bde972b53ac23d02c21bf0b7b2596b");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 95L + "'", long2 == 95L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6570187579156571d + "'", double7 == 0.6570187579156571d);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 51L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.0d + "'", double1 == 51.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.718281828459045d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.66161881444429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2811956688158854d + "'", double1 == 1.2811956688158854d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 116L, (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 116.0d + "'", double2 == 116.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 1, (java.lang.Number) (-1.0f), (java.lang.Number) 0.017453292519943295d);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4);
        java.lang.Throwable throwable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(throwable7, "hi!", objArray9);
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException10, "", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, "", objArray12);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041", objArray12);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(118.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.059488517353309d + "'", double1 == 2.059488517353309d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double1 = org.apache.commons.math.util.FastMath.asinh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.4695362923256565d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math.util.FastMath.atan(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        int int5 = randomDataImpl0.nextBinomial((int) (byte) 0, 1.4428584349276598E-9d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("", "org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 93L + "'", long2 == 93L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability(0.3667424245079105d);
        try {
            double[] doubleArray4 = normalDistributionImpl0.sample((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6430944209998493d + "'", double2 == 0.6430944209998493d);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        double double7 = randomDataImpl0.nextBeta(0.009784837054594254d, (double) 10L);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 88L + "'", long2 == 88L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.5285140709094763E-9d + "'", double7 == 1.5285140709094763E-9d);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math.special.Erf.erf(47.95358161942444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 52);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6929693744344998d + "'", double1 == 1.6929693744344998d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double2 = org.apache.commons.math.util.FastMath.min(44.68930991492643d, 0.17076042790120838d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.17076042790120838d + "'", double2 == 0.17076042790120838d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.99822295029797d, 4.644483341943245d, 4.600161852571429d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 101L, 15.154262241479262d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4218651076456337d + "'", double2 == 1.4218651076456337d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, number5, (java.lang.Number) 105L, false);
        java.lang.Number number9 = numberIsTooSmallException8.getArgument();
        java.lang.Number number10 = numberIsTooSmallException8.getMin();
        java.lang.Throwable throwable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(throwable11, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException14, "", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException17.getGeneralPattern();
        java.lang.Throwable throwable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(throwable19, "hi!", objArray21);
        java.lang.Throwable throwable23 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(throwable23, "hi!", objArray25);
        java.lang.Throwable[] throwableArray27 = convergenceException26.getSuppressed();
        convergenceException22.addSuppressed((java.lang.Throwable) convergenceException26);
        java.lang.Object[] objArray30 = null;
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException26, "org.apache.commons.math.ConvergenceException: hi!", objArray30);
        java.lang.Throwable[] throwableArray32 = convergenceException31.getSuppressed();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable18, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException33);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException34);
        numberIsTooSmallException8.addSuppressed((java.lang.Throwable) mathException35);
        java.lang.Throwable throwable37 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(throwable37, "hi!", objArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException40, "", objArray42);
        org.apache.commons.math.exception.util.Localizable localizable44 = convergenceException40.getGeneralPattern();
        java.lang.Throwable throwable45 = null;
        java.lang.Throwable throwable47 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(throwable47, "hi!", objArray49);
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException50, "", objArray52);
        org.apache.commons.math.exception.util.Localizable localizable54 = convergenceException53.getGeneralPattern();
        java.lang.Throwable throwable55 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(throwable55, "hi!", objArray57);
        java.lang.Throwable throwable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException(throwable59, "hi!", objArray61);
        java.lang.Throwable[] throwableArray63 = convergenceException62.getSuppressed();
        convergenceException58.addSuppressed((java.lang.Throwable) convergenceException62);
        java.lang.Object[] objArray66 = null;
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException62, "org.apache.commons.math.ConvergenceException: hi!", objArray66);
        java.lang.Throwable[] throwableArray68 = convergenceException67.getSuppressed();
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(localizable54, (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException(throwable45, "", (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException8, localizable44, (java.lang.Object[]) throwableArray68);
        java.lang.Object[] objArray73 = null;
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException71, "", objArray73);
        java.lang.Object[] objArray75 = convergenceException71.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "org.apache.commons.math.ConvergenceException: hi!", objArray75);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException77 = new org.apache.commons.math.MaxIterationsExceededException(1, "", objArray75);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 105L + "'", number10.equals(105L));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(localizable54);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(throwableArray63);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertNotNull(objArray75);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(100);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        int int3 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.1422808082595999d, (double) 45L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.special.Erf.erf((-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.019691932154573932d) + "'", double1 == (-0.019691932154573932d));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double1 = org.apache.commons.math.util.FastMath.log(4.524514827724147d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5095103510109185d + "'", double1 == 1.5095103510109185d);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf((int) (short) 100, 1.665672727543436d);
//        long long6 = randomDataImpl0.nextSecureLong((long) (short) -1, 0L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double[] doubleArray2 = normalDistributionImpl0.sample(32);
        double[] doubleArray4 = normalDistributionImpl0.sample(1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Object[] objArray8 = convergenceException6.getArguments();
        java.lang.String str9 = convergenceException6.getPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.5130380755642154d, (double) ' ', 1.0d, 52);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.586137717495309E-14d + "'", double4 == 8.586137717495309E-14d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        java.lang.Class<?> wildcardClass2 = notStrictlyPositiveException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(throwable8, "hi!", objArray10);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        convergenceException11.addSuppressed((java.lang.Throwable) convergenceException15);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "org.apache.commons.math.ConvergenceException: hi!", objArray19);
        java.lang.Throwable[] throwableArray21 = convergenceException20.getSuppressed();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException23);
        java.lang.Throwable[] throwableArray25 = convergenceException23.getSuppressed();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray25);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) (short) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double6 = normalDistributionImpl4.cumulativeProbability((double) 97.0f);
//        double double7 = normalDistributionImpl4.sample();
//        double double8 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        double double9 = normalDistributionImpl4.getMean();
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0525892241343182d + "'", double7 == 1.0525892241343182d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5888219938221677d + "'", double8 == 0.5888219938221677d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        java.lang.Throwable throwable20 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(throwable20, "hi!", objArray22);
        java.lang.Throwable throwable24 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(throwable24, "hi!", objArray26);
        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
        convergenceException23.addSuppressed((java.lang.Throwable) convergenceException27);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException27, "org.apache.commons.math.ConvergenceException: hi!", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable19, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable7, (java.lang.Object[]) throwableArray33);
        java.lang.Throwable throwable36 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, "hi!", objArray38);
        java.lang.Throwable throwable40 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(throwable40, "hi!", objArray42);
        java.lang.Throwable[] throwableArray44 = convergenceException43.getSuppressed();
        convergenceException39.addSuppressed((java.lang.Throwable) convergenceException43);
        java.lang.Object[] objArray47 = null;
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException43, "org.apache.commons.math.ConvergenceException: hi!", objArray47);
        java.lang.Throwable[] throwableArray49 = convergenceException48.getSuppressed();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray49);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException54 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1, (java.lang.Number) 0.5772156649015329d, true);
        java.lang.Object[] objArray55 = numberIsTooLargeException54.getArguments();
        mathException50.addSuppressed((java.lang.Throwable) numberIsTooLargeException54);
        java.lang.Object[] objArray57 = mathException50.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray57);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy(100.0d, (double) (byte) 100);
//        double double6 = randomDataImpl0.nextF((double) 8L, 0.3650768932609182d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 162.1605745804084d + "'", double3 == 162.1605745804084d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 77823.6502245294d + "'", double6 == 77823.6502245294d);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        randomDataImpl0.reSeedSecure((long) ' ');
        int int13 = randomDataImpl0.nextHypergeometric((int) (short) 100, 0, (int) (short) 0);
        try {
            java.lang.String str15 = randomDataImpl0.nextSecureHexString((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability((double) 97.0f);
        java.lang.Class<?> wildcardClass3 = normalDistributionImpl0.getClass();
        double double6 = normalDistributionImpl0.cumulativeProbability(0.0d, 0.9999998903978647d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.34134471954803347d + "'", double6 == 0.34134471954803347d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 88.58082754219768d + "'", double1 == 88.58082754219768d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextCauchy(0.0d, 1.5130380755642154d);
        long long7 = randomDataImpl0.nextPoisson(1.66161881444429d);
        try {
            double double10 = randomDataImpl0.nextBeta(0.0d, 0.5888219938221677d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.244");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.3375619403500054d + "'", double5 == 1.3375619403500054d);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.1622776601683795d, 1.356360972744053E-9d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 52, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        try {
            double double10 = randomDataImpl0.nextF(0.8813735870195429d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.005370665480790587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.673617379884035E-19d + "'", double1 == 8.673617379884035E-19d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(100);
        java.lang.String str2 = maxIterationsExceededException1.getPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str2.equals("maximal number of iterations ({0}) exceeded"));
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        double double4 = randomDataImpl0.nextChiSquare((double) 45L);
//        randomDataImpl0.reSeedSecure((long) '4');
//        try {
//            int int9 = randomDataImpl0.nextInt((int) (short) 10, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (-1): lower bound (10) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 101L + "'", long2 == 101L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 56.116738898427656d + "'", double4 == 56.116738898427656d);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.00975536087541375d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000475839102714d + "'", double1 == 1.0000475839102714d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        java.lang.Throwable throwable20 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(throwable20, "hi!", objArray22);
        java.lang.Throwable throwable24 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(throwable24, "hi!", objArray26);
        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
        convergenceException23.addSuppressed((java.lang.Throwable) convergenceException27);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException27, "org.apache.commons.math.ConvergenceException: hi!", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable19, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable7, (java.lang.Object[]) throwableArray33);
        java.lang.Throwable throwable36 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, "hi!", objArray38);
        java.lang.Throwable throwable40 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(throwable40, "hi!", objArray42);
        java.lang.Throwable[] throwableArray44 = convergenceException43.getSuppressed();
        convergenceException39.addSuppressed((java.lang.Throwable) convergenceException43);
        java.lang.Object[] objArray47 = null;
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException43, "org.apache.commons.math.ConvergenceException: hi!", objArray47);
        java.lang.Throwable[] throwableArray49 = convergenceException48.getSuppressed();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray49);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException54 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1, (java.lang.Number) 0.5772156649015329d, true);
        java.lang.Object[] objArray55 = numberIsTooLargeException54.getArguments();
        mathException50.addSuppressed((java.lang.Throwable) numberIsTooLargeException54);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooLargeException54.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNull(localizable57);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        randomDataImpl1.reSeedSecure((long) 'a');
        try {
            java.lang.String str7 = randomDataImpl1.nextHexString((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        long long2 = org.apache.commons.math.util.FastMath.min((-1L), (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        try {
//            int int7 = randomDataImpl0.nextSecureInt(100, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (0): lower bound (100) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 92L + "'", long2 == 92L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-76.71582800353974d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.009784837054594254d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.784833931829355E-4d + "'", double2 == 9.784833931829355E-4d);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long4 = randomDataImpl1.nextLong((long) '#', (long) (byte) 100);
//        double double6 = randomDataImpl1.nextChiSquare(0.36674242450791045d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("hi!", "0ad4e51286");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 0ad4e51286");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 36L + "'", long4 == 36L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.7034254466545236E-9d + "'", double6 == 1.7034254466545236E-9d);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.180678914967459E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.469703219092953E8d) + "'", double1 == (-8.469703219092953E8d));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        long long1 = org.apache.commons.math.util.FastMath.abs(83L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 83L + "'", long1 == 83L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 5, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 100L, 0.34946096378210023d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        double double7 = randomDataImpl0.nextUniform(0.0d, (double) 1L);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution8 = null;
//        try {
//            double double9 = randomDataImpl0.nextInversionDeviate(continuousDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 112L + "'", long2 == 112L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.09399460051428343d + "'", double7 == 0.09399460051428343d);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Object[] objArray8 = convergenceException6.getArguments();
        java.lang.Object[] objArray9 = convergenceException6.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 345.37940706226686d + "'", double1 == 345.37940706226686d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 118.0d, (double) (short) -1);
        double double4 = normalDistributionImpl3.getMean();
        double double5 = normalDistributionImpl3.getStandardDeviation();
        double[] doubleArray7 = normalDistributionImpl3.sample((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 118.0d + "'", double5 == 118.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.3650768932609182d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.067384026056675d + "'", double1 == 1.067384026056675d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3124383412727525d + "'", double1 == 2.3124383412727525d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        double double8 = randomDataImpl1.nextWeibull((double) '4', (double) (byte) 1);
        try {
            int int11 = randomDataImpl1.nextInt((int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (0): lower bound (32) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.977787856101637d + "'", double8 == 0.977787856101637d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1.3991949460826119d), (-0.009755051424170096d), (double) 97.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.01 is smaller than, or equal to, the minimum (0): standard deviation (-0.01)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 105L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        java.lang.Throwable throwable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(throwable7, "hi!", objArray9);
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException10, "", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        java.lang.Throwable throwable15 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(throwable15, "hi!", objArray17);
        java.lang.Throwable throwable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(throwable19, "hi!", objArray21);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        convergenceException18.addSuppressed((java.lang.Throwable) convergenceException22);
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, "org.apache.commons.math.ConvergenceException: hi!", objArray26);
        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable14, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathException31);
        java.lang.Throwable throwable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable33, "hi!", objArray35);
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException36, "", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = convergenceException36.getGeneralPattern();
        java.lang.Throwable throwable41 = null;
        java.lang.Throwable throwable43 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(throwable43, "hi!", objArray45);
        java.lang.Object[] objArray48 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException46, "", objArray48);
        org.apache.commons.math.exception.util.Localizable localizable50 = convergenceException49.getGeneralPattern();
        java.lang.Throwable throwable51 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(throwable51, "hi!", objArray53);
        java.lang.Throwable throwable55 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(throwable55, "hi!", objArray57);
        java.lang.Throwable[] throwableArray59 = convergenceException58.getSuppressed();
        convergenceException54.addSuppressed((java.lang.Throwable) convergenceException58);
        java.lang.Object[] objArray62 = null;
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException58, "org.apache.commons.math.ConvergenceException: hi!", objArray62);
        java.lang.Throwable[] throwableArray64 = convergenceException63.getSuppressed();
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(localizable50, (java.lang.Object[]) throwableArray64);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException(throwable41, "", (java.lang.Object[]) throwableArray64);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, localizable40, (java.lang.Object[]) throwableArray64);
        java.lang.Number number70 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException(localizable40, (java.lang.Number) 118L, (java.lang.Number) 1.180678914967459E-9d, number70);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 4.600161852571429d, (java.lang.Number) 155.74607629780772d, true);
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException75);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 105L + "'", number6.equals(105L));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(localizable50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertNotNull(throwableArray64);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long4 = randomDataImpl1.nextLong((long) '#', (long) (byte) 100);
//        double double6 = randomDataImpl1.nextChiSquare(0.36674242450791045d);
//        try {
//            int int9 = randomDataImpl1.nextSecureInt((int) '4', (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (-1): lower bound (52) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 59L + "'", long4 == 59L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.868210662308423E-8d + "'", double6 == 4.868210662308423E-8d);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 118.0d, (double) (short) -1);
        double double4 = normalDistributionImpl3.getMean();
        double double5 = normalDistributionImpl3.getStandardDeviation();
        double double6 = normalDistributionImpl3.getStandardDeviation();
        double double8 = normalDistributionImpl3.cumulativeProbability(0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 118.0d + "'", double5 == 118.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 118.0d + "'", double6 == 118.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Throwable[] throwableArray4 = convergenceException3.getSuppressed();
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(throwable6, "hi!", objArray8);
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException12.getGeneralPattern();
        java.lang.Throwable throwable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(throwable14, "hi!", objArray16);
        java.lang.Throwable throwable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(throwable18, "hi!", objArray20);
        java.lang.Throwable[] throwableArray22 = convergenceException21.getSuppressed();
        convergenceException17.addSuppressed((java.lang.Throwable) convergenceException21);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21, "org.apache.commons.math.ConvergenceException: hi!", objArray25);
        java.lang.Throwable[] throwableArray27 = convergenceException26.getSuppressed();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable13, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, "", (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        convergenceException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException33);
        boolean boolean35 = numberIsTooLargeException33.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.5077780472135416d), (double) '4');
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.5604874136486533d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 89.40934278535333d + "'", double1 == 89.40934278535333d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100, (java.lang.Number) (-1.0d), (java.lang.Number) Double.NEGATIVE_INFINITY);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 10, 45L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) (short) 100);
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
//        long long8 = randomDataImpl1.nextSecureLong((long) 0, (long) (short) 10);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl1.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9L + "'", long8 == 9L);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 51L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 51L + "'", long2 == 51L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        java.lang.String str6 = numberIsTooLargeException3.toString();
        java.lang.Object[] objArray7 = numberIsTooLargeException3.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException3.getGeneralPattern();
        boolean boolean9 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooLargeException14.getSpecificPattern();
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException14);
        java.lang.String str17 = numberIsTooLargeException14.toString();
        java.lang.Object[] objArray18 = numberIsTooLargeException14.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(localizable10, objArray18);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)"));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)" + "'", str17.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)"));
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.24197072451914334d, (double) 117L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1031908548556288E-53d + "'", double2 == 1.1031908548556288E-53d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 52, 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability((double) 97.0f);
        try {
            double double5 = normalDistributionImpl0.cumulativeProbability(155.74607629780772d, (double) 88);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(throwable8, "hi!", objArray10);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        convergenceException11.addSuppressed((java.lang.Throwable) convergenceException15);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "org.apache.commons.math.ConvergenceException: hi!", objArray19);
        java.lang.Throwable[] throwableArray21 = convergenceException20.getSuppressed();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException23);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException23.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 44.68930991492643d, (java.lang.Number) 116L, true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double2 = org.apache.commons.math.util.FastMath.max(1.180678914967459E-9d, (-0.008992146246399135d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.180678914967459E-9d + "'", double2 == 1.180678914967459E-9d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        double double9 = randomDataImpl0.nextExponential(0.4485633290585931d);
        try {
            double double12 = randomDataImpl0.nextF((-1.3991949460826119d), (-0.5495393129816448d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.399 is smaller than, or equal to, the minimum (0): degrees of freedom (-1.399)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.1422808082595999d + "'", double9 == 0.1422808082595999d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 52, (java.lang.Number) 101L, (java.lang.Number) 1.0000000000000003E-9d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 101L + "'", number4.equals(101L));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double4 = normalDistributionImpl0.density(1.0000000000000002d);
        try {
            double double7 = normalDistributionImpl0.cumulativeProbability(89.40934278535333d, 1.5285140709094763E-9d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.24197072451914334d + "'", double4 == 0.24197072451914334d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.40267377258000214d, (java.lang.Number) 0.5403023058681398d, false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 105.0d, (java.lang.Number) (byte) 100, false);
        java.lang.Throwable throwable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(throwable4, "hi!", objArray6);
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException10.getGeneralPattern();
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Throwable throwable16 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(throwable16, "hi!", objArray18);
        java.lang.Throwable[] throwableArray20 = convergenceException19.getSuppressed();
        convergenceException15.addSuppressed((java.lang.Throwable) convergenceException19);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException19, "org.apache.commons.math.ConvergenceException: hi!", objArray23);
        java.lang.Throwable[] throwableArray25 = convergenceException24.getSuppressed();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable11, (java.lang.Object[]) throwableArray25);
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(throwable27, "hi!", objArray29);
        java.lang.Object[] objArray32 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException30, "", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = convergenceException33.getGeneralPattern();
        java.lang.Throwable throwable35 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(throwable35, "hi!", objArray37);
        java.lang.Throwable throwable39 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(throwable39, "hi!", objArray41);
        java.lang.Throwable[] throwableArray43 = convergenceException42.getSuppressed();
        convergenceException38.addSuppressed((java.lang.Throwable) convergenceException42);
        java.lang.Object[] objArray46 = null;
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException42, "org.apache.commons.math.ConvergenceException: hi!", objArray46);
        java.lang.Throwable[] throwableArray48 = convergenceException47.getSuppressed();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable34, (java.lang.Object[]) throwableArray48);
        java.lang.Throwable throwable50 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(throwable50, "hi!", objArray52);
        java.lang.Throwable[] throwableArray54 = convergenceException53.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable34, (java.lang.Object[]) throwableArray54);
        java.lang.Throwable throwable56 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(throwable56, "hi!", objArray58);
        java.lang.Throwable throwable60 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(throwable60, "hi!", objArray62);
        java.lang.Throwable[] throwableArray64 = convergenceException63.getSuppressed();
        convergenceException59.addSuppressed((java.lang.Throwable) convergenceException63);
        java.lang.Object[] objArray67 = null;
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException63, "org.apache.commons.math.ConvergenceException: hi!", objArray67);
        java.lang.Throwable[] throwableArray69 = convergenceException68.getSuppressed();
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException(localizable11, (java.lang.Object[]) throwableArray69);
        java.lang.Throwable throwable72 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(throwable72, "hi!", objArray74);
        java.lang.Throwable throwable76 = null;
        java.lang.Object[] objArray78 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException(throwable76, "hi!", objArray78);
        java.lang.Throwable[] throwableArray80 = convergenceException79.getSuppressed();
        convergenceException75.addSuppressed((java.lang.Throwable) convergenceException79);
        java.lang.Object[] objArray83 = null;
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException79, "org.apache.commons.math.ConvergenceException: hi!", objArray83);
        java.lang.Throwable[] throwableArray85 = convergenceException84.getSuppressed();
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException("hi!", (java.lang.Object[]) throwableArray85);
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException(localizable11, (java.lang.Object[]) throwableArray85);
        java.lang.Throwable throwable88 = null;
        java.lang.Object[] objArray90 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException(throwable88, "hi!", objArray90);
        java.lang.Object[] objArray93 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException91, "", objArray93);
        org.apache.commons.math.ConvergenceException convergenceException95 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, localizable11, objArray93);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertNotNull(throwableArray69);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(throwableArray80);
        org.junit.Assert.assertNotNull(throwableArray85);
        org.junit.Assert.assertNotNull(objArray90);
        org.junit.Assert.assertNotNull(objArray93);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(57.29577951308232d, 94.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999815377189943d + "'", double2 == 0.9999815377189943d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.40267377258000214d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.39504665644848797d) + "'", double1 == (-0.39504665644848797d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 5.298292365610485d, (java.lang.Number) 116L);
        numberIsTooSmallException11.addSuppressed((java.lang.Throwable) outOfRangeException15);
        java.lang.Number number17 = outOfRangeException15.getHi();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 116L + "'", number17.equals(116L));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double2 = org.apache.commons.math.util.FastMath.max(3.141592653589793d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.math.util.FastMath.acos(5.347084854209185d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.4428584349276598E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4428584349276598E-9d + "'", double1 == 1.4428584349276598E-9d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math.util.FastMath.cosh(94.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.331588108205448E40d + "'", double1 == 3.331588108205448E40d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-9d + "'", double1 == 1.0E-9d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.644483341943245d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08106152637093929d + "'", double1 == 0.08106152637093929d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(throwable8, "hi!", objArray10);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        convergenceException11.addSuppressed((java.lang.Throwable) convergenceException15);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "org.apache.commons.math.ConvergenceException: hi!", objArray19);
        java.lang.Throwable[] throwableArray21 = convergenceException20.getSuppressed();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException23);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray21);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException(throwable1, "hi!", objArray3);
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException4, "", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        java.lang.Throwable throwable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, "hi!", objArray11);
        java.lang.Throwable throwable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(throwable13, "hi!", objArray15);
        java.lang.Throwable[] throwableArray17 = convergenceException16.getSuppressed();
        convergenceException12.addSuppressed((java.lang.Throwable) convergenceException16);
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException16, "org.apache.commons.math.ConvergenceException: hi!", objArray20);
        java.lang.Throwable[] throwableArray22 = convergenceException21.getSuppressed();
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException(localizable8, (java.lang.Object[]) throwableArray22);
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable8, objArray24);
        int int26 = maxIterationsExceededException25.getMaxIterations();
        int int27 = maxIterationsExceededException25.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32 + "'", int26 == 32);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 32 + "'", int27 == 32);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(throwable8, "hi!", objArray10);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        convergenceException11.addSuppressed((java.lang.Throwable) convergenceException15);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "org.apache.commons.math.ConvergenceException: hi!", objArray19);
        java.lang.Throwable[] throwableArray21 = convergenceException20.getSuppressed();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray21);
        java.lang.Throwable throwable23 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(throwable23, "hi!", objArray25);
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException26, "", objArray28);
        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException29.getGeneralPattern();
        java.lang.Throwable throwable31 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(throwable31, "hi!", objArray33);
        java.lang.Throwable throwable35 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(throwable35, "hi!", objArray37);
        java.lang.Throwable[] throwableArray39 = convergenceException38.getSuppressed();
        convergenceException34.addSuppressed((java.lang.Throwable) convergenceException38);
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException38, "org.apache.commons.math.ConvergenceException: hi!", objArray42);
        java.lang.Throwable[] throwableArray44 = convergenceException43.getSuppressed();
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable30, (java.lang.Object[]) throwableArray44);
        java.lang.Throwable throwable46 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(throwable46, "hi!", objArray48);
        java.lang.Throwable[] throwableArray50 = convergenceException49.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable30, (java.lang.Object[]) throwableArray50);
        java.lang.Throwable throwable52 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(throwable52, "hi!", objArray54);
        java.lang.Throwable throwable56 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(throwable56, "hi!", objArray58);
        java.lang.Throwable[] throwableArray60 = convergenceException59.getSuppressed();
        convergenceException55.addSuppressed((java.lang.Throwable) convergenceException59);
        java.lang.Object[] objArray63 = null;
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException59, "org.apache.commons.math.ConvergenceException: hi!", objArray63);
        java.lang.Throwable[] throwableArray65 = convergenceException64.getSuppressed();
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray65);
        java.lang.Throwable throwable68 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException(throwable68, "hi!", objArray70);
        java.lang.Throwable throwable72 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(throwable72, "hi!", objArray74);
        java.lang.Throwable[] throwableArray76 = convergenceException75.getSuppressed();
        convergenceException71.addSuppressed((java.lang.Throwable) convergenceException75);
        java.lang.Object[] objArray79 = null;
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException75, "org.apache.commons.math.ConvergenceException: hi!", objArray79);
        java.lang.Throwable[] throwableArray81 = convergenceException80.getSuppressed();
        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException("hi!", (java.lang.Object[]) throwableArray81);
        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray81);
        org.apache.commons.math.exception.util.Localizable localizable84 = mathException83.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(throwableArray60);
        org.junit.Assert.assertNotNull(throwableArray65);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(throwableArray76);
        org.junit.Assert.assertNotNull(throwableArray81);
        org.junit.Assert.assertNotNull(localizable84);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (byte) 10, (double) 101L, 100.0d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.5234361951759435E-32d + "'", double4 == 4.5234361951759435E-32d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.009755051424170096d), 1.5095103510109185d, 7.338311150777212E44d, (int) 'a');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        double double7 = randomDataImpl0.nextUniform(0.0d, (double) 1L);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution8 = null;
//        try {
//            int int9 = randomDataImpl0.nextInversionDeviate(integerDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 68L + "'", long2 == 68L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2458976409962187d + "'", double7 == 0.2458976409962187d);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.505149978319906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.12058193734529499d) + "'", double1 == (-0.12058193734529499d));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double double1 = org.apache.commons.math.special.Erf.erf((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 52, (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) '#');
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextUniform((-0.5495393129816448d), (double) 94L);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 118.0d, (double) (short) -1);
        double double10 = normalDistributionImpl9.getMean();
        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution12 = null;
        try {
            double double13 = randomDataImpl0.nextInversionDeviate(continuousDistribution12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 68.51230874435387d + "'", double5 == 68.51230874435387d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-76.71582800353974d) + "'", double11 == (-76.71582800353974d));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.801827480081469d + "'", double1 == 12.801827480081469d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        long long2 = org.apache.commons.math.util.FastMath.max(1L, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException(throwable1, "hi!", objArray3);
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException4, "", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, number9, (java.lang.Number) 100.0d, false);
        java.lang.Throwable throwable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(throwable13, "hi!", objArray15);
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException16, "", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        java.lang.Throwable throwable21 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(throwable21, "hi!", objArray23);
        java.lang.Throwable throwable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(throwable25, "hi!", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        convergenceException24.addSuppressed((java.lang.Throwable) convergenceException28);
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException28, "org.apache.commons.math.ConvergenceException: hi!", objArray32);
        java.lang.Throwable[] throwableArray34 = convergenceException33.getSuppressed();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable20, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable8, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[]) throwableArray34);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(throwableArray34);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.977787856101637d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.977787856101637d + "'", double1 == 0.977787856101637d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double1 = org.apache.commons.math.util.FastMath.log10(155.74607629780772d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1924171143124243d + "'", double1 == 2.1924171143124243d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double2 = org.apache.commons.math.util.FastMath.max(0.7949577687638787d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.569547482465657d + "'", double1 == 4.569547482465657d);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        double double4 = randomDataImpl0.nextChiSquare((double) 45L);
//        double double6 = randomDataImpl0.nextExponential(0.017453292519943295d);
//        try {
//            java.lang.String str8 = randomDataImpl0.nextSecureHexString((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 88L + "'", long2 == 88L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 37.54058258833351d + "'", double4 == 37.54058258833351d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.019766690572462376d + "'", double6 == 0.019766690572462376d);
//    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        int int5 = randomDataImpl0.nextSecureInt(0, (int) (short) 1);
//        java.lang.String str7 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double9 = randomDataImpl0.nextT(5557.690612768985d);
//        double double12 = randomDataImpl0.nextUniform((double) (-1.0f), (double) 10.0f);
//        try {
//            int int15 = randomDataImpl0.nextBinomial(10, 44.68930991492643d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 44.689 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 81L + "'", long2 == 81L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4f0ff81407640a0bc7b67aff2805b220d76fbfcffc2008bc1e968d76a2359b2f1fdeb103eb4ef74a0905c281eca1c58facdc" + "'", str7.equals("4f0ff81407640a0bc7b67aff2805b220d76fbfcffc2008bc1e968d76a2359b2f1fdeb103eb4ef74a0905c281eca1c58facdc"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.41289028475171424d + "'", double9 == 0.41289028475171424d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 5.334238428317786d + "'", double12 == 5.334238428317786d);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        float float2 = org.apache.commons.math.util.FastMath.max(52.0f, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-57.29577951308232d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 1, (java.lang.Number) (-1.0f), (java.lang.Number) 0.017453292519943295d);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3);
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(throwable6, "hi!", objArray8);
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "", objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, "", objArray11);
        java.lang.Number number14 = outOfRangeException3.getLo();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-1.0f) + "'", number14.equals((-1.0f)));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-2.8305302825148724d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        double double9 = randomDataImpl0.nextExponential(0.4485633290585931d);
        try {
            double double12 = randomDataImpl0.nextGamma((-6.275580970711946d), 5.551115123125783E-17d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -6.276 is smaller than, or equal to, the minimum (0): alpha");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.1422808082595999d + "'", double9 == 0.1422808082595999d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 35L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.5095103510109185d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.147128399668605d + "'", double1 == 1.147128399668605d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        double double8 = randomDataImpl1.nextWeibull((double) '4', (double) (byte) 1);
        try {
            long long11 = randomDataImpl1.nextLong(58L, (long) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 58 is larger than, or equal to, the maximum (35): lower bound (58) must be strictly less than upper bound (35)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.977787856101637d + "'", double8 == 0.977787856101637d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 5.298292365610485d, (java.lang.Number) 116L);
        java.lang.Object[] objArray5 = outOfRangeException4.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("47525d14781e16cd70ba1bde46604edb69faf07887dca405aea1875acfe1358de5cad9bde972b53ac23d02c21bf0b7b2596b", objArray5);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math.special.Erf.erf(1.5095103510109185d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9672201989655437d + "'", double1 == 0.9672201989655437d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math.util.FastMath.acosh(26.240759798930277d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.960097834730633d + "'", double1 == 3.960097834730633d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextCauchy(0.0d, 1.5130380755642154d);
        long long7 = randomDataImpl0.nextPoisson(1.66161881444429d);
        try {
            double double10 = randomDataImpl0.nextF(1.147128399668605d, (-0.39504665644848797d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.395 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.395)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.3375619403500054d + "'", double5 == 1.3375619403500054d);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(12.801827480081469d, 1.4210854715202004E-14d, 11013.232920103323d, 97);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.436609250591996E-187d + "'", double4 == 1.436609250591996E-187d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(12.801827480081469d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08124407643300252d + "'", double1 == 0.08124407643300252d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(4.524514827724147d, 4.406157709407613E-7d, (double) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        double double8 = randomDataImpl0.nextWeibull(1.66161881444429d, 1.0000000000000003E-9d);
        try {
            int int11 = randomDataImpl0.nextZipf(5, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.827190116422218E-10d + "'", double8 == 4.827190116422218E-10d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.827190116422218E-10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.827190116422218E-10d + "'", double1 == 4.827190116422218E-10d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double1 = org.apache.commons.math.util.FastMath.floor((-8.469703219092953E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.46970322E8d) + "'", double1 == (-8.46970322E8d));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 97L, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        long long2 = org.apache.commons.math.util.FastMath.min(10L, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextCauchy(0.0d, 1.5130380755642154d);
        try {
            int int9 = randomDataImpl0.nextHypergeometric((int) '#', (int) (byte) 1, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (35): sample size (100) must be less than or equal to population size (35)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.3375619403500054d + "'", double5 == 1.3375619403500054d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.23447406570294205d, (double) 83L, 1.5430806348152437d, (int) '4');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.792736994144453E-39d + "'", double4 == 7.792736994144453E-39d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 105L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        java.lang.Number number8 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 105L + "'", number6.equals(105L));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 105L + "'", number7.equals(105L));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 105L + "'", number8.equals(105L));
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        double double4 = randomDataImpl0.nextChiSquare((double) 45L);
//        try {
//            randomDataImpl0.setSecureAlgorithm("47525d14781e16cd70ba1bde46604edb69faf07887dca405aea1875acfe1358de5cad9bde972b53ac23d02c21bf0b7b2596b", "51e095b11819b59807101a48841667d3ddd2b26d60bf1de0ad4cfa1752fc514561ee86931125e6fcbe2b2624b7f23b601859");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 51e095b11819b59807101a48841667d3ddd2b26d60bf1de0ad4cfa1752fc514561ee86931125e6fcbe2b2624b7f23b601859");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 109L + "'", long2 == 109L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 55.00807798573313d + "'", double4 == 55.00807798573313d);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 0.0f, 0.0d, 3.332204510175204d, 27);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy(100.0d, (double) (byte) 100);
//        try {
//            randomDataImpl0.setSecureAlgorithm("maximal number of iterations ({0}) exceeded", "5b560d6e4833e634e53822282c7e43a6135a19bd2b874f34d389ba42978470b069e106ffacc517804c5cd371b0e8596cd");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 5b560d6e4833e634e53822282c7e43a6135a19bd2b874f34d389ba42978470b069e106ffacc517804c5cd371b0e8596cd");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-395.7451254480553d) + "'", double3 == (-395.7451254480553d));
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5130380755642154d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9214924098848808d + "'", double1 == 0.9214924098848808d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 32L, 1.4428584349276598E-9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.73137E-319d + "'", double2 == 4.73137E-319d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1, (java.lang.Number) 0.5772156649015329d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.String str6 = numberIsTooLargeException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than the maximum (0.577)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than the maximum (0.577)"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 'a', (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.010309278350515464d + "'", double2 == 0.010309278350515464d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int3 = randomDataImpl0.nextZipf((int) (short) 100, 1.665672727543436d);
        randomDataImpl0.reSeed();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.7913031001334778d), (java.lang.Number) 0.5888219938221677d, false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, 0.0d, 4.569547482465657d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException(throwable1, "hi!", objArray3);
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException4, "", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, number9, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 3.332204510175204d, (java.lang.Number) 116L, (java.lang.Number) 97);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooLargeException21.getSpecificPattern();
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException21);
        java.lang.String str24 = numberIsTooLargeException21.toString();
        java.lang.Object[] objArray25 = numberIsTooLargeException21.getArguments();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException16, "48660e36d2fddeaffc0521face2d6e27fe6e3cdb8fbab5573166154e22acf0c88ea899d4d9abebba3ff785c92e0ed183b0f3", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("3035ea3a17", objArray25);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNull(localizable22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)" + "'", str24.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)"));
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double double1 = org.apache.commons.math.util.FastMath.log(1.4428584349276598E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-20.356639666660495d) + "'", double1 == (-20.356639666660495d));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.5077780472135416d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8738270591458991d + "'", double1 == 0.8738270591458991d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 97L, (double) (short) -1, 4.339317855293556d, 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString(10);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution3 = null;
//        try {
//            int int4 = randomDataImpl0.nextInversionDeviate(integerDistribution3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "45f0c66ea9" + "'", str2.equals("45f0c66ea9"));
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException(throwable2, "hi!", objArray4);
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException5, "", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getGeneralPattern();
        java.lang.Throwable throwable10 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(throwable10, "hi!", objArray12);
        java.lang.Throwable throwable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(throwable14, "hi!", objArray16);
        java.lang.Throwable[] throwableArray18 = convergenceException17.getSuppressed();
        convergenceException13.addSuppressed((java.lang.Throwable) convergenceException17);
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException17, "org.apache.commons.math.ConvergenceException: hi!", objArray21);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable9, (java.lang.Object[]) throwableArray23);
        java.lang.Throwable throwable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(throwable25, "hi!", objArray27);
        java.lang.Object[] objArray30 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException28, "", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        java.lang.Throwable throwable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable33, "hi!", objArray35);
        java.lang.Throwable throwable37 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(throwable37, "hi!", objArray39);
        java.lang.Throwable[] throwableArray41 = convergenceException40.getSuppressed();
        convergenceException36.addSuppressed((java.lang.Throwable) convergenceException40);
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException40, "org.apache.commons.math.ConvergenceException: hi!", objArray44);
        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable32, (java.lang.Object[]) throwableArray46);
        java.lang.Throwable throwable48 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(throwable48, "hi!", objArray50);
        java.lang.Throwable[] throwableArray52 = convergenceException51.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable32, (java.lang.Object[]) throwableArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", (java.lang.Object[]) throwableArray52);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException54);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(localizable32);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(throwableArray52);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        double double10 = randomDataImpl0.nextGamma((double) (byte) 100, 5.551115123125783E-17d);
        long long13 = randomDataImpl0.nextLong((long) 1, 101L);
        try {
            int int17 = randomDataImpl0.nextHypergeometric((int) 'a', (int) (short) 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of samples (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.356360972744053E-9d + "'", double10 == 1.356360972744053E-9d);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 51L + "'", long13 == 51L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double1 = org.apache.commons.math.util.FastMath.log(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5553480614894135d + "'", double1 == 3.5553480614894135d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator((long) (byte) 100);
        try {
            double double5 = normalDistributionImpl0.cumulativeProbability(0.0d, (-6.275580970711946d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 95L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 95.0f + "'", float1 == 95.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 51L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8901179185171081d + "'", double1 == 0.8901179185171081d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability((double) (byte) 0, 0.6264011299651113d);
        double double4 = normalDistributionImpl0.getStandardDeviation();
        try {
            double[] doubleArray6 = normalDistributionImpl0.sample((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.23447406570294205d + "'", double3 == 0.23447406570294205d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.8623188722876839d, (java.lang.Number) (-1L), (java.lang.Number) 0.0012799811882669438d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double1 = org.apache.commons.math.util.FastMath.sin(118.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9819521690440836d) + "'", double1 == (-0.9819521690440836d));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100, (java.lang.Number) (-1.0d), (java.lang.Number) Double.NEGATIVE_INFINITY);
        java.lang.String str4 = outOfRangeException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 100 out of [-1, -∞] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: 100 out of [-1, -∞] range"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        long long2 = org.apache.commons.math.util.FastMath.max(45L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45L + "'", long2 == 45L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 104.39390890801062d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(35.0d, 0.999875764595612d, 0.006622473314321887d);
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        randomDataImpl0.reSeedSecure(0L);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution7 = null;
//        try {
//            double double8 = randomDataImpl0.nextInversionDeviate(continuousDistribution7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator((long) (byte) 100);
        double double3 = normalDistributionImpl0.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (-1));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 5.298292365610485d, (java.lang.Number) 116L);
        numberIsTooSmallException11.addSuppressed((java.lang.Throwable) outOfRangeException15);
        boolean boolean17 = numberIsTooSmallException11.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException11.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) 3.332204510175204d, (java.lang.Number) 5.267831587699267d, false);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed((long) 10);
//        long long4 = randomDataImpl0.nextPoisson((double) 104L);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString(27);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "5e75f3a6e391d1bf0007061f9b7" + "'", str6.equals("5e75f3a6e391d1bf0007061f9b7"));
//    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        double double4 = randomDataImpl0.nextChiSquare((double) 45L);
//        try {
//            int[] intArray7 = randomDataImpl0.nextPermutation((int) (short) 1, 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than the maximum (1): permutation size (10) exceeds permuation domain (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 38.09924900363274d + "'", double4 == 38.09924900363274d);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double1 = org.apache.commons.math.util.FastMath.atan(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        long long4 = randomDataImpl0.nextPoisson((double) 104L);
        try {
            int int7 = randomDataImpl0.nextSecureInt(1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (-1): lower bound (1) must be strictly less than upper bound (-1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 4.339317855293556d, number13, false);
        java.lang.Number number16 = numberIsTooSmallException15.getMin();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(throwable8, "hi!", objArray10);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        convergenceException11.addSuppressed((java.lang.Throwable) convergenceException15);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "org.apache.commons.math.ConvergenceException: hi!", objArray19);
        java.lang.Throwable[] throwableArray21 = convergenceException20.getSuppressed();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooLargeException26.getSpecificPattern();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException26);
        java.lang.String str29 = numberIsTooLargeException26.toString();
        java.lang.Object[] objArray30 = numberIsTooLargeException26.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooLargeException26.getGeneralPattern();
        boolean boolean32 = numberIsTooLargeException26.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooLargeException26.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 2.99822295029797d, (java.lang.Number) (byte) 0, true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable33, (java.lang.Number) 97, (java.lang.Number) 105L, true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable46 = numberIsTooLargeException45.getSpecificPattern();
        java.lang.Throwable throwable48 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(throwable48, "hi!", objArray50);
        java.lang.Throwable throwable52 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(throwable52, "hi!", objArray54);
        java.lang.Throwable[] throwableArray56 = convergenceException55.getSuppressed();
        convergenceException51.addSuppressed((java.lang.Throwable) convergenceException55);
        java.lang.Object[] objArray59 = null;
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException55, "org.apache.commons.math.ConvergenceException: hi!", objArray59);
        java.lang.Throwable[] throwableArray61 = convergenceException60.getSuppressed();
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException45, "47525d14781e16cd70ba1bde46604edb69faf07887dca405aea1875acfe1358de5cad9bde972b53ac23d02c21bf0b7b2596b", (java.lang.Object[]) throwableArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable33, (java.lang.Object[]) throwableArray61);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNull(localizable27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)" + "'", str29.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)"));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable46);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertNotNull(throwableArray61);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.9214924098848808d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextUniform((-0.5495393129816448d), (double) 94L);
        double double8 = randomDataImpl0.nextGamma(0.23447406570294205d, 0.9672201989655437d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 68.51230874435387d + "'", double5 == 68.51230874435387d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.00199647099720634d + "'", double8 == 0.00199647099720634d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        randomDataImpl1.reSeedSecure();
        double double6 = randomDataImpl1.nextExponential((double) 100);
        try {
            int int9 = randomDataImpl1.nextBinomial((int) (short) 10, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.57167677969427d + "'", double6 == 32.57167677969427d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.008992146246399135d), (java.lang.Number) 8L, false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.12058193734529499d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.0f, (java.lang.Number) 100, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        java.lang.Throwable throwable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(throwable7, "hi!", objArray9);
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException10, "", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        java.lang.Throwable throwable15 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(throwable15, "hi!", objArray17);
        java.lang.Throwable throwable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(throwable19, "hi!", objArray21);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        convergenceException18.addSuppressed((java.lang.Throwable) convergenceException22);
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, "org.apache.commons.math.ConvergenceException: hi!", objArray26);
        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable14, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "hi!", (java.lang.Object[]) throwableArray28);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0f + "'", number4.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100 + "'", number5.equals(100));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        double double8 = randomDataImpl1.nextBeta(1.5430806348152437d, (double) 101L);
        long long10 = randomDataImpl1.nextPoisson(0.0174532925199433d);
        int int13 = randomDataImpl1.nextBinomial((int) (short) 100, 0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.006622473314321887d + "'", double8 == 0.006622473314321887d);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 58 + "'", int13 == 58);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.0000000000000003E-9d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 118L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.77912349311153d + "'", double1 == 4.77912349311153d);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) (short) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double6 = normalDistributionImpl4.cumulativeProbability((double) 97.0f);
//        double double7 = normalDistributionImpl4.sample();
//        double double8 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        try {
//            long long11 = randomDataImpl1.nextLong((long) '#', 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (0): lower bound (35) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.36834785148067534d) + "'", double7 == (-0.36834785148067534d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5888219938221677d + "'", double8 == 0.5888219938221677d);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double4 = randomDataImpl0.nextChiSquare((double) 35);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 39.670515905542324d + "'", double4 == 39.670515905542324d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        java.lang.Object[] objArray12 = numberIsTooSmallException11.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599454d + "'", double1 == 0.6931471805599454d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) (-0.8474827660881417d), true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-105.3294356130328d), 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-105.32943561303279d) + "'", double2 == (-105.32943561303279d));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 5.298292365610485d, (java.lang.Number) 116L);
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(throwable8, "hi!", objArray10);
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        java.lang.Throwable throwable16 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(throwable16, "hi!", objArray18);
        java.lang.Throwable throwable20 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(throwable20, "hi!", objArray22);
        java.lang.Throwable[] throwableArray24 = convergenceException23.getSuppressed();
        convergenceException19.addSuppressed((java.lang.Throwable) convergenceException23);
        java.lang.Object[] objArray27 = null;
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException23, "org.apache.commons.math.ConvergenceException: hi!", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(localizable15, (java.lang.Object[]) throwableArray29);
        java.lang.Throwable throwable31 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(throwable31, "hi!", objArray33);
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException34, "", objArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = convergenceException37.getGeneralPattern();
        java.lang.Throwable throwable39 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(throwable39, "hi!", objArray41);
        java.lang.Throwable throwable43 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(throwable43, "hi!", objArray45);
        java.lang.Throwable[] throwableArray47 = convergenceException46.getSuppressed();
        convergenceException42.addSuppressed((java.lang.Throwable) convergenceException46);
        java.lang.Object[] objArray50 = null;
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException46, "org.apache.commons.math.ConvergenceException: hi!", objArray50);
        java.lang.Throwable[] throwableArray52 = convergenceException51.getSuppressed();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException(localizable38, (java.lang.Object[]) throwableArray52);
        java.lang.Throwable throwable54 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(throwable54, "hi!", objArray56);
        java.lang.Throwable[] throwableArray58 = convergenceException57.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable38, (java.lang.Object[]) throwableArray58);
        java.lang.Throwable throwable60 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(throwable60, "hi!", objArray62);
        java.lang.Throwable throwable64 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException(throwable64, "hi!", objArray66);
        java.lang.Throwable[] throwableArray68 = convergenceException67.getSuppressed();
        convergenceException63.addSuppressed((java.lang.Throwable) convergenceException67);
        java.lang.Object[] objArray71 = null;
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException67, "org.apache.commons.math.ConvergenceException: hi!", objArray71);
        java.lang.Throwable[] throwableArray73 = convergenceException72.getSuppressed();
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException(localizable15, (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException78 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable79 = numberIsTooLargeException78.getSpecificPattern();
        java.lang.Throwable throwable81 = null;
        java.lang.Object[] objArray83 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException(throwable81, "hi!", objArray83);
        java.lang.Throwable throwable85 = null;
        java.lang.Object[] objArray87 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException(throwable85, "hi!", objArray87);
        java.lang.Throwable[] throwableArray89 = convergenceException88.getSuppressed();
        convergenceException84.addSuppressed((java.lang.Throwable) convergenceException88);
        java.lang.Object[] objArray92 = null;
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException88, "org.apache.commons.math.ConvergenceException: hi!", objArray92);
        java.lang.Throwable[] throwableArray94 = convergenceException93.getSuppressed();
        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException78, "47525d14781e16cd70ba1bde46604edb69faf07887dca405aea1875acfe1358de5cad9bde972b53ac23d02c21bf0b7b2596b", (java.lang.Object[]) throwableArray94);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException96 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable15, (java.lang.Object[]) throwableArray94);
        org.apache.commons.math.ConvergenceException convergenceException97 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, "51e095b11819b59807101a48841667d3ddd2b26d60bf1de0ad4cfa1752fc514561ee86931125e6fcbe2b2624b7f23b601859", (java.lang.Object[]) throwableArray94);
        org.apache.commons.math.ConvergenceException convergenceException98 = new org.apache.commons.math.ConvergenceException("5e75f3a6e391d1bf0007061f9b7", (java.lang.Object[]) throwableArray94);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 116L + "'", number5.equals(116L));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable38);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertNotNull(throwableArray73);
        org.junit.Assert.assertNull(localizable79);
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertNotNull(objArray87);
        org.junit.Assert.assertNotNull(throwableArray89);
        org.junit.Assert.assertNotNull(throwableArray94);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double double2 = org.apache.commons.math.util.FastMath.max(32.57167677969427d, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.57167677969427d + "'", double2 == 32.57167677969427d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double4 = normalDistributionImpl0.density(1.0000000000000002d);
        try {
            double double6 = normalDistributionImpl0.inverseCumulativeProbability((double) 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 52 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.24197072451914334d + "'", double4 == 0.24197072451914334d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        int int2 = org.apache.commons.math.util.FastMath.max(7, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double1 = org.apache.commons.math.util.FastMath.sinh(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 45L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8509035245341184d + "'", double1 == 0.8509035245341184d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.6574544541530771d, (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.017085496627355166d + "'", double2 == 0.017085496627355166d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 105.0d, (java.lang.Number) (byte) 100, false);
        java.lang.Throwable[] throwableArray4 = numberIsTooLargeException3.getSuppressed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 100 + "'", number6.equals((byte) 100));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        randomDataImpl1.reSeedSecure();
        try {
            int int7 = randomDataImpl1.nextZipf((int) (byte) 10, (-57.29577951308232d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -57.296 is smaller than, or equal to, the minimum (0): exponent (-57.296)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 88.58082754219768d, (java.lang.Number) 0.8623188722876839d, false);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 100.0f, 0.5234978164981341d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5655613964506483d + "'", double2 == 1.5655613964506483d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        randomDataImpl1.reSeedSecure((long) 'a');
        double double8 = randomDataImpl1.nextCauchy(1.6574544541530771d, (double) 97L);
        java.lang.String str10 = randomDataImpl1.nextHexString(27);
        try {
            double double13 = randomDataImpl1.nextBeta((-0.41032129904824216d), 7.105427357601002E-15d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.778");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 82.93979543186188d + "'", double8 == 82.93979543186188d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "c57369b1e963be37e7784a2af4d" + "'", str10.equals("c57369b1e963be37e7784a2af4d"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 58L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 58.0f + "'", float1 == 58.0f);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        long long9 = randomDataImpl0.nextPoisson((double) 118L);
        try {
            long long12 = randomDataImpl0.nextSecureLong((long) (short) 100, 32L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (32): lower bound (100) must be strictly less than upper bound (32)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 117L + "'", long9 == 117L);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        double double7 = randomDataImpl0.nextBeta(0.009784837054594254d, (double) 10L);
//        randomDataImpl0.reSeedSecure(35L);
//        randomDataImpl0.reSeed();
//        try {
//            long long13 = randomDataImpl0.nextLong(127L, 82L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 127 is larger than, or equal to, the maximum (82): lower bound (127) must be strictly less than upper bound (82)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 106L + "'", long2 == 106L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 9.176517291198808E-8d + "'", double7 == 9.176517291198808E-8d);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException(throwable2, "hi!", objArray4);
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException5, "", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getGeneralPattern();
        java.lang.Throwable throwable10 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(throwable10, "hi!", objArray12);
        java.lang.Throwable throwable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(throwable14, "hi!", objArray16);
        java.lang.Throwable[] throwableArray18 = convergenceException17.getSuppressed();
        convergenceException13.addSuppressed((java.lang.Throwable) convergenceException17);
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException17, "org.apache.commons.math.ConvergenceException: hi!", objArray21);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable9, (java.lang.Object[]) throwableArray23);
        java.lang.Throwable throwable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(throwable25, "hi!", objArray27);
        java.lang.Object[] objArray30 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException28, "", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        java.lang.Throwable throwable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable33, "hi!", objArray35);
        java.lang.Throwable throwable37 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(throwable37, "hi!", objArray39);
        java.lang.Throwable[] throwableArray41 = convergenceException40.getSuppressed();
        convergenceException36.addSuppressed((java.lang.Throwable) convergenceException40);
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException40, "org.apache.commons.math.ConvergenceException: hi!", objArray44);
        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable32, (java.lang.Object[]) throwableArray46);
        java.lang.Throwable throwable48 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(throwable48, "hi!", objArray50);
        java.lang.Throwable[] throwableArray52 = convergenceException51.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable32, (java.lang.Object[]) throwableArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", (java.lang.Object[]) throwableArray52);
        java.lang.Object[] objArray55 = maxIterationsExceededException54.getArguments();
        int int56 = maxIterationsExceededException54.getMaxIterations();
        int int57 = maxIterationsExceededException54.getMaxIterations();
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException54);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(localizable32);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 10 + "'", int56 == 10);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 105L, (java.lang.Number) 104L, (java.lang.Number) 3.1622776601683795d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 3.1622776601683795d + "'", number4.equals(3.1622776601683795d));
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.08106152637093929d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(5.347084854209185d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.347084854209186d + "'", double1 == 5.347084854209186d);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        double double7 = randomDataImpl0.nextUniform(0.0d, (double) 1L);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double11 = randomDataImpl0.nextWeibull(0.999875764595612d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 85L + "'", long2 == 85L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.31474133799798776d + "'", double7 == 0.31474133799798776d);
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double4 = normalDistributionImpl0.density(1.0000000000000002d);
        double double5 = normalDistributionImpl0.getMean();
        double double7 = normalDistributionImpl0.cumulativeProbability((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.24197072451914334d + "'", double4 == 0.24197072451914334d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        int int1 = org.apache.commons.math.util.FastMath.abs(27);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 27 + "'", int1 == 27);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 52, (java.lang.Number) 101L, (java.lang.Number) 1.0000000000000003E-9d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getSpecificPattern();
        java.lang.Throwable[] throwableArray5 = outOfRangeException3.getSuppressed();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.017085496627355166d, (double) 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3866480534218617E-62d + "'", double2 == 1.3866480534218617E-62d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        long long9 = randomDataImpl0.nextPoisson((double) 118L);
        try {
            double double12 = randomDataImpl0.nextWeibull(0.0d, 1.2811956688158854d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 117L + "'", long9 == 117L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.8509035245341184d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 1.6574544541530771d, (java.lang.Number) 105L, (java.lang.Number) 52.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.9614286869038096d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6176537574924793d) + "'", double1 == (-0.6176537574924793d));
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) (short) 100);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed(92L);
//        long long9 = randomDataImpl1.nextSecureLong((long) 32, 95L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 84L + "'", long9 == 84L);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 118.0d, (double) (short) -1);
        double double4 = normalDistributionImpl3.getMean();
        double[] doubleArray6 = normalDistributionImpl3.sample(59);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 4.406157709407613E-7d, true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 1, (java.lang.Number) (-1.0f), (java.lang.Number) 0.017453292519943295d);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3);
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0f) + "'", number5.equals((-1.0f)));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 26.240759798930277d, (java.lang.Number) 155.74607629780772d, false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }
}

