import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 116L, (float) 116L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 116.0f + "'", float2 == 116.0f);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 59);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.07753744390572d + "'", double1 == 4.07753744390572d);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed((long) 10);
//        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
//        randomDataImpl0.reSeed((long) '#');
//        double double10 = randomDataImpl0.nextGamma((double) (byte) 100, 5.551115123125783E-17d);
//        int int13 = randomDataImpl0.nextSecureInt((int) (short) -1, (int) (short) 100);
//        double double16 = randomDataImpl0.nextBeta((double) 58, (double) 45L);
//        try {
//            double double18 = randomDataImpl0.nextChiSquare((double) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.5 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.356360972744053E-9d + "'", double10 == 1.356360972744053E-9d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.5630763048687648d + "'", double16 == 0.5630763048687648d);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 116L, 1.505149978319906d, (double) 105L, 27);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        randomDataImpl1.reSeedSecure((long) 'a');
        int int8 = randomDataImpl1.nextZipf((int) (short) 100, (double) '4');
        randomDataImpl1.reSeed(0L);
        try {
            int int14 = randomDataImpl1.nextHypergeometric((int) (byte) 10, 58, 58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 58 is larger than the maximum (10): number of successes (58) must be less than or equal to population size (10)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        float float2 = org.apache.commons.math.util.FastMath.max(52.0f, (float) 88L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 88.0f + "'", float2 == 88.0f);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math.util.FastMath.signum((-9335.99058474676d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 5);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 1, (java.lang.Number) (-1.0f), (java.lang.Number) 0.017453292519943295d);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5);
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(throwable8, "hi!", objArray10);
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, "", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable1, objArray13);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("eaaaf5fad095380dd0cf5ed8602", objArray13);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        double double7 = randomDataImpl0.nextUniform(0.0d, (double) 1L);
//        randomDataImpl0.reSeedSecure();
//        double double10 = randomDataImpl0.nextExponential(4.440892098500626E-16d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 110L + "'", long2 == 110L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.10015847291903901d + "'", double7 == 0.10015847291903901d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.98968579737588E-16d + "'", double10 == 3.98968579737588E-16d);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int2 = org.apache.commons.math.util.FastMath.min(97, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math.util.FastMath.sin(15.154262241479262d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5258388577743273d + "'", double1 == 0.5258388577743273d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        java.lang.Throwable throwable20 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(throwable20, "hi!", objArray22);
        java.lang.Throwable throwable24 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(throwable24, "hi!", objArray26);
        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
        convergenceException23.addSuppressed((java.lang.Throwable) convergenceException27);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException27, "org.apache.commons.math.ConvergenceException: hi!", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable19, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable7, (java.lang.Object[]) throwableArray33);
        java.lang.Throwable throwable36 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, "hi!", objArray38);
        java.lang.Throwable throwable40 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(throwable40, "hi!", objArray42);
        java.lang.Throwable[] throwableArray44 = convergenceException43.getSuppressed();
        convergenceException39.addSuppressed((java.lang.Throwable) convergenceException43);
        java.lang.Object[] objArray47 = null;
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException43, "org.apache.commons.math.ConvergenceException: hi!", objArray47);
        java.lang.Throwable[] throwableArray49 = convergenceException48.getSuppressed();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray49);
        java.lang.Throwable throwable51 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(throwable51, "hi!", objArray53);
        java.lang.Throwable[] throwableArray55 = convergenceException54.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException60 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 155.74607629780772d, (java.lang.Number) 15.154262241479262d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 4.524514827724147d);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(throwableArray55);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 8.673617379884035E-19d, (java.lang.Number) 0.009784837054594254d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.abs(89.40934278535333d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 89.40934278535333d + "'", double1 == 89.40934278535333d);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) (short) 100);
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
//        double double8 = randomDataImpl1.nextWeibull((double) '4', (double) (byte) 1);
//        double double10 = randomDataImpl1.nextT((double) 1L);
//        randomDataImpl1.reSeed();
//        double double13 = randomDataImpl1.nextChiSquare((double) 97L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.977787856101637d + "'", double8 == 0.977787856101637d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-2.8305302825148724d) + "'", double10 == (-2.8305302825148724d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 73.37132434358908d + "'", double13 == 73.37132434358908d);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextBeta(0.0d, 47.95358161942444d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.031");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(100);
        int int4 = maxIterationsExceededException3.getMaxIterations();
        java.lang.Throwable[] throwableArray5 = maxIterationsExceededException3.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("c57369b1e963be37e7784a2af4d", (java.lang.Object[]) throwableArray5);
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable0, (java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 116L, (java.lang.Number) 95.0f, true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.6453838090716478d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 105.0d, (java.lang.Number) (byte) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        int int2 = org.apache.commons.math.util.FastMath.max(32, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 152.40959258449735d + "'", double1 == 152.40959258449735d);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) (short) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double6 = normalDistributionImpl4.cumulativeProbability((double) 97.0f);
//        double double7 = normalDistributionImpl4.sample();
//        double double8 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        try {
//            double double11 = randomDataImpl1.nextUniform(0.765039386526217d, 0.765039386526217d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0.765 is larger than, or equal to, the maximum (0.765): lower bound (0.765) must be strictly less than upper bound (0.765)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.46028391980833194d) + "'", double7 == (-0.46028391980833194d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5888219938221677d + "'", double8 == 0.5888219938221677d);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(50.44490929979055d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.020021391805349825d + "'", double1 == 0.020021391805349825d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextWeibull((double) (byte) 0, (double) 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 1, (java.lang.Number) (-1.0f), (java.lang.Number) 0.017453292519943295d);
        java.lang.Class<?> wildcardClass4 = outOfRangeException3.getClass();
        java.lang.Number number5 = outOfRangeException3.getHi();
        java.lang.Number number6 = outOfRangeException3.getLo();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.017453292519943295d + "'", number5.equals(0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0f) + "'", number6.equals((-1.0f)));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        double double7 = randomDataImpl0.nextBeta(0.009784837054594254d, (double) 10L);
//        randomDataImpl0.reSeedSecure(35L);
//        randomDataImpl0.reSeed(97L);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str15 = randomDataImpl0.nextHexString(7);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 117L + "'", long2 == 117L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0261558606821757E-9d + "'", double7 == 1.0261558606821757E-9d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1cbc673" + "'", str15.equals("1cbc673"));
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.0525892241343182d, 4.440892098500626E-16d, (double) 127L, 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.761661175625663E-17d + "'", double4 == 6.761661175625663E-17d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6264011299651113d, 11013.232920103323d);
        double double3 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6264011299651113d + "'", double3 == 0.6264011299651113d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.331588108205448E40d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.436609250591996E-187d, (java.lang.Number) 0.8577443895511387d, (java.lang.Number) 0.9999815377189943d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(7.792736994144453E-39d, (double) 92L, 0.40267377258000214d, (int) '#');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.293170267196957E-81d + "'", double4 == 9.293170267196957E-81d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0525892241343182d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02225891962106638d + "'", double1 == 0.02225891962106638d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        float float1 = org.apache.commons.math.util.FastMath.abs(52.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double2 = org.apache.commons.math.util.FastMath.max(1.107943536736182d, 2.1924171143124243d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1924171143124243d + "'", double2 == 2.1924171143124243d);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 100, (java.lang.Number) 97.0f, false);
//        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 100);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 105.0d, (java.lang.Number) (byte) 100, false);
//        java.lang.Throwable[] throwableArray14 = numberIsTooLargeException13.getSuppressed();
//        java.lang.Number number15 = numberIsTooLargeException13.getMax();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl17 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str19 = randomDataImpl17.nextSecureHexString(10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double22 = normalDistributionImpl20.cumulativeProbability((double) 97.0f);
//        java.lang.Class<?> wildcardClass23 = normalDistributionImpl20.getClass();
//        double double24 = randomDataImpl17.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        java.lang.Object[] objArray25 = new java.lang.Object[] { (byte) 10, number15, (byte) 10, double24 };
//        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException7, "3035ea3a17", objArray25);
//        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "3035ea3a17", objArray25);
//        java.lang.String str28 = convergenceException27.getPattern();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(throwableArray14);
//        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) 100 + "'", number15.equals((byte) 100));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ffce6ac281" + "'", str19.equals("ffce6ac281"));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.09688391243458824d + "'", double24 == 0.09688391243458824d);
//        org.junit.Assert.assertNotNull(objArray25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "3035ea3a17" + "'", str28.equals("3035ea3a17"));
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.abs(8.586137717495309E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.586137717495309E-14d + "'", double1 == 8.586137717495309E-14d);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed((long) 10);
//        long long4 = randomDataImpl0.nextPoisson((double) 104L);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString(27);
//        try {
//            double double9 = randomDataImpl0.nextBeta((double) 52, (-0.8474827660881417d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.856");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "5a4339d6a5e6d24b7e63f07d3af" + "'", str6.equals("5a4339d6a5e6d24b7e63f07d3af"));
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        java.lang.String str6 = randomDataImpl0.nextHexString(97);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "e3f05cbb4d5a0ab311200cba1f72e41fe704cd73f352f47ed573acbc857f5839fadaee887bba7f0b715f476c65bfaa289" + "'", str6.equals("e3f05cbb4d5a0ab311200cba1f72e41fe704cd73f352f47ed573acbc857f5839fadaee887bba7f0b715f476c65bfaa289"));
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 5.298292365610485d, (java.lang.Number) 116L);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 116L + "'", number4.equals(116L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 5.298292365610485d + "'", number5.equals(5.298292365610485d));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 105L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        java.lang.Throwable throwable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(throwable7, "hi!", objArray9);
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException10, "", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        java.lang.Throwable throwable15 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(throwable15, "hi!", objArray17);
        java.lang.Throwable throwable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(throwable19, "hi!", objArray21);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        convergenceException18.addSuppressed((java.lang.Throwable) convergenceException22);
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, "org.apache.commons.math.ConvergenceException: hi!", objArray26);
        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable14, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathException31);
        java.lang.Throwable throwable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable33, "hi!", objArray35);
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException36, "", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = convergenceException36.getGeneralPattern();
        java.lang.Throwable throwable41 = null;
        java.lang.Throwable throwable43 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(throwable43, "hi!", objArray45);
        java.lang.Object[] objArray48 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException46, "", objArray48);
        org.apache.commons.math.exception.util.Localizable localizable50 = convergenceException49.getGeneralPattern();
        java.lang.Throwable throwable51 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(throwable51, "hi!", objArray53);
        java.lang.Throwable throwable55 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(throwable55, "hi!", objArray57);
        java.lang.Throwable[] throwableArray59 = convergenceException58.getSuppressed();
        convergenceException54.addSuppressed((java.lang.Throwable) convergenceException58);
        java.lang.Object[] objArray62 = null;
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException58, "org.apache.commons.math.ConvergenceException: hi!", objArray62);
        java.lang.Throwable[] throwableArray64 = convergenceException63.getSuppressed();
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(localizable50, (java.lang.Object[]) throwableArray64);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException(throwable41, "", (java.lang.Object[]) throwableArray64);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, localizable40, (java.lang.Object[]) throwableArray64);
        java.lang.Object[] objArray68 = convergenceException67.getArguments();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 105L + "'", number6.equals(105L));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(localizable50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertNotNull(objArray68);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 1, (java.lang.Number) (-1.0f), (java.lang.Number) 0.017453292519943295d);
        java.lang.Class<?> wildcardClass4 = outOfRangeException3.getClass();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, number6, (java.lang.Number) 105L, false);
        java.lang.Number number10 = numberIsTooSmallException9.getArgument();
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        java.lang.Throwable throwable20 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(throwable20, "hi!", objArray22);
        java.lang.Throwable throwable24 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(throwable24, "hi!", objArray26);
        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
        convergenceException23.addSuppressed((java.lang.Throwable) convergenceException27);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException27, "org.apache.commons.math.ConvergenceException: hi!", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable19, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException35);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) mathException36);
        java.lang.Throwable throwable38 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(throwable38, "hi!", objArray40);
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException41, "", objArray43);
        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException41.getGeneralPattern();
        java.lang.Throwable throwable46 = null;
        java.lang.Throwable throwable48 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(throwable48, "hi!", objArray50);
        java.lang.Object[] objArray53 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException51, "", objArray53);
        org.apache.commons.math.exception.util.Localizable localizable55 = convergenceException54.getGeneralPattern();
        java.lang.Throwable throwable56 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(throwable56, "hi!", objArray58);
        java.lang.Throwable throwable60 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(throwable60, "hi!", objArray62);
        java.lang.Throwable[] throwableArray64 = convergenceException63.getSuppressed();
        convergenceException59.addSuppressed((java.lang.Throwable) convergenceException63);
        java.lang.Object[] objArray67 = null;
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException63, "org.apache.commons.math.ConvergenceException: hi!", objArray67);
        java.lang.Throwable[] throwableArray69 = convergenceException68.getSuppressed();
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException(localizable55, (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException(throwable46, "", (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException9, localizable45, (java.lang.Object[]) throwableArray69);
        java.lang.Number number75 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException76 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) 118L, (java.lang.Number) 1.180678914967459E-9d, number75);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException80 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, (java.lang.Number) 4.600161852571429d, (java.lang.Number) 155.74607629780772d, true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException84 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1, (java.lang.Number) 0.5772156649015329d, true);
        java.lang.Object[] objArray85 = numberIsTooLargeException84.getArguments();
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable45, objArray85);
        org.apache.commons.math.exception.util.Localizable localizable87 = mathException86.getSpecificPattern();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 105L + "'", number11.equals(105L));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(localizable55);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertNotNull(throwableArray69);
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertNull(localizable87);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString(1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6" + "'", str2.equals("6"));
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        double double4 = randomDataImpl0.nextChiSquare((double) 45L);
//        double double6 = randomDataImpl0.nextExponential(0.017453292519943295d);
//        double double9 = randomDataImpl0.nextBeta(11013.232920103323d, 3.388796649142697d);
//        double double11 = randomDataImpl0.nextT(1.5655613964506483d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 91L + "'", long2 == 91L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.81515659939933d + "'", double4 == 52.81515659939933d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.002551325885831884d + "'", double6 == 0.002551325885831884d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9997372614303056d + "'", double9 == 0.9997372614303056d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.445470756110603d + "'", double11 == 2.445470756110603d);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Throwable throwable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(throwable4, "hi!", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        convergenceException3.addSuppressed((java.lang.Throwable) convergenceException7);
        java.lang.Throwable throwable10 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(throwable10, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException13, "", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable17, objArray18);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable17);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        double double7 = randomDataImpl0.nextUniform(0.0d, (double) 1L);
//        try {
//            long long10 = randomDataImpl0.nextSecureLong(93L, (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 93 is larger than, or equal to, the maximum (-1): lower bound (93) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 95L + "'", long2 == 95L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6173942761266895d + "'", double7 == 0.6173942761266895d);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.Throwable throwable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(throwable4, "hi!", objArray6);
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException10.getGeneralPattern();
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Throwable throwable16 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(throwable16, "hi!", objArray18);
        java.lang.Throwable[] throwableArray20 = convergenceException19.getSuppressed();
        convergenceException15.addSuppressed((java.lang.Throwable) convergenceException19);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException19, "org.apache.commons.math.ConvergenceException: hi!", objArray23);
        java.lang.Throwable[] throwableArray25 = convergenceException24.getSuppressed();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable11, (java.lang.Object[]) throwableArray25);
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(throwable27, "hi!", objArray29);
        java.lang.Object[] objArray32 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException30, "", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = convergenceException33.getGeneralPattern();
        java.lang.Throwable throwable35 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(throwable35, "hi!", objArray37);
        java.lang.Throwable throwable39 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(throwable39, "hi!", objArray41);
        java.lang.Throwable[] throwableArray43 = convergenceException42.getSuppressed();
        convergenceException38.addSuppressed((java.lang.Throwable) convergenceException42);
        java.lang.Object[] objArray46 = null;
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException42, "org.apache.commons.math.ConvergenceException: hi!", objArray46);
        java.lang.Throwable[] throwableArray48 = convergenceException47.getSuppressed();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable34, (java.lang.Object[]) throwableArray48);
        java.lang.Throwable throwable50 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(throwable50, "hi!", objArray52);
        java.lang.Throwable[] throwableArray54 = convergenceException53.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable34, (java.lang.Object[]) throwableArray54);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", (java.lang.Object[]) throwableArray54);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException(27, "51e095b11819b59807101a48841667d3ddd2b26d60bf1de0ad4cfa1752fc514561ee86931125e6fcbe2b2624b7f23b601859", (java.lang.Object[]) throwableArray54);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(throwableArray54);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.017085496627355166d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017232288537435584d + "'", double1 == 0.017232288537435584d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        randomDataImpl1.reSeedSecure();
        int int7 = randomDataImpl1.nextBinomial(100, 0.0d);
        try {
            int int10 = randomDataImpl1.nextInt(35, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (1): lower bound (35) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.5285140709094763E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(100.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double[] doubleArray2 = normalDistributionImpl0.sample(32);
        double[] doubleArray4 = normalDistributionImpl0.sample(27);
        double double5 = normalDistributionImpl0.getMean();
        try {
            double[] doubleArray7 = normalDistributionImpl0.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.expm1(9.784833931829355E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.789622642346902E-4d + "'", double1 == 9.789622642346902E-4d);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy(100.0d, (double) (byte) 100);
//        randomDataImpl0.reSeedSecure((long) (short) 0);
//        int int8 = randomDataImpl0.nextSecureInt((int) (byte) -1, 7);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-11.461803708449452d) + "'", double3 == (-11.461803708449452d));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability(0.3667424245079105d);
        double double4 = normalDistributionImpl0.density(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6430944209998493d + "'", double2 == 0.6430944209998493d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.27053650577353006d + "'", double4 == 0.27053650577353006d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.Throwable throwable2 = null;
        java.lang.Throwable throwable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException(throwable3, "hi!", objArray5);
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, "", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, number11, (java.lang.Number) 100.0d, false);
        java.lang.Throwable throwable15 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(throwable15, "hi!", objArray17);
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getGeneralPattern();
        java.lang.Throwable throwable23 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(throwable23, "hi!", objArray25);
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(throwable27, "hi!", objArray29);
        java.lang.Throwable[] throwableArray31 = convergenceException30.getSuppressed();
        convergenceException26.addSuppressed((java.lang.Throwable) convergenceException30);
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException30, "org.apache.commons.math.ConvergenceException: hi!", objArray34);
        java.lang.Throwable[] throwableArray36 = convergenceException35.getSuppressed();
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable22, (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable10, (java.lang.Object[]) throwableArray36);
        java.lang.Throwable throwable39 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(throwable39, "hi!", objArray41);
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException42, "", objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = convergenceException45.getGeneralPattern();
        java.lang.Throwable throwable47 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(throwable47, "hi!", objArray49);
        java.lang.Throwable throwable51 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(throwable51, "hi!", objArray53);
        java.lang.Throwable[] throwableArray55 = convergenceException54.getSuppressed();
        convergenceException50.addSuppressed((java.lang.Throwable) convergenceException54);
        java.lang.Object[] objArray58 = null;
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException54, "org.apache.commons.math.ConvergenceException: hi!", objArray58);
        java.lang.Throwable[] throwableArray60 = convergenceException59.getSuppressed();
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException(localizable46, (java.lang.Object[]) throwableArray60);
        java.lang.Throwable throwable62 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(throwable62, "hi!", objArray64);
        java.lang.Object[] objArray67 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException65, "", objArray67);
        org.apache.commons.math.exception.util.Localizable localizable69 = convergenceException68.getGeneralPattern();
        java.lang.Throwable throwable70 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException(throwable70, "hi!", objArray72);
        java.lang.Throwable throwable74 = null;
        java.lang.Object[] objArray76 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(throwable74, "hi!", objArray76);
        java.lang.Throwable[] throwableArray78 = convergenceException77.getSuppressed();
        convergenceException73.addSuppressed((java.lang.Throwable) convergenceException77);
        java.lang.Object[] objArray81 = null;
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException77, "org.apache.commons.math.ConvergenceException: hi!", objArray81);
        java.lang.Throwable[] throwableArray83 = convergenceException82.getSuppressed();
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException(localizable69, (java.lang.Object[]) throwableArray83);
        java.lang.Throwable throwable85 = null;
        java.lang.Object[] objArray87 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException(throwable85, "hi!", objArray87);
        java.lang.Throwable[] throwableArray89 = convergenceException88.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException90 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, localizable69, (java.lang.Object[]) throwableArray89);
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException(throwable2, localizable10, (java.lang.Object[]) throwableArray89);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException92 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "ffce6ac281", (java.lang.Object[]) throwableArray89);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable22);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(localizable46);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNotNull(throwableArray60);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(localizable69);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(throwableArray78);
        org.junit.Assert.assertNotNull(throwableArray83);
        org.junit.Assert.assertNotNull(objArray87);
        org.junit.Assert.assertNotNull(throwableArray89);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        int int1 = org.apache.commons.math.util.FastMath.abs(5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(throwable8, "hi!", objArray10);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        convergenceException11.addSuppressed((java.lang.Throwable) convergenceException15);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "org.apache.commons.math.ConvergenceException: hi!", objArray19);
        java.lang.Throwable[] throwableArray21 = convergenceException20.getSuppressed();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException23);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException23.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooLargeException29.getSpecificPattern();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException29);
        java.lang.String str32 = numberIsTooLargeException29.toString();
        java.lang.Object[] objArray33 = numberIsTooLargeException29.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable34 = numberIsTooLargeException29.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable35 = numberIsTooLargeException29.getGeneralPattern();
        java.lang.Throwable throwable37 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(throwable37, "hi!", objArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException40, "", objArray42);
        org.apache.commons.math.exception.util.Localizable localizable44 = convergenceException43.getGeneralPattern();
        java.lang.Number number45 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable44, number45, (java.lang.Number) 100.0d, false);
        java.lang.Throwable throwable49 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(throwable49, "hi!", objArray51);
        java.lang.Object[] objArray54 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException52, "", objArray54);
        org.apache.commons.math.exception.util.Localizable localizable56 = convergenceException55.getGeneralPattern();
        java.lang.Throwable throwable57 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException(throwable57, "hi!", objArray59);
        java.lang.Throwable throwable61 = null;
        java.lang.Object[] objArray63 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(throwable61, "hi!", objArray63);
        java.lang.Throwable[] throwableArray65 = convergenceException64.getSuppressed();
        convergenceException60.addSuppressed((java.lang.Throwable) convergenceException64);
        java.lang.Object[] objArray68 = null;
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException64, "org.apache.commons.math.ConvergenceException: hi!", objArray68);
        java.lang.Throwable[] throwableArray70 = convergenceException69.getSuppressed();
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException(localizable56, (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException(localizable44, (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.ConvergenceException: hi!", (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException23, localizable35, (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.exception.util.Localizable localizable75 = mathException74.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)" + "'", str32.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)"));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(localizable56);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(throwableArray65);
        org.junit.Assert.assertNotNull(throwableArray70);
        org.junit.Assert.assertNull(localizable75);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) -1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0);
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException(throwable2, "hi!", objArray4);
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException5, "", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getGeneralPattern();
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, number10, (java.lang.Number) 100.0d, false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { (short) 100 };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray16);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, number21, (java.lang.Number) 105L, false);
        java.lang.Number number25 = numberIsTooSmallException24.getArgument();
        java.lang.Number number26 = numberIsTooSmallException24.getMin();
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(throwable27, "hi!", objArray29);
        java.lang.Object[] objArray32 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException30, "", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = convergenceException33.getGeneralPattern();
        java.lang.Throwable throwable35 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(throwable35, "hi!", objArray37);
        java.lang.Throwable throwable39 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(throwable39, "hi!", objArray41);
        java.lang.Throwable[] throwableArray43 = convergenceException42.getSuppressed();
        convergenceException38.addSuppressed((java.lang.Throwable) convergenceException42);
        java.lang.Object[] objArray46 = null;
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException42, "org.apache.commons.math.ConvergenceException: hi!", objArray46);
        java.lang.Throwable[] throwableArray48 = convergenceException47.getSuppressed();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable34, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException49);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException50);
        numberIsTooSmallException24.addSuppressed((java.lang.Throwable) mathException51);
        java.lang.Throwable throwable53 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException(throwable53, "hi!", objArray55);
        java.lang.Object[] objArray58 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, "", objArray58);
        org.apache.commons.math.exception.util.Localizable localizable60 = convergenceException56.getGeneralPattern();
        java.lang.Throwable throwable61 = null;
        java.lang.Throwable throwable63 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(throwable63, "hi!", objArray65);
        java.lang.Object[] objArray68 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException66, "", objArray68);
        org.apache.commons.math.exception.util.Localizable localizable70 = convergenceException69.getGeneralPattern();
        java.lang.Throwable throwable71 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(throwable71, "hi!", objArray73);
        java.lang.Throwable throwable75 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(throwable75, "hi!", objArray77);
        java.lang.Throwable[] throwableArray79 = convergenceException78.getSuppressed();
        convergenceException74.addSuppressed((java.lang.Throwable) convergenceException78);
        java.lang.Object[] objArray82 = null;
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException78, "org.apache.commons.math.ConvergenceException: hi!", objArray82);
        java.lang.Throwable[] throwableArray84 = convergenceException83.getSuppressed();
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException(localizable70, (java.lang.Object[]) throwableArray84);
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException(throwable61, "", (java.lang.Object[]) throwableArray84);
        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException24, localizable60, (java.lang.Object[]) throwableArray84);
        java.lang.Object[] objArray89 = null;
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException87, "", objArray89);
        java.lang.Object[] objArray91 = convergenceException87.getArguments();
        org.apache.commons.math.MathException mathException92 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException1, localizable19, objArray91);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 105L + "'", number26.equals(105L));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(localizable60);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(localizable70);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(throwableArray79);
        org.junit.Assert.assertNotNull(throwableArray84);
        org.junit.Assert.assertNotNull(objArray91);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Throwable throwable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(throwable4, "hi!", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        convergenceException3.addSuppressed((java.lang.Throwable) convergenceException7);
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "org.apache.commons.math.ConvergenceException: hi!", objArray11);
        java.lang.Throwable[] throwableArray13 = convergenceException12.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException12);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        randomDataImpl0.reSeedSecure(0L);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 103L + "'", long2 == 103L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 1, (java.lang.Number) (-1.0f), (java.lang.Number) 0.017453292519943295d);
        java.lang.Class<?> wildcardClass4 = outOfRangeException3.getClass();
        java.lang.Number number5 = outOfRangeException3.getHi();
        java.lang.Number number6 = outOfRangeException3.getHi();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.017453292519943295d + "'", number5.equals(0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.017453292519943295d + "'", number6.equals(0.017453292519943295d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 105L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        java.lang.Throwable throwable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(throwable7, "hi!", objArray9);
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException10, "", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        java.lang.Throwable throwable15 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(throwable15, "hi!", objArray17);
        java.lang.Throwable throwable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(throwable19, "hi!", objArray21);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        convergenceException18.addSuppressed((java.lang.Throwable) convergenceException22);
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, "org.apache.commons.math.ConvergenceException: hi!", objArray26);
        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable14, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathException31);
        java.lang.Throwable throwable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable33, "hi!", objArray35);
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException36, "", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = convergenceException36.getGeneralPattern();
        java.lang.Throwable throwable41 = null;
        java.lang.Throwable throwable43 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(throwable43, "hi!", objArray45);
        java.lang.Object[] objArray48 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException46, "", objArray48);
        org.apache.commons.math.exception.util.Localizable localizable50 = convergenceException49.getGeneralPattern();
        java.lang.Throwable throwable51 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(throwable51, "hi!", objArray53);
        java.lang.Throwable throwable55 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(throwable55, "hi!", objArray57);
        java.lang.Throwable[] throwableArray59 = convergenceException58.getSuppressed();
        convergenceException54.addSuppressed((java.lang.Throwable) convergenceException58);
        java.lang.Object[] objArray62 = null;
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException58, "org.apache.commons.math.ConvergenceException: hi!", objArray62);
        java.lang.Throwable[] throwableArray64 = convergenceException63.getSuppressed();
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(localizable50, (java.lang.Object[]) throwableArray64);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException(throwable41, "", (java.lang.Object[]) throwableArray64);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, localizable40, (java.lang.Object[]) throwableArray64);
        java.lang.Object[] objArray69 = null;
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException67, "", objArray69);
        java.lang.String str71 = convergenceException67.toString();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 105L + "'", number6.equals(105L));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(localizable50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "org.apache.commons.math.ConvergenceException: hi!" + "'", str71.equals("org.apache.commons.math.ConvergenceException: hi!"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(77823.6502245294d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 77823.65022452941d + "'", double1 == 77823.65022452941d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException(throwable2, "hi!", objArray4);
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException5, "", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getGeneralPattern();
        java.lang.Throwable throwable10 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(throwable10, "hi!", objArray12);
        java.lang.Throwable throwable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(throwable14, "hi!", objArray16);
        java.lang.Throwable[] throwableArray18 = convergenceException17.getSuppressed();
        convergenceException13.addSuppressed((java.lang.Throwable) convergenceException17);
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException17, "org.apache.commons.math.ConvergenceException: hi!", objArray21);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable9, (java.lang.Object[]) throwableArray23);
        java.lang.Throwable throwable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(throwable25, "hi!", objArray27);
        java.lang.Object[] objArray30 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException28, "", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        java.lang.Throwable throwable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable33, "hi!", objArray35);
        java.lang.Throwable throwable37 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(throwable37, "hi!", objArray39);
        java.lang.Throwable[] throwableArray41 = convergenceException40.getSuppressed();
        convergenceException36.addSuppressed((java.lang.Throwable) convergenceException40);
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException40, "org.apache.commons.math.ConvergenceException: hi!", objArray44);
        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable32, (java.lang.Object[]) throwableArray46);
        java.lang.Throwable throwable48 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(throwable48, "hi!", objArray50);
        java.lang.Throwable[] throwableArray52 = convergenceException51.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable32, (java.lang.Object[]) throwableArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", (java.lang.Object[]) throwableArray52);
        java.lang.Object[] objArray55 = maxIterationsExceededException54.getArguments();
        int int56 = maxIterationsExceededException54.getMaxIterations();
        int int57 = maxIterationsExceededException54.getMaxIterations();
        java.lang.Throwable throwable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException(throwable59, "hi!", objArray61);
        java.lang.Object[] objArray64 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException62, "", objArray64);
        org.apache.commons.math.exception.util.Localizable localizable66 = convergenceException65.getGeneralPattern();
        java.lang.Number number67 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException70 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable66, number67, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException(localizable66, (java.lang.Number) 3.332204510175204d, (java.lang.Number) 116L, (java.lang.Number) 97);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException79 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable80 = numberIsTooLargeException79.getSpecificPattern();
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException79);
        java.lang.String str82 = numberIsTooLargeException79.toString();
        java.lang.Object[] objArray83 = numberIsTooLargeException79.getArguments();
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException74, "48660e36d2fddeaffc0521face2d6e27fe6e3cdb8fbab5573166154e22acf0c88ea899d4d9abebba3ff785c92e0ed183b0f3", objArray83);
        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException54, "eaaaf5fad095380dd0cf5ed8602", objArray83);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(localizable32);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 10 + "'", int56 == 10);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(localizable66);
        org.junit.Assert.assertNull(localizable80);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)" + "'", str82.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)"));
        org.junit.Assert.assertNotNull(objArray83);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 3.332204510175204d, (java.lang.Number) 116L, (java.lang.Number) 97);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooLargeException20.getSpecificPattern();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException20);
        java.lang.String str23 = numberIsTooLargeException20.toString();
        java.lang.Object[] objArray24 = numberIsTooLargeException20.getArguments();
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException15, "48660e36d2fddeaffc0521face2d6e27fe6e3cdb8fbab5573166154e22acf0c88ea899d4d9abebba3ff785c92e0ed183b0f3", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNull(localizable21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)" + "'", str23.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)"));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNull(localizable26);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1, (java.lang.Number) 0.5772156649015329d, true);
        java.lang.Object[] objArray6 = numberIsTooLargeException5.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "org.apache.commons.math.ConvergenceException: hi!", objArray6);
        int int8 = maxIterationsExceededException7.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        double double8 = randomDataImpl1.nextWeibull((double) '4', (double) (byte) 1);
        randomDataImpl1.reSeedSecure((long) 10);
        try {
            int int13 = randomDataImpl1.nextSecureInt(58, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 58 is larger than, or equal to, the maximum (-1): lower bound (58) must be strictly less than upper bound (-1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.977787856101637d + "'", double8 == 0.977787856101637d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.5553480614894135d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.514285714285712d + "'", double1 == 17.514285714285712d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        java.lang.String str6 = numberIsTooLargeException3.toString();
        java.lang.Object[] objArray7 = numberIsTooLargeException3.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Throwable throwable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(throwable11, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException14, "", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException17.getGeneralPattern();
        java.lang.Throwable throwable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(throwable19, "hi!", objArray21);
        java.lang.Throwable throwable23 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(throwable23, "hi!", objArray25);
        java.lang.Throwable[] throwableArray27 = convergenceException26.getSuppressed();
        convergenceException22.addSuppressed((java.lang.Throwable) convergenceException26);
        java.lang.Object[] objArray30 = null;
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException26, "org.apache.commons.math.ConvergenceException: hi!", objArray30);
        java.lang.Throwable[] throwableArray32 = convergenceException31.getSuppressed();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable18, (java.lang.Object[]) throwableArray32);
        java.lang.Throwable throwable34 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(throwable34, "hi!", objArray36);
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException37, "", objArray39);
        org.apache.commons.math.exception.util.Localizable localizable41 = convergenceException40.getGeneralPattern();
        java.lang.Throwable throwable42 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(throwable42, "hi!", objArray44);
        java.lang.Throwable throwable46 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(throwable46, "hi!", objArray48);
        java.lang.Throwable[] throwableArray50 = convergenceException49.getSuppressed();
        convergenceException45.addSuppressed((java.lang.Throwable) convergenceException49);
        java.lang.Object[] objArray53 = null;
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException49, "org.apache.commons.math.ConvergenceException: hi!", objArray53);
        java.lang.Throwable[] throwableArray55 = convergenceException54.getSuppressed();
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException(localizable41, (java.lang.Object[]) throwableArray55);
        java.lang.Throwable throwable57 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException(throwable57, "hi!", objArray59);
        java.lang.Throwable[] throwableArray61 = convergenceException60.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable41, (java.lang.Object[]) throwableArray61);
        java.lang.Throwable throwable63 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(throwable63, "hi!", objArray65);
        java.lang.Throwable throwable67 = null;
        java.lang.Object[] objArray69 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(throwable67, "hi!", objArray69);
        java.lang.Throwable[] throwableArray71 = convergenceException70.getSuppressed();
        convergenceException66.addSuppressed((java.lang.Throwable) convergenceException70);
        java.lang.Object[] objArray74 = null;
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException70, "org.apache.commons.math.ConvergenceException: hi!", objArray74);
        java.lang.Throwable[] throwableArray76 = convergenceException75.getSuppressed();
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException(localizable18, (java.lang.Object[]) throwableArray76);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException("1d26a52bd0", (java.lang.Object[]) throwableArray76);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException(localizable9, (java.lang.Object[]) throwableArray76);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)"));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(localizable41);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(throwableArray71);
        org.junit.Assert.assertNotNull(throwableArray76);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(throwable8, "hi!", objArray10);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        convergenceException11.addSuppressed((java.lang.Throwable) convergenceException15);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "org.apache.commons.math.ConvergenceException: hi!", objArray19);
        java.lang.Throwable[] throwableArray21 = convergenceException20.getSuppressed();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 1.0f, (java.lang.Number) 5557.690612768985d, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 1.0f);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray21);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.406157709407613E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.406157709407898E-7d + "'", double1 == 4.406157709407898E-7d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6470434810831891d + "'", double1 == 0.6470434810831891d);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 100, (java.lang.Number) 97.0f, false);
//        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 100);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 105.0d, (java.lang.Number) (byte) 100, false);
//        java.lang.Throwable[] throwableArray14 = numberIsTooLargeException13.getSuppressed();
//        java.lang.Number number15 = numberIsTooLargeException13.getMax();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl17 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str19 = randomDataImpl17.nextSecureHexString(10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double22 = normalDistributionImpl20.cumulativeProbability((double) 97.0f);
//        java.lang.Class<?> wildcardClass23 = normalDistributionImpl20.getClass();
//        double double24 = randomDataImpl17.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        java.lang.Object[] objArray25 = new java.lang.Object[] { (byte) 10, number15, (byte) 10, double24 };
//        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException7, "3035ea3a17", objArray25);
//        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "3035ea3a17", objArray25);
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException(100);
//        int int31 = maxIterationsExceededException30.getMaxIterations();
//        java.lang.Throwable[] throwableArray32 = maxIterationsExceededException30.getSuppressed();
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException27, localizable28, (java.lang.Object[]) throwableArray32);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(throwableArray14);
//        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) 100 + "'", number15.equals((byte) 100));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "bfa91820e7" + "'", str19.equals("bfa91820e7"));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.015240431553777101d + "'", double24 == 0.015240431553777101d);
//        org.junit.Assert.assertNotNull(objArray25);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
//        org.junit.Assert.assertNotNull(throwableArray32);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.27053650577353006d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2672484669265062d + "'", double1 == 0.2672484669265062d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 8L, 35.0d, 7.792736994144453E-39d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        long long2 = org.apache.commons.math.util.FastMath.min(37L, 117L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 37L + "'", long2 == 37L);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) (short) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double6 = normalDistributionImpl4.cumulativeProbability((double) 97.0f);
//        double double7 = normalDistributionImpl4.sample();
//        double double8 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        double double9 = normalDistributionImpl4.getStandardDeviation();
//        normalDistributionImpl4.reseedRandomGenerator(37L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.34270948787557515d) + "'", double7 == (-0.34270948787557515d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5888219938221677d + "'", double8 == 0.5888219938221677d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(throwable8, "hi!", objArray10);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        convergenceException11.addSuppressed((java.lang.Throwable) convergenceException15);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "org.apache.commons.math.ConvergenceException: hi!", objArray19);
        java.lang.Throwable[] throwableArray21 = convergenceException20.getSuppressed();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException23);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException23.getGeneralPattern();
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(throwable27, "hi!", objArray29);
        java.lang.Throwable throwable31 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(throwable31, "hi!", objArray33);
        java.lang.Throwable[] throwableArray35 = convergenceException34.getSuppressed();
        convergenceException30.addSuppressed((java.lang.Throwable) convergenceException34);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException34, "org.apache.commons.math.ConvergenceException: hi!", objArray38);
        java.lang.Throwable[] throwableArray40 = convergenceException39.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException23, "{0}", (java.lang.Object[]) throwableArray40);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException41);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray40);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 105L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        boolean boolean8 = numberIsTooSmallException4.getBoundIsAllowed();
        boolean boolean9 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number10 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 105L + "'", number5.equals(105L));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 105L + "'", number7.equals(105L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 105L + "'", number10.equals(105L));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        randomDataImpl1.reSeedSecure((long) 'a');
        int int8 = randomDataImpl1.nextZipf((int) (short) 100, (double) '4');
        randomDataImpl1.reSeed();
        try {
            int int13 = randomDataImpl1.nextHypergeometric(0, (int) (byte) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 105L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        boolean boolean8 = numberIsTooSmallException4.getBoundIsAllowed();
        boolean boolean9 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number10 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 105L + "'", number5.equals(105L));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 105L + "'", number7.equals(105L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        java.lang.String str6 = numberIsTooLargeException3.toString();
        java.lang.Object[] objArray7 = numberIsTooLargeException3.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException3.getGeneralPattern();
        boolean boolean9 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean10 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)"));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 5.298292365610485d, (java.lang.Number) 116L);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
        java.lang.String str5 = mathException4.getPattern();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{0}" + "'", str5.equals("{0}"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextUniform((-0.5495393129816448d), (double) 94L);
        double double8 = randomDataImpl0.nextBeta((double) 100L, 49.2588789979908d);
        try {
            double double11 = randomDataImpl0.nextGaussian((-1.1217129806834838d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 68.51230874435387d + "'", double5 == 68.51230874435387d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6453838090716478d + "'", double8 == 0.6453838090716478d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.107943536736182d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8033342622685465d + "'", double1 == 0.8033342622685465d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.994759785273608E45d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("3035ea3a17", objArray1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        java.lang.Object[] objArray14 = new java.lang.Object[] { (short) 100 };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathIllegalArgumentException16.getGeneralPattern();
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException16);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(localizable17);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 35, (java.lang.Number) (short) 100, true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 5.298292365610485d, (java.lang.Number) 116L);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        int int1 = org.apache.commons.math.util.FastMath.abs(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 88L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.258181274970009E37d + "'", double1 == 8.258181274970009E37d);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 100);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 105.0d, (java.lang.Number) (byte) 100, false);
//        java.lang.Throwable[] throwableArray8 = numberIsTooLargeException7.getSuppressed();
//        java.lang.Number number9 = numberIsTooLargeException7.getMax();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str13 = randomDataImpl11.nextSecureHexString(10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double16 = normalDistributionImpl14.cumulativeProbability((double) 97.0f);
//        java.lang.Class<?> wildcardClass17 = normalDistributionImpl14.getClass();
//        double double18 = randomDataImpl11.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        java.lang.Object[] objArray19 = new java.lang.Object[] { (byte) 10, number9, (byte) 10, double18 };
//        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, "3035ea3a17", objArray19);
//        java.lang.Number number21 = notStrictlyPositiveException1.getMin();
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (byte) 100 + "'", number9.equals((byte) 100));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ce2248a6c9" + "'", str13.equals("ce2248a6c9"));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-0.28895065638752415d) + "'", double18 == (-0.28895065638752415d));
//        org.junit.Assert.assertNotNull(objArray19);
//        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0 + "'", number21.equals(0));
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 5.298292365610485d, (java.lang.Number) 116L);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException(throwable5, "hi!", objArray7);
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        java.lang.Throwable throwable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(throwable13, "hi!", objArray15);
        java.lang.Throwable throwable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(throwable17, "hi!", objArray19);
        java.lang.Throwable[] throwableArray21 = convergenceException20.getSuppressed();
        convergenceException16.addSuppressed((java.lang.Throwable) convergenceException20);
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException20, "org.apache.commons.math.ConvergenceException: hi!", objArray24);
        java.lang.Throwable[] throwableArray26 = convergenceException25.getSuppressed();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable12, (java.lang.Object[]) throwableArray26);
        java.lang.Throwable throwable28 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(throwable28, "hi!", objArray30);
        java.lang.Object[] objArray33 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException31, "", objArray33);
        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException34.getGeneralPattern();
        java.lang.Throwable throwable36 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, "hi!", objArray38);
        java.lang.Throwable throwable40 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(throwable40, "hi!", objArray42);
        java.lang.Throwable[] throwableArray44 = convergenceException43.getSuppressed();
        convergenceException39.addSuppressed((java.lang.Throwable) convergenceException43);
        java.lang.Object[] objArray47 = null;
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException43, "org.apache.commons.math.ConvergenceException: hi!", objArray47);
        java.lang.Throwable[] throwableArray49 = convergenceException48.getSuppressed();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(localizable35, (java.lang.Object[]) throwableArray49);
        java.lang.Throwable throwable51 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(throwable51, "hi!", objArray53);
        java.lang.Throwable[] throwableArray55 = convergenceException54.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable35, (java.lang.Object[]) throwableArray55);
        java.lang.Throwable throwable57 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException(throwable57, "hi!", objArray59);
        java.lang.Throwable throwable61 = null;
        java.lang.Object[] objArray63 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(throwable61, "hi!", objArray63);
        java.lang.Throwable[] throwableArray65 = convergenceException64.getSuppressed();
        convergenceException60.addSuppressed((java.lang.Throwable) convergenceException64);
        java.lang.Object[] objArray68 = null;
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException64, "org.apache.commons.math.ConvergenceException: hi!", objArray68);
        java.lang.Throwable[] throwableArray70 = convergenceException69.getSuppressed();
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException(localizable12, (java.lang.Object[]) throwableArray70);
        java.lang.Throwable throwable72 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(throwable72, "hi!", objArray74);
        java.lang.Object[] objArray77 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException75, "", objArray77);
        org.apache.commons.math.exception.util.Localizable localizable79 = convergenceException78.getGeneralPattern();
        java.lang.Number number80 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException83 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable79, number80, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException87 = new org.apache.commons.math.exception.OutOfRangeException(localizable79, (java.lang.Number) 3.332204510175204d, (java.lang.Number) 116L, (java.lang.Number) 97);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException92 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable93 = numberIsTooLargeException92.getSpecificPattern();
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException92);
        java.lang.String str95 = numberIsTooLargeException92.toString();
        java.lang.Object[] objArray96 = numberIsTooLargeException92.getArguments();
        org.apache.commons.math.MathException mathException97 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException87, "48660e36d2fddeaffc0521face2d6e27fe6e3cdb8fbab5573166154e22acf0c88ea899d4d9abebba3ff785c92e0ed183b0f3", objArray96);
        org.apache.commons.math.ConvergenceException convergenceException98 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable12, objArray96);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(throwableArray65);
        org.junit.Assert.assertNotNull(throwableArray70);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(localizable79);
        org.junit.Assert.assertNull(localizable93);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)" + "'", str95.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)"));
        org.junit.Assert.assertNotNull(objArray96);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.741450291257945d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308231d + "'", double1 == 57.29577951308231d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-105.32943561303279d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7730817523151774E45d + "'", double1 == 2.7730817523151774E45d);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        int int5 = randomDataImpl0.nextBinomial((int) (byte) 0, 1.4428584349276598E-9d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double9 = normalDistributionImpl6.cumulativeProbability((double) (byte) 0, 0.6264011299651113d);
//        double double10 = normalDistributionImpl6.getStandardDeviation();
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double13 = normalDistributionImpl6.density(1.107943536736182d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 103L + "'", long2 == 103L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.23447406570294205d + "'", double9 == 0.23447406570294205d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.258612599640374d) + "'", double11 == (-1.258612599640374d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.21595008769148527d + "'", double13 == 0.21595008769148527d);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double4 = normalDistributionImpl0.density(1.0000000000000002d);
        double double6 = normalDistributionImpl0.density(3.388796649142697d);
        double double8 = normalDistributionImpl0.cumulativeProbability(0.0d);
        double double10 = normalDistributionImpl0.inverseCumulativeProbability(4.406157709407898E-7d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.24197072451914334d + "'", double4 == 0.24197072451914334d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0012799811882669438d + "'", double6 == 0.0012799811882669438d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-4.916460087444044d) + "'", double10 == (-4.916460087444044d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 93L, (-0.5495393129816448d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5495393129816448d) + "'", double2 == (-0.5495393129816448d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 0.5613873848086915d, false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 1, (java.lang.Number) (-1.0f), (java.lang.Number) 0.017453292519943295d);
        java.lang.Class<?> wildcardClass6 = outOfRangeException5.getClass();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 105L, false);
        java.lang.Number number12 = numberIsTooSmallException11.getArgument();
        java.lang.Number number13 = numberIsTooSmallException11.getMin();
        java.lang.Throwable throwable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(throwable14, "hi!", objArray16);
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException17, "", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException20.getGeneralPattern();
        java.lang.Throwable throwable22 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(throwable22, "hi!", objArray24);
        java.lang.Throwable throwable26 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(throwable26, "hi!", objArray28);
        java.lang.Throwable[] throwableArray30 = convergenceException29.getSuppressed();
        convergenceException25.addSuppressed((java.lang.Throwable) convergenceException29);
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException29, "org.apache.commons.math.ConvergenceException: hi!", objArray33);
        java.lang.Throwable[] throwableArray35 = convergenceException34.getSuppressed();
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException(localizable21, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException37);
        numberIsTooSmallException11.addSuppressed((java.lang.Throwable) mathException38);
        java.lang.Throwable throwable40 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(throwable40, "hi!", objArray42);
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException43, "", objArray45);
        org.apache.commons.math.exception.util.Localizable localizable47 = convergenceException43.getGeneralPattern();
        java.lang.Throwable throwable48 = null;
        java.lang.Throwable throwable50 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(throwable50, "hi!", objArray52);
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException53, "", objArray55);
        org.apache.commons.math.exception.util.Localizable localizable57 = convergenceException56.getGeneralPattern();
        java.lang.Throwable throwable58 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(throwable58, "hi!", objArray60);
        java.lang.Throwable throwable62 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(throwable62, "hi!", objArray64);
        java.lang.Throwable[] throwableArray66 = convergenceException65.getSuppressed();
        convergenceException61.addSuppressed((java.lang.Throwable) convergenceException65);
        java.lang.Object[] objArray69 = null;
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException65, "org.apache.commons.math.ConvergenceException: hi!", objArray69);
        java.lang.Throwable[] throwableArray71 = convergenceException70.getSuppressed();
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException(localizable57, (java.lang.Object[]) throwableArray71);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException(throwable48, "", (java.lang.Object[]) throwableArray71);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException11, localizable47, (java.lang.Object[]) throwableArray71);
        java.lang.Number number77 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException78 = new org.apache.commons.math.exception.OutOfRangeException(localizable47, (java.lang.Number) 118L, (java.lang.Number) 1.180678914967459E-9d, number77);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException82 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable47, (java.lang.Number) 4.600161852571429d, (java.lang.Number) 155.74607629780772d, true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException86 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1, (java.lang.Number) 0.5772156649015329d, true);
        java.lang.Object[] objArray87 = numberIsTooLargeException86.getArguments();
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable47, objArray87);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException89 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", objArray87);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 105L + "'", number13.equals(105L));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(localizable47);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(localizable57);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertNotNull(throwableArray71);
        org.junit.Assert.assertNotNull(objArray87);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        java.lang.String str6 = numberIsTooLargeException3.toString();
        java.lang.Object[] objArray7 = numberIsTooLargeException3.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException3.getGeneralPattern();
        boolean boolean9 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 2.99822295029797d, (java.lang.Number) (byte) 0, true);
        boolean boolean15 = numberIsTooSmallException14.getBoundIsAllowed();
        java.lang.Number number16 = numberIsTooSmallException14.getMin();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1.108 is larger than, or equal to, the maximum (0)"));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (byte) 0 + "'", number16.equals((byte) 0));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        randomDataImpl0.reSeed((long) 27);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("5b560d6e4833e634e53822282c7e43a6135a19bd2b874f34d389ba42978470b069e106ffacc517804c5cd371b0e8596cd", objArray1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        randomDataImpl1.reSeedSecure((long) 'a');
        int int8 = randomDataImpl1.nextZipf((int) (short) 100, (double) '4');
        double double11 = randomDataImpl1.nextCauchy((double) '#', 52.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-39.00034721390904d) + "'", double11 == (-39.00034721390904d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.cosh(8.673617379884035E-19d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 8L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 458.3662361046586d + "'", double1 == 458.3662361046586d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double2 = org.apache.commons.math.util.FastMath.max((-9335.99058474676d), (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double double1 = org.apache.commons.math.util.FastMath.atanh(39.670515905542324d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 52.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(throwable8, "hi!", objArray10);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        convergenceException11.addSuppressed((java.lang.Throwable) convergenceException15);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "org.apache.commons.math.ConvergenceException: hi!", objArray19);
        java.lang.Throwable[] throwableArray21 = convergenceException20.getSuppressed();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 57.29577951308232d, (java.lang.Number) 155.74607629780772d, true);
        boolean boolean27 = numberIsTooLargeException26.getBoundIsAllowed();
        java.lang.Number number28 = numberIsTooLargeException26.getMax();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 155.74607629780772d + "'", number28.equals(155.74607629780772d));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long4 = randomDataImpl1.nextLong((long) '#', (long) (byte) 100);
//        int[] intArray7 = randomDataImpl1.nextPermutation(27, 27);
//        long long9 = randomDataImpl1.nextPoisson(0.009784837054594254d);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 85L + "'", long4 == 85L);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        randomDataImpl1.reSeedSecure();
        double double6 = randomDataImpl1.nextExponential((double) 100);
        long long9 = randomDataImpl1.nextLong((long) (byte) 1, (long) 7);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.57167677969427d + "'", double6 == 32.57167677969427d);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 0.006622473314321887d, (java.lang.Number) 0.009784837054594254d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.009784837054594254d + "'", number4.equals(0.009784837054594254d));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.8738270591458991d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08680315236652447d + "'", double1 == 0.08680315236652447d);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        int int5 = randomDataImpl0.nextBinomial((int) (byte) 0, 1.4428584349276598E-9d);
//        try {
//            int int8 = randomDataImpl0.nextZipf(10, (-0.9614286869038096d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.961 is smaller than, or equal to, the minimum (0): exponent (-0.961)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 111L + "'", long2 == 111L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextCauchy(0.0d, 1.5130380755642154d);
        int int8 = randomDataImpl0.nextPascal(52, 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.3375619403500054d + "'", double5 == 1.3375619403500054d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.1422808082595999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 50.75621223367407d + "'", double1 == 50.75621223367407d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, number15, (java.lang.Number) 105L, false);
        java.lang.Number number19 = numberIsTooSmallException18.getArgument();
        java.lang.Number number20 = numberIsTooSmallException18.getMin();
        java.lang.Throwable throwable21 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(throwable21, "hi!", objArray23);
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException24, "", objArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = convergenceException27.getGeneralPattern();
        java.lang.Throwable throwable29 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(throwable29, "hi!", objArray31);
        java.lang.Throwable throwable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable33, "hi!", objArray35);
        java.lang.Throwable[] throwableArray37 = convergenceException36.getSuppressed();
        convergenceException32.addSuppressed((java.lang.Throwable) convergenceException36);
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException36, "org.apache.commons.math.ConvergenceException: hi!", objArray40);
        java.lang.Throwable[] throwableArray42 = convergenceException41.getSuppressed();
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException(localizable28, (java.lang.Object[]) throwableArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException44);
        numberIsTooSmallException18.addSuppressed((java.lang.Throwable) mathException45);
        java.lang.Throwable throwable47 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(throwable47, "hi!", objArray49);
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException50, "", objArray52);
        org.apache.commons.math.exception.util.Localizable localizable54 = convergenceException50.getGeneralPattern();
        java.lang.Throwable throwable55 = null;
        java.lang.Throwable throwable57 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException(throwable57, "hi!", objArray59);
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException60, "", objArray62);
        org.apache.commons.math.exception.util.Localizable localizable64 = convergenceException63.getGeneralPattern();
        java.lang.Throwable throwable65 = null;
        java.lang.Object[] objArray67 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException(throwable65, "hi!", objArray67);
        java.lang.Throwable throwable69 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException(throwable69, "hi!", objArray71);
        java.lang.Throwable[] throwableArray73 = convergenceException72.getSuppressed();
        convergenceException68.addSuppressed((java.lang.Throwable) convergenceException72);
        java.lang.Object[] objArray76 = null;
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException72, "org.apache.commons.math.ConvergenceException: hi!", objArray76);
        java.lang.Throwable[] throwableArray78 = convergenceException77.getSuppressed();
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException(localizable64, (java.lang.Object[]) throwableArray78);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException(throwable55, "", (java.lang.Object[]) throwableArray78);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException18, localizable54, (java.lang.Object[]) throwableArray78);
        java.lang.Object[] objArray83 = null;
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException81, "", objArray83);
        java.lang.Object[] objArray85 = convergenceException81.getArguments();
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException("1d26a52bd0", objArray85);
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException(localizable12, objArray85);
        java.lang.String str88 = mathException87.getPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 105L + "'", number20.equals(105L));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(localizable28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(localizable54);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(localizable64);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(throwableArray73);
        org.junit.Assert.assertNotNull(throwableArray78);
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "{0} is smaller than, or equal to, the minimum ({1})" + "'", str88.equals("{0} is smaller than, or equal to, the minimum ({1})"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString(10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double5 = normalDistributionImpl3.cumulativeProbability((double) 97.0f);
//        java.lang.Class<?> wildcardClass6 = normalDistributionImpl3.getClass();
//        double double7 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        randomDataImpl0.reSeed((long) (short) 1);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double12 = randomDataImpl0.nextT((-3.7521857890261927d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -3.752 is smaller than, or equal to, the minimum (0): degrees of freedom (-3.752)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e7ade9eb09" + "'", str2.equals("e7ade9eb09"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.4863899772810607d + "'", double7 == 1.4863899772810607d);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.5495393129816448d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5001748560970438d) + "'", double1 == (-0.5001748560970438d));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        long long4 = randomDataImpl0.nextPoisson((double) 104L);
        int int7 = randomDataImpl0.nextInt(35, (int) 'a');
        int[] intArray10 = randomDataImpl0.nextPermutation(100, (int) (short) 10);
        try {
            double double13 = randomDataImpl0.nextBeta((-0.5872139151569291d), 1.2811956688158854d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.815");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 88 + "'", int7 == 88);
        org.junit.Assert.assertNotNull(intArray10);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long4 = randomDataImpl1.nextLong((long) '#', (long) (byte) 100);
//        int[] intArray7 = randomDataImpl1.nextPermutation(27, 27);
//        randomDataImpl1.reSeedSecure();
//        try {
//            int int11 = randomDataImpl1.nextInt(100, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (97): lower bound (100) must be strictly less than upper bound (97)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 96L + "'", long4 == 96L);
//        org.junit.Assert.assertNotNull(intArray7);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.8509035245341184d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2594178038616215d + "'", double1 == 1.2594178038616215d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.util.FastMath.expm1(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextCauchy(0.0d, 1.5130380755642154d);
        randomDataImpl0.reSeed();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.3375619403500054d + "'", double5 == 1.3375619403500054d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.220446049250313E-16d, (java.lang.Number) 105.0d, number2);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 95.0f, (java.lang.Number) 5.347084854209185d, true);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed((long) 10);
//        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
//        randomDataImpl0.reSeed((long) '#');
//        long long9 = randomDataImpl0.nextPoisson((double) 118L);
//        double double12 = randomDataImpl0.nextGaussian(4.339317855293556d, 35.0d);
//        java.lang.String str14 = randomDataImpl0.nextSecureHexString((int) 'a');
//        try {
//            double double16 = randomDataImpl0.nextChiSquare(9.784833931829355E-4d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 0.001], values: [0.621, 0.922]: number of iterations=1, maximum iterations=2,147,483,647, initial=0, lower bound=0, upper bound=0.001, final a value=0, final b value=0.001, f(a)=0.621, f(b)=0.922");
//        } catch (org.apache.commons.math.exception.NoBracketingException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 117L + "'", long9 == 117L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-65.75050293780329d) + "'", double12 == (-65.75050293780329d));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "75b1c89e8281c5c3c4544b424ae14e0d5ebacf7cf64cd2926ff4a3d34d84c7588be28b684274dd35769d694ddbe83a9e7" + "'", str14.equals("75b1c89e8281c5c3c4544b424ae14e0d5ebacf7cf64cd2926ff4a3d34d84c7588be28b684274dd35769d694ddbe83a9e7"));
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        int int2 = org.apache.commons.math.util.FastMath.max(97, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextCauchy(0.0d, 1.5130380755642154d);
        long long7 = randomDataImpl0.nextPoisson(1.66161881444429d);
        int int10 = randomDataImpl0.nextInt(0, 7);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.3375619403500054d + "'", double5 == 1.3375619403500054d);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.3296798906723511E-46d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.4136443391590922d, 0.977787856101637d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4218350086806193d + "'", double2 == 0.4218350086806193d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        int int8 = randomDataImpl1.nextInt(1, (int) (byte) 100);
        double double10 = randomDataImpl1.nextChiSquare(0.8813735870195429d);
        double double13 = randomDataImpl1.nextWeibull(4.569547482465657d, (double) 35);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 27 + "'", int8 == 27);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.009784837054594254d + "'", double10 == 0.009784837054594254d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 39.107680463234075d + "'", double13 == 39.107680463234075d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double5 = normalDistributionImpl0.cumulativeProbability(57.29577951308231d, 104.39390890801062d);
        double double7 = normalDistributionImpl0.cumulativeProbability(0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.6453838090716478d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6911287471423853d + "'", double1 == 0.6911287471423853d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability((double) (byte) 0, 0.6264011299651113d);
        double double5 = normalDistributionImpl0.cumulativeProbability((-2.8305302825148724d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.23447406570294205d + "'", double3 == 0.23447406570294205d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0023235455919483616d + "'", double5 == 0.0023235455919483616d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-20.356639666660495d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-20.0d) + "'", double1 == (-20.0d));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        long long1 = org.apache.commons.math.util.FastMath.round(0.017232288537435584d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.0f, (java.lang.Number) 100, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Object[] objArray5 = numberIsTooLargeException3.getArguments();
        java.lang.Number number6 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100 + "'", number4.equals(100));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0f + "'", number6.equals(0.0f));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.4210854715202004E-14d, 0.8509035245341184d, (-0.12058193734529499d), 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (10) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy(100.0d, (double) (byte) 100);
//        double double6 = randomDataImpl0.nextGaussian(4.524514827724147d, (double) 32);
//        java.lang.String str8 = randomDataImpl0.nextHexString((int) '4');
//        double double10 = randomDataImpl0.nextT(2.445470756110603d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 191.79848241330677d + "'", double3 == 191.79848241330677d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 29.825899107351482d + "'", double6 == 29.825899107351482d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ad3134556674dc412c3f3e377ee3ecf0a0eebc7411a48c969e32" + "'", str8.equals("ad3134556674dc412c3f3e377ee3ecf0a0eebc7411a48c969e32"));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.38006235862607146d) + "'", double10 == (-0.38006235862607146d));
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 105L, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999288136d + "'", double2 == 0.9999999999288136d);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed((long) 10);
//        long long4 = randomDataImpl0.nextPoisson((double) 104L);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString(27);
//        try {
//            double double8 = randomDataImpl0.nextExponential((-1.8066454710957265d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.807 is smaller than, or equal to, the minimum (0): mean (-1.807)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "cba191b78d1caf50d0e797ef86e" + "'", str6.equals("cba191b78d1caf50d0e797ef86e"));
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.8509035245341184d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6156739115059177d + "'", double1 == 0.6156739115059177d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.665672727543436d, (double) 10L, 88.58082754219768d, (int) ' ');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9997520101186251d + "'", double4 == 0.9997520101186251d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.28895065638752415d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.34101345128814464d) + "'", double1 == (-0.34101345128814464d));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.String str1 = mathException0.getPattern();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}" + "'", str1.equals("{0}"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        randomDataImpl1.reSeedSecure((long) 'a');
        int int8 = randomDataImpl1.nextZipf((int) (short) 100, (double) '4');
        long long10 = randomDataImpl1.nextPoisson(155.74607629780772d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 172L + "'", long10 == 172L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1, (java.lang.Number) 0.5772156649015329d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Object[] objArray6 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 118.0d, (double) (short) -1);
        double double4 = normalDistributionImpl3.getMean();
        double double5 = normalDistributionImpl3.getStandardDeviation();
        double double7 = normalDistributionImpl3.density(5.551115123125783E-17d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 118.0d + "'", double5 == 118.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0033808667830629888d + "'", double7 == 0.0033808667830629888d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.lang.Throwable throwable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException(throwable3, "hi!", objArray5);
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, "", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        java.lang.Throwable throwable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(throwable11, "hi!", objArray13);
        java.lang.Throwable throwable15 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(throwable15, "hi!", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        convergenceException14.addSuppressed((java.lang.Throwable) convergenceException18);
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "org.apache.commons.math.ConvergenceException: hi!", objArray22);
        java.lang.Throwable[] throwableArray24 = convergenceException23.getSuppressed();
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable10, (java.lang.Object[]) throwableArray24);
        java.lang.Throwable throwable26 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(throwable26, "hi!", objArray28);
        java.lang.Object[] objArray31 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException29, "", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = convergenceException32.getGeneralPattern();
        java.lang.Throwable throwable34 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(throwable34, "hi!", objArray36);
        java.lang.Throwable throwable38 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(throwable38, "hi!", objArray40);
        java.lang.Throwable[] throwableArray42 = convergenceException41.getSuppressed();
        convergenceException37.addSuppressed((java.lang.Throwable) convergenceException41);
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException41, "org.apache.commons.math.ConvergenceException: hi!", objArray45);
        java.lang.Throwable[] throwableArray47 = convergenceException46.getSuppressed();
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException(localizable33, (java.lang.Object[]) throwableArray47);
        java.lang.Throwable throwable49 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(throwable49, "hi!", objArray51);
        java.lang.Throwable[] throwableArray53 = convergenceException52.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable33, (java.lang.Object[]) throwableArray53);
        java.lang.Throwable throwable55 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(throwable55, "hi!", objArray57);
        java.lang.Throwable throwable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException(throwable59, "hi!", objArray61);
        java.lang.Throwable[] throwableArray63 = convergenceException62.getSuppressed();
        convergenceException58.addSuppressed((java.lang.Throwable) convergenceException62);
        java.lang.Object[] objArray66 = null;
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException62, "org.apache.commons.math.ConvergenceException: hi!", objArray66);
        java.lang.Throwable[] throwableArray68 = convergenceException67.getSuppressed();
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(localizable10, (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("48660e36d2fddeaffc0521face2d6e27fe6e3cdb8fbab5573166154e22acf0c88ea899d4d9abebba3ff785c92e0ed183b0f3", (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than the maximum (0.577)", (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException("ad3134556674dc412c3f3e377ee3ecf0a0eebc7411a48c969e32", (java.lang.Object[]) throwableArray68);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(throwableArray63);
        org.junit.Assert.assertNotNull(throwableArray68);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.FastMath.log1p(118.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.77912349311153d + "'", double1 == 4.77912349311153d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 3.332204510175204d, (java.lang.Number) 116L, (java.lang.Number) 97);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 12L, (java.lang.Number) 118.00000000000001d, (java.lang.Number) 57.29577951308232d);
        java.lang.Number number20 = outOfRangeException19.getHi();
        java.lang.Throwable throwable22 = null;
        java.lang.Throwable throwable24 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(throwable24, "hi!", objArray26);
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException27, "", objArray29);
        org.apache.commons.math.exception.util.Localizable localizable31 = convergenceException30.getGeneralPattern();
        java.lang.Throwable throwable32 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(throwable32, "hi!", objArray34);
        java.lang.Throwable throwable36 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, "hi!", objArray38);
        java.lang.Throwable[] throwableArray40 = convergenceException39.getSuppressed();
        convergenceException35.addSuppressed((java.lang.Throwable) convergenceException39);
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException39, "org.apache.commons.math.ConvergenceException: hi!", objArray43);
        java.lang.Throwable[] throwableArray45 = convergenceException44.getSuppressed();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException(localizable31, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(throwable22, "", (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException19, "51e095b11819b59807101a48841667d3ddd2b26d60bf1de0ad4cfa1752fc514561ee86931125e6fcbe2b2624b7f23b601859", (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.util.Localizable localizable49 = outOfRangeException19.getSpecificPattern();
        java.lang.Number number50 = outOfRangeException19.getHi();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 57.29577951308232d + "'", number20.equals(57.29577951308232d));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(localizable49);
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 57.29577951308232d + "'", number50.equals(57.29577951308232d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0033808667830629888d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.003380873223793959d + "'", double1 == 0.003380873223793959d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.3667424245079105d, 47.95358161942444d);
        try {
            double[] doubleArray4 = normalDistributionImpl2.sample((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 0.6430944209998493d, 1.0261558606821757E-9d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        long long1 = org.apache.commons.math.util.FastMath.abs(92L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 92L + "'", long1 == 92L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.6143583690369782d), (java.lang.Number) 93L, false);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.5655613964506483d, 50.75621223367407d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03083494848484526d + "'", double2 == 0.03083494848484526d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        long long4 = randomDataImpl0.nextPoisson((double) 104L);
        randomDataImpl0.reSeedSecure(92L);
        int int9 = randomDataImpl0.nextInt(0, (int) '4');
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 45 + "'", int9 == 45);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double1 = org.apache.commons.math.util.FastMath.log(2.875319943624051E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.154176419179755d) + "'", double1 == (-8.154176419179755d));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 58);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 58L + "'", long2 == 58L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        double double8 = randomDataImpl1.nextBeta(1.5430806348152437d, (double) 101L);
        randomDataImpl1.reSeed();
        try {
            java.lang.String str11 = randomDataImpl1.nextSecureHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.006622473314321887d + "'", double8 == 0.006622473314321887d);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure(116L);
//        double double4 = randomDataImpl0.nextExponential(2.059488517353309d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.06820004880581906d + "'", double4 == 0.06820004880581906d);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 104L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5958.761069360561d + "'", double1 == 5958.761069360561d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100L, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.5888219938221677d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        double double10 = randomDataImpl0.nextGamma((double) (byte) 100, 5.551115123125783E-17d);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double[] doubleArray13 = normalDistributionImpl11.sample(32);
        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
        double double17 = randomDataImpl0.nextCauchy(1.1031908548556288E-53d, 162.1605745804084d);
        java.lang.String str19 = randomDataImpl0.nextHexString(35);
        try {
            long long22 = randomDataImpl0.nextLong(51L, 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 51 is larger than, or equal to, the maximum (0): lower bound (51) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.356360972744053E-9d + "'", double10 == 1.356360972744053E-9d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.008992146246399135d) + "'", double14 == (-0.008992146246399135d));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-105.3294356130328d) + "'", double17 == (-105.3294356130328d));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "c295964df55fa86a190d769241e5be164b3" + "'", str19.equals("c295964df55fa86a190d769241e5be164b3"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.017085496627355166d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.008992146246399135d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 1, (java.lang.Number) (-1.0f), (java.lang.Number) 0.017453292519943295d);
        java.lang.Class<?> wildcardClass4 = outOfRangeException3.getClass();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, number6, (java.lang.Number) 105L, false);
        java.lang.Number number10 = numberIsTooSmallException9.getArgument();
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        java.lang.Throwable throwable20 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(throwable20, "hi!", objArray22);
        java.lang.Throwable throwable24 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(throwable24, "hi!", objArray26);
        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
        convergenceException23.addSuppressed((java.lang.Throwable) convergenceException27);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException27, "org.apache.commons.math.ConvergenceException: hi!", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable19, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException35);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) mathException36);
        java.lang.Throwable throwable38 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(throwable38, "hi!", objArray40);
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException41, "", objArray43);
        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException41.getGeneralPattern();
        java.lang.Throwable throwable46 = null;
        java.lang.Throwable throwable48 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(throwable48, "hi!", objArray50);
        java.lang.Object[] objArray53 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException51, "", objArray53);
        org.apache.commons.math.exception.util.Localizable localizable55 = convergenceException54.getGeneralPattern();
        java.lang.Throwable throwable56 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(throwable56, "hi!", objArray58);
        java.lang.Throwable throwable60 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(throwable60, "hi!", objArray62);
        java.lang.Throwable[] throwableArray64 = convergenceException63.getSuppressed();
        convergenceException59.addSuppressed((java.lang.Throwable) convergenceException63);
        java.lang.Object[] objArray67 = null;
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException63, "org.apache.commons.math.ConvergenceException: hi!", objArray67);
        java.lang.Throwable[] throwableArray69 = convergenceException68.getSuppressed();
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException(localizable55, (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException(throwable46, "", (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException9, localizable45, (java.lang.Object[]) throwableArray69);
        java.lang.Number number75 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException76 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) 118L, (java.lang.Number) 1.180678914967459E-9d, number75);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException80 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, (java.lang.Number) 4.600161852571429d, (java.lang.Number) 155.74607629780772d, true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException84 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1, (java.lang.Number) 0.5772156649015329d, true);
        java.lang.Object[] objArray85 = numberIsTooLargeException84.getArguments();
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable45, objArray85);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException90 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable45, (java.lang.Number) (-0.1119916940226243d), (java.lang.Number) 105L, true);
        java.lang.Number number91 = numberIsTooLargeException90.getMax();
        java.lang.String str92 = numberIsTooLargeException90.toString();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 105L + "'", number11.equals(105L));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(localizable55);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertNotNull(throwableArray69);
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertTrue("'" + number91 + "' != '" + 105L + "'", number91.equals(105L));
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -0.112 is larger than the maximum (105): hi!" + "'", str92.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -0.112 is larger than the maximum (105): hi!"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException11.getGeneralPattern();
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(localizable12, objArray13);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        double double4 = randomDataImpl0.nextChiSquare((double) 45L);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double8 = randomDataImpl0.nextChiSquare(4.524514827724147d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 104L + "'", long2 == 104L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 29.891195236117365d + "'", double4 == 29.891195236117365d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9.703052197595493d + "'", double8 == 9.703052197595493d);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math.special.Gamma.digamma(118.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.766441351416843d + "'", double1 == 4.766441351416843d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, (-0.12058193734529499d), 1.0525892241343182d, (int) ' ');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(51.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.00000000000001d + "'", double1 == 51.00000000000001d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        long long2 = org.apache.commons.math.util.FastMath.max(109L, 127L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 127L + "'", long2 == 127L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        int int8 = randomDataImpl1.nextInt(1, (int) (byte) 100);
        long long10 = randomDataImpl1.nextPoisson((double) 117L);
        java.lang.Class<?> wildcardClass11 = randomDataImpl1.getClass();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 27 + "'", int8 == 27);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 127L + "'", long10 == 127L);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        long long4 = randomDataImpl0.nextPoisson((double) 104L);
        int int7 = randomDataImpl0.nextInt(35, (int) 'a');
        int[] intArray10 = randomDataImpl0.nextPermutation(100, (int) (short) 10);
        double double12 = randomDataImpl0.nextChiSquare((double) 95L);
        try {
            long long15 = randomDataImpl0.nextSecureLong(172L, 105L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 172 is larger than, or equal to, the maximum (105): lower bound (172) must be strictly less than upper bound (105)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 88 + "'", int7 == 88);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 107.16775700476393d + "'", double12 == 107.16775700476393d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9999999999288136d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01745329251870086d + "'", double1 == 0.01745329251870086d);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        double double7 = randomDataImpl0.nextBeta(0.009784837054594254d, (double) 10L);
//        randomDataImpl0.reSeedSecure(35L);
//        randomDataImpl0.reSeed(97L);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        try {
//            int int16 = randomDataImpl0.nextBinomial((int) (byte) -1, 8.586137717495309E-14d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of trials (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 88L + "'", long2 == 88L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.6399426325318646E-9d + "'", double7 == 1.6399426325318646E-9d);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 32.57167677969427d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 3.332204510175204d, (java.lang.Number) 116L, (java.lang.Number) 97);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 12L, (java.lang.Number) 118.00000000000001d, (java.lang.Number) 57.29577951308232d);
        java.lang.Number number20 = outOfRangeException19.getHi();
        java.lang.Number number21 = outOfRangeException19.getHi();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 57.29577951308232d + "'", number20.equals(57.29577951308232d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 57.29577951308232d + "'", number21.equals(57.29577951308232d));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.019691932154573932d), 2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.01969193215457393d) + "'", double2 == (-0.01969193215457393d));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 5.298292365610485d, (java.lang.Number) 116L);
        numberIsTooSmallException11.addSuppressed((java.lang.Throwable) outOfRangeException15);
        java.lang.Throwable throwable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(throwable17, "hi!", objArray19);
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException20, "", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable24 = convergenceException23.getGeneralPattern();
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, number25, (java.lang.Number) 100.0d, false);
        java.lang.Throwable throwable29 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(throwable29, "hi!", objArray31);
        java.lang.Object[] objArray34 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException32, "", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable36 = convergenceException35.getGeneralPattern();
        java.lang.Throwable throwable37 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(throwable37, "hi!", objArray39);
        java.lang.Throwable throwable41 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(throwable41, "hi!", objArray43);
        java.lang.Throwable[] throwableArray45 = convergenceException44.getSuppressed();
        convergenceException40.addSuppressed((java.lang.Throwable) convergenceException44);
        java.lang.Object[] objArray48 = null;
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException44, "org.apache.commons.math.ConvergenceException: hi!", objArray48);
        java.lang.Throwable[] throwableArray50 = convergenceException49.getSuppressed();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(localizable36, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable24, (java.lang.Object[]) throwableArray50);
        java.lang.Throwable throwable53 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException(throwable53, "hi!", objArray55);
        java.lang.Throwable throwable57 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException(throwable57, "hi!", objArray59);
        java.lang.Throwable[] throwableArray61 = convergenceException60.getSuppressed();
        convergenceException56.addSuppressed((java.lang.Throwable) convergenceException60);
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException60, "org.apache.commons.math.ConvergenceException: hi!", objArray64);
        java.lang.Throwable[] throwableArray66 = convergenceException65.getSuppressed();
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException(localizable24, (java.lang.Object[]) throwableArray66);
        numberIsTooSmallException11.addSuppressed((java.lang.Throwable) mathException67);
        boolean boolean69 = numberIsTooSmallException11.getBoundIsAllowed();
        boolean boolean70 = numberIsTooSmallException11.getBoundIsAllowed();
        boolean boolean71 = numberIsTooSmallException11.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable24);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability((double) 97.0f);
        java.lang.Class<?> wildcardClass3 = normalDistributionImpl0.getClass();
        double double6 = normalDistributionImpl0.cumulativeProbability(2.718281828459045d, (double) 92L);
        double double7 = normalDistributionImpl0.getMean();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0032810958362956555d + "'", double6 == 0.0032810958362956555d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.4218350086806193d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.41023149835830525d + "'", double1 == 0.41023149835830525d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        long long1 = org.apache.commons.math.util.FastMath.abs(116L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 116L + "'", long1 == 116L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 52.0f, 4.621351742195683d, (double) (-1.0f));
        double double4 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double[] doubleArray2 = normalDistributionImpl0.sample(32);
//        double[] doubleArray4 = normalDistributionImpl0.sample(27);
//        double double5 = normalDistributionImpl0.sample();
//        org.junit.Assert.assertNotNull(doubleArray2);
//        org.junit.Assert.assertNotNull(doubleArray4);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.20361512110973398d) + "'", double5 == (-0.20361512110973398d));
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        randomDataImpl0.reSeed((long) (short) 100);
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeedSecure();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray10);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        double double5 = randomDataImpl0.nextCauchy((double) 8L, (double) 1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 101L + "'", long2 == 101L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 7.782294766053089d + "'", double5 == 7.782294766053089d);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1.3991949460826119d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.770145870788499d) + "'", double1 == (-5.770145870788499d));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        int int8 = randomDataImpl1.nextInt(1, (int) (byte) 100);
        double double10 = randomDataImpl1.nextChiSquare(0.8813735870195429d);
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution11 = null;
        try {
            int int12 = randomDataImpl1.nextInversionDeviate(integerDistribution11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 27 + "'", int8 == 27);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.009784837054594254d + "'", double10 == 0.009784837054594254d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math.util.FastMath.exp(345.37940706226686d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.916779348709596E149d + "'", double1 == 9.916779348709596E149d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.3036139798334847d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.303613979833485d + "'", double1 == 1.303613979833485d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextCauchy(0.0d, 1.5130380755642154d);
        long long7 = randomDataImpl0.nextPoisson(1.66161881444429d);
        double double10 = randomDataImpl0.nextF(116.0d, 54.702575672487015d);
        randomDataImpl0.reSeedSecure(127L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.3375619403500054d + "'", double5 == 1.3375619403500054d);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.8577443895511387d + "'", double10 == 0.8577443895511387d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 118.0d, (double) (short) -1);
        double double4 = normalDistributionImpl3.getMean();
        double double5 = normalDistributionImpl3.getStandardDeviation();
        double double6 = normalDistributionImpl3.getStandardDeviation();
        double double7 = normalDistributionImpl3.getStandardDeviation();
        double[] doubleArray9 = normalDistributionImpl3.sample(7);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 118.0d + "'", double5 == 118.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 118.0d + "'", double6 == 118.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 118.0d + "'", double7 == 118.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.2672484669265062d, 57.29577951308231d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(54.702575672487015d, (double) 84L);
//        double double3 = normalDistributionImpl2.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 59.13996087963216d + "'", double3 == 59.13996087963216d);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        double double8 = randomDataImpl1.nextBeta(1.5430806348152437d, (double) 101L);
        randomDataImpl1.reSeed();
        randomDataImpl1.reSeed((-1L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.006622473314321887d + "'", double8 == 0.006622473314321887d);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString(10);
//        try {
//            int int5 = randomDataImpl0.nextBinomial((int) (byte) 0, (-0.34101345128814464d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.341 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a5f302f63c" + "'", str2.equals("a5f302f63c"));
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        java.lang.Throwable throwable20 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(throwable20, "hi!", objArray22);
        java.lang.Throwable throwable24 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(throwable24, "hi!", objArray26);
        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
        convergenceException23.addSuppressed((java.lang.Throwable) convergenceException27);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException27, "org.apache.commons.math.ConvergenceException: hi!", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable19, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable7, (java.lang.Object[]) throwableArray33);
        java.lang.Throwable throwable36 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, "hi!", objArray38);
        java.lang.Throwable throwable40 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(throwable40, "hi!", objArray42);
        java.lang.Throwable[] throwableArray44 = convergenceException43.getSuppressed();
        convergenceException39.addSuppressed((java.lang.Throwable) convergenceException43);
        java.lang.Object[] objArray47 = null;
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException43, "org.apache.commons.math.ConvergenceException: hi!", objArray47);
        java.lang.Throwable[] throwableArray49 = convergenceException48.getSuppressed();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray49);
        java.lang.Throwable throwable51 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(throwable51, "hi!", objArray53);
        java.lang.Throwable[] throwableArray55 = convergenceException54.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 0.7949577687638787d, (java.lang.Number) 1.4210854715202004E-14d, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException64 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 1L, (java.lang.Number) 5.8822072909201655d, false);
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        java.lang.Number number66 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException69 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable65, number66, (java.lang.Number) 105L, false);
        java.lang.Number number70 = numberIsTooSmallException69.getMin();
        org.apache.commons.math.exception.util.Localizable localizable71 = numberIsTooSmallException69.getGeneralPattern();
        java.lang.Number number72 = numberIsTooSmallException69.getMin();
        boolean boolean73 = numberIsTooSmallException69.getBoundIsAllowed();
        numberIsTooLargeException64.addSuppressed((java.lang.Throwable) numberIsTooSmallException69);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 105L + "'", number70.equals(105L));
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number72 + "' != '" + 105L + "'", number72.equals(105L));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 5.298292365610485d, (java.lang.Number) 116L);
        numberIsTooSmallException11.addSuppressed((java.lang.Throwable) outOfRangeException15);
        java.lang.Throwable throwable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(throwable17, "hi!", objArray19);
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException20, "", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable24 = convergenceException23.getGeneralPattern();
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, number25, (java.lang.Number) 100.0d, false);
        outOfRangeException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException28);
        boolean boolean30 = numberIsTooSmallException28.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double1 = org.apache.commons.math.util.FastMath.tanh(59.13996087963216d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        randomDataImpl1.reSeedSecure();
        double double6 = randomDataImpl1.nextExponential((double) 100);
        randomDataImpl1.reSeedSecure();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.57167677969427d + "'", double6 == 32.57167677969427d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Throwable throwable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(throwable4, "hi!", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        convergenceException3.addSuppressed((java.lang.Throwable) convergenceException7);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 127L, (java.lang.Number) 47.95358161942444d, false);
        convergenceException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException13);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.ulp(6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.737125245533627E25d + "'", double1 == 7.737125245533627E25d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 5.298292365610485d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        long long2 = org.apache.commons.math.util.FastMath.min(82L, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 82L + "'", long2 == 82L);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test233");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) (short) 100);
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
//        java.lang.String str7 = randomDataImpl1.nextSecureHexString((int) 'a');
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "805ad2a5c70e0f1c406a51c408c108d3c0869d9c358c7875870bd90fc004c8d74c49c67c50011edd26c07a97cbc964e5b" + "'", str7.equals("805ad2a5c70e0f1c406a51c408c108d3c0869d9c358c7875870bd90fc004c8d74c49c67c50011edd26c07a97cbc964e5b"));
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed((long) 10);
//        double double4 = randomDataImpl0.nextT((double) 116L);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str7 = randomDataImpl5.nextSecureHexString(10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double10 = normalDistributionImpl8.cumulativeProbability((double) 97.0f);
//        java.lang.Class<?> wildcardClass11 = normalDistributionImpl8.getClass();
//        double double12 = randomDataImpl5.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        normalDistributionImpl8.reseedRandomGenerator(0L);
//        double double15 = normalDistributionImpl8.getStandardDeviation();
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.615942194802602d + "'", double4 == 0.615942194802602d);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "8011dc58df" + "'", str7.equals("8011dc58df"));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.41273759504724d) + "'", double12 == (-1.41273759504724d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.6501341356232105d) + "'", double16 == (-0.6501341356232105d));
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 12L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 27, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893698d) + "'", double1 == (-0.5440211108893698d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.0f, (java.lang.Number) 100, false);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 0 is larger than, or equal to, the maximum (100)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 0 is larger than, or equal to, the maximum (100)"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.5553480614894135d, 0.0032810958362956555d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.555348061489413d + "'", double2 == 3.555348061489413d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.apache.commons.math.util.FastMath.acosh(8.673617379884035E-19d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 2.3124383412727525d, (java.lang.Number) (-8.469703219092953E8d), false);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 100);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 105.0d, (java.lang.Number) (byte) 100, false);
//        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException11.getSuppressed();
//        java.lang.Number number13 = numberIsTooLargeException11.getMax();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str17 = randomDataImpl15.nextSecureHexString(10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl18 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double20 = normalDistributionImpl18.cumulativeProbability((double) 97.0f);
//        java.lang.Class<?> wildcardClass21 = normalDistributionImpl18.getClass();
//        double double22 = randomDataImpl15.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        java.lang.Object[] objArray23 = new java.lang.Object[] { (byte) 10, number13, (byte) 10, double22 };
//        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException5, "3035ea3a17", objArray23);
//        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException5);
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (byte) 100 + "'", number13.equals((byte) 100));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "93c873c128" + "'", str17.equals("93c873c128"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.2969732973096655d) + "'", double22 == (-1.2969732973096655d));
//        org.junit.Assert.assertNotNull(objArray23);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 52.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        double double10 = randomDataImpl0.nextGamma((double) (byte) 100, 5.551115123125783E-17d);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double[] doubleArray13 = normalDistributionImpl11.sample(32);
        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
        double double17 = randomDataImpl0.nextCauchy(1.1031908548556288E-53d, 162.1605745804084d);
        java.lang.String str19 = randomDataImpl0.nextHexString(35);
        long long22 = randomDataImpl0.nextLong((long) 59, 103L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.356360972744053E-9d + "'", double10 == 1.356360972744053E-9d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.008992146246399135d) + "'", double14 == (-0.008992146246399135d));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-105.3294356130328d) + "'", double17 == (-105.3294356130328d));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "c295964df55fa86a190d769241e5be164b3" + "'", str19.equals("c295964df55fa86a190d769241e5be164b3"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 65L + "'", long22 == 65L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Throwable[] throwableArray4 = convergenceException3.getSuppressed();
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(throwable6, "hi!", objArray8);
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException12.getGeneralPattern();
        java.lang.Throwable throwable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(throwable14, "hi!", objArray16);
        java.lang.Throwable throwable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(throwable18, "hi!", objArray20);
        java.lang.Throwable[] throwableArray22 = convergenceException21.getSuppressed();
        convergenceException17.addSuppressed((java.lang.Throwable) convergenceException21);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21, "org.apache.commons.math.ConvergenceException: hi!", objArray25);
        java.lang.Throwable[] throwableArray27 = convergenceException26.getSuppressed();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable13, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, "", (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        convergenceException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException33);
        java.lang.Number number35 = numberIsTooLargeException33.getArgument();
        java.lang.Throwable throwable36 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, "hi!", objArray38);
        java.lang.Object[] objArray41 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException39, "", objArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = convergenceException39.getGeneralPattern();
        java.lang.Object[] objArray47 = new java.lang.Object[] { (short) 100 };
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("", objArray47);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("51e095b11819b59807101a48841667d3ddd2b26d60bf1de0ad4cfa1752fc514561ee86931125e6fcbe2b2624b7f23b601859", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException33, localizable43, objArray47);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 1.107943536736182d + "'", number35.equals(1.107943536736182d));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertNotNull(objArray47);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed((long) 10);
//        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
//        randomDataImpl0.reSeed((long) '#');
//        double double10 = randomDataImpl0.nextGamma((double) (byte) 100, 5.551115123125783E-17d);
//        java.lang.String str12 = randomDataImpl0.nextSecureHexString((int) '#');
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.356360972744053E-9d + "'", double10 == 1.356360972744053E-9d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0d27921842e11f0c194b3f4cbc7f7552673" + "'", str12.equals("0d27921842e11f0c194b3f4cbc7f7552673"));
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 118L);
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException(throwable2, "hi!", objArray4);
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException5, "", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getGeneralPattern();
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, number10, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 5.298292365610485d, (java.lang.Number) 116L);
        numberIsTooSmallException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
        java.lang.Throwable throwable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(throwable19, "hi!", objArray21);
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, "", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = convergenceException25.getGeneralPattern();
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable26, number27, (java.lang.Number) 100.0d, false);
        outOfRangeException17.addSuppressed((java.lang.Throwable) numberIsTooSmallException30);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) outOfRangeException17);
        boolean boolean33 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Throwable[] throwableArray4 = convergenceException3.getSuppressed();
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(throwable6, "hi!", objArray8);
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException12.getGeneralPattern();
        java.lang.Throwable throwable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(throwable14, "hi!", objArray16);
        java.lang.Throwable throwable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(throwable18, "hi!", objArray20);
        java.lang.Throwable[] throwableArray22 = convergenceException21.getSuppressed();
        convergenceException17.addSuppressed((java.lang.Throwable) convergenceException21);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21, "org.apache.commons.math.ConvergenceException: hi!", objArray25);
        java.lang.Throwable[] throwableArray27 = convergenceException26.getSuppressed();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable13, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, "", (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        convergenceException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException33);
        java.lang.Number number35 = numberIsTooLargeException33.getMax();
        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException33.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (short) 0 + "'", number35.equals((short) 0));
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 105.0d, (java.lang.Number) (byte) 100, false);
        java.lang.Throwable[] throwableArray4 = numberIsTooLargeException3.getSuppressed();
        java.lang.Number number5 = numberIsTooLargeException3.getArgument();
        java.lang.Object[] objArray6 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 105.0d + "'", number5.equals(105.0d));
        org.junit.Assert.assertNotNull(objArray6);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString(10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double5 = normalDistributionImpl3.cumulativeProbability((double) 97.0f);
//        java.lang.Class<?> wildcardClass6 = normalDistributionImpl3.getClass();
//        double double7 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        randomDataImpl0.reSeed((long) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution11 = null;
//        try {
//            int int12 = randomDataImpl0.nextInversionDeviate(integerDistribution11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0ecf8ba07b" + "'", str2.equals("0ecf8ba07b"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.3518351404641975d) + "'", double7 == (-0.3518351404641975d));
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        int int8 = randomDataImpl1.nextZipf(27, (double) 94L);
        double double11 = randomDataImpl1.nextGamma(5.267831587699267d, (double) 91L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 244.53454358653224d + "'", double11 == 244.53454358653224d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
        int int8 = randomDataImpl1.nextInt(1, (int) (byte) 100);
        try {
            long long10 = randomDataImpl1.nextPoisson((-20.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -20 is smaller than, or equal to, the minimum (0): mean (-20)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 27 + "'", int8 == 27);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed((long) 10);
//        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
//        double double8 = randomDataImpl0.nextWeibull(1.66161881444429d, 1.0000000000000003E-9d);
//        double double11 = randomDataImpl0.nextCauchy((double) 0.0f, (double) 108L);
//        randomDataImpl0.reSeedSecure();
//        double double14 = randomDataImpl0.nextExponential(5557.690612768985d);
//        long long17 = randomDataImpl0.nextSecureLong((long) (short) 1, (long) 32);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.827190116422218E-10d + "'", double8 == 4.827190116422218E-10d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-573.9701093641019d) + "'", double11 == (-573.9701093641019d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 7836.936402838169d + "'", double14 == 7836.936402838169d);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 27L + "'", long17 == 27L);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 10);
        double double5 = randomDataImpl0.nextF(0.5772156649015329d, 10.0d);
        randomDataImpl0.reSeed((long) '#');
        double double9 = randomDataImpl0.nextExponential(0.4485633290585931d);
        double double12 = randomDataImpl0.nextCauchy((-0.6501341356232105d), 0.08680315236652447d);
        try {
            int int16 = randomDataImpl0.nextHypergeometric((int) (short) -1, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.107943536736182d + "'", double5 == 1.107943536736182d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.1422808082595999d + "'", double9 == 0.1422808082595999d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.6511124339973873d) + "'", double12 == (-0.6511124339973873d));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(throwable8, "hi!", objArray10);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        convergenceException11.addSuppressed((java.lang.Throwable) convergenceException15);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "org.apache.commons.math.ConvergenceException: hi!", objArray19);
        java.lang.Throwable[] throwableArray21 = convergenceException20.getSuppressed();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 57.29577951308232d, (java.lang.Number) 155.74607629780772d, true);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooLargeException26.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.015240431553777101d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.015241611632258793d + "'", double1 == 0.015241611632258793d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.4428584349276598E-9d, 17.514285714285712d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4458336988667309E-155d + "'", double2 == 1.4458336988667309E-155d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, "hi!", objArray14);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        java.lang.Throwable throwable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(throwable18, "hi!", objArray20);
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21, "", objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        java.lang.Throwable throwable26 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(throwable26, "hi!", objArray28);
        java.lang.Throwable throwable30 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(throwable30, "hi!", objArray32);
        java.lang.Throwable[] throwableArray34 = convergenceException33.getSuppressed();
        convergenceException29.addSuppressed((java.lang.Throwable) convergenceException33);
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException33, "org.apache.commons.math.ConvergenceException: hi!", objArray37);
        java.lang.Throwable[] throwableArray39 = convergenceException38.getSuppressed();
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable25, (java.lang.Object[]) throwableArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, "", (java.lang.Object[]) throwableArray39);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        convergenceException15.addSuppressed((java.lang.Throwable) numberIsTooLargeException45);
        numberIsTooSmallException11.addSuppressed((java.lang.Throwable) numberIsTooLargeException45);
        java.lang.Number number48 = numberIsTooSmallException11.getMin();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 100.0d + "'", number48.equals(100.0d));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException11.getGeneralPattern();
        boolean boolean13 = numberIsTooSmallException11.getBoundIsAllowed();
        java.lang.Number number14 = numberIsTooSmallException11.getMin();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 100.0d + "'", number14.equals(100.0d));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.2672484669265062d, 39.670515905542324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.842600654448784E-23d + "'", double2 == 1.842600654448784E-23d);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) (short) 100);
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
//        long long8 = randomDataImpl1.nextSecureLong((long) 0, (long) (short) 10);
//        randomDataImpl1.reSeedSecure((long) 10);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041" + "'", str5.equals("561f5538345b923cc57369b1e963be37e7784a2af4d78c871866c747d17a15cdf691dd1ec20938337dc8031f9a7a2fbfc041"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 4.73137E-319d, (java.lang.Number) 45, false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        long long1 = org.apache.commons.math.util.FastMath.abs(8L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8L + "'", long1 == 8L);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long4 = randomDataImpl0.nextPoisson(1.3296798906723511E-46d);
//        double double7 = randomDataImpl0.nextBeta(0.009784837054594254d, (double) 10L);
//        randomDataImpl0.reSeedSecure(35L);
//        randomDataImpl0.reSeed();
//        try {
//            randomDataImpl0.setSecureAlgorithm("8011dc58df", "ce2248a6c9");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: ce2248a6c9");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Throwable[] throwableArray4 = convergenceException3.getSuppressed();
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(throwable6, "hi!", objArray8);
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException12.getGeneralPattern();
        java.lang.Throwable throwable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(throwable14, "hi!", objArray16);
        java.lang.Throwable throwable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(throwable18, "hi!", objArray20);
        java.lang.Throwable[] throwableArray22 = convergenceException21.getSuppressed();
        convergenceException17.addSuppressed((java.lang.Throwable) convergenceException21);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21, "org.apache.commons.math.ConvergenceException: hi!", objArray25);
        java.lang.Throwable[] throwableArray27 = convergenceException26.getSuppressed();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable13, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, "", (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.exception.util.Localizable localizable30 = mathException29.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNull(localizable30);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double2 = org.apache.commons.math.util.FastMath.max(0.6264011299651113d, (-296.7781898810204d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6264011299651113d + "'", double2 == 0.6264011299651113d);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull(Double.NaN, (double) 127L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double6 = normalDistributionImpl4.cumulativeProbability((double) 97.0f);
//        double double7 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.30151243931239285d) + "'", double7 == (-0.30151243931239285d));
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(100);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 100, (java.lang.Number) 97.0f, false);
//        boolean boolean7 = numberIsTooLargeException6.getBoundIsAllowed();
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 100);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 105.0d, (java.lang.Number) (byte) 100, false);
//        java.lang.Throwable[] throwableArray17 = numberIsTooLargeException16.getSuppressed();
//        java.lang.Number number18 = numberIsTooLargeException16.getMax();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str22 = randomDataImpl20.nextSecureHexString(10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl23 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double25 = normalDistributionImpl23.cumulativeProbability((double) 97.0f);
//        java.lang.Class<?> wildcardClass26 = normalDistributionImpl23.getClass();
//        double double27 = randomDataImpl20.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        java.lang.Object[] objArray28 = new java.lang.Object[] { (byte) 10, number18, (byte) 10, double27 };
//        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException10, "3035ea3a17", objArray28);
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, "3035ea3a17", objArray28);
//        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1, "ad3134556674dc412c3f3e377ee3ecf0a0eebc7411a48c969e32", objArray28);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(throwableArray17);
//        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (byte) 100 + "'", number18.equals((byte) 100));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "f346548d83" + "'", str22.equals("f346548d83"));
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-0.6186841988624728d) + "'", double27 == (-0.6186841988624728d));
//        org.junit.Assert.assertNotNull(objArray28);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        randomDataImpl1.reSeedSecure((long) 'a');
        int int8 = randomDataImpl1.nextZipf((int) (short) 100, (double) '4');
        randomDataImpl1.reSeed(0L);
        try {
            int[] intArray13 = randomDataImpl1.nextPermutation((int) (byte) 10, 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2,147,483,647 is larger than the maximum (10): permutation size (2,147,483,647) exceeds permuation domain (10)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        long long2 = org.apache.commons.math.util.FastMath.max(91L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 91L + "'", long2 == 91L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double1 = org.apache.commons.math.util.FastMath.ulp(9.784833931829355E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1684043449710089E-19d + "'", double1 == 2.1684043449710089E-19d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.447572511216542d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Object[] objArray3 = notStrictlyPositiveException1.getArguments();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 100);
        randomDataImpl1.reSeedSecure((long) 'a');
        double double8 = randomDataImpl1.nextCauchy(1.6574544541530771d, (double) 97L);
        java.lang.String str10 = randomDataImpl1.nextHexString(27);
        randomDataImpl1.reSeed((long) 52);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 82.93979543186188d + "'", double8 == 82.93979543186188d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "c57369b1e963be37e7784a2af4d" + "'", str10.equals("c57369b1e963be37e7784a2af4d"));
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString(10);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "dcc7450478" + "'", str2.equals("dcc7450478"));
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.5655613964506483d, (java.lang.Number) 2.059488517353309d, number2);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.cumulativeProbability((double) 97.0f);
//        double double3 = normalDistributionImpl0.sample();
//        double double5 = normalDistributionImpl0.density(5.8822072909201655d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.5666361272406402d) + "'", double3 == (-0.5666361272406402d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.2233107393975772E-8d + "'", double5 == 1.2233107393975772E-8d);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 105L, (java.lang.Number) 104L, (java.lang.Number) 3.1622776601683795d);
        java.lang.Object[] objArray4 = outOfRangeException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 100);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 105.0d, (java.lang.Number) (byte) 100, false);
//        java.lang.Throwable[] throwableArray9 = numberIsTooLargeException8.getSuppressed();
//        java.lang.Number number10 = numberIsTooLargeException8.getMax();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str14 = randomDataImpl12.nextSecureHexString(10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double17 = normalDistributionImpl15.cumulativeProbability((double) 97.0f);
//        java.lang.Class<?> wildcardClass18 = normalDistributionImpl15.getClass();
//        double double19 = randomDataImpl12.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        java.lang.Object[] objArray20 = new java.lang.Object[] { (byte) 10, number10, (byte) 10, double19 };
//        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "3035ea3a17", objArray20);
//        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray20);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 100 + "'", number10.equals((byte) 100));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "c2c76e1ae9" + "'", str14.equals("c2c76e1ae9"));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.6056845555184938d) + "'", double19 == (-0.6056845555184938d));
//        org.junit.Assert.assertNotNull(objArray20);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-8.46970322E8d), (-0.39504665644848797d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.01745329251870086d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.553342148058554d + "'", double1 == 1.553342148058554d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.107943536736182d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 0.999875764595612d, (java.lang.Number) (-0.9819521690440836d), (java.lang.Number) (byte) 1);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double4 = normalDistributionImpl0.density(1.0000000000000002d);
        double double6 = normalDistributionImpl0.inverseCumulativeProbability(0.0d);
        double double7 = normalDistributionImpl0.getStandardDeviation();
        double double9 = normalDistributionImpl0.cumulativeProbability(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.24197072451914334d + "'", double4 == 0.24197072451914334d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.NEGATIVE_INFINITY + "'", double6 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 5.298292365610485d, (java.lang.Number) 116L);
        numberIsTooSmallException11.addSuppressed((java.lang.Throwable) outOfRangeException15);
        java.lang.Throwable throwable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(throwable17, "hi!", objArray19);
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException20, "", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable24 = convergenceException23.getGeneralPattern();
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, number25, (java.lang.Number) 100.0d, false);
        outOfRangeException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException28);
        java.lang.Number number30 = numberIsTooSmallException28.getMin();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable24);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 100.0d + "'", number30.equals(100.0d));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) 100.0d, false);
        java.lang.Object[] objArray14 = new java.lang.Object[] { (short) 100 };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray14);
        java.lang.Throwable throwable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(throwable19, "hi!", objArray21);
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, "", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = convergenceException25.getGeneralPattern();
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(throwable27, "hi!", objArray29);
        java.lang.Throwable throwable31 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(throwable31, "hi!", objArray33);
        java.lang.Throwable[] throwableArray35 = convergenceException34.getSuppressed();
        convergenceException30.addSuppressed((java.lang.Throwable) convergenceException34);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException34, "org.apache.commons.math.ConvergenceException: hi!", objArray38);
        java.lang.Throwable[] throwableArray40 = convergenceException39.getSuppressed();
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable26, (java.lang.Object[]) throwableArray40);
        java.lang.Throwable throwable42 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(throwable42, "hi!", objArray44);
        java.lang.Object[] objArray47 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException45, "", objArray47);
        org.apache.commons.math.exception.util.Localizable localizable49 = convergenceException48.getGeneralPattern();
        java.lang.Throwable throwable50 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(throwable50, "hi!", objArray52);
        java.lang.Throwable throwable54 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(throwable54, "hi!", objArray56);
        java.lang.Throwable[] throwableArray58 = convergenceException57.getSuppressed();
        convergenceException53.addSuppressed((java.lang.Throwable) convergenceException57);
        java.lang.Object[] objArray61 = null;
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException57, "org.apache.commons.math.ConvergenceException: hi!", objArray61);
        java.lang.Throwable[] throwableArray63 = convergenceException62.getSuppressed();
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException(localizable49, (java.lang.Object[]) throwableArray63);
        java.lang.Throwable throwable65 = null;
        java.lang.Object[] objArray67 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException(throwable65, "hi!", objArray67);
        java.lang.Throwable[] throwableArray69 = convergenceException68.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable49, (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", (java.lang.Object[]) throwableArray69);
        java.lang.Object[] objArray72 = maxIterationsExceededException71.getArguments();
        int int73 = maxIterationsExceededException71.getMaxIterations();
        mathIllegalArgumentException16.addSuppressed((java.lang.Throwable) maxIterationsExceededException71);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(localizable49);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertNotNull(throwableArray63);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(throwableArray69);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 10 + "'", int73 == 10);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 118L);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.4485633290585931d, (-0.6186841988624728d), 0.6156739115059177d, 27);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.615942194802602d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5520593064361228d + "'", double1 == 0.5520593064361228d);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long4 = randomDataImpl1.nextLong((long) '#', (long) (byte) 100);
//        int[] intArray7 = randomDataImpl1.nextPermutation(27, 27);
//        long long10 = randomDataImpl1.nextLong((long) (byte) 10, 35L);
//        int int13 = randomDataImpl1.nextPascal((int) (byte) 1, 0.0d);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 36L + "'", long4 == 36L);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 17L + "'", long10 == 17L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(7836.936402838169d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 62430.198837086486d + "'", double1 == 62430.198837086486d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.0000475839102714d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray2);
        java.lang.Throwable throwable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(throwable4, "hi!", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        convergenceException3.addSuppressed((java.lang.Throwable) convergenceException7);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7);
        java.lang.Throwable[] throwableArray11 = mathException10.getSuppressed();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.147128399668605d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, number4, (java.lang.Number) 105L, false);
        java.lang.Number number8 = numberIsTooSmallException7.getArgument();
        java.lang.Number number9 = numberIsTooSmallException7.getMin();
        java.lang.Throwable throwable10 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(throwable10, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException13, "", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        java.lang.Throwable throwable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(throwable18, "hi!", objArray20);
        java.lang.Throwable throwable22 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(throwable22, "hi!", objArray24);
        java.lang.Throwable[] throwableArray26 = convergenceException25.getSuppressed();
        convergenceException21.addSuppressed((java.lang.Throwable) convergenceException25);
        java.lang.Object[] objArray29 = null;
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException25, "org.apache.commons.math.ConvergenceException: hi!", objArray29);
        java.lang.Throwable[] throwableArray31 = convergenceException30.getSuppressed();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable17, (java.lang.Object[]) throwableArray31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException32);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException33);
        numberIsTooSmallException7.addSuppressed((java.lang.Throwable) mathException34);
        java.lang.Throwable throwable36 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, "hi!", objArray38);
        java.lang.Object[] objArray41 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException39, "", objArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = convergenceException39.getGeneralPattern();
        java.lang.Throwable throwable44 = null;
        java.lang.Throwable throwable46 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(throwable46, "hi!", objArray48);
        java.lang.Object[] objArray51 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException49, "", objArray51);
        org.apache.commons.math.exception.util.Localizable localizable53 = convergenceException52.getGeneralPattern();
        java.lang.Throwable throwable54 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(throwable54, "hi!", objArray56);
        java.lang.Throwable throwable58 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(throwable58, "hi!", objArray60);
        java.lang.Throwable[] throwableArray62 = convergenceException61.getSuppressed();
        convergenceException57.addSuppressed((java.lang.Throwable) convergenceException61);
        java.lang.Object[] objArray65 = null;
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException61, "org.apache.commons.math.ConvergenceException: hi!", objArray65);
        java.lang.Throwable[] throwableArray67 = convergenceException66.getSuppressed();
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException(localizable53, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(throwable44, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException7, localizable43, (java.lang.Object[]) throwableArray67);
        java.lang.Object[] objArray72 = null;
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException70, "", objArray72);
        java.lang.Object[] objArray74 = convergenceException70.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException("", objArray74);
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException("3035ea3a17", objArray74);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException(localizable0, objArray74);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 105L + "'", number9.equals(105L));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(localizable53);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(objArray74);
    }
}

