import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getZero();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.1374631790669105d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((int) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp9.subtract(dfp16);
        java.lang.Object obj18 = null;
        boolean boolean19 = dfp9.equals(obj18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getE();
        int int23 = dfpField21.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp25 = new org.apache.commons.math.dfp.Dfp(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getE();
        int int29 = dfpField27.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getSqr2Reciprocal();
        dfpField27.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getPi();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.newDfp((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = org.apache.commons.math.dfp.DfpField.computeLn(dfp24, dfp32, dfp37);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp9.multiply(dfp24);
        boolean boolean40 = dfp4.equals((java.lang.Object) dfp39);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getE();
        int int44 = dfpField42.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp46 = new org.apache.commons.math.dfp.Dfp(dfp45);
        int int47 = dfp46.log10K();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.getZero();
        boolean boolean49 = dfp46.isNaN();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp46.getTwo();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.newInstance();
        boolean boolean52 = dfp4.equals((java.lang.Object) dfp50);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.subtract(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp15);
        int int17 = dfp16.log10K();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp9.multiply(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.sqrt();
        boolean boolean20 = dfp16.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp16.newInstance();
        double double22 = dfp21.toDouble();
        org.apache.commons.math.dfp.Dfp dfp23 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp24 = dfp21.add(dfp23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + Double.NEGATIVE_INFINITY + "'", double22 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.negate();
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((byte) 3);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.subtract(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp15);
        int int17 = dfp16.log10K();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp9.multiply(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.sqrt();
        boolean boolean20 = dfp16.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.newInstance(32760);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getE();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField25.newDfp((-1.0d));
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField25.getE();
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.DfpField.computeExp(dfp23, dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getE();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.newInstance((int) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getE();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp44.newInstance();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp39.add(dfp47);
        java.lang.Class<?> wildcardClass49 = dfp47.getClass();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.getE();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp52.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp52.newInstance();
        boolean boolean56 = dfp52.isNaN();
        org.apache.commons.math.dfp.Dfp dfp57 = org.apache.commons.math.dfp.Dfp.copysign(dfp47, dfp52);
        try {
            org.apache.commons.math.dfp.Dfp dfp58 = org.apache.commons.math.dfp.DfpField.computeLn(dfp33, dfp34, dfp52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dfp57);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.9949371190584296d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) -1, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.subtract(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp15);
        int int17 = dfp16.log10K();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp9.multiply(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.sqrt();
        org.apache.commons.math.dfp.Dfp dfp20 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance((int) ' ');
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        try {
            org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 2.99822295029797d);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Number number5 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 2.99822295029797d + "'", number3.equals(2.99822295029797d));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.99822295029797d + "'", number5.equals(2.99822295029797d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.subtract(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp15);
        int int17 = dfp16.log10K();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp9.multiply(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.sqrt();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp16.newInstance((double) (byte) -1);
        double double22 = dfp21.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.0d) + "'", double22 == (-1.0d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.05813117374834222d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0016900925350325d + "'", double1 == 1.0016900925350325d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.power10((int) (short) 1);
        boolean boolean13 = dfp10.isInfinite();
        boolean boolean14 = dfp7.unequal(dfp10);
        int int15 = dfp10.log10K();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.subtract(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.divide((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp10.subtract(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp10.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp19 = dfp10.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-4));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 16);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 16.0f + "'", float1 == 16.0f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        int int8 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getE();
        int int19 = dfpField17.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.add(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getE();
        int int25 = dfpField23.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.getSqr2Reciprocal();
        boolean boolean27 = dfp26.isNaN();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp20.remainder(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp10.nextAfter(dfp20);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.multiply(0);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getE();
        int int35 = dfpField33.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getSqr2Reciprocal();
        dfpField33.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField33.getE();
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeExp(dfp29, dfp39);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.multiply((int) '#');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.power10(32768);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getZero();
        java.lang.String str6 = dfp5.toString();
        boolean boolean7 = dfp5.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0." + "'", str6.equals("0."));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        boolean boolean5 = dfp2.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.subtract(dfp15);
        java.lang.Object obj17 = null;
        boolean boolean18 = dfp8.equals(obj17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        int int22 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = new org.apache.commons.math.dfp.Dfp(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getE();
        int int28 = dfpField26.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getSqr2Reciprocal();
        dfpField26.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.getPi();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp37 = org.apache.commons.math.dfp.DfpField.computeLn(dfp23, dfp31, dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp8.multiply(dfp23);
        boolean boolean39 = dfp2.lessThan(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getE();
        int int43 = dfpField41.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField41.getESplit();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField41.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getE();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getE();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp53.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp56 = dfp48.subtract(dfp55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField58.getE();
        int int60 = dfpField58.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField58.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp62 = new org.apache.commons.math.dfp.Dfp(dfp61);
        int int63 = dfp62.log10K();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp55.multiply(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp62.sqrt();
        boolean boolean66 = dfp62.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp67 = dfp62.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getE();
        int int71 = dfpField69.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray72 = dfpField69.getESplit();
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField69.newDfp(1.0d);
        boolean boolean75 = dfp67.equals((java.lang.Object) dfpField69);
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField41.newDfp(dfp67);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp8.newInstance(dfp76);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 4 + "'", int60 == 4);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 4 + "'", int71 == 4);
        org.junit.Assert.assertNotNull(dfpArray72);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        dfpField1.clearIEEEFlags();
        int int6 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getE();
        int int9 = dfpField7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getSqr2Reciprocal();
        dfpField7.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.getPi();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeLn(dfp4, dfp12, dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp4.newInstance((long) '#');
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getE();
        int int24 = dfpField22.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = new org.apache.commons.math.dfp.Dfp(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.power10K((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getE();
        int int32 = dfpField30.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp34 = new org.apache.commons.math.dfp.Dfp(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeExp(dfp28, dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.sqrt();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp4.nextAfter(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getE();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getE();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp45.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp48 = dfp40.subtract(dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getE();
        int int52 = dfpField50.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp54 = new org.apache.commons.math.dfp.Dfp(dfp53);
        int int55 = dfp54.log10K();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp47.multiply(dfp54);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp54.sqrt();
        boolean boolean58 = dfp54.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp54.newInstance(32760);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp60.getTwo();
        org.apache.commons.math.dfp.Dfp dfp62 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp61);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField64.newDfp((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray68 = dfpField64.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField64.getLn2();
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField64.getPi();
        org.apache.commons.math.dfp.DfpField dfpField72 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField72.getE();
        int int74 = dfpField72.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField72.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp76 = new org.apache.commons.math.dfp.Dfp(dfp75);
        int int77 = dfp76.log10K();
        org.apache.commons.math.dfp.Dfp dfp78 = dfp76.getZero();
        boolean boolean79 = dfp76.isNaN();
        org.apache.commons.math.dfp.Dfp dfp80 = dfp76.getTwo();
        org.apache.commons.math.dfp.Dfp dfp82 = dfp76.newInstance(0.0d);
        org.apache.commons.math.dfp.Dfp dfp83 = org.apache.commons.math.dfp.DfpField.computeLn(dfp62, dfp70, dfp76);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfpArray68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 4 + "'", int74 == 4);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.FastMath.exp(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.642595581083531E24d + "'", double1 == 7.642595581083531E24d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(7.896296018268069E13d);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 7.896296018268069E13d, number1, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField6.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) dfpArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathIllegalArgumentException8.getSpecificPattern();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) mathIllegalArgumentException8);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException8);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNull(localizable9);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.0016900925350325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = new org.apache.commons.math.dfp.Dfp(dfp4);
        int int6 = dfp5.log10K();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.getZero();
        boolean boolean8 = dfp5.isNaN();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.newInstance();
        boolean boolean11 = dfp9.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.divide((int) (byte) 3);
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        double double2 = mersenneTwister0.nextGaussian();
//        mersenneTwister0.setSeed(8);
//        int int6 = mersenneTwister0.nextInt((int) (byte) 3);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.9237262540474687d) + "'", double2 == (-1.9237262540474687d));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.negate();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10((int) (short) 1);
        boolean boolean15 = dfp12.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getE();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getE();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp26 = dfp18.subtract(dfp25);
        java.lang.Object obj27 = null;
        boolean boolean28 = dfp18.equals(obj27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getE();
        int int32 = dfpField30.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp34 = new org.apache.commons.math.dfp.Dfp(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getE();
        int int38 = dfpField36.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.getSqr2Reciprocal();
        dfpField36.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField36.getPi();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField43.newDfp((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp47 = org.apache.commons.math.dfp.DfpField.computeLn(dfp33, dfp41, dfp46);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp18.multiply(dfp33);
        boolean boolean49 = dfp12.lessThan(dfp18);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp18.power10K((-32767));
        org.apache.commons.math.dfp.Dfp dfp52 = dfp9.nextAfter(dfp51);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.5347999967395426d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8117029642780976d + "'", double1 == 0.8117029642780976d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(2L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 7.896296018268069E13d, number1, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField6.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) dfpArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathIllegalArgumentException8.getSpecificPattern();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) mathIllegalArgumentException8);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathIllegalArgumentException8.getGeneralPattern();
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        double double3 = mersenneTwister2.nextGaussian();
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister();
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 1);
        double double7 = mersenneTwister6.nextGaussian();
        int int9 = mersenneTwister6.nextInt((int) 'a');
        byte[] byteArray11 = new byte[] { (byte) 100 };
        mersenneTwister6.nextBytes(byteArray11);
        mersenneTwister4.nextBytes(byteArray11);
        mersenneTwister2.nextBytes(byteArray11);
        double double15 = mersenneTwister2.nextDouble();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7650730050315234d + "'", double3 == 0.7650730050315234d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0019203836877835d + "'", double7 == 1.0019203836877835d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 27 + "'", int9 == 27);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.1747475073563043d + "'", double15 == 0.1747475073563043d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        int int2 = org.apache.commons.math.util.FastMath.max(338087802, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 338087802 + "'", int2 == 338087802);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1L));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) '4');
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.762747174039086d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.762747174039086d + "'", double1 == 1.762747174039086d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0d, (java.lang.Number) (-0.7856166766042585d), false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.subtract(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getE();
        int int20 = dfpField18.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp22.log10K();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp15.multiply(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp22.sqrt();
        boolean boolean26 = dfp22.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp22.newInstance();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.power10(4);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp5.multiply(dfp31);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.subtract(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp15);
        int int17 = dfp16.log10K();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp9.multiply(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.sqrt();
        boolean boolean20 = dfp16.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp16.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getE();
        int int25 = dfpField23.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField23.getESplit();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.newDfp(1.0d);
        boolean boolean29 = dfp21.equals((java.lang.Object) dfpField23);
        dfpField23.setIEEEFlags((int) (byte) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = null;
        dfpField1.setRoundingMode(roundingMode4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9251475365964139d) + "'", double1 == (-0.9251475365964139d));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 2.99822295029797d);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField6.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) dfpArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 2.99822295029797d);
        java.lang.Number number16 = notStrictlyPositiveException15.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException15.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getE();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField19.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, (java.lang.Object[]) dfpArray24);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 0.05813117374834222d);
        java.lang.Throwable[] throwableArray28 = notStrictlyPositiveException27.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) throwableArray28);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 2.99822295029797d + "'", number3.equals(2.99822295029797d));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 2.99822295029797d + "'", number16.equals(2.99822295029797d));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.atan(32768.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570765809216781d + "'", double1 == 1.570765809216781d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 1);
        int[] intArray3 = new int[] { 0 };
        mersenneTwister1.setSeed(intArray3);
        int[] intArray6 = new int[] { (byte) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextGaussian();
        mersenneTwister7.setSeed((long) 100);
        int[] intArray17 = new int[] { (-4), 3, (byte) 10, 2147483647, '#', 4 };
        mersenneTwister7.setSeed(intArray17);
        int[] intArray20 = new int[] { (byte) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math.random.MersenneTwister(intArray20);
        double double22 = mersenneTwister21.nextGaussian();
        org.apache.commons.math.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math.random.MersenneTwister();
        org.apache.commons.math.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 1);
        double double26 = mersenneTwister25.nextGaussian();
        int int28 = mersenneTwister25.nextInt((int) 'a');
        byte[] byteArray30 = new byte[] { (byte) 100 };
        mersenneTwister25.nextBytes(byteArray30);
        mersenneTwister23.nextBytes(byteArray30);
        mersenneTwister21.nextBytes(byteArray30);
        mersenneTwister7.nextBytes(byteArray30);
        mersenneTwister1.nextBytes(byteArray30);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7650730050315234d + "'", double8 == 0.7650730050315234d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7650730050315234d + "'", double22 == 0.7650730050315234d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0019203836877835d + "'", double26 == 1.0019203836877835d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 27 + "'", int28 == 27);
        org.junit.Assert.assertNotNull(byteArray30);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.subtract(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp15);
        int int17 = dfp16.log10K();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp9.multiply(dfp16);
        try {
            org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance(7256785470231326570L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (byte) 10);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Throwable[] throwableArray4 = notStrictlyPositiveException2.getSuppressed();
        java.lang.Number number5 = notStrictlyPositiveException2.getMin();
        java.lang.Number number6 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number7 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 10 + "'", number6.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((int) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.add(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((byte) -1);
        boolean boolean21 = dfp4.lessThan(dfp18);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.762747174039086d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1907742746372595d) + "'", double1 == (-0.1907742746372595d));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        int[] intArray4 = new int[] { (byte) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        double double6 = mersenneTwister5.nextGaussian();
        mersenneTwister5.setSeed((long) 100);
        int[] intArray15 = new int[] { (-4), 3, (byte) 10, 2147483647, '#', 4 };
        mersenneTwister5.setSeed(intArray15);
        mersenneTwister2.setSeed(intArray15);
        boolean boolean18 = mersenneTwister2.nextBoolean();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7650730050315234d + "'", double6 == 0.7650730050315234d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10K((int) 'a');
        double double5 = dfp4.toDouble();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10K((int) (byte) 0);
        boolean boolean9 = dfp6.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.subtract(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp15);
        int int17 = dfp16.log10K();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp9.multiply(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.sqrt();
        boolean boolean20 = dfp16.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp16.newInstance();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10(4);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance(16);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 750534796);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.129443752280466d + "'", double1 == 21.129443752280466d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.exception.MathRuntimeException(throwable1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathRuntimeException2.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException2);
        java.lang.String str5 = mathRuntimeException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        int int11 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField9.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException4, localizable6, localizable7, (java.lang.Object[]) dfpArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray12);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 2.99822295029797d);
        java.lang.Number number18 = notStrictlyPositiveException17.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable19 = notStrictlyPositiveException17.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getE();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField21.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, (java.lang.Object[]) dfpArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable28, (java.lang.Number) 2.99822295029797d);
        java.lang.Number number31 = notStrictlyPositiveException30.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable32 = notStrictlyPositiveException30.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getE();
        int int36 = dfpField34.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.getSqr2Reciprocal();
        dfpField34.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getE();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.divide((int) (byte) 3);
        int int44 = dfp43.log10K();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField34.newDfp(dfp43);
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField34.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable32, (java.lang.Object[]) dfpArray46);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable48, (java.lang.Number) 2.99822295029797d);
        java.lang.Number number51 = notStrictlyPositiveException50.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable52 = notStrictlyPositiveException50.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException55 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable53, (java.lang.Number) 2.99822295029797d);
        java.lang.Number number56 = notStrictlyPositiveException55.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable57 = notStrictlyPositiveException55.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getE();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField59.newDfp();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField59.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField59.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, (java.lang.Object[]) dfpArray64);
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException68 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable66, (java.lang.Number) 2.99822295029797d);
        java.lang.Number number69 = notStrictlyPositiveException68.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable70 = notStrictlyPositiveException68.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField72 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField72.getE();
        int int74 = dfpField72.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField72.getSqr2Reciprocal();
        dfpField72.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField78 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField78.getE();
        org.apache.commons.math.dfp.Dfp dfp81 = dfp79.divide((int) (byte) 3);
        int int82 = dfp81.log10K();
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField72.newDfp(dfp81);
        org.apache.commons.math.dfp.Dfp[] dfpArray84 = dfpField72.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException85 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable70, (java.lang.Object[]) dfpArray84);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException86 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException14, localizable32, localizable52, (java.lang.Object[]) dfpArray84);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException90 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable52, (java.lang.Number) 7256785470231326570L, (java.lang.Number) 180.99723754798026d, true);
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str5.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 2.99822295029797d + "'", number18.equals(2.99822295029797d));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 2.99822295029797d + "'", number31.equals(2.99822295029797d));
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 2.99822295029797d + "'", number51.equals(2.99822295029797d));
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 2.99822295029797d + "'", number56.equals(2.99822295029797d));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertTrue("'" + number69 + "' != '" + 2.99822295029797d + "'", number69.equals(2.99822295029797d));
        org.junit.Assert.assertTrue("'" + localizable70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable70.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 4 + "'", int74 == 4);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfpArray84);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        dfpField1.setIEEEFlags(32768);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((int) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.add(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp4.sqrt();
        java.lang.Object obj15 = null;
        boolean boolean16 = dfp14.equals(obj15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp14.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.subtract(dfp9);
        java.lang.Object obj11 = null;
        boolean boolean12 = dfp2.equals(obj11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getE();
        int int16 = dfpField14.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = new org.apache.commons.math.dfp.Dfp(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        int int22 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getSqr2Reciprocal();
        dfpField20.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.getPi();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.DfpField.computeLn(dfp17, dfp25, dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp2.multiply(dfp17);
        boolean boolean34 = dfp17.equals((java.lang.Object) 2.0f);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp17.newInstance(0.8091273563329898d);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getE();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getE();
        int int45 = dfpField43.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField43.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp41.add(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getE();
        int int51 = dfpField49.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.getSqr2Reciprocal();
        boolean boolean53 = dfp52.isNaN();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp46.remainder(dfp52);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.getE();
        int int58 = dfpField56.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField56.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp60 = new org.apache.commons.math.dfp.Dfp(dfp59);
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField62.getE();
        int int64 = dfpField62.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField62.getSqr2Reciprocal();
        dfpField62.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField62.getPi();
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField69.newDfp((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp73 = org.apache.commons.math.dfp.DfpField.computeLn(dfp59, dfp67, dfp72);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp67.getTwo();
        boolean boolean75 = dfp54.unequal(dfp74);
        boolean boolean76 = dfp36.lessThan(dfp74);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 4 + "'", int58 == 4);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 4 + "'", int64 == 4);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (short) -1);
        dfpField1.setIEEEFlags(1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((int) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getE();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.newInstance();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp13.add(dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.sqrt();
        java.lang.Object obj24 = null;
        boolean boolean25 = dfp23.equals(obj24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField1.newDfp(dfp23);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        mersenneTwister1.setSeed((long) (byte) -1);
        mersenneTwister1.setSeed((long) (byte) 100);
        float float6 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.07871711f + "'", float6 == 0.07871711f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.28170633747652984d), (java.lang.Number) (-0.1907742746372595d), true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        mersenneTwister1.setSeed((long) (byte) -1);
        mersenneTwister1.setSeed((long) (byte) 100);
        boolean boolean6 = mersenneTwister1.nextBoolean();
        float float7 = mersenneTwister1.nextFloat();
        int int9 = mersenneTwister1.nextInt(32768);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.45785296f + "'", float7 == 0.45785296f);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 21996 + "'", int9 == 21996);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, (int) (byte) 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.1907742746372595d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(1.0d);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        dfpField1.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2Reciprocal();
        int int9 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((byte) 0, (byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 21996);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.342343711009842d + "'", double1 == 4.342343711009842d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.multiply((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField9 = dfp8.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpField9);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 78,962,960,182,680.69 is smaller than the minimum (null)");
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) -1, (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance((int) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.newInstance();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp16.add(dfp24);
        java.lang.Class<?> wildcardClass26 = dfp24.getClass();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp29.newInstance();
        boolean boolean33 = dfp29.isNaN();
        org.apache.commons.math.dfp.Dfp dfp34 = org.apache.commons.math.dfp.Dfp.copysign(dfp24, dfp29);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.getTwo();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField1.newDfp(dfp29);
        org.apache.commons.math.dfp.Dfp dfp37 = null;
        try {
            boolean boolean38 = dfp29.lessThan(dfp37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        java.lang.Class<?> wildcardClass9 = dfpArray8.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.7650730050315234d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6996416322154407d + "'", double1 == 0.6996416322154407d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        dfpField1.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) '#');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        double double3 = mersenneTwister2.nextGaussian();
        mersenneTwister2.setSeed((long) 100);
        int[] intArray12 = new int[] { (-4), 3, (byte) 10, 2147483647, '#', 4 };
        mersenneTwister2.setSeed(intArray12);
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister(intArray12);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7650730050315234d + "'", double3 == 0.7650730050315234d);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.subtract(dfp9);
        java.lang.Object obj11 = null;
        boolean boolean12 = dfp2.equals(obj11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getE();
        int int16 = dfpField14.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = new org.apache.commons.math.dfp.Dfp(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        int int22 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getSqr2Reciprocal();
        dfpField20.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.getPi();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.DfpField.computeLn(dfp17, dfp25, dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp2.multiply(dfp17);
        boolean boolean34 = dfp17.equals((java.lang.Object) 2.0f);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp17.newInstance(0.8091273563329898d);
        double double37 = dfp36.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.809127356333d + "'", double37 == 0.809127356333d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        int int2 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 647325673 + "'", int2 == 647325673);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (byte) 1);
        int int9 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(5.916079783099616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8086089434116457d + "'", double1 == 1.8086089434116457d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(4L);
        mersenneTwister1.setSeed((long) 27);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = new org.apache.commons.math.dfp.Dfp(dfp4);
        int int6 = dfp5.log10K();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.getZero();
        boolean boolean8 = dfp5.isNaN();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.power10K(0);
        java.lang.String str11 = dfp10.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1." + "'", str11.equals("1."));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 0.45785296f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.007991041635594331d + "'", double1 == 0.007991041635594331d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        int[] intArray5 = new int[] { (byte) 100, 32768 };
        mersenneTwister2.setSeed(intArray5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray5);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        int int1 = org.apache.commons.math.util.FastMath.abs(10000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10000 + "'", int1 == 10000);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.9997618294932212d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9997618294932212d + "'", double1 == 0.9997618294932212d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getZero();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53.598150033144236d + "'", double1 == 53.598150033144236d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField6.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField6.getESplit();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.newDfp((long) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        int int15 = dfpField13.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = new org.apache.commons.math.dfp.Dfp(dfp16);
        int int18 = dfp17.log10K();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        int int22 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField20.getESplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.getLn10();
        boolean boolean25 = dfp17.equals((java.lang.Object) dfpField20);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField20.newDfp(100L);
        dfpField20.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode29 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField20.setRoundingMode(roundingMode29);
        dfpField1.setRoundingMode(roundingMode29);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + roundingMode29 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode29.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) -1, (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((-32767));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.subtract(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp15);
        int int17 = dfp16.log10K();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp9.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        int int22 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getSqr2Reciprocal();
        dfpField20.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField20.getSqr2Reciprocal();
        int int28 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField20.getESplit();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField20.newDfp((long) 2);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp9.nextAfter(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getE();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getE();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp43 = dfp35.subtract(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getE();
        int int47 = dfpField45.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp49 = new org.apache.commons.math.dfp.Dfp(dfp48);
        int int50 = dfp49.log10K();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp42.multiply(dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp49.sqrt();
        boolean boolean53 = dfp49.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp49.newInstance(32760);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp55.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField58.getE();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp59.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.getE();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp64.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp67 = dfp59.subtract(dfp66);
        java.lang.Object obj68 = null;
        boolean boolean69 = dfp59.equals(obj68);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField71.getE();
        int int73 = dfpField71.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField71.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp75 = new org.apache.commons.math.dfp.Dfp(dfp74);
        org.apache.commons.math.dfp.DfpField dfpField77 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField77.getE();
        int int79 = dfpField77.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField77.getSqr2Reciprocal();
        dfpField77.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField77.getPi();
        org.apache.commons.math.dfp.DfpField dfpField84 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp87 = dfpField84.newDfp((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp88 = org.apache.commons.math.dfp.DfpField.computeLn(dfp74, dfp82, dfp87);
        org.apache.commons.math.dfp.Dfp dfp89 = dfp59.multiply(dfp74);
        boolean boolean90 = dfp56.greaterThan(dfp89);
        org.apache.commons.math.dfp.Dfp dfp91 = dfp31.divide(dfp56);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 4 + "'", int73 == 4);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 4 + "'", int79 == 4);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(dfp91);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 0, false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-1.0d));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.subtract(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp15);
        int int17 = dfp16.log10K();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp9.multiply(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = new org.apache.commons.math.dfp.Dfp(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getE();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance((byte) 1);
        int int27 = dfp26.log10();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp19.divide(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp30 = dfp19.add(dfp29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-2869910283837542466L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double2 = org.apache.commons.math.util.FastMath.max(0.40481454969959474d, (double) (-1223252363L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.40481454969959474d + "'", double2 == 0.40481454969959474d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.subtract(dfp9);
        java.lang.Object obj11 = null;
        boolean boolean12 = dfp2.equals(obj11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getE();
        int int16 = dfpField14.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = new org.apache.commons.math.dfp.Dfp(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        int int22 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getSqr2Reciprocal();
        dfpField20.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.getPi();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.DfpField.computeLn(dfp17, dfp25, dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp2.multiply(dfp17);
        boolean boolean34 = dfp17.equals((java.lang.Object) 2.0f);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp17.newInstance(0.8091273563329898d);
        int int37 = dfp36.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = new org.apache.commons.math.dfp.Dfp(dfp4);
        int int6 = dfp5.log10K();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getE();
        int int10 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField8.getESplit();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getLn10();
        boolean boolean13 = dfp5.equals((java.lang.Object) dfpField8);
        int int14 = dfp5.intValue();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        int int18 = dfpField16.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField16.getESplit();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.getLn10();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField16.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp5.add(dfp21);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        dfpField1.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) '#');
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.power10K((int) 'a');
        double double14 = dfp13.toDouble();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.ceil();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.subtract(dfp13);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.newInstance(0.8117029642780976d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '#', (float) 32760);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32760.0f + "'", float2 == 32760.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 2.99822295029797d);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField6.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) dfpArray11);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 0.05813117374834222d);
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, number15, (java.lang.Number) (-1.0d), true);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getE();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp29 = dfp21.subtract(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getE();
        int int33 = dfpField31.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = new org.apache.commons.math.dfp.Dfp(dfp34);
        int int36 = dfp35.log10K();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp28.multiply(dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.sqrt();
        boolean boolean39 = dfp35.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp35.newInstance();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.power10(4);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.newInstance(16);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getE();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField50.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray55 = dfpField50.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable47, localizable48, (java.lang.Object[]) dfpArray55);
        boolean boolean57 = dfp46.equals((java.lang.Object) dfpArray55);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) dfpArray55);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 2.99822295029797d + "'", number3.equals(2.99822295029797d));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfpArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.8622957433108482d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8622957433108482d + "'", double1 == 1.8622957433108482d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((int) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.add(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp4.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((int) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getE();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp24.newInstance();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp19.add(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp4.add(dfp28);
        int int30 = dfp29.intValue();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.exception.MathRuntimeException(throwable1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathRuntimeException2.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException2);
        java.lang.String str5 = mathRuntimeException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        int int11 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField9.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException4, localizable6, localizable7, (java.lang.Object[]) dfpArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray12);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 2.99822295029797d);
        java.lang.Number number18 = notStrictlyPositiveException17.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable19 = notStrictlyPositiveException17.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getE();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField21.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, (java.lang.Object[]) dfpArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable28, (java.lang.Number) 2.99822295029797d);
        java.lang.Number number31 = notStrictlyPositiveException30.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable32 = notStrictlyPositiveException30.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getE();
        int int36 = dfpField34.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.getSqr2Reciprocal();
        dfpField34.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getE();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.divide((int) (byte) 3);
        int int44 = dfp43.log10K();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField34.newDfp(dfp43);
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField34.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable32, (java.lang.Object[]) dfpArray46);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable48, (java.lang.Number) 2.99822295029797d);
        java.lang.Number number51 = notStrictlyPositiveException50.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable52 = notStrictlyPositiveException50.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException55 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable53, (java.lang.Number) 2.99822295029797d);
        java.lang.Number number56 = notStrictlyPositiveException55.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable57 = notStrictlyPositiveException55.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getE();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField59.newDfp();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField59.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField59.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, (java.lang.Object[]) dfpArray64);
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException68 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable66, (java.lang.Number) 2.99822295029797d);
        java.lang.Number number69 = notStrictlyPositiveException68.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable70 = notStrictlyPositiveException68.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField72 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField72.getE();
        int int74 = dfpField72.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField72.getSqr2Reciprocal();
        dfpField72.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField78 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField78.getE();
        org.apache.commons.math.dfp.Dfp dfp81 = dfp79.divide((int) (byte) 3);
        int int82 = dfp81.log10K();
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField72.newDfp(dfp81);
        org.apache.commons.math.dfp.Dfp[] dfpArray84 = dfpField72.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException85 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable70, (java.lang.Object[]) dfpArray84);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException86 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException14, localizable32, localizable52, (java.lang.Object[]) dfpArray84);
        org.apache.commons.math.exception.util.Localizable localizable87 = mathRuntimeException86.getSpecificPattern();
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str5.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 2.99822295029797d + "'", number18.equals(2.99822295029797d));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 2.99822295029797d + "'", number31.equals(2.99822295029797d));
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 2.99822295029797d + "'", number51.equals(2.99822295029797d));
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 2.99822295029797d + "'", number56.equals(2.99822295029797d));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertTrue("'" + number69 + "' != '" + 2.99822295029797d + "'", number69.equals(2.99822295029797d));
        org.junit.Assert.assertTrue("'" + localizable70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable70.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 4 + "'", int74 == 4);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfpArray84);
        org.junit.Assert.assertTrue("'" + localizable87 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable87.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(4L);
        mersenneTwister1.setSeed((long) 4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        long long2 = org.apache.commons.math.util.FastMath.min((long) ' ', (long) 10000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(1.0d);
        int int7 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1181780348));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1181780352) + "'", int1 == (-1181780352));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-1.0d));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 1, (java.lang.Number) 0.8791090668715426d, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        dfpField1.clearIEEEFlags();
        int int6 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.subtract(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp15);
        int int17 = dfp16.log10K();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp9.multiply(dfp16);
        java.lang.String str19 = dfp16.toString();
        int int20 = dfp16.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0.7071067811865475" + "'", str19.equals("0.7071067811865475"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999329299739067d + "'", double1 == 0.999329299739067d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.7837391225053279E80d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        int int8 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.add(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getE();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((int) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getE();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getE();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfp22.subtract(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getE();
        int int34 = dfpField32.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp36 = new org.apache.commons.math.dfp.Dfp(dfp35);
        int int37 = dfp36.log10K();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp29.multiply(dfp36);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp36.sqrt();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp9.dotrap((-1), "", dfp17, dfp36);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getE();
        int int44 = dfpField42.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.getSqr2Reciprocal();
        dfpField42.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField42.getPi();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField42.getTwo();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField42.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp51 = org.apache.commons.math.dfp.DfpField.computeExp(dfp36, dfp50);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getE();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp54.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField58.getE();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp59.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp62 = dfp54.subtract(dfp61);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField64.getE();
        int int66 = dfpField64.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField64.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp68 = new org.apache.commons.math.dfp.Dfp(dfp67);
        int int69 = dfp68.log10K();
        org.apache.commons.math.dfp.Dfp dfp70 = dfp61.multiply(dfp68);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp68.sqrt();
        boolean boolean72 = dfp68.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp68.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField75.getE();
        int int77 = dfpField75.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray78 = dfpField75.getESplit();
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField75.newDfp(1.0d);
        boolean boolean81 = dfp73.equals((java.lang.Object) dfpField75);
        org.apache.commons.math.dfp.Dfp dfp82 = dfp50.multiply(dfp73);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp50.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 4 + "'", int66 == 4);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 4 + "'", int77 == 4);
        org.junit.Assert.assertNotNull(dfpArray78);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
    }
}

