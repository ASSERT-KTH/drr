import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.MEAN;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MEAN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MEAN));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray1 = zeroException0.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException0, (org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray3);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer7 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter8 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer7);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray9 = harmonicFitter8.getObservations();
        harmonicFitter8.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter8.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray15 = harmonicFitter8.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) weightedObservedPointArray15);
        java.lang.Object[] objArray17 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray15);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray17);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray17);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray26 = new java.lang.Object[] { localizedFormats21, localizedFormats22, localizedFormats23, localizedFormats24, localizedFormats25 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats20, objArray26);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext28 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalArgumentException27);
        java.lang.Throwable throwable29 = exceptionContext28.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer32 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter33 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer32);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray34 = harmonicFitter33.getObservations();
        harmonicFitter33.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter33.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter33.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint46 = null;
        harmonicFitter33.addObservedPoint(weightedObservedPoint46);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray48 = harmonicFitter33.getObservations();
        java.lang.Object[] objArray49 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray48);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats31, objArray49);
        java.lang.Object[] objArray51 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray49);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException52 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable29, (org.apache.commons.math3.exception.util.Localizable) localizedFormats30, objArray49);
        org.apache.commons.math3.exception.ZeroException zeroException53 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray49);
        org.junit.Assert.assertNotNull(throwableArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray9);
        org.junit.Assert.assertNotNull(weightedObservedPointArray15);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(throwable29);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY));
        org.junit.Assert.assertNotNull(weightedObservedPointArray34);
        org.junit.Assert.assertNotNull(weightedObservedPointArray48);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray51);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        harmonicFitter1.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray18 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint(0.0d, (double) (short) 0, (double) (short) 100);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric24 = null;
        double[] doubleArray29 = new double[] { (short) 100, 0L, (byte) 100, 0.0d };
        try {
            double[] doubleArray30 = harmonicFitter1.fit((int) (short) 1, parametric24, doubleArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray18);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = zeroException0.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        exceptionContext1.setValue("unknown parameter {0}", (java.lang.Object) localizedFormats3);
        java.lang.Object obj6 = exceptionContext1.getValue("Cardan angles singularity");
        java.lang.Throwable throwable7 = exceptionContext1.getThrowable();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer9 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter10 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer9);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray11 = harmonicFitter10.getObservations();
        harmonicFitter10.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter10.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray17 = harmonicFitter10.getObservations();
        harmonicFitter10.addObservedPoint((-1.0d), (double) 0.0f, (double) 0L);
        harmonicFitter10.addObservedPoint((double) (short) 0, (double) 10L);
        exceptionContext1.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0", (java.lang.Object) (short) 0);
        java.util.Set<java.lang.String> strSet26 = exceptionContext1.getKeys();
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(throwable7);
        org.junit.Assert.assertNotNull(weightedObservedPointArray11);
        org.junit.Assert.assertNotNull(weightedObservedPointArray17);
        org.junit.Assert.assertNotNull(strSet26);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint20 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 1L, (-1.0d), (double) 10L);
        harmonicFitter1.addObservedPoint(weightedObservedPoint20);
        harmonicFitter1.addObservedPoint((double) '4', 52.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray25 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer26 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter27 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer26);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray28 = harmonicFitter27.getObservations();
        harmonicFitter27.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter27.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint37 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0L, (double) 100.0f, (double) 1);
        double double38 = weightedObservedPoint37.getWeight();
        harmonicFitter27.addObservedPoint(weightedObservedPoint37);
        harmonicFitter1.addObservedPoint(weightedObservedPoint37);
        double double41 = weightedObservedPoint37.getY();
        double double42 = weightedObservedPoint37.getX();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
        org.junit.Assert.assertNotNull(weightedObservedPointArray25);
        org.junit.Assert.assertNotNull(weightedObservedPointArray28);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        harmonicFitter1.addObservedPoint((double) '#', (double) (byte) -1, (double) (short) 1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint23 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) '4', (double) (-1.0f));
        double double24 = weightedObservedPoint23.getX();
        double double25 = weightedObservedPoint23.getY();
        double double26 = weightedObservedPoint23.getY();
        double double27 = weightedObservedPoint23.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint23);
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 52.0d + "'", double24 == 52.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-1.0d) + "'", double25 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 52.0d + "'", double27 == 52.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 'a');
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) 100, (double) (byte) 10, 0.0d);
        try {
            double[] doubleArray19 = harmonicFitter1.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: sample contains 1 observed points, at least 4 are required");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathIllegalStateException0.getContext();
        java.util.Set<java.lang.String> strSet2 = exceptionContext1.getKeys();
        java.lang.Object obj4 = exceptionContext1.getValue("org.apache.commons.math3.exception.ZeroException: zero not allowed here");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        exceptionContext1.setValue("overflow in fraction {0}/{1}, cannot negate", (java.lang.Object) localizedFormats6);
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint(10.0d, (double) 10L);
        harmonicFitter1.addObservedPoint((double) 100L, (double) 1L, (double) (short) 1);
        harmonicFitter1.addObservedPoint((double) (short) 1, 0.0d);
        harmonicFitter1.addObservedPoint((double) (-1.0f), (double) (-1L), (double) (-1.0f));
        harmonicFitter1.addObservedPoint((-1.0d), (double) 10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint31 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 'a', (double) (short) -1, 10.0d);
        harmonicFitter1.addObservedPoint(weightedObservedPoint31);
        try {
            double[] doubleArray33 = harmonicFitter1.fit();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray1 = zeroException0.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException0, (org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray3);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = mathIllegalStateException4.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException4);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = mathIllegalStateException4.getContext();
        java.lang.Throwable throwable8 = exceptionContext7.getThrowable();
        java.util.Set<java.lang.String> strSet9 = exceptionContext7.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) -1, (java.lang.Number) 100L, false);
        boolean boolean16 = numberIsTooSmallException15.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray17 = numberIsTooSmallException15.getSuppressed();
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math3.exception.ZeroException zeroException19 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, (java.lang.Number) 0L, true);
        java.lang.Number number24 = numberIsTooSmallException23.getArgument();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME;
        org.apache.commons.math3.exception.ZeroException zeroException26 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray27 = zeroException26.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray29 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException26, (org.apache.commons.math3.exception.util.Localizable) localizedFormats28, objArray29);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray39 = new java.lang.Object[] { localizedFormats34, localizedFormats35, localizedFormats36, localizedFormats37, localizedFormats38 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats33, objArray39);
        org.apache.commons.math3.exception.ZeroException zeroException41 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats32, objArray39);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        java.lang.Object[] objArray47 = new java.lang.Object[] { localizedFormats32, "unknown parameter {0}", localizedFormats43, localizedFormats44, localizedFormats45, localizedFormats46 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats31, objArray47);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException49 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats28, objArray47);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException50 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException23, (org.apache.commons.math3.exception.util.Localizable) localizedFormats25, objArray47);
        exceptionContext7.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, objArray47);
        java.lang.Object obj53 = exceptionContext7.getValue("");
        org.junit.Assert.assertNotNull(throwableArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNotNull(throwable8);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 100.0f + "'", number24.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats32.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats33.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats36.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats37.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats38.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats43.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats44.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats45.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats46.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNull(obj53);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = zeroException0.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        exceptionContext1.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: cannot access 0 method in percentile implementation -1", (java.lang.Object) localizedFormats3);
        java.lang.Object obj6 = exceptionContext1.getValue("org.apache.commons.math3.exception.MathIllegalArgumentException: index (NOT_POSITIVE_SCALE) is not positive");
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray15 = new java.lang.Object[] { localizedFormats10, localizedFormats11, localizedFormats12, localizedFormats13, localizedFormats14 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, objArray15);
        org.apache.commons.math3.exception.ZeroException zeroException17 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray15);
        exceptionContext1.addMessage(localizable7, objArray15);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, (java.lang.Number) 0L, true);
        java.lang.Number number24 = numberIsTooSmallException23.getArgument();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME;
        org.apache.commons.math3.exception.ZeroException zeroException26 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray27 = zeroException26.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray29 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException26, (org.apache.commons.math3.exception.util.Localizable) localizedFormats28, objArray29);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray39 = new java.lang.Object[] { localizedFormats34, localizedFormats35, localizedFormats36, localizedFormats37, localizedFormats38 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats33, objArray39);
        org.apache.commons.math3.exception.ZeroException zeroException41 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats32, objArray39);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        java.lang.Object[] objArray47 = new java.lang.Object[] { localizedFormats32, "unknown parameter {0}", localizedFormats43, localizedFormats44, localizedFormats45, localizedFormats46 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats31, objArray47);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException49 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats28, objArray47);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException50 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException23, (org.apache.commons.math3.exception.util.Localizable) localizedFormats25, objArray47);
        exceptionContext1.setValue("", (java.lang.Object) numberIsTooSmallException23);
        java.lang.Number number52 = numberIsTooSmallException23.getMin();
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 100.0f + "'", number24.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats32.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats33.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats36.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats37.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats38.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats43.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats44.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats45.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats46.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 0L + "'", number52.equals(0L));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0f, number2, false);
        java.lang.String str5 = numberIsTooSmallException4.toString();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats9, localizedFormats10, localizedFormats11, localizedFormats12, localizedFormats13 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray14);
        org.apache.commons.math3.exception.ZeroException zeroException16 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray14);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) zeroException16);
        boolean boolean18 = numberIsTooSmallException4.getBoundIsAllowed();
        boolean boolean19 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer21 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter22 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer21);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray23 = harmonicFitter22.getObservations();
        harmonicFitter22.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter22.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray32 = harmonicFitter22.getObservations();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException33 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats20, (java.lang.Object[]) weightedObservedPointArray32);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathIllegalStateException33);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0" + "'", str5.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA));
        org.junit.Assert.assertNotNull(weightedObservedPointArray23);
        org.junit.Assert.assertNotNull(weightedObservedPointArray32);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathIllegalStateException0.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = mathIllegalStateException0.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException0);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer6 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter7 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer6);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter7.getObservations();
        harmonicFitter7.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter7.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray14 = harmonicFitter7.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray15 = harmonicFitter7.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) weightedObservedPointArray15);
        exceptionContext3.setValue("number of successes ({0})", (java.lang.Object) weightedObservedPointArray15);
        java.util.Set<java.lang.String> strSet18 = exceptionContext3.getKeys();
        java.lang.Object obj20 = null;
        exceptionContext3.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: cannot access 0 method in percentile implementation -1", obj20);
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
        org.junit.Assert.assertNotNull(weightedObservedPointArray14);
        org.junit.Assert.assertNotNull(weightedObservedPointArray15);
        org.junit.Assert.assertNotNull(strSet18);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint11 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0L, (double) 100.0f, (double) 1);
        double double12 = weightedObservedPoint11.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint11);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray14 = harmonicFitter1.getObservations();
        try {
            org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser15 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: sample contains 1 observed points, at least 4 are required");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray14);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray1 = zeroException0.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException0, (org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray3);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException4);
        java.lang.Class<?> wildcardClass6 = mathIllegalStateException4.getClass();
        org.junit.Assert.assertNotNull(throwableArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint20 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 1L, (-1.0d), (double) 10L);
        harmonicFitter1.addObservedPoint(weightedObservedPoint20);
        harmonicFitter1.addObservedPoint((double) '4', 52.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray25 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer26 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter27 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer26);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray28 = harmonicFitter27.getObservations();
        harmonicFitter27.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter27.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint37 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0L, (double) 100.0f, (double) 1);
        double double38 = weightedObservedPoint37.getWeight();
        harmonicFitter27.addObservedPoint(weightedObservedPoint37);
        harmonicFitter1.addObservedPoint(weightedObservedPoint37);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray41 = harmonicFitter1.getObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
        org.junit.Assert.assertNotNull(weightedObservedPointArray25);
        org.junit.Assert.assertNotNull(weightedObservedPointArray28);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray41);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.BANDWIDTH;
        org.apache.commons.math3.exception.ZeroException zeroException4 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray5 = zeroException4.getSuppressed();
        org.apache.commons.math3.exception.ZeroException zeroException6 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) throwableArray5);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray5);
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray5);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BANDWIDTH + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BANDWIDTH));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.EVALUATION;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 1, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.LENGTH;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = mathIllegalStateException6.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = mathIllegalStateException6.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException6);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer12 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter13 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer12);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray14 = harmonicFitter13.getObservations();
        harmonicFitter13.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter13.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray20 = harmonicFitter13.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray21 = harmonicFitter13.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Object[]) weightedObservedPointArray21);
        exceptionContext9.setValue("number of successes ({0})", (java.lang.Object) weightedObservedPointArray21);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) weightedObservedPointArray21);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats25, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number30 = numberIsTooSmallException29.getArgument();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext31 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException29);
        mathIllegalStateException24.addSuppressed((java.lang.Throwable) numberIsTooSmallException29);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LENGTH));
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray14);
        org.junit.Assert.assertNotNull(weightedObservedPointArray20);
        org.junit.Assert.assertNotNull(weightedObservedPointArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 0.0d + "'", number30.equals(0.0d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) 10.0f, (double) '4');
        harmonicFitter1.addObservedPoint(0.0d, 0.0d, (double) (byte) 1);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric11 = null;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer12 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter13 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer12);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray14 = harmonicFitter13.getObservations();
        harmonicFitter13.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter13.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter13.addObservedPoint((double) 1, 1.0d);
        harmonicFitter13.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray30 = harmonicFitter13.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser31 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray30);
        double[] doubleArray32 = parameterGuesser31.guess();
        double[] doubleArray33 = parameterGuesser31.guess();
        double[] doubleArray34 = parameterGuesser31.guess();
        try {
            double[] doubleArray35 = harmonicFitter1.fit((int) (short) 10, parametric11, doubleArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray14);
        org.junit.Assert.assertNotNull(weightedObservedPointArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats2, localizedFormats3, localizedFormats4, localizedFormats5, localizedFormats6 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray7);
        org.apache.commons.math3.exception.ZeroException zeroException9 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray7);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) zeroException9);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) zeroException9);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION;
        java.lang.Object[] objArray13 = null;
        exceptionContext11.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 10, number2, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eigen decomposition of assymetric matrices not supported yet" + "'", str1.equals("eigen decomposition of assymetric matrices not supported yet"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.clearObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = zeroException0.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        exceptionContext1.setValue("unknown parameter {0}", (java.lang.Object) localizedFormats3);
        java.lang.Object obj6 = exceptionContext1.getValue("Cardan angles singularity");
        java.lang.Class<?> wildcardClass7 = exceptionContext1.getClass();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE;
        java.lang.Class<?> wildcardClass10 = localizedFormats9.getClass();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer12 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter13 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer12);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray14 = harmonicFitter13.getObservations();
        harmonicFitter13.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter13.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter13.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint26 = null;
        harmonicFitter13.addObservedPoint(weightedObservedPoint26);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray28 = harmonicFitter13.getObservations();
        java.lang.Object[] objArray29 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray28);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, objArray29);
        java.lang.Object[] objArray31 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray29);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, objArray31);
        java.lang.String str33 = localizedFormats9.getSourceString();
        exceptionContext1.setValue("", (java.lang.Object) str33);
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY));
        org.junit.Assert.assertNotNull(weightedObservedPointArray14);
        org.junit.Assert.assertNotNull(weightedObservedPointArray28);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "all ordinatae must be finite real numbers, but {0}-th is {1}" + "'", str33.equals("all ordinatae must be finite real numbers, but {0}-th is {1}"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) (byte) 100, 0.0d, (double) (short) 10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray15 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter1.getObservations();
        harmonicFitter1.clearObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray15);
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray1 = zeroException0.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException0, (org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray3);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException4);
        java.util.Set<java.lang.String> strSet6 = exceptionContext5.getKeys();
        java.lang.Throwable throwable7 = exceptionContext5.getThrowable();
        java.lang.Throwable throwable8 = exceptionContext5.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.INPUT_ARRAY;
        java.lang.Number number10 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, number10, (java.lang.Number) 1.0d, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray22 = new java.lang.Object[] { localizedFormats17, localizedFormats18, localizedFormats19, localizedFormats20, localizedFormats21 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, objArray22);
        org.apache.commons.math3.exception.ZeroException zeroException24 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats15, objArray22);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        java.lang.Object[] objArray30 = new java.lang.Object[] { localizedFormats15, "unknown parameter {0}", localizedFormats26, localizedFormats27, localizedFormats28, localizedFormats29 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats14, objArray30);
        java.lang.Class<?> wildcardClass32 = objArray30.getClass();
        java.lang.Object[] objArray33 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray30);
        java.lang.Object[] objArray34 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray30);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException35 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable8, (org.apache.commons.math3.exception.util.Localizable) localizedFormats9, objArray34);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT;
        java.lang.Number number37 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats36, number37, (java.lang.Number) (-1.0d), false);
        mathIllegalStateException35.addSuppressed((java.lang.Throwable) numberIsTooSmallException40);
        org.junit.Assert.assertNotNull(throwableArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNotNull(throwable7);
        org.junit.Assert.assertNotNull(throwable8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT + "'", localizedFormats36.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) (byte) 100, 0.0d, (double) (short) 10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray15 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter1.getObservations();
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric17 = null;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer18 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter19 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer18);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray20 = harmonicFitter19.getObservations();
        harmonicFitter19.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter19.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter19.addObservedPoint((double) 1, 1.0d);
        harmonicFitter19.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray36 = harmonicFitter19.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser37 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray36);
        double[] doubleArray38 = parameterGuesser37.guess();
        double[] doubleArray39 = parameterGuesser37.guess();
        double[] doubleArray40 = parameterGuesser37.guess();
        try {
            double[] doubleArray41 = harmonicFitter1.fit(parametric17, doubleArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray15);
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
        org.junit.Assert.assertNotNull(weightedObservedPointArray20);
        org.junit.Assert.assertNotNull(weightedObservedPointArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray1 = zeroException0.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException0, (org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray3);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = mathIllegalStateException4.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException4);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = mathIllegalStateException4.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer12 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter13 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer12);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray14 = harmonicFitter13.getObservations();
        harmonicFitter13.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter13.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter13.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint26 = null;
        harmonicFitter13.addObservedPoint(weightedObservedPoint26);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray28 = harmonicFitter13.getObservations();
        org.apache.commons.math3.exception.ZeroException zeroException29 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Object[]) weightedObservedPointArray28);
        org.apache.commons.math3.exception.ZeroException zeroException30 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) weightedObservedPointArray28);
        org.apache.commons.math3.exception.ZeroException zeroException31 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Object[]) weightedObservedPointArray28);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer32 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter33 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer32);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray34 = harmonicFitter33.getObservations();
        harmonicFitter33.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter33.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint43 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0L, (double) 100.0f, (double) 1);
        double double44 = weightedObservedPoint43.getWeight();
        harmonicFitter33.addObservedPoint(weightedObservedPoint43);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray46 = harmonicFitter33.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Object[]) weightedObservedPointArray46);
        exceptionContext7.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) weightedObservedPointArray46);
        org.junit.Assert.assertNotNull(throwableArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA));
        org.junit.Assert.assertNotNull(weightedObservedPointArray14);
        org.junit.Assert.assertNotNull(weightedObservedPointArray28);
        org.junit.Assert.assertNotNull(weightedObservedPointArray34);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray46);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer3 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter4 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer3);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray5 = harmonicFitter4.getObservations();
        harmonicFitter4.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter4.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter4.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint17 = null;
        harmonicFitter4.addObservedPoint(weightedObservedPoint17);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray19 = harmonicFitter4.getObservations();
        org.apache.commons.math3.exception.ZeroException zeroException20 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) weightedObservedPointArray19);
        org.apache.commons.math3.exception.ZeroException zeroException21 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) weightedObservedPointArray19);
        org.apache.commons.math3.exception.ZeroException zeroException22 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray19);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) -1, (java.lang.Number) 100L, false);
        boolean boolean27 = numberIsTooSmallException26.getBoundIsAllowed();
        zeroException22.addSuppressed((java.lang.Throwable) numberIsTooSmallException26);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA));
        org.junit.Assert.assertNotNull(weightedObservedPointArray5);
        org.junit.Assert.assertNotNull(weightedObservedPointArray19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.BANDWIDTH;
        org.apache.commons.math3.exception.ZeroException zeroException2 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray3 = zeroException2.getSuppressed();
        org.apache.commons.math3.exception.ZeroException zeroException4 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray3);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray3);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray13 = new java.lang.Object[] { localizedFormats8, localizedFormats9, localizedFormats10, localizedFormats11, localizedFormats12 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray13);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray13);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray23 = new java.lang.Object[] { localizedFormats18, localizedFormats19, localizedFormats20, localizedFormats21, localizedFormats22 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, objArray23);
        org.apache.commons.math3.exception.ZeroException zeroException25 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, objArray23);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException5, (org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray23);
        java.lang.String str27 = mathIllegalStateException5.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BANDWIDTH + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BANDWIDTH));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.apache.commons.math3.exception.MathIllegalStateException: denominator must be different from 0" + "'", str27.equals("org.apache.commons.math3.exception.MathIllegalStateException: denominator must be different from 0"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) -1, (java.lang.Number) 100L, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.ZeroException zeroException7 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        java.lang.Class<?> wildcardClass8 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        harmonicFitter1.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray18 = harmonicFitter1.getObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint(0.0d, (double) 10, (double) (byte) 100);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric25 = null;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer26 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter27 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer26);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray28 = harmonicFitter27.getObservations();
        harmonicFitter27.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter27.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter27.addObservedPoint((double) 1, 1.0d);
        harmonicFitter27.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray44 = harmonicFitter27.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser45 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray44);
        double[] doubleArray46 = parameterGuesser45.guess();
        double[] doubleArray47 = parameterGuesser45.guess();
        double[] doubleArray48 = parameterGuesser45.guess();
        try {
            double[] doubleArray49 = harmonicFitter1.fit(100, parametric25, doubleArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray18);
        org.junit.Assert.assertNotNull(weightedObservedPointArray28);
        org.junit.Assert.assertNotNull(weightedObservedPointArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0L, (double) (byte) -1, (double) 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException3 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable0, (org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0f, (java.lang.Number) 10.0f, false);
        java.lang.String str5 = numberIsTooSmallException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.MEAN;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer8 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter9 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer8);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray10 = harmonicFitter9.getObservations();
        harmonicFitter9.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter9.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter9.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) weightedObservedPointArray16);
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray16);
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray16);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: Overflow trying to convert 10 to fraction (10/{2})" + "'", str5.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: Overflow trying to convert 10 to fraction (10/{2})"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MEAN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray10);
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) '4', (double) (-1.0f));
        double double4 = weightedObservedPoint3.getX();
        double double5 = weightedObservedPoint3.getWeight();
        double double6 = weightedObservedPoint3.getX();
        double double7 = weightedObservedPoint3.getX();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 52.0d + "'", double5 == 52.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.0d + "'", double6 == 52.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 10, (double) 'a', (double) (-1));
        double double4 = weightedObservedPoint3.getX();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.0d + "'", double4 == 97.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint(10.0d, (double) 10L);
        harmonicFitter1.addObservedPoint((double) 100L, (double) 1L, (double) (short) 1);
        harmonicFitter1.addObservedPoint((double) 0L, (double) 100, (double) 10);
        harmonicFitter1.addObservedPoint((double) (short) 0, 100.0d, (double) (short) 0);
        harmonicFitter1.addObservedPoint(0.0d, (double) 0);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric29 = null;
        double[] doubleArray34 = new double[] { (byte) 100, (short) 0, (short) 100, (byte) -1 };
        try {
            double[] doubleArray35 = harmonicFitter1.fit(parametric29, doubleArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 52.0d, (java.lang.Number) 0.0d, false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint5 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 1L, (double) (byte) 0, (double) (short) 1);
        harmonicFitter1.addObservedPoint(weightedObservedPoint5);
        double double7 = weightedObservedPoint5.getY();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_TOURNAMENT_ARITY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer2 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter3 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer2);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray4 = harmonicFitter3.getObservations();
        harmonicFitter3.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter3.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray13 = harmonicFitter3.getObservations();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) weightedObservedPointArray13);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray13);
        try {
            org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser16 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: sample contains 2 observed points, at least 4 are required");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_TOURNAMENT_ARITY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_TOURNAMENT_ARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA));
        org.junit.Assert.assertNotNull(weightedObservedPointArray4);
        org.junit.Assert.assertNotNull(weightedObservedPointArray13);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) 1, true);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Throwable[] throwableArray11 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = numberIsTooSmallException4.getContext();
        java.lang.Number number13 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1L) + "'", number13.equals((-1L)));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint12 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) '4', (double) (-1.0f));
        double double13 = weightedObservedPoint12.getX();
        double double14 = weightedObservedPoint12.getY();
        double double15 = weightedObservedPoint12.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint12);
        harmonicFitter1.addObservedPoint((double) (short) 100, (double) 10L);
        harmonicFitter1.addObservedPoint((double) 10.0f, 0.0d);
        harmonicFitter1.addObservedPoint(0.0d, (double) (byte) 10, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint30 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(0.0d, (double) (short) 0, (double) (-1L));
        harmonicFitter1.addObservedPoint(weightedObservedPoint30);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 52.0d + "'", double13 == 52.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 52.0d + "'", double15 == 52.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) -1, (java.lang.Number) 100L, false);
        boolean boolean6 = numberIsTooSmallException5.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray7 = numberIsTooSmallException5.getSuppressed();
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) throwableArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = harmonicFitter2.getObservations();
        harmonicFitter2.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter2.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray12 = harmonicFitter2.getObservations();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray12);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext14 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException13);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext15 = mathIllegalStateException13.getContext();
        java.lang.Throwable[] throwableArray16 = mathIllegalStateException13.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA));
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertNotNull(weightedObservedPointArray12);
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) (byte) 0, 0.0d);
        double double4 = weightedObservedPoint3.getY();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0.0f, (double) 0L);
        harmonicFitter1.addObservedPoint((double) (short) 0, (double) 10L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint19 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(52.0d, 0.0d, (double) 1L);
        harmonicFitter1.addObservedPoint(weightedObservedPoint19);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        harmonicFitter1.addObservedPoint((double) '#', (double) (byte) -1, (double) (short) 1);
        harmonicFitter1.clearObservations();
        double[] doubleArray24 = new double[] { 10.0f, (byte) 10, 10.0f };
        try {
            double[] doubleArray25 = harmonicFitter1.fit(doubleArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        harmonicFitter1.addObservedPoint((double) '#', (double) (byte) -1, (double) (short) 1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint23 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) '4', (double) (-1.0f));
        double double24 = weightedObservedPoint23.getX();
        double double25 = weightedObservedPoint23.getY();
        double double26 = weightedObservedPoint23.getY();
        double double27 = weightedObservedPoint23.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint23);
        double double29 = weightedObservedPoint23.getX();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 52.0d + "'", double24 == 52.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-1.0d) + "'", double25 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 52.0d + "'", double27 == 52.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 52.0d + "'", double29 == 52.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray6 = new java.lang.Object[] { localizedFormats1, localizedFormats2, localizedFormats3, localizedFormats4, localizedFormats5 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalArgumentException7);
        java.lang.Object obj10 = exceptionContext8.getValue("org.apache.commons.math3.exception.MathIllegalStateException: scale must be positive (TOO_MANY_REGRESSORS)");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNull(obj10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(0.0d, (double) (short) 0, (double) (-1L));
        double double4 = weightedObservedPoint3.getX();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer4 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter5 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer4);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray6 = harmonicFitter5.getObservations();
        harmonicFitter5.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter5.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter5.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint18 = null;
        harmonicFitter5.addObservedPoint(weightedObservedPoint18);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray20 = harmonicFitter5.getObservations();
        java.lang.Object[] objArray21 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray20);
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray20);
        org.apache.commons.math3.exception.ZeroException zeroException23 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, objArray22);
        java.lang.Object[] objArray24 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray22);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable2, objArray22);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray22);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE;
        java.lang.Class<?> wildcardClass28 = localizedFormats27.getClass();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer30 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter31 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer30);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray32 = harmonicFitter31.getObservations();
        harmonicFitter31.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter31.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter31.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint44 = null;
        harmonicFitter31.addObservedPoint(weightedObservedPoint44);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray46 = harmonicFitter31.getObservations();
        java.lang.Object[] objArray47 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray46);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats29, objArray47);
        java.lang.Object[] objArray49 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray47);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats27, objArray49);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext51 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalArgumentException50);
        mathIllegalArgumentException26.addSuppressed((java.lang.Throwable) mathIllegalArgumentException50);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray6);
        org.junit.Assert.assertNotNull(weightedObservedPointArray20);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE));
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY));
        org.junit.Assert.assertNotNull(weightedObservedPointArray32);
        org.junit.Assert.assertNotNull(weightedObservedPointArray46);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray49);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0d, (java.lang.Number) 52.0d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Cardan angles singularity" + "'", str1.equals("Cardan angles singularity"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Number) (-1.0f), false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer2 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter3 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer2);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray4 = harmonicFitter3.getObservations();
        harmonicFitter3.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter3.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter3.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint16 = null;
        harmonicFitter3.addObservedPoint(weightedObservedPoint16);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray18 = harmonicFitter3.getObservations();
        org.apache.commons.math3.exception.ZeroException zeroException19 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) weightedObservedPointArray18);
        org.apache.commons.math3.exception.ZeroException zeroException20 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray18);
        java.lang.String str21 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA));
        org.junit.Assert.assertNotNull(weightedObservedPointArray4);
        org.junit.Assert.assertNotNull(weightedObservedPointArray18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "sample size ({0}) exceeds collection size ({1})" + "'", str21.equals("sample size ({0}) exceeds collection size ({1})"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats2, localizedFormats3, localizedFormats4, localizedFormats5, localizedFormats6 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray7);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray7);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        java.lang.Class<?> wildcardClass11 = localizedFormats10.getClass();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer12 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter13 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer12);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray14 = harmonicFitter13.getObservations();
        harmonicFitter13.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter13.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter13.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint26 = null;
        harmonicFitter13.addObservedPoint(weightedObservedPoint26);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray28 = harmonicFitter13.getObservations();
        java.lang.Object[] objArray29 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray28);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException9, (org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) weightedObservedPointArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(weightedObservedPointArray14);
        org.junit.Assert.assertNotNull(weightedObservedPointArray28);
        org.junit.Assert.assertNotNull(objArray29);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0d), true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException3.getContext();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.String str1 = zeroException0.toString();
        java.lang.Throwable[] throwableArray2 = zeroException0.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED;
        org.apache.commons.math3.exception.ZeroException zeroException4 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.String str5 = zeroException4.toString();
        java.lang.Throwable[] throwableArray6 = zeroException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException0, (org.apache.commons.math3.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = mathIllegalStateException7.getContext();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "org.apache.commons.math3.exception.ZeroException: zero not allowed here" + "'", str1.equals("org.apache.commons.math3.exception.ZeroException: zero not allowed here"));
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.ZeroException: zero not allowed here" + "'", str5.equals("org.apache.commons.math3.exception.ZeroException: zero not allowed here"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(exceptionContext8);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray11 = harmonicFitter1.getObservations();
        try {
            double[] doubleArray12 = harmonicFitter1.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: sample contains 2 observed points, at least 4 are required");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray11);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = harmonicFitter2.getObservations();
        harmonicFitter2.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter2.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter2.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint15 = null;
        harmonicFitter2.addObservedPoint(weightedObservedPoint15);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray17 = harmonicFitter2.getObservations();
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray17);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray17);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext20 = mathIllegalStateException19.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertNotNull(weightedObservedPointArray17);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(exceptionContext20);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNMATCHED_ODE_IN_EXPANDED_SET;
        java.lang.String str1 = localizedFormats0.getSourceString();
        java.lang.Class<?> wildcardClass2 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNMATCHED_ODE_IN_EXPANDED_SET + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNMATCHED_ODE_IN_EXPANDED_SET));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ode does not match the main ode set in the extended set" + "'", str1.equals("ode does not match the main ode set in the extended set"));
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) 10.0f, (double) '4');
        double[] doubleArray6 = null;
        try {
            double[] doubleArray7 = harmonicFitter1.fit(doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint(10.0d, (double) 10L);
        harmonicFitter1.addObservedPoint((double) 100L, (double) 1L, (double) (short) 1);
        harmonicFitter1.addObservedPoint((double) (short) 1, 0.0d);
        harmonicFitter1.addObservedPoint(0.0d, (double) (byte) 10, (double) (byte) 10);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer25 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter26 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer25);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray27 = harmonicFitter26.getObservations();
        harmonicFitter26.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter26.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter26.addObservedPoint((double) 1, 1.0d);
        harmonicFitter26.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray43 = harmonicFitter26.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser44 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray43);
        double[] doubleArray45 = parameterGuesser44.guess();
        try {
            double[] doubleArray46 = harmonicFitter1.fit(doubleArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray27);
        org.junit.Assert.assertNotNull(weightedObservedPointArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 0 + "'", number6.equals((byte) 0));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1L) + "'", number7.equals((-1L)));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray6 = new java.lang.Object[] { localizedFormats1, localizedFormats2, localizedFormats3, localizedFormats4, localizedFormats5 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalArgumentException7);
        java.util.Set<java.lang.String> strSet9 = exceptionContext8.getKeys();
        java.lang.Throwable throwable10 = exceptionContext8.getThrowable();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertNotNull(throwable10);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        java.lang.String str7 = numberIsTooSmallException4.toString();
        java.lang.Number number8 = numberIsTooSmallException4.getMin();
        java.lang.Number number9 = numberIsTooSmallException4.getArgument();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number15 = numberIsTooSmallException14.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext16 = numberIsTooSmallException14.getContext();
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException14);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: cannot access 0 method in percentile implementation -1" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: cannot access 0 method in percentile implementation -1"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: cannot access 0 method in percentile implementation -1" + "'", str7.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: cannot access 0 method in percentile implementation -1"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1L) + "'", number8.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.0d + "'", number9.equals(0.0d));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-1L) + "'", number15.equals((-1L)));
        org.junit.Assert.assertNotNull(exceptionContext16);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, (java.lang.Number) 0L, true);
        java.lang.Number number6 = numberIsTooSmallException5.getArgument();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME;
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray9 = zeroException8.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException8, (org.apache.commons.math3.exception.util.Localizable) localizedFormats10, objArray11);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizedFormats16, localizedFormats17, localizedFormats18, localizedFormats19, localizedFormats20 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats15, objArray21);
        org.apache.commons.math3.exception.ZeroException zeroException23 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats14, objArray21);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        java.lang.Object[] objArray29 = new java.lang.Object[] { localizedFormats14, "unknown parameter {0}", localizedFormats25, localizedFormats26, localizedFormats27, localizedFormats28 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, objArray29);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, objArray29);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException32 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException5, (org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray29);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException33 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray29);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray29);
        java.lang.Object[] objArray35 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(52.0d, (double) (short) 10, (double) (-1.0f));
        double double4 = weightedObservedPoint3.getY();
        double double5 = weightedObservedPoint3.getY();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0.0f, (double) 0L);
        harmonicFitter1.addObservedPoint((double) (short) 0, (double) 10L);
        harmonicFitter1.addObservedPoint((double) (byte) -1, 52.0d, 0.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = harmonicFitter2.getObservations();
        harmonicFitter2.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter2.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter2.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint15 = null;
        harmonicFitter2.addObservedPoint(weightedObservedPoint15);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray17 = harmonicFitter2.getObservations();
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray17);
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray17);
        org.apache.commons.math3.exception.ZeroException zeroException20 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray19);
        java.util.Locale locale21 = null;
        try {
            java.lang.String str22 = localizedFormats0.getLocalizedString(locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertNotNull(weightedObservedPointArray17);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = harmonicFitter2.getObservations();
        harmonicFitter2.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter2.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter2.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint15 = null;
        harmonicFitter2.addObservedPoint(weightedObservedPoint15);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray17 = harmonicFitter2.getObservations();
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray17);
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray17);
        org.apache.commons.math3.exception.ZeroException zeroException20 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray19);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N;
        java.lang.Number number23 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats21, (java.lang.Number) 0.0f, number23, false);
        java.lang.String str26 = numberIsTooSmallException25.toString();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext27 = numberIsTooSmallException25.getContext();
        zeroException20.addSuppressed((java.lang.Throwable) numberIsTooSmallException25);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext29 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException25);
        java.lang.Number number30 = numberIsTooSmallException25.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertNotNull(weightedObservedPointArray17);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0" + "'", str26.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0"));
        org.junit.Assert.assertNotNull(exceptionContext27);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 0.0f + "'", number30.equals(0.0f));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) 10L, (double) (-1.0f), (double) 100.0f);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter1.getObservations();
        harmonicFitter1.clearObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "empty cluster in k-means" + "'", str1.equals("empty cluster in k-means"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        try {
            double[] doubleArray10 = harmonicFitter1.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: sample contains 0 observed points, at least 4 are required");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) -1, (java.lang.Number) (byte) 0, true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = harmonicFitter2.getObservations();
        harmonicFitter2.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter2.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter2.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint15 = null;
        harmonicFitter2.addObservedPoint(weightedObservedPoint15);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray17 = harmonicFitter2.getObservations();
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray17);
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray18);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray18);
        java.lang.Throwable[] throwableArray21 = mathIllegalStateException20.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext23 = mathIllegalStateException22.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext24 = mathIllegalStateException22.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext25 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException22);
        java.lang.Throwable throwable26 = exceptionContext25.getThrowable();
        mathIllegalStateException20.addSuppressed(throwable26);
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertNotNull(weightedObservedPointArray17);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(exceptionContext23);
        org.junit.Assert.assertNotNull(exceptionContext24);
        org.junit.Assert.assertNotNull(throwable26);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException1 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = mathIllegalStateException1.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = mathIllegalStateException1.getContext();
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer6 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter7 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer6);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter7.getObservations();
        harmonicFitter7.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter7.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint20 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(10.0d, (double) 0, (double) '4');
        harmonicFitter7.addObservedPoint(weightedObservedPoint20);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray22 = harmonicFitter7.getObservations();
        java.lang.Object[] objArray23 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray22);
        org.apache.commons.math3.exception.ZeroException zeroException24 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) weightedObservedPointArray22);
        exceptionContext3.addMessage(localizable4, (java.lang.Object[]) weightedObservedPointArray22);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N));
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
        org.junit.Assert.assertNotNull(weightedObservedPointArray22);
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) (-1L), false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        java.lang.Throwable throwable6 = exceptionContext5.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        java.lang.Class<?> wildcardClass8 = localizedFormats7.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable9 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer11 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter12 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer11);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray13 = harmonicFitter12.getObservations();
        harmonicFitter12.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter12.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter12.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint25 = null;
        harmonicFitter12.addObservedPoint(weightedObservedPoint25);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray27 = harmonicFitter12.getObservations();
        java.lang.Object[] objArray28 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray27);
        java.lang.Object[] objArray29 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray27);
        org.apache.commons.math3.exception.ZeroException zeroException30 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, objArray29);
        java.lang.Object[] objArray31 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray29);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException32 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable9, objArray29);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray29);
        throwable6.addSuppressed((java.lang.Throwable) mathIllegalArgumentException33);
        java.lang.String str35 = mathIllegalArgumentException33.toString();
        java.lang.Throwable[] throwableArray36 = mathIllegalArgumentException33.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(throwable6);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray13);
        org.junit.Assert.assertNotNull(weightedObservedPointArray27);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray36);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathIllegalStateException0.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = mathIllegalStateException0.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException0);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer6 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter7 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer6);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter7.getObservations();
        harmonicFitter7.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter7.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray14 = harmonicFitter7.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray15 = harmonicFitter7.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) weightedObservedPointArray15);
        exceptionContext3.setValue("number of successes ({0})", (java.lang.Object) weightedObservedPointArray15);
        java.util.Set<java.lang.String> strSet18 = exceptionContext3.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        java.lang.Class<?> wildcardClass20 = localizedFormats19.getClass();
        org.apache.commons.math3.exception.ZeroException zeroException21 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray22 = zeroException21.getSuppressed();
        exceptionContext3.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats19, (java.lang.Object[]) throwableArray22);
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
        org.junit.Assert.assertNotNull(weightedObservedPointArray14);
        org.junit.Assert.assertNotNull(weightedObservedPointArray15);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray1 = zeroException0.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException0, (org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray3);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = mathIllegalStateException4.getContext();
        java.lang.Object obj7 = null;
        exceptionContext5.setValue("", obj7);
        java.lang.Throwable throwable9 = exceptionContext5.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE;
        java.lang.Class<?> wildcardClass12 = localizedFormats11.getClass();
        exceptionContext5.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: Overflow trying to convert 10 to fraction (10/{2})", (java.lang.Object) localizedFormats11);
        java.lang.Object obj15 = exceptionContext5.getValue("digest not initialized");
        org.junit.Assert.assertNotNull(throwableArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(throwable9);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint(100.0d, (double) 10, (double) (byte) 1);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric13 = null;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer14 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter15 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer14);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter15.getObservations();
        harmonicFitter15.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter15.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter15.addObservedPoint((double) 1, 1.0d);
        harmonicFitter15.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray32 = harmonicFitter15.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser33 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray32);
        double[] doubleArray34 = parameterGuesser33.guess();
        double[] doubleArray35 = parameterGuesser33.guess();
        double[] doubleArray36 = parameterGuesser33.guess();
        try {
            double[] doubleArray37 = harmonicFitter1.fit(parametric13, doubleArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
        org.junit.Assert.assertNotNull(weightedObservedPointArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = harmonicFitter2.getObservations();
        harmonicFitter2.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter2.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray9 = harmonicFitter2.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray10 = harmonicFitter2.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = mathIllegalArgumentException11.getContext();
        java.lang.Object obj14 = exceptionContext12.getValue("org.apache.commons.math3.exception.MathIllegalArgumentException: index (NOT_POSITIVE_SCALE) is not positive");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertNotNull(weightedObservedPointArray9);
        org.junit.Assert.assertNotNull(weightedObservedPointArray10);
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertNull(obj14);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats2, localizedFormats3, localizedFormats4, localizedFormats5, localizedFormats6 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray7);
        mathIllegalStateException0.addSuppressed((java.lang.Throwable) mathIllegalArgumentException8);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = mathIllegalStateException0.getContext();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint15 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 'a', (double) (short) -1, 10.0d);
        exceptionContext10.setValue("empty cluster in k-means", (java.lang.Object) 'a');
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(exceptionContext10);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint(10.0d, (double) 10L);
        harmonicFitter1.addObservedPoint((double) 100L, (double) 1L, (double) (short) 1);
        harmonicFitter1.addObservedPoint((double) (short) 1, 0.0d);
        harmonicFitter1.addObservedPoint(0.0d, (double) (byte) 10, (double) (byte) 10);
        harmonicFitter1.addObservedPoint((double) 1L, 100.0d);
        try {
            double[] doubleArray28 = harmonicFitter1.fit();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats3, localizedFormats4, localizedFormats5, localizedFormats6, localizedFormats7 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray8);
        org.apache.commons.math3.exception.ZeroException zeroException10 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, (java.lang.Number) 0L, true);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0f + "'", number4.equals(100.0f));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0f, number2, false);
        java.lang.String str5 = numberIsTooSmallException4.toString();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        boolean boolean7 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.String str8 = numberIsTooSmallException4.toString();
        java.lang.Number number9 = numberIsTooSmallException4.getMin();
        java.lang.Number number10 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0" + "'", str5.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0" + "'", str8.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.0f + "'", number10.equals(0.0f));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = zeroException0.getContext();
        java.lang.Throwable throwable2 = exceptionContext1.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray11 = new java.lang.Object[] { localizedFormats6, localizedFormats7, localizedFormats8, localizedFormats9, localizedFormats10 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray11);
        org.apache.commons.math3.exception.ZeroException zeroException13 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats4, objArray11);
        exceptionContext1.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, objArray11);
        java.util.Set<java.lang.String> strSet15 = exceptionContext1.getKeys();
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(throwable2);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(strSet15);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) '4', (double) (-1.0f));
        double double4 = weightedObservedPoint3.getX();
        double double5 = weightedObservedPoint3.getWeight();
        double double6 = weightedObservedPoint3.getX();
        double double7 = weightedObservedPoint3.getWeight();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 52.0d + "'", double5 == 52.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.0d + "'", double6 == 52.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0.0f, (double) 0L);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer13 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter14 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer13);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray15 = harmonicFitter14.getObservations();
        harmonicFitter14.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter14.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter14.addObservedPoint((double) 1, 1.0d);
        harmonicFitter14.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray31 = harmonicFitter14.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser32 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray31);
        double[] doubleArray33 = parameterGuesser32.guess();
        double[] doubleArray34 = parameterGuesser32.guess();
        double[] doubleArray35 = parameterGuesser32.guess();
        try {
            double[] doubleArray36 = harmonicFitter1.fit(doubleArray35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
        org.junit.Assert.assertNotNull(weightedObservedPointArray15);
        org.junit.Assert.assertNotNull(weightedObservedPointArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.ZeroException zeroException7 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray8 = zeroException7.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException7, (org.apache.commons.math3.exception.util.Localizable) localizedFormats9, objArray10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = mathIllegalStateException11.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException11);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext14 = mathIllegalStateException11.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext15 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException11);
        exceptionContext5.setValue("observed counts are both zero for entry {0}", (java.lang.Object) mathIllegalStateException11);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer18 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter19 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer18);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray20 = harmonicFitter19.getObservations();
        harmonicFitter19.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter19.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter19.addObservedPoint((double) 1, 1.0d);
        harmonicFitter19.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray36 = harmonicFitter19.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser37 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray36);
        java.lang.Object[] objArray38 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray36);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, objArray38);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer40 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter41 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer40);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray42 = harmonicFitter41.getObservations();
        harmonicFitter41.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter41.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter41.addObservedPoint((double) 1, 1.0d);
        harmonicFitter41.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray58 = harmonicFitter41.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser59 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray58);
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, (java.lang.Object[]) weightedObservedPointArray58);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser61 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray58);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray20);
        org.junit.Assert.assertNotNull(weightedObservedPointArray36);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(weightedObservedPointArray42);
        org.junit.Assert.assertNotNull(weightedObservedPointArray58);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "overflow in subtraction: {0} - {1}" + "'", str1.equals("overflow in subtraction: {0} - {1}"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.POLYNOMIAL;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.ZeroException zeroException2 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray1);
        java.lang.String str3 = zeroException2.toString();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = zeroException2.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math3.exception.ZeroException: polynomial" + "'", str3.equals("org.apache.commons.math3.exception.ZeroException: polynomial"));
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        harmonicFitter1.addObservedPoint((double) '#', (double) (byte) -1, (double) (short) 1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint23 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) '4', (double) (-1.0f));
        double double24 = weightedObservedPoint23.getX();
        double double25 = weightedObservedPoint23.getY();
        double double26 = weightedObservedPoint23.getY();
        double double27 = weightedObservedPoint23.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint23);
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric31 = null;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer32 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter33 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer32);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray34 = harmonicFitter33.getObservations();
        harmonicFitter33.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter33.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter33.addObservedPoint((double) 1, 1.0d);
        harmonicFitter33.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray50 = harmonicFitter33.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser51 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray50);
        java.lang.Object[] objArray52 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray50);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser53 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray50);
        double[] doubleArray54 = parameterGuesser53.guess();
        try {
            double[] doubleArray55 = harmonicFitter1.fit((int) (byte) -1, parametric31, doubleArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 52.0d + "'", double24 == 52.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-1.0d) + "'", double25 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 52.0d + "'", double27 == 52.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray34);
        org.junit.Assert.assertNotNull(weightedObservedPointArray50);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0, (double) (short) -1, 1.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint12 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) '4', (double) (-1.0f));
        double double13 = weightedObservedPoint12.getX();
        double double14 = weightedObservedPoint12.getY();
        double double15 = weightedObservedPoint12.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint12);
        harmonicFitter1.addObservedPoint((double) (short) 100, (double) 10L);
        harmonicFitter1.addObservedPoint((double) 10.0f, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint26 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 10, (double) 'a', (double) (-1));
        harmonicFitter1.addObservedPoint(weightedObservedPoint26);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 52.0d + "'", double13 == 52.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 52.0d + "'", double15 == 52.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException4.getSuppressed();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 0 + "'", number7.equals((byte) 0));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathIllegalStateException0.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = mathIllegalStateException0.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException0);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        exceptionContext3.setValue("hi!", (java.lang.Object) localizedFormats5);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer8 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter9 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer8);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray10 = harmonicFitter9.getObservations();
        harmonicFitter9.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter9.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint22 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(10.0d, (double) 0, (double) '4');
        harmonicFitter9.addObservedPoint(weightedObservedPoint22);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray24 = harmonicFitter9.getObservations();
        java.lang.Object[] objArray25 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray24);
        org.apache.commons.math3.exception.ZeroException zeroException26 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) weightedObservedPointArray24);
        java.lang.Object[] objArray27 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray24);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) weightedObservedPointArray24);
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N));
        org.junit.Assert.assertNotNull(weightedObservedPointArray10);
        org.junit.Assert.assertNotNull(weightedObservedPointArray24);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer4 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter5 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer4);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray6 = harmonicFitter5.getObservations();
        harmonicFitter5.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter5.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter5.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint18 = null;
        harmonicFitter5.addObservedPoint(weightedObservedPoint18);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray20 = harmonicFitter5.getObservations();
        org.apache.commons.math3.exception.ZeroException zeroException21 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) weightedObservedPointArray20);
        org.apache.commons.math3.exception.ZeroException zeroException22 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) weightedObservedPointArray20);
        org.apache.commons.math3.exception.ZeroException zeroException23 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) weightedObservedPointArray20);
        org.apache.commons.math3.exception.ZeroException zeroException24 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray20);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats25, (java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        org.apache.commons.math3.exception.ZeroException zeroException31 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray32 = zeroException31.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException33 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException29, (org.apache.commons.math3.exception.util.Localizable) localizedFormats30, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math3.exception.util.Localizable localizable34 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer36 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter37 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer36);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray38 = harmonicFitter37.getObservations();
        harmonicFitter37.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter37.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter37.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint50 = null;
        harmonicFitter37.addObservedPoint(weightedObservedPoint50);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray52 = harmonicFitter37.getObservations();
        java.lang.Object[] objArray53 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray52);
        org.apache.commons.math3.exception.ZeroException zeroException54 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats35, objArray53);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException55 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException29, localizable34, objArray53);
        java.lang.Throwable[] throwableArray56 = numberIsTooSmallException29.getSuppressed();
        org.apache.commons.math3.exception.ZeroException zeroException57 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray56);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA));
        org.junit.Assert.assertNotNull(weightedObservedPointArray6);
        org.junit.Assert.assertNotNull(weightedObservedPointArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertNotNull(weightedObservedPointArray38);
        org.junit.Assert.assertNotNull(weightedObservedPointArray52);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(throwableArray56);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0f, number2, false);
        java.lang.String str5 = numberIsTooSmallException4.toString();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        java.util.Set<java.lang.String> strSet8 = exceptionContext7.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0" + "'", str5.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1, (java.lang.Number) (-1), true);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) -1, (java.lang.Number) 100L, false);
        boolean boolean6 = numberIsTooSmallException5.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray7 = numberIsTooSmallException5.getSuppressed();
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math3.exception.ZeroException zeroException9 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = zeroException9.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(exceptionContext10);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint(10.0d, (double) 10L);
        harmonicFitter1.addObservedPoint((double) 100L, (double) 1L, (double) (short) 1);
        harmonicFitter1.addObservedPoint((double) 0L, (double) 100, (double) 10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray22 = harmonicFitter1.getObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray22);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        harmonicFitter1.addObservedPoint((double) '#', (double) (byte) -1, (double) (short) 1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint23 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) '4', (double) (-1.0f));
        double double24 = weightedObservedPoint23.getX();
        double double25 = weightedObservedPoint23.getY();
        double double26 = weightedObservedPoint23.getY();
        double double27 = weightedObservedPoint23.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint23);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer29 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter30 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer29);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray31 = harmonicFitter30.getObservations();
        harmonicFitter30.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter30.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter30.addObservedPoint((double) 1, 1.0d);
        harmonicFitter30.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray47 = harmonicFitter30.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser48 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray47);
        double[] doubleArray49 = parameterGuesser48.guess();
        double[] doubleArray50 = parameterGuesser48.guess();
        double[] doubleArray51 = parameterGuesser48.guess();
        try {
            double[] doubleArray52 = harmonicFitter1.fit(doubleArray51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 52.0d + "'", double24 == 52.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-1.0d) + "'", double25 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 52.0d + "'", double27 == 52.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray31);
        org.junit.Assert.assertNotNull(weightedObservedPointArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) (byte) 0, (double) (-1.0f));
        double double4 = weightedObservedPoint3.getY();
        double double5 = weightedObservedPoint3.getX();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) (-1L), false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.String str5 = numberIsTooSmallException3.toString();
        java.lang.Number number6 = numberIsTooSmallException3.getMin();
        java.lang.Number number7 = numberIsTooSmallException3.getArgument();
        java.lang.Number number8 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1L) + "'", number4.equals((-1L)));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 100 is smaller than, or equal to, the minimum (-1)" + "'", str5.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 100 is smaller than, or equal to, the minimum (-1)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1L) + "'", number6.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100 + "'", number7.equals(100));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100 + "'", number8.equals(100));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) (byte) 0, (double) (-1.0f));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer2 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter3 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer2);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray4 = harmonicFitter3.getObservations();
        harmonicFitter3.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter3.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter3.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint16 = null;
        harmonicFitter3.addObservedPoint(weightedObservedPoint16);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray18 = harmonicFitter3.getObservations();
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray18);
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray18);
        org.apache.commons.math3.exception.ZeroException zeroException21 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray20);
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray20);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray20);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext24 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException23);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray4);
        org.junit.Assert.assertNotNull(weightedObservedPointArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint(10.0d, (double) 10L);
        harmonicFitter1.addObservedPoint((double) 100L, (double) 1L, (double) (short) 1);
        harmonicFitter1.addObservedPoint((double) 1.0f, (double) (short) -1);
        harmonicFitter1.addObservedPoint(1.0d, 52.0d, (double) (byte) 1);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer3 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter4 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer3);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray5 = harmonicFitter4.getObservations();
        harmonicFitter4.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter4.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter4.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint17 = null;
        harmonicFitter4.addObservedPoint(weightedObservedPoint17);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray19 = harmonicFitter4.getObservations();
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray19);
        java.lang.Object[] objArray21 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray19);
        org.apache.commons.math3.exception.ZeroException zeroException22 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray21);
        java.lang.Object[] objArray23 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray21);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray21);
        org.apache.commons.math3.exception.ZeroException zeroException25 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray5);
        org.junit.Assert.assertNotNull(weightedObservedPointArray19);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats3, localizedFormats4, localizedFormats5, localizedFormats6, localizedFormats7 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray8);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray8);
        org.apache.commons.math3.exception.ZeroException zeroException11 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1L), number1, false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        harmonicFitter1.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray18 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser19 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray18);
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray18);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser21 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray18);
        double[] doubleArray22 = parameterGuesser21.guess();
        double[] doubleArray23 = parameterGuesser21.guess();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray18);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) 1, true);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        boolean boolean11 = numberIsTooSmallException9.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint(100.0d, (double) 10, (double) (byte) 1);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer13 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter14 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer13);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray15 = harmonicFitter14.getObservations();
        harmonicFitter14.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter14.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter14.addObservedPoint(10.0d, (double) 10L);
        harmonicFitter14.addObservedPoint((double) 100L, (double) 1L, (double) (short) 1);
        harmonicFitter14.addObservedPoint((double) (short) 1, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint37 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(0.0d, (double) (-1), 0.0d);
        double double38 = weightedObservedPoint37.getX();
        harmonicFitter14.addObservedPoint(weightedObservedPoint37);
        harmonicFitter1.addObservedPoint(weightedObservedPoint37);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
        org.junit.Assert.assertNotNull(weightedObservedPointArray15);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38 == (-1.0d));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer2 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter3 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer2);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray4 = harmonicFitter3.getObservations();
        harmonicFitter3.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter3.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray10 = harmonicFitter3.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) weightedObservedPointArray10);
        java.lang.Object[] objArray12 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray10);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray12);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext14 = mathIllegalStateException13.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext15 = mathIllegalStateException13.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) -1, (java.lang.Number) 100L, false);
        boolean boolean22 = numberIsTooSmallException21.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray23 = numberIsTooSmallException21.getSuppressed();
        org.apache.commons.math3.exception.ZeroException zeroException24 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, (java.lang.Object[]) throwableArray23);
        java.lang.Throwable[] throwableArray25 = zeroException24.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException13, (org.apache.commons.math3.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray25);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray4);
        org.junit.Assert.assertNotNull(weightedObservedPointArray10);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint20 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 1L, (-1.0d), (double) 10L);
        harmonicFitter1.addObservedPoint(weightedObservedPoint20);
        double double22 = weightedObservedPoint20.getY();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = harmonicFitter2.getObservations();
        harmonicFitter2.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray5 = harmonicFitter2.getObservations();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS));
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertNotNull(weightedObservedPointArray5);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer2 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter3 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer2);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray4 = harmonicFitter3.getObservations();
        harmonicFitter3.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter3.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray10 = harmonicFitter3.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) weightedObservedPointArray10);
        java.lang.Object[] objArray12 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray10);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray12);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext14 = mathIllegalStateException13.getContext();
        java.lang.Class<?> wildcardClass15 = exceptionContext14.getClass();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        java.lang.Class<?> wildcardClass18 = localizedFormats17.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable19 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer21 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter22 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer21);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray23 = harmonicFitter22.getObservations();
        harmonicFitter22.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter22.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter22.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint35 = null;
        harmonicFitter22.addObservedPoint(weightedObservedPoint35);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray37 = harmonicFitter22.getObservations();
        java.lang.Object[] objArray38 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray37);
        java.lang.Object[] objArray39 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray37);
        org.apache.commons.math3.exception.ZeroException zeroException40 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats20, objArray39);
        java.lang.Object[] objArray41 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray39);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException42 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable19, objArray39);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, objArray39);
        exceptionContext14.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, objArray39);
        java.lang.String str45 = localizedFormats16.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray4);
        org.junit.Assert.assertNotNull(weightedObservedPointArray10);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray23);
        org.junit.Assert.assertNotNull(weightedObservedPointArray37);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "zero norm for rotation defining vector" + "'", str45.equals("zero norm for rotation defining vector"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = harmonicFitter2.getObservations();
        harmonicFitter2.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter2.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray9 = harmonicFitter2.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray9);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) -1, (java.lang.Number) 100L, false);
        java.lang.Number number15 = numberIsTooSmallException14.getArgument();
        java.lang.Number number16 = numberIsTooSmallException14.getArgument();
        mathIllegalArgumentException10.addSuppressed((java.lang.Throwable) numberIsTooSmallException14);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer20 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter21 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer20);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray22 = harmonicFitter21.getObservations();
        harmonicFitter21.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter21.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter21.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint34 = null;
        harmonicFitter21.addObservedPoint(weightedObservedPoint34);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray36 = harmonicFitter21.getObservations();
        java.lang.Object[] objArray37 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray36);
        java.lang.Object[] objArray38 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray36);
        org.apache.commons.math3.exception.ZeroException zeroException39 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats19, objArray38);
        java.lang.Object[] objArray40 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray38);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException14, (org.apache.commons.math3.exception.util.Localizable) localizedFormats18, objArray38);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertNotNull(weightedObservedPointArray9);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) -1 + "'", number15.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (byte) -1 + "'", number16.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray22);
        org.junit.Assert.assertNotNull(weightedObservedPointArray36);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray40);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(10.0d, (double) 0, (double) '4');
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        harmonicFitter1.addObservedPoint(0.0d, (double) (short) 1, (double) (byte) 1);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer20 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter21 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer20);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray22 = harmonicFitter21.getObservations();
        harmonicFitter21.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter21.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter21.addObservedPoint((double) 1, 1.0d);
        harmonicFitter21.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray38 = harmonicFitter21.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser39 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray38);
        double[] doubleArray40 = parameterGuesser39.guess();
        try {
            double[] doubleArray41 = harmonicFitter1.fit(doubleArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray22);
        org.junit.Assert.assertNotNull(weightedObservedPointArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNMATCHED_ODE_IN_EXPANDED_SET;
        java.lang.String str1 = localizedFormats0.getSourceString();
        java.lang.String str2 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNMATCHED_ODE_IN_EXPANDED_SET + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNMATCHED_ODE_IN_EXPANDED_SET));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ode does not match the main ode set in the extended set" + "'", str1.equals("ode does not match the main ode set in the extended set"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ode does not match the main ode set in the extended set" + "'", str2.equals("ode does not match the main ode set in the extended set"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (short) 10, true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = harmonicFitter2.getObservations();
        harmonicFitter2.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter2.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter2.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint15 = null;
        harmonicFitter2.addObservedPoint(weightedObservedPoint15);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray17 = harmonicFitter2.getObservations();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray17);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext19 = mathIllegalStateException18.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext20 = mathIllegalStateException18.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertNotNull(weightedObservedPointArray17);
        org.junit.Assert.assertNotNull(exceptionContext19);
        org.junit.Assert.assertNotNull(exceptionContext20);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint20 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 1L, (-1.0d), (double) 10L);
        harmonicFitter1.addObservedPoint(weightedObservedPoint20);
        harmonicFitter1.addObservedPoint((double) '4', 52.0d);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer25 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter26 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer25);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray27 = harmonicFitter26.getObservations();
        harmonicFitter26.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter26.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter26.addObservedPoint((double) 1, 1.0d);
        harmonicFitter26.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray43 = harmonicFitter26.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser44 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray43);
        double[] doubleArray45 = parameterGuesser44.guess();
        double[] doubleArray46 = parameterGuesser44.guess();
        double[] doubleArray47 = parameterGuesser44.guess();
        try {
            double[] doubleArray48 = harmonicFitter1.fit(doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
        org.junit.Assert.assertNotNull(weightedObservedPointArray27);
        org.junit.Assert.assertNotNull(weightedObservedPointArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        java.lang.Throwable throwable6 = exceptionContext5.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        java.lang.Class<?> wildcardClass8 = localizedFormats7.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable9 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer11 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter12 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer11);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray13 = harmonicFitter12.getObservations();
        harmonicFitter12.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter12.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter12.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint25 = null;
        harmonicFitter12.addObservedPoint(weightedObservedPoint25);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray27 = harmonicFitter12.getObservations();
        java.lang.Object[] objArray28 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray27);
        java.lang.Object[] objArray29 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray27);
        org.apache.commons.math3.exception.ZeroException zeroException30 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, objArray29);
        java.lang.Object[] objArray31 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray29);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException32 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable9, objArray29);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray29);
        throwable6.addSuppressed((java.lang.Throwable) mathIllegalArgumentException33);
        java.lang.String str35 = mathIllegalArgumentException33.toString();
        java.lang.String str36 = mathIllegalArgumentException33.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(throwable6);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray13);
        org.junit.Assert.assertNotNull(weightedObservedPointArray27);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray31);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint12 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) '4', (double) (-1.0f));
        double double13 = weightedObservedPoint12.getX();
        double double14 = weightedObservedPoint12.getY();
        double double15 = weightedObservedPoint12.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint12);
        harmonicFitter1.addObservedPoint((double) (short) 100, (double) 10L);
        harmonicFitter1.addObservedPoint((double) 10.0f, 0.0d);
        harmonicFitter1.addObservedPoint((double) 1.0f, (double) (short) 1, (double) 0);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 52.0d + "'", double13 == 52.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 52.0d + "'", double15 == 52.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (byte) 100, (double) 0, 10.0d);
        double double4 = weightedObservedPoint3.getY();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) -1, (java.lang.Number) 100L, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = numberIsTooSmallException4.getContext();
        java.lang.Throwable[] throwableArray8 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.ZeroException zeroException9 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "not symmetric matrix" + "'", str1.equals("not symmetric matrix"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray1 = zeroException0.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException0, (org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray3);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = mathIllegalStateException4.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException4);
        java.lang.Object obj8 = exceptionContext6.getValue("");
        java.lang.Throwable throwable9 = exceptionContext6.getThrowable();
        java.lang.Class<?> wildcardClass10 = throwable9.getClass();
        org.junit.Assert.assertNotNull(throwableArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(throwable9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray15 = new java.lang.Object[] { localizedFormats10, localizedFormats11, localizedFormats12, localizedFormats13, localizedFormats14 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, objArray15);
        org.apache.commons.math3.exception.ZeroException zeroException17 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray15);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        java.lang.Object[] objArray23 = new java.lang.Object[] { localizedFormats8, "unknown parameter {0}", localizedFormats19, localizedFormats20, localizedFormats21, localizedFormats22 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray23);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray25);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer28 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter29 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer28);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray30 = harmonicFitter29.getObservations();
        harmonicFitter29.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter29.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray36 = harmonicFitter29.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats27, (java.lang.Object[]) weightedObservedPointArray36);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException38 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) weightedObservedPointArray36);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext39 = mathIllegalStateException38.getContext();
        java.lang.Throwable throwable40 = exceptionContext39.getThrowable();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray30);
        org.junit.Assert.assertNotNull(weightedObservedPointArray36);
        org.junit.Assert.assertNotNull(exceptionContext39);
        org.junit.Assert.assertNotNull(throwable40);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        harmonicFitter1.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray18 = harmonicFitter1.getObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint(0.0d, (double) 10, (double) (byte) 100);
        harmonicFitter1.addObservedPoint((double) (short) 100, (double) 0);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray18);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cannot compute beta density at 1 when beta = %.3g" + "'", str1.equals("cannot compute beta density at 1 when beta = %.3g"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 1, 97.0d, (double) 'a');
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0.0f, (double) 0L);
        harmonicFitter1.addObservedPoint((double) (short) 0, (double) 10L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter1.getObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) -1, (double) (byte) 100, (double) (byte) 10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.ZeroException zeroException7 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray8 = zeroException7.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException7, (org.apache.commons.math3.exception.util.Localizable) localizedFormats9, objArray10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = mathIllegalStateException11.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException11);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext14 = mathIllegalStateException11.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext15 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException11);
        exceptionContext5.setValue("observed counts are both zero for entry {0}", (java.lang.Object) mathIllegalStateException11);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N;
        java.lang.Number number20 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats18, (java.lang.Number) 0.0f, number20, false);
        java.lang.String str23 = numberIsTooSmallException22.toString();
        boolean boolean24 = numberIsTooSmallException22.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray32 = new java.lang.Object[] { localizedFormats27, localizedFormats28, localizedFormats29, localizedFormats30, localizedFormats31 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats26, objArray32);
        org.apache.commons.math3.exception.ZeroException zeroException34 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats25, objArray32);
        numberIsTooSmallException22.addSuppressed((java.lang.Throwable) zeroException34);
        boolean boolean36 = numberIsTooSmallException22.getBoundIsAllowed();
        boolean boolean37 = numberIsTooSmallException22.getBoundIsAllowed();
        java.lang.Number number38 = numberIsTooSmallException22.getMin();
        boolean boolean39 = numberIsTooSmallException22.getBoundIsAllowed();
        exceptionContext5.setValue("number of polynomial interpolants must match the number of segments ({0} != {1} - 1)", (java.lang.Object) boolean39);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0" + "'", str23.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(number38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.clearObservations();
        try {
            double[] doubleArray8 = harmonicFitter1.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: sample contains 0 observed points, at least 4 are required");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint(10.0d, (double) 10L);
        harmonicFitter1.addObservedPoint((double) 100L, (double) 1L, (double) (short) 1);
        harmonicFitter1.addObservedPoint((double) 0L, (double) 100, (double) 10);
        harmonicFitter1.addObservedPoint((double) (short) 0, 100.0d, (double) (short) 0);
        harmonicFitter1.addObservedPoint((double) (short) 0, (double) 10.0f);
        try {
            double[] doubleArray29 = harmonicFitter1.fit();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = numberIsTooSmallException4.getContext();
        java.lang.String str7 = numberIsTooSmallException4.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: cannot access 0 method in percentile implementation -1" + "'", str7.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: cannot access 0 method in percentile implementation -1"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint(10.0d, (double) 10L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint17 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) '4', (double) (-1.0f));
        harmonicFitter1.addObservedPoint(weightedObservedPoint17);
        double double19 = weightedObservedPoint17.getX();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 52.0d + "'", double19 == 52.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = harmonicFitter2.getObservations();
        harmonicFitter2.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter2.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray9 = harmonicFitter2.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray10 = harmonicFitter2.getObservations();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray10);
        try {
            org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser12 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: sample contains 0 observed points, at least 4 are required");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertNotNull(weightedObservedPointArray9);
        org.junit.Assert.assertNotNull(weightedObservedPointArray10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) (byte) 100, 0.0d, (double) (short) 10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray15 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (short) 10, 52.0d, (double) (byte) 100);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray15);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS;
        org.apache.commons.math3.exception.ZeroException zeroException9 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.String str10 = zeroException9.toString();
        java.lang.Throwable[] throwableArray11 = zeroException9.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED;
        org.apache.commons.math3.exception.ZeroException zeroException13 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.String str14 = zeroException13.toString();
        java.lang.Throwable[] throwableArray15 = zeroException13.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException9, (org.apache.commons.math3.exception.util.Localizable) localizedFormats12, (java.lang.Object[]) throwableArray15);
        exceptionContext7.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats18, (java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        org.apache.commons.math3.exception.ZeroException zeroException24 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray25 = zeroException24.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException22, (org.apache.commons.math3.exception.util.Localizable) localizedFormats23, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) throwableArray25);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1L) + "'", number6.equals((-1L)));
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math3.exception.ZeroException: zero not allowed here" + "'", str10.equals("org.apache.commons.math3.exception.ZeroException: zero not allowed here"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math3.exception.ZeroException: zero not allowed here" + "'", str14.equals("org.apache.commons.math3.exception.ZeroException: zero not allowed here"));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer2 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter3 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer2);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray4 = harmonicFitter3.getObservations();
        harmonicFitter3.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter3.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter3.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint16 = null;
        harmonicFitter3.addObservedPoint(weightedObservedPoint16);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray18 = harmonicFitter3.getObservations();
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray18);
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray18);
        org.apache.commons.math3.exception.ZeroException zeroException21 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray20);
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray20);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray20);
        java.lang.String str24 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray4);
        org.junit.Assert.assertNotNull(weightedObservedPointArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction." + "'", str24.equals("contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction."));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        org.apache.commons.math3.exception.ZeroException zeroException7 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray8 = zeroException7.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException5, (org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray8);
        org.apache.commons.math3.exception.ZeroException zeroException10 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) (-1.0d), false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSING_BOUNDARY_LOOPS;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSING_BOUNDARY_LOOPS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSING_BOUNDARY_LOOPS));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.String str1 = zeroException0.toString();
        java.lang.Throwable[] throwableArray2 = zeroException0.getSuppressed();
        java.lang.Number number3 = zeroException0.getArgument();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "org.apache.commons.math3.exception.ZeroException: zero not allowed here" + "'", str1.equals("org.apache.commons.math3.exception.ZeroException: zero not allowed here"));
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        harmonicFitter1.addObservedPoint((double) '#', (double) (byte) -1, (double) (short) 1);
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1, (java.lang.Number) (-1), true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, 0.0d, (double) (short) 1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = zeroException0.getContext();
        java.lang.Throwable throwable2 = exceptionContext1.getThrowable();
        java.lang.String str3 = throwable2.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats4, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number9 = numberIsTooSmallException8.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = numberIsTooSmallException8.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = numberIsTooSmallException8.getContext();
        throwable2.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number18 = numberIsTooSmallException17.getMin();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats19, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Class<?> wildcardClass24 = numberIsTooSmallException23.getClass();
        numberIsTooSmallException17.addSuppressed((java.lang.Throwable) numberIsTooSmallException23);
        throwable2.addSuppressed((java.lang.Throwable) numberIsTooSmallException23);
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(throwable2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math3.exception.ZeroException: zero not allowed here" + "'", str3.equals("org.apache.commons.math3.exception.ZeroException: zero not allowed here"));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1L) + "'", number9.equals((-1L)));
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1L) + "'", number18.equals((-1L)));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNMATCHED_ODE_IN_EXPANDED_SET;
        java.lang.String str1 = localizedFormats0.getSourceString();
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math3.exception.ZeroException zeroException3 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNMATCHED_ODE_IN_EXPANDED_SET + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNMATCHED_ODE_IN_EXPANDED_SET));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ode does not match the main ode set in the extended set" + "'", str1.equals("ode does not match the main ode set in the extended set"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer2 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter3 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer2);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray4 = harmonicFitter3.getObservations();
        harmonicFitter3.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter3.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter3.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint16 = null;
        harmonicFitter3.addObservedPoint(weightedObservedPoint16);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray18 = harmonicFitter3.getObservations();
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray18);
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray18);
        org.apache.commons.math3.exception.ZeroException zeroException21 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray20);
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray20);
        org.apache.commons.math3.exception.ZeroException zeroException23 = new org.apache.commons.math3.exception.ZeroException(localizable0, objArray20);
        java.lang.Object[] objArray24 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray4);
        org.junit.Assert.assertNotNull(weightedObservedPointArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math3.exception.ZeroException zeroException1 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray2 = zeroException1.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException1, (org.apache.commons.math3.exception.util.Localizable) localizedFormats3, objArray4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer8 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter9 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer8);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray10 = harmonicFitter9.getObservations();
        harmonicFitter9.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter9.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter9.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) weightedObservedPointArray16);
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray16);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray18);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, objArray18);
        java.lang.Object[] objArray21 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray18);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray10);
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats4, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number9 = numberIsTooSmallException8.getArgument();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.0d + "'", number9.equals(0.0d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer2 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter3 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer2);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray4 = harmonicFitter3.getObservations();
        harmonicFitter3.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter3.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter3.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint16 = null;
        harmonicFitter3.addObservedPoint(weightedObservedPoint16);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray18 = harmonicFitter3.getObservations();
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray18);
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray18);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable0, localizable1, (java.lang.Object[]) weightedObservedPointArray18);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser22 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray18);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser23 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray18);
        org.junit.Assert.assertNotNull(weightedObservedPointArray4);
        org.junit.Assert.assertNotNull(weightedObservedPointArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.BANDWIDTH;
        org.apache.commons.math3.exception.ZeroException zeroException2 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray3 = zeroException2.getSuppressed();
        org.apache.commons.math3.exception.ZeroException zeroException4 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray3);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray3);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray13 = new java.lang.Object[] { localizedFormats8, localizedFormats9, localizedFormats10, localizedFormats11, localizedFormats12 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray13);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray13);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray23 = new java.lang.Object[] { localizedFormats18, localizedFormats19, localizedFormats20, localizedFormats21, localizedFormats22 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, objArray23);
        org.apache.commons.math3.exception.ZeroException zeroException25 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, objArray23);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException5, (org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray23);
        java.lang.Class<?> wildcardClass27 = objArray23.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BANDWIDTH + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BANDWIDTH));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint(10.0d, (double) 10L);
        harmonicFitter1.addObservedPoint((double) 100L, (double) 1L, (double) (short) 1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint21 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) '4', (double) (-1.0f));
        harmonicFitter1.addObservedPoint(weightedObservedPoint21);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint(10.0d, (double) 10L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint17 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) '4', (double) (-1.0f));
        harmonicFitter1.addObservedPoint(weightedObservedPoint17);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer19 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter20 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer19);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray21 = harmonicFitter20.getObservations();
        harmonicFitter20.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter20.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint30 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0L, (double) 100.0f, (double) 1);
        double double31 = weightedObservedPoint30.getWeight();
        harmonicFitter20.addObservedPoint(weightedObservedPoint30);
        double double33 = weightedObservedPoint30.getY();
        harmonicFitter1.addObservedPoint(weightedObservedPoint30);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint38 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 'a', (double) (short) -1, 10.0d);
        harmonicFitter1.addObservedPoint(weightedObservedPoint38);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray21);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = zeroException0.getContext();
        java.lang.Throwable throwable2 = exceptionContext1.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray11 = new java.lang.Object[] { localizedFormats6, localizedFormats7, localizedFormats8, localizedFormats9, localizedFormats10 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray11);
        org.apache.commons.math3.exception.ZeroException zeroException13 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats4, objArray11);
        exceptionContext1.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, objArray11);
        java.lang.Throwable throwable15 = exceptionContext1.getThrowable();
        java.lang.Object obj17 = exceptionContext1.getValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 100 is smaller than, or equal to, the minimum (-1)");
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(throwable2);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwable15);
        org.junit.Assert.assertNull(obj17);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException3);
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        harmonicFitter1.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray18 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser19 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray18);
        double[] doubleArray20 = parameterGuesser19.guess();
        double[] doubleArray21 = parameterGuesser19.guess();
        double[] doubleArray22 = parameterGuesser19.guess();
        double[] doubleArray23 = parameterGuesser19.guess();
        double[] doubleArray24 = parameterGuesser19.guess();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats2, localizedFormats3, localizedFormats4, localizedFormats5, localizedFormats6 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray7);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray7);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = mathIllegalStateException9.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(exceptionContext10);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException1 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = mathIllegalStateException1.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = mathIllegalStateException1.getContext();
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer6 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter7 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer6);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter7.getObservations();
        harmonicFitter7.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter7.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint20 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(10.0d, (double) 0, (double) '4');
        harmonicFitter7.addObservedPoint(weightedObservedPoint20);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray22 = harmonicFitter7.getObservations();
        java.lang.Object[] objArray23 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray22);
        org.apache.commons.math3.exception.ZeroException zeroException24 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) weightedObservedPointArray22);
        exceptionContext3.addMessage(localizable4, (java.lang.Object[]) weightedObservedPointArray22);
        org.apache.commons.math3.exception.ZeroException zeroException26 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N));
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
        org.junit.Assert.assertNotNull(weightedObservedPointArray22);
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray1 = zeroException0.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException0, (org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray3);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException4);
        java.util.Set<java.lang.String> strSet6 = exceptionContext5.getKeys();
        java.lang.Throwable throwable7 = exceptionContext5.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.DENOMINATOR;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer9 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter10 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer9);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray11 = harmonicFitter10.getObservations();
        harmonicFitter10.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter10.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter10.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint23 = null;
        harmonicFitter10.addObservedPoint(weightedObservedPoint23);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray25 = harmonicFitter10.getObservations();
        java.lang.Object[] objArray26 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray25);
        java.lang.Object[] objArray27 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray25);
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) weightedObservedPointArray25);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        exceptionContext5.setValue("unparseable complex number: \"{0}\"", (java.lang.Object) localizedFormats30);
        java.lang.Throwable throwable32 = exceptionContext5.getThrowable();
        java.lang.Throwable throwable33 = exceptionContext5.getThrowable();
        java.lang.Class<?> wildcardClass34 = throwable33.getClass();
        org.junit.Assert.assertNotNull(throwableArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNotNull(throwable7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DENOMINATOR + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DENOMINATOR));
        org.junit.Assert.assertNotNull(weightedObservedPointArray11);
        org.junit.Assert.assertNotNull(weightedObservedPointArray25);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
        org.junit.Assert.assertNotNull(throwable32);
        org.junit.Assert.assertNotNull(throwable33);
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.ZeroException zeroException1 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.String str2 = zeroException1.toString();
        java.lang.Throwable[] throwableArray3 = zeroException1.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math3.exception.ZeroException: zero not allowed here" + "'", str2.equals("org.apache.commons.math3.exception.ZeroException: zero not allowed here"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 10, number1, false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) (byte) 100, 0.0d, (double) (short) 10);
        harmonicFitter1.addObservedPoint((double) (byte) 1, (double) 10.0f, (double) 1.0f);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint22 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) '4', (double) (-1.0f));
        double double23 = weightedObservedPoint22.getX();
        double double24 = weightedObservedPoint22.getWeight();
        double double25 = weightedObservedPoint22.getX();
        harmonicFitter1.addObservedPoint(weightedObservedPoint22);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray27 = harmonicFitter1.getObservations();
        java.lang.Object[] objArray28 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray27);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 52.0d + "'", double23 == 52.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 52.0d + "'", double24 == 52.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.0d + "'", double25 == 52.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray27);
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) 1, true);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        org.apache.commons.math3.exception.ZeroException zeroException11 = new org.apache.commons.math3.exception.ZeroException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = zeroException11.getContext();
        java.lang.Throwable throwable13 = exceptionContext12.getThrowable();
        java.lang.String str14 = throwable13.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats15, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number20 = numberIsTooSmallException19.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext21 = numberIsTooSmallException19.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext22 = numberIsTooSmallException19.getContext();
        throwable13.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        numberIsTooSmallException4.addSuppressed(throwable13);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext25 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer27 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter28 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer27);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray29 = harmonicFitter28.getObservations();
        harmonicFitter28.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter28.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray38 = harmonicFitter28.getObservations();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats26, (java.lang.Object[]) weightedObservedPointArray38);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer42 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter43 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer42);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray44 = harmonicFitter43.getObservations();
        harmonicFitter43.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter43.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray50 = harmonicFitter43.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats41, (java.lang.Object[]) weightedObservedPointArray50);
        java.lang.Object[] objArray52 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray50);
        java.lang.Object[] objArray53 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray50);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats40, objArray53);
        exceptionContext25.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats26, objArray53);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertNotNull(throwable13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math3.exception.ZeroException: zero not allowed here" + "'", str14.equals("org.apache.commons.math3.exception.ZeroException: zero not allowed here"));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1L) + "'", number20.equals((-1L)));
        org.junit.Assert.assertNotNull(exceptionContext21);
        org.junit.Assert.assertNotNull(exceptionContext22);
        org.junit.Assert.assertNotNull(exceptionContext25);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA));
        org.junit.Assert.assertNotNull(weightedObservedPointArray29);
        org.junit.Assert.assertNotNull(weightedObservedPointArray38);
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats40.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats41.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray44);
        org.junit.Assert.assertNotNull(weightedObservedPointArray50);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray53);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(0.0d, (double) (-1), 0.0d);
        double double4 = weightedObservedPoint3.getY();
        double double5 = weightedObservedPoint3.getY();
        double double6 = weightedObservedPoint3.getY();
        double double7 = weightedObservedPoint3.getWeight();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(10.0d, (double) 0, (double) '4');
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        double double16 = weightedObservedPoint14.getX();
        double double17 = weightedObservedPoint14.getY();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 52.0d + "'", double17 == 52.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(10.0d, (double) 0, (double) '4');
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        harmonicFitter1.addObservedPoint(52.0d, (-1.0d));
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = harmonicFitter2.getObservations();
        harmonicFitter2.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter2.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint15 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(10.0d, (double) 0, (double) '4');
        harmonicFitter2.addObservedPoint(weightedObservedPoint15);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray17 = harmonicFitter2.getObservations();
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray17);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray17);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext20 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalArgumentException19);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertNotNull(weightedObservedPointArray17);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint(10.0d, (double) 10L);
        harmonicFitter1.addObservedPoint((double) 100L, (double) 1L, (double) (short) 1);
        harmonicFitter1.addObservedPoint((double) (short) 1, 0.0d);
        harmonicFitter1.addObservedPoint((double) (-1.0f), (double) (-1L), (double) (-1.0f));
        harmonicFitter1.addObservedPoint((-1.0d), (double) 10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint31 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 'a', (double) (short) -1, 10.0d);
        harmonicFitter1.addObservedPoint(weightedObservedPoint31);
        double double33 = weightedObservedPoint31.getY();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 10.0d + "'", double33 == 10.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray1 = zeroException0.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException0, (org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray3);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = mathIllegalStateException4.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException4);
        java.lang.Object obj8 = exceptionContext6.getValue("");
        java.lang.Throwable throwable9 = exceptionContext6.getThrowable();
        java.lang.Throwable throwable10 = exceptionContext6.getThrowable();
        org.junit.Assert.assertNotNull(throwableArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(throwable9);
        org.junit.Assert.assertNotNull(throwable10);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) (byte) 100, 0.0d, (double) (short) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) 10.0f, (double) (byte) 1);
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), (double) 100L, (double) 1.0f);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint(10.0d, (double) 10L);
        harmonicFitter1.addObservedPoint((double) 100L, (double) 1L, (double) (short) 1);
        harmonicFitter1.addObservedPoint((double) (short) 1, 0.0d);
        harmonicFitter1.addObservedPoint((double) (-1.0f), (double) (-1L), (double) (-1.0f));
        harmonicFitter1.addObservedPoint((-1.0d), (double) 10);
        harmonicFitter1.addObservedPoint(97.0d, (double) 10);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer2 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter3 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer2);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray4 = harmonicFitter3.getObservations();
        harmonicFitter3.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter3.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter3.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint16 = null;
        harmonicFitter3.addObservedPoint(weightedObservedPoint16);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray18 = harmonicFitter3.getObservations();
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray18);
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray18);
        org.apache.commons.math3.exception.ZeroException zeroException21 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray20);
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray20);
        org.apache.commons.math3.exception.ZeroException zeroException23 = new org.apache.commons.math3.exception.ZeroException(localizable0, objArray20);
        java.lang.Number number24 = zeroException23.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray4);
        org.junit.Assert.assertNotNull(weightedObservedPointArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0 + "'", number24.equals(0));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) (byte) 100, 0.0d, (double) (short) 10);
        harmonicFitter1.addObservedPoint((double) (byte) 1, (double) 10.0f, (double) 1.0f);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint22 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) '4', (double) (-1.0f));
        double double23 = weightedObservedPoint22.getX();
        double double24 = weightedObservedPoint22.getWeight();
        double double25 = weightedObservedPoint22.getX();
        harmonicFitter1.addObservedPoint(weightedObservedPoint22);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray27 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser28 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray27);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 52.0d + "'", double23 == 52.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 52.0d + "'", double24 == 52.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.0d + "'", double25 == 52.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray27);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(10.0d, (double) 0, (double) '4');
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        double double16 = weightedObservedPoint14.getX();
        double double17 = weightedObservedPoint14.getX();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (-1L), true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DENOMINATOR_FORMAT;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DENOMINATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DENOMINATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "denominator format" + "'", str1.equals("denominator format"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Discrete cumulative probability function returned NaN for argument {0}" + "'", str1.equals("Discrete cumulative probability function returned NaN for argument {0}"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats2, localizedFormats3, localizedFormats4, localizedFormats5, localizedFormats6 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray7);
        mathIllegalStateException0.addSuppressed((java.lang.Throwable) mathIllegalArgumentException8);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException0);
        java.lang.Throwable throwable11 = exceptionContext10.getThrowable();
        java.lang.Object obj13 = exceptionContext10.getValue("cannot set an element at a negative index {0}");
        java.lang.Throwable throwable14 = exceptionContext10.getThrowable();
        java.lang.Object obj16 = exceptionContext10.getValue("eigen decomposition of assymetric matrices not supported yet");
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwable11);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(throwable14);
        org.junit.Assert.assertNull(obj16);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats3, localizedFormats4, localizedFormats5, localizedFormats6, localizedFormats7 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray8);
        org.apache.commons.math3.exception.ZeroException zeroException10 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray8);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        java.lang.Object[] objArray16 = new java.lang.Object[] { localizedFormats1, "unknown parameter {0}", localizedFormats12, localizedFormats13, localizedFormats14, localizedFormats15 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray16);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext18 = mathIllegalArgumentException17.getContext();
        java.util.Set<java.lang.String> strSet19 = exceptionContext18.getKeys();
        java.lang.Throwable throwable20 = exceptionContext18.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer22 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter23 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer22);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray24 = harmonicFitter23.getObservations();
        harmonicFitter23.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter23.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray30 = harmonicFitter23.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint34 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) '4', (double) (-1.0f));
        double double35 = weightedObservedPoint34.getX();
        double double36 = weightedObservedPoint34.getY();
        double double37 = weightedObservedPoint34.getWeight();
        harmonicFitter23.addObservedPoint(weightedObservedPoint34);
        harmonicFitter23.addObservedPoint((double) (short) 100, (double) 10L);
        harmonicFitter23.addObservedPoint((double) 10.0f, 0.0d);
        java.lang.Object[] objArray46 = new java.lang.Object[] { harmonicFitter23, "cannot compute beta density at 1 when beta = %.3g" };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException47 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable20, (org.apache.commons.math3.exception.util.Localizable) localizedFormats21, objArray46);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(exceptionContext18);
        org.junit.Assert.assertNotNull(strSet19);
        org.junit.Assert.assertNotNull(throwable20);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray24);
        org.junit.Assert.assertNotNull(weightedObservedPointArray30);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 52.0d + "'", double35 == 52.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-1.0d) + "'", double36 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 52.0d + "'", double37 == 52.0d);
        org.junit.Assert.assertNotNull(objArray46);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = harmonicFitter2.getObservations();
        harmonicFitter2.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter2.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray9 = harmonicFitter2.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray10 = harmonicFitter2.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertNotNull(weightedObservedPointArray9);
        org.junit.Assert.assertNotNull(weightedObservedPointArray10);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        harmonicFitter1.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray18 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray19 = harmonicFitter1.getObservations();
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric21 = null;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer22 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter23 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer22);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray24 = harmonicFitter23.getObservations();
        harmonicFitter23.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter23.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter23.addObservedPoint((double) 1, 1.0d);
        harmonicFitter23.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray40 = harmonicFitter23.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser41 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray40);
        java.lang.Object[] objArray42 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray40);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser43 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray40);
        double[] doubleArray44 = parameterGuesser43.guess();
        try {
            double[] doubleArray45 = harmonicFitter1.fit((int) (byte) 1, parametric21, doubleArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray18);
        org.junit.Assert.assertNotNull(weightedObservedPointArray19);
        org.junit.Assert.assertNotNull(weightedObservedPointArray24);
        org.junit.Assert.assertNotNull(weightedObservedPointArray40);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "too many regressors ({0}) specified, only {1} in the model" + "'", str1.equals("too many regressors ({0}) specified, only {1} in the model"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = harmonicFitter2.getObservations();
        harmonicFitter2.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter2.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter2.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint15 = null;
        harmonicFitter2.addObservedPoint(weightedObservedPoint15);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray17 = harmonicFitter2.getObservations();
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray17);
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray17);
        org.apache.commons.math3.exception.ZeroException zeroException20 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray19);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N;
        java.lang.Number number23 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats21, (java.lang.Number) 0.0f, number23, false);
        java.lang.String str26 = numberIsTooSmallException25.toString();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext27 = numberIsTooSmallException25.getContext();
        zeroException20.addSuppressed((java.lang.Throwable) numberIsTooSmallException25);
        java.lang.Class<?> wildcardClass29 = zeroException20.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertNotNull(weightedObservedPointArray17);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0" + "'", str26.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0"));
        org.junit.Assert.assertNotNull(exceptionContext27);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        boolean boolean7 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer11 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter12 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer11);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray13 = harmonicFitter12.getObservations();
        harmonicFitter12.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter12.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter12.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint25 = null;
        harmonicFitter12.addObservedPoint(weightedObservedPoint25);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray27 = harmonicFitter12.getObservations();
        org.apache.commons.math3.exception.ZeroException zeroException28 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) weightedObservedPointArray27);
        org.apache.commons.math3.exception.ZeroException zeroException29 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Object[]) weightedObservedPointArray27);
        org.apache.commons.math3.exception.ZeroException zeroException30 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) weightedObservedPointArray27);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) zeroException30);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: cannot access 0 method in percentile implementation -1" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: cannot access 0 method in percentile implementation -1"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA));
        org.junit.Assert.assertNotNull(weightedObservedPointArray13);
        org.junit.Assert.assertNotNull(weightedObservedPointArray27);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (byte) 1, (double) 10, (double) (short) 10);
        double double4 = weightedObservedPoint3.getY();
        double double5 = weightedObservedPoint3.getY();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray1 = zeroException0.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException0, (org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray3);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = mathIllegalStateException4.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException4);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = mathIllegalStateException4.getContext();
        java.lang.Throwable throwable8 = exceptionContext7.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer11 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter12 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer11);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray13 = harmonicFitter12.getObservations();
        harmonicFitter12.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter12.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter12.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint25 = null;
        harmonicFitter12.addObservedPoint(weightedObservedPoint25);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray27 = harmonicFitter12.getObservations();
        java.lang.Object[] objArray28 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray27);
        java.lang.Object[] objArray29 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray27);
        org.apache.commons.math3.exception.ZeroException zeroException30 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, objArray29);
        java.lang.Object[] objArray31 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray29);
        exceptionContext7.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, objArray31);
        java.lang.Object obj34 = exceptionContext7.getValue("");
        java.util.Set<java.lang.String> strSet35 = exceptionContext7.getKeys();
        org.junit.Assert.assertNotNull(throwableArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNotNull(throwable8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray13);
        org.junit.Assert.assertNotNull(weightedObservedPointArray27);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertNotNull(strSet35);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) 1, true);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooSmallException4.getArgument();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0d + "'", number11.equals(0.0d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint11 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 1L, (double) (byte) 0, (double) (short) 1);
        harmonicFitter1.addObservedPoint(weightedObservedPoint11);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) (short) 10, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathIllegalStateException0.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = mathIllegalStateException0.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException0);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer6 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter7 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer6);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter7.getObservations();
        harmonicFitter7.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter7.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray14 = harmonicFitter7.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray15 = harmonicFitter7.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) weightedObservedPointArray15);
        exceptionContext3.setValue("number of successes ({0})", (java.lang.Object) weightedObservedPointArray15);
        java.util.Set<java.lang.String> strSet18 = exceptionContext3.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N;
        java.lang.Number number22 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats20, (java.lang.Number) 0.0f, number22, false);
        java.lang.String str25 = numberIsTooSmallException24.toString();
        boolean boolean26 = numberIsTooSmallException24.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray34 = new java.lang.Object[] { localizedFormats29, localizedFormats30, localizedFormats31, localizedFormats32, localizedFormats33 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats28, objArray34);
        org.apache.commons.math3.exception.ZeroException zeroException36 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats27, objArray34);
        numberIsTooSmallException24.addSuppressed((java.lang.Throwable) zeroException36);
        boolean boolean38 = numberIsTooSmallException24.getBoundIsAllowed();
        boolean boolean39 = numberIsTooSmallException24.getBoundIsAllowed();
        java.lang.Number number40 = numberIsTooSmallException24.getMin();
        exceptionContext3.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0", (java.lang.Object) number40);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer43 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter44 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer43);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray45 = harmonicFitter44.getObservations();
        harmonicFitter44.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter44.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter44.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint57 = null;
        harmonicFitter44.addObservedPoint(weightedObservedPoint57);
        harmonicFitter44.addObservedPoint((double) '#', (double) (byte) -1, (double) (short) 1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint66 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) '4', (double) '4', (double) (-1.0f));
        double double67 = weightedObservedPoint66.getX();
        double double68 = weightedObservedPoint66.getY();
        double double69 = weightedObservedPoint66.getY();
        double double70 = weightedObservedPoint66.getWeight();
        harmonicFitter44.addObservedPoint(weightedObservedPoint66);
        exceptionContext3.setValue("hi!", (java.lang.Object) harmonicFitter44);
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
        org.junit.Assert.assertNotNull(weightedObservedPointArray14);
        org.junit.Assert.assertNotNull(weightedObservedPointArray15);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0" + "'", str25.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats32.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats33.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(number40);
        org.junit.Assert.assertNotNull(weightedObservedPointArray45);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 52.0d + "'", double67 == 52.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + (-1.0d) + "'", double68 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + (-1.0d) + "'", double69 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 52.0d + "'", double70 == 52.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.ZeroException zeroException2 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = zeroException0.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        exceptionContext1.setValue("unknown parameter {0}", (java.lang.Object) localizedFormats3);
        java.lang.Object obj6 = exceptionContext1.getValue("Cardan angles singularity");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer9 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter10 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer9);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray11 = harmonicFitter10.getObservations();
        harmonicFitter10.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter10.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray17 = harmonicFitter10.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) weightedObservedPointArray17);
        exceptionContext1.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) weightedObservedPointArray17);
        java.lang.Throwable throwable20 = exceptionContext1.getThrowable();
        java.lang.Throwable throwable21 = exceptionContext1.getThrowable();
        java.lang.Object obj23 = exceptionContext1.getValue("org.apache.commons.math3.exception.NumberIsTooSmallException: cannot normalize a zero norm vector");
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_BIN_SELECTED));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray11);
        org.junit.Assert.assertNotNull(weightedObservedPointArray17);
        org.junit.Assert.assertNotNull(throwable20);
        org.junit.Assert.assertNotNull(throwable21);
        org.junit.Assert.assertNull(obj23);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) (byte) 100, 0.0d, (double) (short) 10);
        harmonicFitter1.addObservedPoint((double) (byte) 1, (double) 10.0f, (double) 1.0f);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric20 = null;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer21 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter22 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer21);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray23 = harmonicFitter22.getObservations();
        harmonicFitter22.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter22.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter22.addObservedPoint((double) 1, 1.0d);
        harmonicFitter22.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray39 = harmonicFitter22.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser40 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray39);
        double[] doubleArray41 = parameterGuesser40.guess();
        double[] doubleArray42 = parameterGuesser40.guess();
        double[] doubleArray43 = parameterGuesser40.guess();
        try {
            double[] doubleArray44 = harmonicFitter1.fit((-1), parametric20, doubleArray43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray23);
        org.junit.Assert.assertNotNull(weightedObservedPointArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter1.getObservations();
        java.lang.Object[] objArray17 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray16);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser18 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray16);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser19 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray16);
        try {
            double[] doubleArray20 = parameterGuesser19.guess();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        org.apache.commons.math3.exception.ZeroException zeroException6 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray7 = zeroException6.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray7);
        boolean boolean9 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = numberIsTooSmallException4.getContext();
        java.lang.Number number11 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number7 = numberIsTooSmallException6.getMin();
        java.lang.Number number8 = numberIsTooSmallException6.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = numberIsTooSmallException6.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS;
        org.apache.commons.math3.exception.ZeroException zeroException11 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.String str12 = zeroException11.toString();
        java.lang.Throwable[] throwableArray13 = zeroException11.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED;
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.String str16 = zeroException15.toString();
        java.lang.Throwable[] throwableArray17 = zeroException15.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) zeroException11, (org.apache.commons.math3.exception.util.Localizable) localizedFormats14, (java.lang.Object[]) throwableArray17);
        exceptionContext9.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) throwableArray17);
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray17);
        org.apache.commons.math3.exception.ZeroException zeroException21 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "unknown parameter {0}" + "'", str1.equals("unknown parameter {0}"));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1L) + "'", number7.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1L) + "'", number8.equals((-1L)));
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math3.exception.ZeroException: zero not allowed here" + "'", str12.equals("org.apache.commons.math3.exception.ZeroException: zero not allowed here"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math3.exception.ZeroException: zero not allowed here" + "'", str16.equals("org.apache.commons.math3.exception.ZeroException: zero not allowed here"));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 0.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats9, localizedFormats10, localizedFormats11, localizedFormats12, localizedFormats13 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray14);
        mathIllegalStateException7.addSuppressed((java.lang.Throwable) mathIllegalArgumentException15);
        exceptionContext5.setValue("", (java.lang.Object) mathIllegalArgumentException15);
        java.lang.Object obj19 = exceptionContext5.getValue("");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) 10L, false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.LENGTH;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.EVALUATION;
        java.lang.Number number3 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, number3, (java.lang.Number) 1, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.LENGTH;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = mathIllegalStateException8.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = mathIllegalStateException8.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException8);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer14 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter15 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer14);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter15.getObservations();
        harmonicFitter15.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter15.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray22 = harmonicFitter15.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray23 = harmonicFitter15.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, (java.lang.Object[]) weightedObservedPointArray23);
        exceptionContext11.setValue("number of successes ({0})", (java.lang.Object) weightedObservedPointArray23);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException6, (org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) weightedObservedPointArray23);
        java.lang.Object[] objArray27 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray23);
        org.apache.commons.math3.exception.ZeroException zeroException28 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) weightedObservedPointArray23);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray23);
        java.util.Locale locale30 = null;
        try {
            java.lang.String str31 = localizedFormats0.getLocalizedString(locale30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LENGTH));
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
        org.junit.Assert.assertNotNull(weightedObservedPointArray22);
        org.junit.Assert.assertNotNull(weightedObservedPointArray23);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) 1, true);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Throwable[] throwableArray11 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = numberIsTooSmallException4.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertNotNull(exceptionContext13);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = zeroException0.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        exceptionContext1.setValue("unknown parameter {0}", (java.lang.Object) localizedFormats3);
        java.util.Set<java.lang.String> strSet5 = exceptionContext1.getKeys();
        java.util.Set<java.lang.String> strSet6 = exceptionContext1.getKeys();
        java.util.Set<java.lang.String> strSet7 = exceptionContext1.getKeys();
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNotNull(strSet7);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = zeroException0.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        exceptionContext1.setValue("unknown parameter {0}", (java.lang.Object) localizedFormats3);
        java.lang.Object obj6 = exceptionContext1.getValue("Cardan angles singularity");
        java.lang.Class<?> wildcardClass7 = exceptionContext1.getClass();
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.BOBYQA_BOUND_DIFFERENCE_CONDITION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N;
        java.lang.Number number13 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Number) 0.0f, number13, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.BANDWIDTH;
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray19 = zeroException18.getSuppressed();
        org.apache.commons.math3.exception.ZeroException zeroException20 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, (java.lang.Object[]) throwableArray19);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray19);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Object[]) throwableArray19);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable9, (org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) throwableArray19);
        exceptionContext1.setValue("org.apache.commons.math3.exception.ZeroException: vector length mismatch: got 0 but expected {1}", (java.lang.Object) localizedFormats10);
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BOBYQA_BOUND_DIFFERENCE_CONDITION + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BOBYQA_BOUND_DIFFERENCE_CONDITION));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BANDWIDTH + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BANDWIDTH));
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 'a');
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric17 = null;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer18 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter19 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer18);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray20 = harmonicFitter19.getObservations();
        harmonicFitter19.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter19.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter19.addObservedPoint((double) 1, 1.0d);
        harmonicFitter19.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray36 = harmonicFitter19.getObservations();
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser37 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray36);
        double[] doubleArray38 = parameterGuesser37.guess();
        double[] doubleArray39 = parameterGuesser37.guess();
        double[] doubleArray40 = parameterGuesser37.guess();
        double[] doubleArray41 = parameterGuesser37.guess();
        try {
            double[] doubleArray42 = harmonicFitter1.fit((int) (short) -1, parametric17, doubleArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray20);
        org.junit.Assert.assertNotNull(weightedObservedPointArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) (byte) 100, 0.0d, (double) (short) 10);
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer16 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter17 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer16);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray18 = harmonicFitter17.getObservations();
        harmonicFitter17.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter17.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint30 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(10.0d, (double) 0, (double) '4');
        harmonicFitter17.addObservedPoint(weightedObservedPoint30);
        double double32 = weightedObservedPoint30.getX();
        harmonicFitter1.addObservedPoint(weightedObservedPoint30);
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray18);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathIllegalStateException0.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = mathIllegalStateException0.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException0);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer6 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter7 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer6);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter7.getObservations();
        harmonicFitter7.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter7.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray14 = harmonicFitter7.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray15 = harmonicFitter7.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) weightedObservedPointArray15);
        exceptionContext3.setValue("number of successes ({0})", (java.lang.Object) weightedObservedPointArray15);
        java.util.Set<java.lang.String> strSet18 = exceptionContext3.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N;
        java.lang.Number number22 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats20, (java.lang.Number) 0.0f, number22, false);
        java.lang.String str25 = numberIsTooSmallException24.toString();
        boolean boolean26 = numberIsTooSmallException24.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Object[] objArray34 = new java.lang.Object[] { localizedFormats29, localizedFormats30, localizedFormats31, localizedFormats32, localizedFormats33 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats28, objArray34);
        org.apache.commons.math3.exception.ZeroException zeroException36 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats27, objArray34);
        numberIsTooSmallException24.addSuppressed((java.lang.Throwable) zeroException36);
        boolean boolean38 = numberIsTooSmallException24.getBoundIsAllowed();
        boolean boolean39 = numberIsTooSmallException24.getBoundIsAllowed();
        java.lang.Number number40 = numberIsTooSmallException24.getMin();
        exceptionContext3.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0", (java.lang.Object) number40);
        java.lang.Object obj43 = exceptionContext3.getValue("number of polynomial interpolants must match the number of segments ({0} != {1} - 1)");
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_ELEMENT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
        org.junit.Assert.assertNotNull(weightedObservedPointArray14);
        org.junit.Assert.assertNotNull(weightedObservedPointArray15);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0" + "'", str25.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats32.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats33.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(number40);
        org.junit.Assert.assertNull(obj43);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.Throwable[] throwableArray9 = numberIsTooSmallException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: cannot access 0 method in percentile implementation -1" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: cannot access 0 method in percentile implementation -1"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1L) + "'", number7.equals((-1L)));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) -1, (java.lang.Number) 100L, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = numberIsTooSmallException3.getContext();
        java.lang.Throwable[] throwableArray7 = numberIsTooSmallException3.getSuppressed();
        java.lang.Number number8 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100L + "'", number5.equals(100L));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100L + "'", number8.equals(100L));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint14);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint20 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 1L, (-1.0d), (double) 10L);
        harmonicFitter1.addObservedPoint(weightedObservedPoint20);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray22 = harmonicFitter1.getObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
        org.junit.Assert.assertNotNull(weightedObservedPointArray22);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 100.0f, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0f + "'", number5.equals(100.0f));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter1.addObservedPoint((double) 1, 1.0d);
        harmonicFitter1.addObservedPoint(0.0d, (double) (short) 100, (double) 1L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray18 = harmonicFitter1.getObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint(0.0d, (double) 10, (double) (byte) 100);
        harmonicFitter1.addObservedPoint((double) 100.0f, (double) (short) 0, (double) (-1L));
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray18);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer2 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter3 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer2);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray4 = harmonicFitter3.getObservations();
        harmonicFitter3.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter3.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter3.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint16 = null;
        harmonicFitter3.addObservedPoint(weightedObservedPoint16);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray18 = harmonicFitter3.getObservations();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) weightedObservedPointArray18);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray18);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser21 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray18);
        try {
            double[] doubleArray22 = parameterGuesser21.guess();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
        org.junit.Assert.assertNotNull(weightedObservedPointArray4);
        org.junit.Assert.assertNotNull(weightedObservedPointArray18);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) (short) 10, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = harmonicFitter2.getObservations();
        harmonicFitter2.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter2.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter2.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint15 = null;
        harmonicFitter2.addObservedPoint(weightedObservedPoint15);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray17 = harmonicFitter2.getObservations();
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray17);
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray17);
        org.apache.commons.math3.exception.ZeroException zeroException20 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray19);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N;
        java.lang.Number number23 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats21, (java.lang.Number) 0.0f, number23, false);
        java.lang.String str26 = numberIsTooSmallException25.toString();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext27 = numberIsTooSmallException25.getContext();
        zeroException20.addSuppressed((java.lang.Throwable) numberIsTooSmallException25);
        java.lang.Number number29 = numberIsTooSmallException25.getArgument();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        numberIsTooSmallException25.addSuppressed((java.lang.Throwable) numberIsTooSmallException33);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext35 = numberIsTooSmallException33.getContext();
        org.apache.commons.math3.exception.ZeroException zeroException37 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray38 = zeroException37.getSuppressed();
        exceptionContext35.setValue("org.apache.commons.math3.exception.MathIllegalStateException: cannot set an element at a negative index {0}", (java.lang.Object) throwableArray38);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer43 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter44 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer43);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray45 = harmonicFitter44.getObservations();
        harmonicFitter44.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter44.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray51 = harmonicFitter44.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats42, (java.lang.Object[]) weightedObservedPointArray51);
        java.lang.Object[] objArray53 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray51);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException54 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats41, objArray53);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext55 = mathIllegalStateException54.getContext();
        java.lang.Class<?> wildcardClass56 = exceptionContext55.getClass();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats57 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        java.lang.Class<?> wildcardClass59 = localizedFormats58.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable60 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats61 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer62 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter63 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer62);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray64 = harmonicFitter63.getObservations();
        harmonicFitter63.addObservedPoint((double) (byte) 10, (double) 100, (double) ' ');
        harmonicFitter63.addObservedPoint((double) (short) 10, (double) (-1), (double) 'a');
        harmonicFitter63.addObservedPoint((double) 1, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint76 = null;
        harmonicFitter63.addObservedPoint(weightedObservedPoint76);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray78 = harmonicFitter63.getObservations();
        java.lang.Object[] objArray79 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray78);
        java.lang.Object[] objArray80 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray78);
        org.apache.commons.math3.exception.ZeroException zeroException81 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats61, objArray80);
        java.lang.Object[] objArray82 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray80);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException83 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable60, objArray80);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException84 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats58, objArray80);
        exceptionContext55.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats57, objArray80);
        exceptionContext35.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: Overflow trying to convert 10 to fraction (10/{2})", (java.lang.Object) exceptionContext55);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertNotNull(weightedObservedPointArray17);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0" + "'", str26.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: method not supported in dimension 0"));
        org.junit.Assert.assertNotNull(exceptionContext27);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 0.0f + "'", number29.equals(0.0f));
        org.junit.Assert.assertNotNull(exceptionContext35);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION + "'", localizedFormats41.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_REGRESSION));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats42.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray45);
        org.junit.Assert.assertNotNull(weightedObservedPointArray51);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(exceptionContext55);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + localizedFormats57 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats57.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats58.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertTrue("'" + localizedFormats61 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats61.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray64);
        org.junit.Assert.assertNotNull(weightedObservedPointArray78);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(objArray82);
    }
}

