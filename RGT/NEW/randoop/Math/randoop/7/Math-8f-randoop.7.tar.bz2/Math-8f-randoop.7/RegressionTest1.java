import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1054269.6159652844d, (java.lang.Number) (-0.42978164783246015d), true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) numberIsTooSmallException4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-0.42978164783246015d) + "'", number5.equals((-0.42978164783246015d)));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.Well19937c well19937c9 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c9);
        int[] intArray14 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c9.setSeed(intArray14);
        double double16 = org.apache.commons.math3.util.MathArrays.distance(intArray6, intArray14);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c18);
        int[] intArray23 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c18.setSeed(intArray23);
        org.apache.commons.math3.random.Well19937c well19937c26 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl27 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c26);
        int[] intArray31 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c26.setSeed(intArray31);
        double double33 = org.apache.commons.math3.util.MathArrays.distance(intArray23, intArray31);
        int[] intArray35 = org.apache.commons.math3.util.MathArrays.copyOf(intArray31, (int) 'a');
        int int36 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray35);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        double double32 = discreteRealDistribution29.density((double) 7);
        double double33 = discreteRealDistribution29.sample();
        double double35 = discreteRealDistribution29.density(0.09294902424688352d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 9.347883475356515d, number1, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 9.347883475356515d + "'", number5.equals(9.347883475356515d));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double12 = randomDataGenerator9.nextGaussian((double) 1L, (double) 1748310433);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 5.757757058701872E8d + "'", double12 == 5.757757058701872E8d);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 0, (java.lang.Number) 0.30955021719333553d, (java.lang.Number) 10);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException();
        double[] doubleArray13 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray19 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray13, doubleArray19);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray33 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray27, doubleArray33);
        double double35 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray20, doubleArray33);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator36 = new org.apache.commons.math3.random.RandomDataGenerator();
        java.lang.Object[] objArray37 = new java.lang.Object[] { nullArgumentException7, doubleArray20, randomDataGenerator36 };
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException38 = new org.apache.commons.math3.exception.NullArgumentException(localizable6, objArray37);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException39 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (short) 0, objArray37);
        java.lang.Throwable[] throwableArray40 = notFiniteNumberException39.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException3, localizable4, (java.lang.Object[]) throwableArray40);
        java.lang.Number number42 = outOfRangeException3.getHi();
        java.lang.Number number43 = outOfRangeException3.getLo();
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1012010.0d + "'", double35 == 1012010.0d);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 10 + "'", number42.equals(10));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0.30955021719333553d + "'", number43.equals(0.30955021719333553d));
    }

//    @Test
//    public void test07() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test07");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeed((long) (short) 1);
//        randomDataGenerator0.reSeed();
//        int int6 = randomDataGenerator0.nextSecureInt(7, (int) '#');
//        long long9 = randomDataGenerator0.nextSecureLong((long) 35, (long) 'a');
//        int int12 = randomDataGenerator0.nextZipf(9, (double) 530971062);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 28 + "'", int6 == 28);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 63L + "'", long9 == 63L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0, (java.lang.Number) (-1.0f));
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.String str5 = outOfRangeException3.toString();
        java.lang.Number number6 = outOfRangeException3.getHi();
        java.lang.Number number7 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 0 out of [0, -1] range" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: 0 out of [0, -1] range"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0f) + "'", number6.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0f) + "'", number7.equals((-1.0f)));
    }

//    @Test
//    public void test09() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test09");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeed((long) (short) 1);
//        randomDataGenerator0.reSeed();
//        double double5 = randomDataGenerator0.nextChiSquare((double) 7);
//        try {
//            int int9 = randomDataGenerator0.nextHypergeometric(14, 463846793, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (463,846,793) must be less than or equal to population size (14)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.100896901092394d + "'", double5 == 4.100896901092394d);
//    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        float[] floatArray0 = null;
        float[] floatArray2 = new float[] { 100.0f };
        float[] floatArray7 = new float[] { (-1), (-1L), (byte) 1, 10L };
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray2, floatArray7);
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(floatArray0, floatArray2);
        float[] floatArray11 = new float[] { 100.0f };
        float[] floatArray16 = new float[] { (-1), (-1L), (byte) 1, 10L };
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray11, floatArray16);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equals(floatArray2, floatArray16);
        float[] floatArray19 = null;
        float[] floatArray21 = new float[] { 100.0f };
        float[] floatArray26 = new float[] { (-1), (-1L), (byte) 1, 10L };
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray21, floatArray26);
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equals(floatArray19, floatArray21);
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray2, floatArray19);
        float[] floatArray30 = null;
        float[] floatArray31 = null;
        float[] floatArray33 = new float[] { 100.0f };
        float[] floatArray38 = new float[] { (-1), (-1L), (byte) 1, 10L };
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray33, floatArray38);
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equals(floatArray31, floatArray33);
        float[] floatArray42 = new float[] { 100.0f };
        float[] floatArray47 = new float[] { (-1), (-1L), (byte) 1, 10L };
        boolean boolean48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray42, floatArray47);
        boolean boolean49 = org.apache.commons.math3.util.MathArrays.equals(floatArray33, floatArray47);
        boolean boolean50 = org.apache.commons.math3.util.MathArrays.equals(floatArray30, floatArray33);
        boolean boolean51 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray2, floatArray33);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        double double8 = randomDataImpl2.nextChiSquare((double) 100);
        int int12 = randomDataImpl2.nextHypergeometric((int) 'a', 0, 10);
        java.lang.String str14 = randomDataImpl2.nextHexString(32);
        randomDataImpl2.reSeedSecure();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 105.42696159652844d + "'", double8 == 105.42696159652844d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "037ac0bc91eaf7c3da6a9f948d8c9034" + "'", str14.equals("037ac0bc91eaf7c3da6a9f948d8c9034"));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double6 = randomDataImpl2.nextUniform(0.0d, 1012010.0d, false);
        randomDataImpl2.reSeed((long) (short) 0);
        randomDataImpl2.reSeedSecure();
        double double12 = randomDataImpl2.nextGaussian((-2.0d), (double) 44L);
        java.lang.String str14 = randomDataImpl2.nextHexString((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 328552.22402481775d + "'", double6 == 328552.22402481775d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-3.913170299716576d) + "'", double12 == (-3.913170299716576d));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5560b024803c29248e108866f1306a890" + "'", str14.equals("d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5560b024803c29248e108866f1306a890"));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray6 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c1.setSeed(intArray6);
        double double8 = well19937c1.nextGaussian();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-2.344630206476761d) + "'", double8 == (-2.344630206476761d));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        long[][] longArray0 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkRectangular(longArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        java.util.ArrayList<org.apache.commons.math3.util.Pair<float[], java.lang.Double>> floatArrayPairList0 = new java.util.ArrayList<org.apache.commons.math3.util.Pair<float[], java.lang.Double>>();
        try {
            org.apache.commons.math3.distribution.DiscreteDistribution<float[]> floatArrayDiscreteDistribution1 = new org.apache.commons.math3.distribution.DiscreteDistribution<float[]>((java.util.List<org.apache.commons.math3.util.Pair<float[], java.lang.Double>>) floatArrayPairList0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test16");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        well19937c1.clear();
//        float float4 = well19937c1.nextFloat();
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int int8 = randomDataGenerator5.nextSecureInt((int) (byte) -1, 8);
//        long long10 = randomDataGenerator5.nextPoisson(100.0d);
//        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.32465303f + "'", float4 == 0.32465303f);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 86L + "'", long10 == 86L);
//    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 10);
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        org.apache.commons.math3.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable8, (java.lang.Number) (short) -1, objArray13);
        org.apache.commons.math3.exception.MathInternalError mathInternalError15 = new org.apache.commons.math3.exception.MathInternalError(localizable7, objArray13);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException16 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable5, (java.lang.Number) 328552.22402481775d, objArray13);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable4, objArray13);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) notStrictlyPositiveException2, localizable3, objArray13);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException19 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray13);
        org.junit.Assert.assertNotNull(objArray13);
    }

//    @Test
//    public void test18() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test18");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextInt((int) (byte) -1, (int) (short) 10);
//        java.lang.String str5 = randomDataGenerator0.nextHexString((int) (byte) 10);
//        java.lang.String str7 = randomDataGenerator0.nextSecureHexString(7);
//        randomDataGenerator0.reSeed();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a1175a978a" + "'", str5.equals("a1175a978a"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "044c8df" + "'", str7.equals("044c8df"));
//    }

//    @Test
//    public void test19() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test19");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        double double2 = randomDataGenerator0.nextT((double) (short) 10);
//        double double4 = randomDataGenerator0.nextT(0.1845842603151447d);
//        randomDataGenerator0.reSeed(5590325047021507584L);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.1794540912541066d) + "'", double2 == (-0.1794540912541066d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-12.406038258635904d) + "'", double4 == (-12.406038258635904d));
//    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) (short) 100);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int3 = well19937c1.nextInt();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1347491339) + "'", int3 == (-1347491339));
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray6 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c1.setSeed(intArray6);
        double[] doubleArray13 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray19 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray13, doubleArray19);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray33 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray27, doubleArray33);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34);
        org.apache.commons.math3.random.Well19937c well19937c37 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c37.clear();
        double[] doubleArray44 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray50 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray44, doubleArray50);
        double[] doubleArray57 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray63 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray57, doubleArray63);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution65 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c37, doubleArray44, doubleArray64);
        boolean boolean66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray34, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution67 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray21, doubleArray34);
        double[] doubleArray68 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray68, (double) (short) 10);
        double[] doubleArray71 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray68);
        double[] doubleArray72 = null;
        try {
            double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray71, doubleArray72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
    }

//    @Test
//    public void test22() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test22");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeed((long) (short) 1);
//        randomDataGenerator0.reSeed();
//        int int6 = randomDataGenerator0.nextSecureInt(7, (int) '#');
//        try {
//            int int9 = randomDataGenerator0.nextBinomial((int) (short) 10, 9900.822238582006d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 9,900.822 out of [0, 1] range");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
//    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        discreteRealDistribution76.reseedRandomGenerator((long) 'a');
        double double79 = discreteRealDistribution76.getSupportUpperBound();
        double double82 = discreteRealDistribution76.cumulativeProbability((-1449.930491234778d), (-0.1794540912541066d));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 10000.0d + "'", double79 == 10000.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        double double8 = randomDataImpl2.nextChiSquare((double) 100);
        int int11 = randomDataImpl2.nextInt(0, (int) ' ');
        try {
            java.lang.String str13 = randomDataImpl2.nextSecureHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 105.42696159652844d + "'", double8 == 105.42696159652844d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray26);
        double[] doubleArray33 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray39 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray33, doubleArray39);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40);
        double[] doubleArray47 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray53 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray47, doubleArray53);
        double double55 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray40, doubleArray53);
        double double56 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray26, doubleArray53);
        double[] doubleArray62 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray68 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray62, doubleArray68);
        double[] doubleArray75 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray81 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray82 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray75, doubleArray81);
        double[] doubleArray83 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray82);
        double double84 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray69, doubleArray83);
        double double85 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray83);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution86 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(doubleArray26, doubleArray83);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (10,000 >= 100)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1012010.0d + "'", double55 == 1012010.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 9900.0d + "'", double56 == 9900.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 10001.504886765792d + "'", double85 == 10001.504886765792d);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 38011.69819126901d);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = notPositiveException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 9900.0d, (java.lang.Number) 3.1362296620555803d, false);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10001.504886765792d, (java.lang.Number) 271, false);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
        java.lang.IllegalStateException illegalStateException33 = discreteRealDistributionPair32.getSecond();
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution34 = discreteRealDistributionPair32.getKey();
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution35 = discreteRealDistributionPair32.getFirst();
        double double37 = discreteRealDistribution35.cumulativeProbability(0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertNotNull(illegalStateException33);
        org.junit.Assert.assertNotNull(discreteRealDistribution34);
        org.junit.Assert.assertNotNull(discreteRealDistribution35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 10.0d, (java.lang.Number) (-0.7890639983076418d), (java.lang.Number) 971.4281508340689d);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
        java.lang.IllegalStateException illegalStateException33 = discreteRealDistributionPair32.getSecond();
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution34 = discreteRealDistributionPair32.getKey();
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution35 = discreteRealDistributionPair32.getFirst();
        discreteRealDistribution35.reseedRandomGenerator((long) 530971062);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertNotNull(illegalStateException33);
        org.junit.Assert.assertNotNull(discreteRealDistribution34);
        org.junit.Assert.assertNotNull(discreteRealDistribution35);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 10000.0d, (java.lang.Number) 22.981618453278884d, (java.lang.Number) 2.6535446267034742E8d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 22.981618453278884d + "'", number4.equals(22.981618453278884d));
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        double double8 = randomDataImpl2.nextExponential(0.09709622577147363d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.031887436958104226d + "'", double8 == 0.031887436958104226d);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray1);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        well19937c1.clear();
        long long4 = well19937c1.nextLong();
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        int[] intArray11 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c6.setSeed(intArray11);
        org.apache.commons.math3.random.Well19937c well19937c14 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c14);
        int[] intArray19 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c14.setSeed(intArray19);
        double double21 = org.apache.commons.math3.util.MathArrays.distance(intArray11, intArray19);
        well19937c1.setSeed(intArray11);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5988793534754658721L + "'", long4 == 5988793534754658721L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        long[] longArray4 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray9 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray14 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray19 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray24 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray29 = new long[] { 10, 100, 0L, (byte) 10 };
        long[][] longArray30 = new long[][] { longArray4, longArray9, longArray14, longArray19, longArray24, longArray29 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray30);
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray30);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray29);
        org.junit.Assert.assertNotNull(longArray30);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
        boolean boolean34 = discreteRealDistributionPair32.equals((java.lang.Object) (-1));
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution35 = discreteRealDistributionPair32.getKey();
        boolean boolean36 = discreteRealDistribution35.isSupportUpperBoundInclusive();
        double double38 = discreteRealDistribution35.probability(0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(discreteRealDistribution35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeedSecure((long) (short) 0);
        int[] intArray13 = randomDataImpl8.nextPermutation(52, 8);
        int int17 = randomDataImpl8.nextHypergeometric(414070727, 6, (int) (byte) 1);
        double double20 = randomDataImpl8.nextGamma(0.07466132577245381d, (double) 463846793);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.1566593462549586E7d + "'", double20 == 2.1566593462549586E7d);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, (-0.42978164783246015d), 328552.22402481775d, (double) 100L, 10001.504886765792d, 0.1324893915945104d, 33.817840312133065d, (double) 63L);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.2858678019718915E7d + "'", double8 == 3.2858678019718915E7d);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) 0);
        try {
            int int5 = randomDataGenerator0.nextInt((int) (byte) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10) must be strictly less than upper bound (10)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, 5, (int) '4');
        int int4 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number0, (java.lang.Number) 26.56353953166036d, (int) (short) -1);
        int int4 = nonMonotonicSequenceException3.getIndex();
        int int5 = nonMonotonicSequenceException3.getIndex();
        int int6 = nonMonotonicSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        double double8 = randomDataImpl2.nextT(0.09294902424688352d);
        try {
            java.lang.String str10 = randomDataImpl2.nextHexString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 11.446697401807153d + "'", double8 == 11.446697401807153d);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        long[] longArray7 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray12 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray17 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray22 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray27 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray32 = new long[] { 10, 100, 0L, (byte) 10 };
        long[][] longArray33 = new long[][] { longArray7, longArray12, longArray17, longArray22, longArray27, longArray32 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray33);
        org.apache.commons.math3.exception.MathInternalError mathInternalError35 = new org.apache.commons.math3.exception.MathInternalError(localizable2, (java.lang.Object[]) longArray33);
        org.apache.commons.math3.exception.MathInternalError mathInternalError36 = new org.apache.commons.math3.exception.MathInternalError(localizable1, (java.lang.Object[]) longArray33);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException37 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) longArray33);
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray33);
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray33);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray32);
        org.junit.Assert.assertNotNull(longArray33);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.Well19937c well19937c10 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray15 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c10.setSeed(intArray15);
        org.apache.commons.math3.random.Well19937c well19937c17 = new org.apache.commons.math3.random.Well19937c(intArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c(intArray15);
        org.apache.commons.math3.random.Well19937c well19937c20 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c20.clear();
        double[] doubleArray27 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray33 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray27, doubleArray33);
        double[] doubleArray40 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray46 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray46);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution48 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c20, doubleArray27, doubleArray47);
        double double49 = well19937c20.nextGaussian();
        int[] intArray56 = new int[] { (short) 1, 7, (short) 1, 100, 0, (byte) 100 };
        int[] intArray58 = org.apache.commons.math3.util.MathArrays.copyOf(intArray56, (int) 'a');
        well19937c20.setSeed(intArray56);
        well19937c18.setSeed(intArray56);
        well19937c1.setSeed(intArray56);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + (-0.40892891016592103d) + "'", double49 == (-0.40892891016592103d));
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray58);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        int[] intArray8 = org.apache.commons.math3.util.MathArrays.copyOf(intArray6);
        int[] intArray13 = new int[] { 25, ' ', 1, 25 };
        int int14 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray13);
        int[] intArray15 = org.apache.commons.math3.util.MathArrays.copyOf(intArray6);
        org.apache.commons.math3.random.Well19937c well19937c17 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray22 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c17.setSeed(intArray22);
        double double24 = org.apache.commons.math3.util.MathArrays.distance(intArray6, intArray22);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 174 + "'", int14 == 174);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 146.5980900284857d + "'", double24 == 146.5980900284857d);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 100L, (java.lang.Number) 100.0f, (java.lang.Number) (short) -1);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getHi();
        java.lang.Throwable[] throwableArray6 = outOfRangeException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0f + "'", number4.equals(100.0f));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) -1 + "'", number5.equals((short) -1));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 25);
        java.lang.Number number4 = dimensionMismatchException3.getArgument();
        java.lang.Throwable[] throwableArray5 = dimensionMismatchException3.getSuppressed();
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException6 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) throwableArray5);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = mathArithmeticException6.getContext();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(exceptionContext7);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0d, (java.lang.Number) (short) 0, (int) ' ');
        int int4 = nonMonotonicSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonicSequenceException3.getPrevious();
        java.lang.Number number6 = nonMonotonicSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 0 + "'", number5.equals((short) 0));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 0 + "'", number6.equals((short) 0));
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 14);
    }

//    @Test
//    public void test51() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test51");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 1, (long) 7);
//        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        well19937c5.clear();
//        double[] doubleArray12 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
//        double[] doubleArray18 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
//        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray12, doubleArray18);
//        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
//        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
//        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
//        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution33 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c5, doubleArray12, doubleArray32);
//        double double34 = discreteRealDistribution33.getSupportUpperBound();
//        org.apache.commons.math3.exception.MathInternalError mathInternalError35 = new org.apache.commons.math3.exception.MathInternalError();
//        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair36 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution33, (java.lang.IllegalStateException) mathInternalError35);
//        double double37 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) discreteRealDistribution33);
//        double double38 = discreteRealDistribution33.sample();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
//        org.junit.Assert.assertNotNull(doubleArray12);
//        org.junit.Assert.assertNotNull(doubleArray18);
//        org.junit.Assert.assertNotNull(doubleArray19);
//        org.junit.Assert.assertNotNull(doubleArray25);
//        org.junit.Assert.assertNotNull(doubleArray31);
//        org.junit.Assert.assertNotNull(doubleArray32);
//        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.0d + "'", double34 == 100.0d);
//        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 99.99999859391905d + "'", double37 == 99.99999859391905d);
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 100.0d + "'", double38 == 100.0d);
//    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) 'a', 32);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double11 = well19937c1.nextGaussian();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.32933264825411424d + "'", double11 == 0.32933264825411424d);
    }

//    @Test
//    public void test54() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test54");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeedSecure();
//        double double3 = randomDataGenerator0.nextChiSquare(39.525652590500485d);
//        int int6 = randomDataGenerator0.nextSecureInt(1, 1394374653);
//        randomDataGenerator0.reSeed();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 43.27156438490565d + "'", double3 == 43.27156438490565d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 990373824 + "'", int6 == 990373824);
//    }

//    @Test
//    public void test55() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test55");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
//        well19937c1.setSeed(intArray6);
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        randomDataImpl8.reSeedSecure((long) (short) 0);
//        int[] intArray13 = randomDataImpl8.nextPermutation(52, 8);
//        int int16 = randomDataImpl8.nextSecureInt((int) (short) 1, 42);
//        double double19 = randomDataImpl8.nextUniform((double) 3, 9.347883475356515d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 6.069762673533268d + "'", double19 == 6.069762673533268d);
//    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        double double8 = randomDataImpl2.nextChiSquare((double) 100);
        randomDataImpl2.reSeedSecure(44L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 105.42696159652844d + "'", double8 == 105.42696159652844d);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        double double2 = well19937c1.nextGaussian();
        well19937c1.setSeed(0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.327000036267693d + "'", double2 == 1.327000036267693d);
    }

//    @Test
//    public void test58() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test58");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeed((long) (short) 1);
//        randomDataGenerator0.reSeed();
//        int int6 = randomDataGenerator0.nextSecureInt(7, (int) '#');
//        double double8 = randomDataGenerator0.nextChiSquare((double) (short) 100);
//        long long11 = randomDataGenerator0.nextSecureLong(0L, (long) 463846793);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 20 + "'", int6 == 20);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 120.99229539942735d + "'", double8 == 120.99229539942735d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 115907365L + "'", long11 == 115907365L);
//    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable4, (java.lang.Number) (short) -1, objArray9);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable3, objArray9);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable2, objArray9);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException13 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) (-13.019780028987341d), objArray9);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double6 = randomDataImpl2.nextUniform(0.0d, 1012010.0d, false);
        randomDataImpl2.reSeed((long) (short) 0);
        randomDataImpl2.reSeedSecure();
        double double12 = randomDataImpl2.nextGaussian((-2.0d), (double) 44L);
        double double15 = randomDataImpl2.nextGaussian((double) (short) 10, 2.1566593462549586E7d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 328552.22402481775d + "'", double6 == 328552.22402481775d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-3.913170299716576d) + "'", double12 == (-3.913170299716576d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-2.206996926989481E7d) + "'", double15 == (-2.206996926989481E7d));
    }

//    @Test
//    public void test61() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test61");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeedSecure();
//        double double3 = randomDataGenerator0.nextChiSquare(39.525652590500485d);
//        randomDataGenerator0.reSeed();
//        double double6 = randomDataGenerator0.nextExponential(10000.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 36.90519552836964d + "'", double3 == 36.90519552836964d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 13355.267811871645d + "'", double6 == 13355.267811871645d);
//    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeedSecure((long) (short) 0);
        int[] intArray13 = randomDataImpl8.nextPermutation(52, 8);
        randomDataImpl8.reSeed(86L);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        boolean boolean30 = discreteRealDistribution29.isSupportUpperBoundInclusive();
        try {
            double double32 = discreteRealDistribution29.inverseCumulativeProbability(1.6383254778327327d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 1.638 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

//    @Test
//    public void test64() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test64");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
//        well19937c1.setSeed(intArray6);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        java.lang.String str10 = randomDataGenerator8.nextSecureHexString(20);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9284073e6794f017ab14" + "'", str10.equals("9284073e6794f017ab14"));
//    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test65");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        double double77 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray15);
        double[] doubleArray83 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray89 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray90 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray83, doubleArray89);
        double[] doubleArray91 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray15, doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 10001.504886765792d + "'", double77 == 10001.504886765792d);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test66");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 5988793534754658721L);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }
}

