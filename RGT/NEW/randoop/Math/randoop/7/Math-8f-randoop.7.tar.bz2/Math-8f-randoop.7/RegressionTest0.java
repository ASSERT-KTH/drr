import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException6 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) (short) -1, objArray5);
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) notFiniteNumberException6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        try {
            randomDataImpl2.setSecureAlgorithm("", "hi!");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: hi!");
        } catch (java.security.NoSuchProviderException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        try {
            java.lang.String str8 = randomDataImpl2.nextHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection1 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray0, orderDirection1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (byte) 1, objArray1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray12 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        try {
            org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution15 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(doubleArray0, doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        try {
            int int9 = randomDataImpl2.nextZipf(1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: exponent (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException7 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable1, (java.lang.Number) (short) -1, objArray6);
        org.apache.commons.math3.exception.MathInternalError mathInternalError8 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray6);
        try {
            java.lang.String str9 = mathInternalError8.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math3.exception.NullArgumentException();
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        randomDataImpl2.reSeed((long) (-1));
        try {
            double double11 = randomDataImpl2.nextF((-1.0d), (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12);
        double[] doubleArray19 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray25 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray19, doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray12, doubleArray25);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (10,000 >= 100)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1012010.0d + "'", double27 == 1012010.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
        try {
            long long6 = randomDataGenerator0.nextLong((long) 10, 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int5 = randomDataImpl2.nextBinomial((int) (byte) 1, (double) 0);
        try {
            long long7 = randomDataImpl2.nextPoisson(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            double double11 = randomDataImpl8.nextF((double) (short) -1, (double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray26);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection28 = null;
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[][] doubleArray32 = new double[][] { doubleArray29, doubleArray30, doubleArray31 };
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray12, orderDirection28, doubleArray32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (short) 1);
        randomDataGenerator0.reSeed();
        try {
            double double6 = randomDataGenerator0.nextGaussian((double) 0.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
        try {
            long long6 = randomDataGenerator0.nextLong(0L, 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        well19937c1.setSeed(0);
        java.util.ArrayList<org.apache.commons.math3.util.Pair<java.lang.IllegalArgumentException, java.lang.Double>> illegalArgumentExceptionPairList10 = new java.util.ArrayList<org.apache.commons.math3.util.Pair<java.lang.IllegalArgumentException, java.lang.Double>>();
        try {
            org.apache.commons.math3.distribution.DiscreteDistribution<java.lang.IllegalArgumentException> illegalArgumentExceptionDiscreteDistribution11 = new org.apache.commons.math3.distribution.DiscreteDistribution<java.lang.IllegalArgumentException>((org.apache.commons.math3.random.RandomGenerator) well19937c1, (java.util.List<org.apache.commons.math3.util.Pair<java.lang.IllegalArgumentException, java.lang.Double>>) illegalArgumentExceptionPairList10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        byte[] byteArray3 = null;
        try {
            well19937c1.nextBytes(byteArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (short) 1);
        randomDataGenerator0.reSeed();
        try {
            java.lang.String str5 = randomDataGenerator0.nextSecureHexString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math3.exception.NotANumberException notANumberException0 = new org.apache.commons.math3.exception.NotANumberException();
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 1);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 100.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 10001.504886765792d, objArray1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray26);
        double[] doubleArray28 = null;
        try {
            double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray26, doubleArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        try {
            double double32 = discreteRealDistribution29.inverseCumulativeProbability(10001.504886765792d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 10,001.505 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            double double5 = randomDataImpl2.nextWeibull((double) (byte) -1, (double) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        try {
            long long3 = randomDataGenerator0.nextLong((long) (short) 100, (long) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (100) must be strictly less than upper bound (100)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextZipf((int) (short) 1, (-111.1476792949898d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: exponent (-111.148)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextBeta(105.42696159652844d, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.203, 0.797]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        try {
            double double32 = discreteRealDistribution29.cumulativeProbability((double) 1L, (-2.454354035192198d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (1) must be less than or equal to upper endpoint (-2.454)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (short) 1, (int) '4');
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (10,000 >= 100)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (short) 1);
        randomDataGenerator0.reSeed();
        try {
            int int6 = randomDataGenerator0.nextBinomial((int) (short) 0, 10001.504886765792d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 10,001.505 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12);
        org.apache.commons.math3.random.Well19937c well19937c15 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c15.clear();
        double[] doubleArray22 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray28 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray28);
        double[] doubleArray35 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray41 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray35, doubleArray41);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution43 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c15, doubleArray22, doubleArray42);
        boolean boolean44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray12, doubleArray22);
        double[] doubleArray47 = new double[] { (short) 0, (-1L) };
        double[] doubleArray50 = new double[] { (short) 0, (-1L) };
        double[][] doubleArray51 = new double[][] { doubleArray47, doubleArray50 };
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray12, doubleArray51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, (java.lang.Number) 1.0d, false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            int int12 = randomDataGenerator9.nextSecureInt((int) 'a', 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (97) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) (short) -1);
        try {
            int int14 = randomDataImpl8.nextHypergeometric((int) (byte) 1, (int) '#', (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of samples (-1)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 0.0f, 0);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = nonMonotonicSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        double double31 = discreteRealDistribution29.sample();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 100.0d + "'", double31 == 100.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        randomDataImpl2.reSeed((long) (-1));
        try {
            double double10 = randomDataImpl2.nextChiSquare((double) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12);
        org.apache.commons.math3.random.Well19937c well19937c15 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c15.clear();
        double[] doubleArray22 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray28 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray28);
        double[] doubleArray35 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray41 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray35, doubleArray41);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution43 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c15, doubleArray22, doubleArray42);
        boolean boolean44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray12, doubleArray22);
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10001.504886765792d + "'", double45 == 10001.504886765792d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.util.ArrayList<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.NonMonotonicSequenceException, java.lang.Double>> nonMonotonicSequenceExceptionPairList0 = new java.util.ArrayList<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.NonMonotonicSequenceException, java.lang.Double>>();
        try {
            org.apache.commons.math3.distribution.DiscreteDistribution<org.apache.commons.math3.exception.NonMonotonicSequenceException> nonMonotonicSequenceExceptionDiscreteDistribution1 = new org.apache.commons.math3.distribution.DiscreteDistribution<org.apache.commons.math3.exception.NonMonotonicSequenceException>((java.util.List<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.NonMonotonicSequenceException, java.lang.Double>>) nonMonotonicSequenceExceptionPairList0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException2 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, objArray1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        int int3 = randomDataGenerator0.nextInt((int) (byte) -1, (int) (short) 10);
        try {
            double double6 = randomDataGenerator0.nextF(0.30955021719333553d, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            int[] intArray5 = randomDataImpl2.nextPermutation((int) (short) 1, 7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (7) exceeds permuation domain (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            int int12 = randomDataGenerator9.nextZipf(1, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: exponent (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int int5 = randomDataImpl2.nextSecureInt((int) (byte) -1, (int) (byte) 10);
//        java.lang.String str7 = randomDataImpl2.nextSecureHexString(100);
//        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution8 = null;
//        try {
//            int int9 = randomDataImpl2.nextInversionDeviate(integerDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "57bfb52c43fa0d7e992bf12a98050dc5ba0bbbc70f7427bdb597a84118e00348d506d93d6e04aa3730df6551f7615da76fe3" + "'", str7.equals("57bfb52c43fa0d7e992bf12a98050dc5ba0bbbc70f7427bdb597a84118e00348d506d93d6e04aa3730df6551f7615da76fe3"));
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
        java.lang.IllegalStateException illegalStateException33 = discreteRealDistributionPair32.getSecond();
        java.lang.IllegalStateException illegalStateException34 = discreteRealDistributionPair32.getSecond();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertNotNull(illegalStateException33);
        org.junit.Assert.assertNotNull(illegalStateException34);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException6 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) (short) -1, objArray5);
        java.lang.Number number7 = notFiniteNumberException6.getArgument();
        java.lang.Number number8 = notFiniteNumberException6.getArgument();
        org.apache.commons.math3.exception.util.Localizable localizable9 = null;
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        org.apache.commons.math3.exception.util.Localizable localizable12 = null;
        org.apache.commons.math3.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException19 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable13, (java.lang.Number) (short) -1, objArray18);
        org.apache.commons.math3.exception.MathInternalError mathInternalError20 = new org.apache.commons.math3.exception.MathInternalError(localizable12, objArray18);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException21 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable10, (java.lang.Number) 328552.22402481775d, objArray18);
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) notFiniteNumberException6, localizable9, objArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) -1 + "'", number8.equals((short) -1));
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 4L, (-1.0d), 1.0d, 0.0d, (double) 1.0f, (double) 2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-2.0d) + "'", double6 == (-2.0d));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        try {
            double double32 = discreteRealDistribution29.inverseCumulativeProbability((double) 4L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 4 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        well19937c1.clear();
        java.util.ArrayList<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.NumberIsTooLargeException, java.lang.Double>> numberIsTooLargeExceptionPairList4 = new java.util.ArrayList<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.NumberIsTooLargeException, java.lang.Double>>();
        try {
            org.apache.commons.math3.distribution.DiscreteDistribution<org.apache.commons.math3.exception.NumberIsTooLargeException> numberIsTooLargeExceptionDiscreteDistribution5 = new org.apache.commons.math3.distribution.DiscreteDistribution<org.apache.commons.math3.exception.NumberIsTooLargeException>((org.apache.commons.math3.random.RandomGenerator) well19937c1, (java.util.List<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.NumberIsTooLargeException, java.lang.Double>>) numberIsTooLargeExceptionPairList4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 10.0f, objArray1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 0.0f, 0);
        int int4 = nonMonotonicSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        try {
            double double3 = randomDataGenerator0.nextF(0.0d, (double) 1L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int3 = well19937c1.nextInt();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1394374653 + "'", int3 == 1394374653);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 9702.240543161977d, (java.lang.Number) 100.0d, true);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 1, (long) 7);
//        try {
//            double double6 = randomDataImpl0.nextGamma((double) (byte) 1, (-2.0d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-2)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        randomDataImpl2.reSeed((long) (-1));
        try {
            double double11 = randomDataImpl2.nextGamma((double) (byte) 1, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.util.ArrayList<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.NullArgumentException, java.lang.Double>> nullArgumentExceptionPairList0 = new java.util.ArrayList<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.NullArgumentException, java.lang.Double>>();
        try {
            org.apache.commons.math3.distribution.DiscreteDistribution<org.apache.commons.math3.exception.NullArgumentException> nullArgumentExceptionDiscreteDistribution1 = new org.apache.commons.math3.distribution.DiscreteDistribution<org.apache.commons.math3.exception.NullArgumentException>((java.util.List<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.NullArgumentException, java.lang.Double>>) nullArgumentExceptionPairList0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            double double11 = randomDataGenerator8.nextBeta(100.0d, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.124, 0.876]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
//        double double6 = randomDataGenerator0.nextGaussian(10.0d, 105.42696159652844d);
//        try {
//            int int9 = randomDataGenerator0.nextSecureInt(2, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (2) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 80.17420149135377d + "'", double6 == 80.17420149135377d);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray9 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c4.setSeed(intArray9);
        double[] doubleArray16 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray22 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray16, doubleArray22);
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23);
        double[] doubleArray30 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray36 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray30, doubleArray36);
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        org.apache.commons.math3.random.Well19937c well19937c40 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c40.clear();
        double[] doubleArray47 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray53 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray47, doubleArray53);
        double[] doubleArray60 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray66 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray60, doubleArray66);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution68 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c40, doubleArray47, doubleArray67);
        boolean boolean69 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray37, doubleArray47);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution70 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c4, doubleArray24, doubleArray37);
        double[] doubleArray76 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray82 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray83 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray76, doubleArray82);
        double[] doubleArray89 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray95 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray96 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray89, doubleArray95);
        double[] doubleArray97 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray96);
        double double98 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray83, doubleArray97);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution99 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray24, doubleArray83);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertNotNull(doubleArray97);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.0d + "'", double98 == 0.0d);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeed((long) (short) 1);
//        randomDataGenerator0.reSeed();
//        int int6 = randomDataGenerator0.nextSecureInt(7, (int) '#');
//        try {
//            double double9 = randomDataGenerator0.nextF((double) '4', 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 27 + "'", int6 == 27);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 100);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        double double8 = randomDataImpl2.nextChiSquare((double) 100);
        int int12 = randomDataImpl2.nextHypergeometric((int) 'a', 0, 10);
        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution13 = null;
        try {
            int int14 = randomDataImpl2.nextInversionDeviate(integerDistribution13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 105.42696159652844d + "'", double8 == 105.42696159652844d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int int5 = randomDataImpl2.nextSecureInt((int) (byte) -1, (int) (byte) 10);
//        try {
//            double double8 = randomDataImpl2.nextWeibull((double) (short) 100, (double) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-1)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
        java.lang.String str1 = mathInternalError0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH" + "'", str1.equals("org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) (short) 1);
//        double double5 = randomDataImpl0.nextBeta((double) 10.0f, (double) '4');
//        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution6 = null;
//        try {
//            int int7 = randomDataImpl0.nextInversionDeviate(integerDistribution6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.13379287940895715d + "'", double5 == 0.13379287940895715d);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0d, (java.lang.Number) (byte) 100, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double0 = org.apache.commons.math3.distribution.AbstractRealDistribution.SOLVER_DEFAULT_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-6d + "'", double0 == 1.0E-6d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.0013733592917636712d, (java.lang.Number) 1.0d, false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(105.42696159652844d, (double) (-1L), (-1.0d), 1.0d, (double) (-1.0f), 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-106.42696159652844d) + "'", double6 == (-106.42696159652844d));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double32 = discreteRealDistribution29.cumulativeProbability((double) 0, 0.0013733592917636712d);
        boolean boolean33 = discreteRealDistribution29.isSupportLowerBoundInclusive();
        boolean boolean34 = discreteRealDistribution29.isSupportUpperBoundInclusive();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(10000.0d, 105.42696159652844d, (double) 100L, (double) 0, 9702.240543161977d, 0.0d, 0.0d, (double) 0.23953891f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1054269.6159652844d + "'", double8 == 1054269.6159652844d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        well19937c1.clear();
        int[] intArray7 = new int[] { (short) 0, 7, ' ' };
        well19937c1.setSeed(intArray7);
        java.util.ArrayList<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalArgumentException, java.lang.Double>> mathIllegalArgumentExceptionPairList9 = new java.util.ArrayList<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalArgumentException, java.lang.Double>>();
        try {
            org.apache.commons.math3.distribution.DiscreteDistribution<org.apache.commons.math3.exception.MathIllegalArgumentException> mathIllegalArgumentExceptionDiscreteDistribution10 = new org.apache.commons.math3.distribution.DiscreteDistribution<org.apache.commons.math3.exception.MathIllegalArgumentException>((org.apache.commons.math3.random.RandomGenerator) well19937c1, (java.util.List<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalArgumentException, java.lang.Double>>) mathIllegalArgumentExceptionPairList9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (byte) 1, (int) '#');
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int int5 = randomDataImpl2.nextSecureInt((int) (byte) -1, (int) (byte) 10);
//        try {
//            double double7 = randomDataImpl2.nextT((double) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-1)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray15 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray21 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray15, doubleArray21);
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22);
        org.apache.commons.math3.random.Well19937c well19937c25 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c25.clear();
        double[] doubleArray32 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray38 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray32, doubleArray38);
        double[] doubleArray45 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray51 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray52 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray45, doubleArray51);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution53 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c25, doubleArray32, doubleArray52);
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray22, doubleArray32);
        org.apache.commons.math3.random.Well19937c well19937c56 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c56.clear();
        double[] doubleArray63 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray69 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray63, doubleArray69);
        double[] doubleArray76 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray82 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray83 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray76, doubleArray82);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution84 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c56, doubleArray63, doubleArray83);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution85 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray22, doubleArray83);
        double[] doubleArray87 = new double[] { (-2.454354035192198d) };
        double[] doubleArray89 = new double[] { (-2.454354035192198d) };
        double[][] doubleArray90 = new double[][] { doubleArray87, doubleArray89 };
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray22, doubleArray90);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure();
        try {
            int[] intArray4 = randomDataGenerator0.nextPermutation((int) (short) 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (0");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
        try {
            java.lang.String str5 = randomDataGenerator0.nextHexString((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray12 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.random.Well19937c well19937c16 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c16.clear();
        double[] doubleArray23 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray29 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray23, doubleArray29);
        double[] doubleArray36 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray42 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray36, doubleArray42);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution44 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c16, doubleArray23, doubleArray43);
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray13, doubleArray23);
        try {
            double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray0, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        discreteRealDistribution76.reseedRandomGenerator((long) 'a');
        double double81 = discreteRealDistribution76.cumulativeProbability((double) 0.32465303f, 9900.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.03006789524733269d + "'", double81 == 0.03006789524733269d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double[] doubleArray5 = new double[] { (byte) 1, (-2.454354035192198d), ' ', 100L, 100.0f };
        double[] doubleArray11 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray17 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray11, doubleArray17);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray5, doubleArray18);
        org.apache.commons.math3.random.Well19937c well19937c22 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl23 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c22);
        double[] doubleArray29 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray35 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray29, doubleArray35);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36);
        org.apache.commons.math3.random.Well19937c well19937c39 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c39.clear();
        double[] doubleArray46 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray52 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray46, doubleArray52);
        double[] doubleArray59 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray65 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray66 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray59, doubleArray65);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution67 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c39, doubleArray46, doubleArray66);
        boolean boolean68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray36, doubleArray46);
        double[] doubleArray74 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray80 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray81 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray74, doubleArray80);
        double[] doubleArray87 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray93 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray94 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray87, doubleArray93);
        double[] doubleArray95 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray94);
        double double96 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray81, doubleArray95);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution97 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c22, doubleArray36, doubleArray81);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution98 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(doubleArray5, doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.Well19937c well19937c9 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c9);
        int[] intArray14 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c9.setSeed(intArray14);
        double double16 = org.apache.commons.math3.util.MathArrays.distance(intArray6, intArray14);
        int[] intArray18 = org.apache.commons.math3.util.MathArrays.copyOf(intArray14, (int) 'a');
        org.apache.commons.math3.random.Well19937c well19937c20 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c20);
        well19937c20.clear();
        int[] intArray26 = new int[] { (short) 0, 7, ' ' };
        well19937c20.setSeed(intArray26);
        try {
            double double28 = org.apache.commons.math3.util.MathArrays.distance(intArray18, intArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray26);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        double double2 = randomDataGenerator0.nextT((double) (short) 10);
//        double double4 = randomDataGenerator0.nextChiSquare((double) 0.23953891f);
//        try {
//            int int7 = randomDataGenerator0.nextBinomial(1394374653, 2132.4513068180036d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 2,132.451 out of [0, 1] range");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.2881460014486376d) + "'", double2 == (-0.2881460014486376d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.6590161101130382E-5d + "'", double4 == 2.6590161101130382E-5d);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        java.lang.Class<?> wildcardClass3 = randomDataImpl2.getClass();
        double double6 = randomDataImpl2.nextGamma((double) 5, 10001.504886765792d);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 38384.253589064254d + "'", double6 == 38384.253589064254d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            int int5 = randomDataImpl2.nextInt((int) '4', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (52) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double[] doubleArray5 = new double[] { (byte) 1, (-2.454354035192198d), ' ', 100L, 100.0f };
        double[] doubleArray11 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray17 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray11, doubleArray17);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray5, doubleArray18);
        org.apache.commons.math3.random.Well19937c well19937c22 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl23 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c22);
        double[] doubleArray29 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray35 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray29, doubleArray35);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36);
        org.apache.commons.math3.random.Well19937c well19937c39 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c39.clear();
        double[] doubleArray46 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray52 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray46, doubleArray52);
        double[] doubleArray59 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray65 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray66 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray59, doubleArray65);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution67 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c39, doubleArray46, doubleArray66);
        boolean boolean68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray36, doubleArray46);
        double[] doubleArray74 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray80 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray81 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray74, doubleArray80);
        double[] doubleArray87 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray93 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray94 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray87, doubleArray93);
        double[] doubleArray95 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray94);
        double double96 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray81, doubleArray95);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution97 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c22, doubleArray36, doubleArray81);
        double double98 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray36);
        double[] doubleArray99 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray20, doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 10001.504886765792d + "'", double98 == 10001.504886765792d);
        org.junit.Assert.assertNotNull(doubleArray99);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeedSecure((long) (short) 0);
        double double12 = randomDataImpl8.nextChiSquare(97.2065955383123d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 81.35173968711932d + "'", double12 == 81.35173968711932d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        randomDataImpl2.reSeed((long) (-1));
        try {
            int[] intArray11 = randomDataImpl2.nextPermutation((int) (byte) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (0");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            double double11 = randomDataGenerator8.nextGamma((double) 8, (-2.253205282766861d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-2.253)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
        try {
            java.lang.String str5 = randomDataGenerator0.nextSecureHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection33 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException35 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection33, false);
        try {
            boolean boolean38 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray8, orderDirection33, false, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not increasing (100 > 10)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection33.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double6 = randomDataImpl2.nextUniform(0.0d, 1012010.0d, false);
        try {
            long long8 = randomDataImpl2.nextPoisson((double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 328552.22402481775d + "'", double6 == 328552.22402481775d);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeed((long) (short) 1);
//        randomDataGenerator0.reSeed();
//        double double5 = randomDataGenerator0.nextChiSquare((double) 7);
//        try {
//            double double8 = randomDataGenerator0.nextGamma(3.136469916217921d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.3977595102571936d + "'", double5 == 2.3977595102571936d);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int int5 = randomDataImpl2.nextSecureInt((int) (byte) -1, (int) (byte) 10);
//        try {
//            randomDataImpl2.setSecureAlgorithm("org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH", "d46543f007103015639091102cf419ed924aa9f7cd876c5941f8b7822b22c47eeefb3d15633b49bb034e27fe6a3d14f76f5b");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: d46543f007103015639091102cf419ed924aa9f7cd876c5941f8b7822b22c47eeefb3d15633b49bb034e27fe6a3d14f76f5b");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
        try {
            int int6 = randomDataGenerator0.nextZipf((int) (byte) 0, (double) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: dimension (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getNumericalMean();
        try {
            double double33 = discreteRealDistribution29.cumulativeProbability(1.327000036267693d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (1.327) must be less than or equal to upper endpoint (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 97.2065955383123d + "'", double30 == 97.2065955383123d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double[] doubleArray2 = new double[] { 328552.22402481775d, (-2.454354035192198d) };
        double[] doubleArray7 = new double[] { '4', 10L, (-1L), 31.931273192771652d };
        double[] doubleArray12 = new double[] { '4', 10L, (-1L), 31.931273192771652d };
        double[] doubleArray17 = new double[] { '4', 10L, (-1L), 31.931273192771652d };
        double[] doubleArray22 = new double[] { '4', 10L, (-1L), 31.931273192771652d };
        double[] doubleArray27 = new double[] { '4', 10L, (-1L), 31.931273192771652d };
        double[] doubleArray32 = new double[] { '4', 10L, (-1L), 31.931273192771652d };
        double[][] doubleArray33 = new double[][] { doubleArray7, doubleArray12, doubleArray17, doubleArray22, doubleArray27, doubleArray32 };
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray2, doubleArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        try {
            double double32 = discreteRealDistribution29.probability((double) 5, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (5) must be less than or equal to upper endpoint (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        discreteRealDistribution76.reseedRandomGenerator((long) 'a');
        double double79 = discreteRealDistribution76.getSupportUpperBound();
        try {
            double double82 = discreteRealDistribution76.probability((double) 10.0f, 0.32465313981563204d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (10) must be less than or equal to upper endpoint (0.325)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 10000.0d + "'", double79 == 10000.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) (-1.0d));
        try {
            java.lang.String str3 = notPositiveException2.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeedSecure((long) (short) 0);
        try {
            int int13 = randomDataImpl8.nextBinomial((int) 'a', (double) 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 2 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        discreteRealDistribution76.reseedRandomGenerator((long) 'a');
        double double79 = discreteRealDistribution76.getSupportUpperBound();
        double double81 = discreteRealDistribution76.probability(10.0d);
        double double82 = discreteRealDistribution76.getNumericalVariance();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 10000.0d + "'", double79 == 10000.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 9.699321047526673E-4d + "'", double81 == 9.699321047526673E-4d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 2860029.9945153743d + "'", double82 == 2860029.9945153743d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (short) 0, 0.03006789524733269d, 9.699321047526673E-4d, (double) 100L, 1.327000036267693d, 42.23873472118208d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 56.14779571738535d + "'", double6 == 56.14779571738535d);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) (short) 1);
//        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution3 = null;
//        try {
//            int int4 = randomDataImpl0.nextInversionDeviate(integerDistribution3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "d" + "'", str2.equals("d"));
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, (double) 0.32465303f, 9702.240543161977d, 2860029.9945153743d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.7748698967446392E10d + "'", double4 == 2.7748698967446392E10d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeedSecure((long) (short) 0);
        try {
            double double13 = randomDataImpl8.nextBeta((-2.253205282766861d), 328552.22402481775d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.124, 0.876]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
//        well19937c1.setSeed(intArray6);
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        java.lang.String str10 = randomDataImpl8.nextSecureHexString((int) '4');
//        try {
//            randomDataImpl8.setSecureAlgorithm("bf5d6b565d89034d60a2c1e58714a953c3cc5fcd57e0b2941d4f", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "dc08298499c820ecdb9c2254bcf6e5e76ab76dcbf6a9b6400362" + "'", str10.equals("dc08298499c820ecdb9c2254bcf6e5e76ab76dcbf6a9b6400362"));
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        double double8 = randomDataImpl2.nextChiSquare((double) 100);
        try {
            int[] intArray11 = randomDataImpl2.nextPermutation(2, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (35) exceeds permuation domain (2)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 105.42696159652844d + "'", double8 == 105.42696159652844d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        discreteRealDistribution76.reseedRandomGenerator((long) 'a');
        double double79 = discreteRealDistribution76.getNumericalMean();
        boolean boolean80 = discreteRealDistribution76.isSupportUpperBoundInclusive();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 9702.240543161977d + "'", double79 == 9702.240543161977d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double6 = randomDataImpl2.nextUniform(0.0d, 1012010.0d, false);
        try {
            double double8 = randomDataImpl2.nextChiSquare((-2.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 328552.22402481775d + "'", double6 == 328552.22402481775d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.String[] strArray0 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection1 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray0, orderDirection1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection0 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.junit.Assert.assertTrue("'" + orderDirection0 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection0.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) (short) 1);
//        try {
//            int int5 = randomDataImpl0.nextZipf(2, (double) (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: exponent (-1)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5" + "'", str2.equals("5"));
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException3 = new org.apache.commons.math3.exception.NullArgumentException();
        double[] doubleArray9 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray15 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray9, doubleArray15);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        double[] doubleArray23 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray29 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray23, doubleArray29);
        double double31 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray16, doubleArray29);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator32 = new org.apache.commons.math3.random.RandomDataGenerator();
        java.lang.Object[] objArray33 = new java.lang.Object[] { nullArgumentException3, doubleArray16, randomDataGenerator32 };
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException34 = new org.apache.commons.math3.exception.NullArgumentException(localizable2, objArray33);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException35 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (short) 0, objArray33);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray33);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1012010.0d + "'", double31 == 1012010.0d);
        org.junit.Assert.assertNotNull(objArray33);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray0, 10000.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (short) 1);
        double double5 = randomDataGenerator0.nextUniform((-2.454354035192198d), 0.30955021719333553d);
        try {
            long long8 = randomDataGenerator0.nextLong(10L, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10) must be strictly less than upper bound (-1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2.253205282766861d) + "'", double5 == (-2.253205282766861d));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "dc4f4680c5", "bf5d6b565d89034d60a2c1e58714a953c3cc5fcd57e0b2941d4f", "c39dd38938158ec0325d4b570b1279568415f6d97be5a999ef8646e3427abb03e4da1bc8c9527b7d8585296d78f68f051362", "5661f406fb", "9" };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = null;
        try {
            boolean boolean9 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray6, orderDirection7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double[] doubleArray0 = null;
        org.apache.commons.math3.random.Well19937c well19937c2 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c2);
        double[] doubleArray9 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray15 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray9, doubleArray15);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        org.apache.commons.math3.random.Well19937c well19937c19 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c19.clear();
        double[] doubleArray26 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray32 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray26, doubleArray32);
        double[] doubleArray39 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray45 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray45);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c19, doubleArray26, doubleArray46);
        boolean boolean48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray16, doubleArray26);
        double[] doubleArray54 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray60 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray54, doubleArray60);
        double[] doubleArray67 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray73 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray67, doubleArray73);
        double[] doubleArray75 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray74);
        double double76 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray61, doubleArray75);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution77 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c2, doubleArray16, doubleArray61);
        try {
            double[] doubleArray78 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray0, doubleArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) (short) -1);
        try {
            double double13 = randomDataImpl8.nextCauchy(39.525652590500485d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(number0, (java.lang.Number) 73.92695241609769d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) (short) 1);
//        try {
//            randomDataImpl0.setSecureAlgorithm("0", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
//        double double6 = randomDataGenerator0.nextGaussian(10.0d, 105.42696159652844d);
//        double double9 = randomDataGenerator0.nextBeta(10.0d, 10000.0d);
//        try {
//            double double12 = randomDataGenerator0.nextUniform((double) 1.0f, 0.012586043473500211d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1) must be strictly less than upper bound (0.013)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 85.54308956212783d + "'", double6 == 85.54308956212783d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0014712139897699276d + "'", double9 == 0.0014712139897699276d);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = well19937c1.nextGaussian();
        byte[] byteArray31 = null;
        try {
            well19937c1.nextBytes(byteArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-0.40892891016592103d) + "'", double30 == (-0.40892891016592103d));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (short) 1);
        int int6 = randomDataGenerator0.nextHypergeometric(99, (int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double[] doubleArray5 = new double[] { (byte) 1, (-2.454354035192198d), ' ', 100L, 100.0f };
        double[] doubleArray11 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray17 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray11, doubleArray17);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray5, doubleArray18);
        double[] doubleArray26 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray32 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray26, doubleArray32);
        double[] doubleArray39 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray45 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray45);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray46);
        double double48 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray33, doubleArray47);
        double[] doubleArray54 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray60 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray54, doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray61);
        double[] doubleArray68 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray74 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray68, doubleArray74);
        double double76 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray61, doubleArray74);
        double double77 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray47, doubleArray74);
        boolean boolean78 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray18, doubleArray47);
        java.lang.Class<?> wildcardClass79 = doubleArray18.getClass();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1012010.0d + "'", double76 == 1012010.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 9900.0d + "'", double77 == 9900.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(wildcardClass79);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (byte) 1, (int) '4');
        int int4 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeedSecure();
//        double double3 = randomDataGenerator0.nextChiSquare(39.525652590500485d);
//        try {
//            long long6 = randomDataGenerator0.nextLong(1L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.48102088161268d + "'", double3 == 35.48102088161268d);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        boolean boolean77 = discreteRealDistribution76.isSupportUpperBoundInclusive();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        well19937c1.setSeed((int) (short) 10);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (short) 1);
        double double5 = randomDataGenerator0.nextUniform((-2.454354035192198d), 0.30955021719333553d);
        try {
            int int8 = randomDataGenerator0.nextSecureInt(1394374653, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,394,374,653) must be strictly less than upper bound (10)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2.253205282766861d) + "'", double5 == (-2.253205282766861d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 0.0013733592917636712d };
        double[] doubleArray4 = new double[] { 0.0013733592917636712d };
        double[] doubleArray6 = new double[] { 0.0013733592917636712d };
        double[] doubleArray8 = new double[] { 0.0013733592917636712d };
        double[] doubleArray10 = new double[] { 0.0013733592917636712d };
        double[] doubleArray12 = new double[] { 0.0013733592917636712d };
        double[][] doubleArray13 = new double[][] { doubleArray2, doubleArray4, doubleArray6, doubleArray8, doubleArray10, doubleArray12 };
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray0, doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        float[] floatArray3 = new float[] { (short) 1, 100.0f, '4' };
        float[] floatArray4 = null;
        float[] floatArray6 = new float[] { 100.0f };
        float[] floatArray11 = new float[] { (-1), (-1L), (byte) 1, 10L };
        boolean boolean12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray6, floatArray11);
        boolean boolean13 = org.apache.commons.math3.util.MathArrays.equals(floatArray4, floatArray6);
        float[] floatArray15 = new float[] { 100.0f };
        float[] floatArray20 = new float[] { (-1), (-1L), (byte) 1, 10L };
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray15, floatArray20);
        boolean boolean22 = org.apache.commons.math3.util.MathArrays.equals(floatArray6, floatArray20);
        float[] floatArray23 = null;
        float[] floatArray25 = new float[] { 100.0f };
        float[] floatArray30 = new float[] { (-1), (-1L), (byte) 1, 10L };
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray25, floatArray30);
        boolean boolean32 = org.apache.commons.math3.util.MathArrays.equals(floatArray23, floatArray25);
        boolean boolean33 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray6, floatArray23);
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.equals(floatArray3, floatArray23);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int int5 = randomDataImpl2.nextSecureInt((int) (byte) -1, (int) (byte) 10);
//        java.lang.String str7 = randomDataImpl2.nextSecureHexString(100);
//        randomDataImpl2.reSeed();
//        try {
//            long long11 = randomDataImpl2.nextSecureLong((long) 19, (long) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (19) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "e7f0e2b8682ad87af7904be598050080ff29ec85366a635c2f4dfe90bd515533642a211600ab827509722897927686436fb9" + "'", str7.equals("e7f0e2b8682ad87af7904be598050080ff29ec85366a635c2f4dfe90bd515533642a211600ab827509722897927686436fb9"));
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 100);
        org.apache.commons.math3.util.Pair<java.lang.CharSequence, org.apache.commons.math3.exception.DimensionMismatchException> charSequencePair4 = new org.apache.commons.math3.util.Pair<java.lang.CharSequence, org.apache.commons.math3.exception.DimensionMismatchException>((java.lang.CharSequence) "6", dimensionMismatchException3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        long[] longArray5 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray10 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray15 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray20 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray25 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray30 = new long[] { 10, 100, 0L, (byte) 10 };
        long[][] longArray31 = new long[][] { longArray5, longArray10, longArray15, longArray20, longArray25, longArray30 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray31);
        org.apache.commons.math3.exception.MathInternalError mathInternalError33 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) longArray31);
        java.lang.Throwable[] throwableArray34 = mathInternalError33.getSuppressed();
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertNotNull(longArray31);
        org.junit.Assert.assertNotNull(throwableArray34);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextInt((int) (byte) -1, (int) (short) 10);
//        java.lang.String str5 = randomDataGenerator0.nextHexString((int) (byte) 10);
//        double double8 = randomDataGenerator0.nextCauchy(9.347883475356515d, 26.56353953166036d);
//        randomDataGenerator0.reSeed();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a50dd5f0e9" + "'", str5.equals("a50dd5f0e9"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9.164146516064406d + "'", double8 == 9.164146516064406d);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 0, (java.lang.Number) (short) 100, (int) (byte) 0);
        int int4 = nonMonotonicSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonicSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
        java.lang.IllegalStateException illegalStateException33 = discreteRealDistributionPair32.getSecond();
        org.apache.commons.math3.exception.MathInternalError mathInternalError34 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) illegalStateException33);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertNotNull(illegalStateException33);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray26);
        double[] doubleArray33 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray39 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray33, doubleArray39);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40);
        double[] doubleArray47 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray53 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray47, doubleArray53);
        double double55 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray40, doubleArray53);
        double double56 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray26, doubleArray53);
        double[] doubleArray62 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray68 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray62, doubleArray68);
        double[] doubleArray75 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray81 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray82 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray75, doubleArray81);
        double[] doubleArray83 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray82);
        double double84 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray69, doubleArray83);
        double double85 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray83);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution86 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(doubleArray26, doubleArray83);
        double double87 = discreteRealDistribution86.getSupportUpperBound();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1012010.0d + "'", double55 == 1012010.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 9900.0d + "'", double56 == 9900.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 10001.504886765792d + "'", double85 == 10001.504886765792d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 10000.0d + "'", double87 == 10000.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray6 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c1.setSeed(intArray6);
        double[] doubleArray13 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray19 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray13, doubleArray19);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray33 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray27, doubleArray33);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34);
        org.apache.commons.math3.random.Well19937c well19937c37 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c37.clear();
        double[] doubleArray44 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray50 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray44, doubleArray50);
        double[] doubleArray57 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray63 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray57, doubleArray63);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution65 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c37, doubleArray44, doubleArray64);
        boolean boolean66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray34, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution67 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray21, doubleArray34);
        double[] doubleArray68 = null;
        try {
            double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray34, doubleArray68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0d, (java.lang.Number) (byte) 100, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getArgument();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0d + "'", number5.equals(1.0d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 100 + "'", number6.equals((byte) 100));
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextInt((int) (byte) -1, (int) (short) 10);
//        try {
//            long long6 = randomDataGenerator0.nextLong((long) 1, (long) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) '#');
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeed((long) (short) 1);
//        long long5 = randomDataGenerator0.nextSecureLong(10L, 64L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 38L + "'", long5 == 38L);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataGenerator9.reSeedSecure((long) 7);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        double double32 = discreteRealDistribution29.density((double) (short) 0);
        discreteRealDistribution29.reseedRandomGenerator((long) 8);
        try {
            double double37 = discreteRealDistribution29.probability(10001.504886765792d, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (10,001.505) must be less than or equal to upper endpoint (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        boolean boolean30 = discreteRealDistribution29.isSupportUpperBoundInclusive();
        double double32 = discreteRealDistribution29.inverseCumulativeProbability(0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (byte) 1, 3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12);
        double[] doubleArray19 = new double[] { (byte) 1, (-2.454354035192198d), ' ', 100L, 100.0f };
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32);
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray32);
        double[] doubleArray40 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray46 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray46);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double double62 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray47, doubleArray61);
        double[] doubleArray68 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray74 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray68, doubleArray74);
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray75);
        double[] doubleArray82 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray88 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray89 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray82, doubleArray88);
        double double90 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray75, doubleArray88);
        double double91 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray61, doubleArray88);
        double[] doubleArray92 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray32, doubleArray88);
        double double93 = org.apache.commons.math3.util.MathArrays.distance(doubleArray13, doubleArray88);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (10,000 >= 100)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 1012010.0d + "'", double90 == 1012010.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 9900.0d + "'", double91 == 9900.0d);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 9900.822238582006d + "'", double93 == 9900.822238582006d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        long[] longArray7 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray12 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray17 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray22 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray27 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray32 = new long[] { 10, 100, 0L, (byte) 10 };
        long[][] longArray33 = new long[][] { longArray7, longArray12, longArray17, longArray22, longArray27, longArray32 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray33);
        org.apache.commons.math3.exception.MathInternalError mathInternalError35 = new org.apache.commons.math3.exception.MathInternalError(localizable2, (java.lang.Object[]) longArray33);
        org.apache.commons.math3.exception.MathInternalError mathInternalError36 = new org.apache.commons.math3.exception.MathInternalError(localizable1, (java.lang.Object[]) longArray33);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException37 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (-1), (java.lang.Object[]) longArray33);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray32);
        org.junit.Assert.assertNotNull(longArray33);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int int5 = randomDataImpl2.nextSecureInt((int) (byte) -1, (int) (byte) 10);
//        java.lang.String str7 = randomDataImpl2.nextSecureHexString(100);
//        randomDataImpl2.reSeed();
//        try {
//            randomDataImpl2.setSecureAlgorithm("", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "285d7808f801d1f1fd17ae9abf8c257f98dd6def55b4696cd2a8de42ea13d48a8ed637a33c1b35eae71e18d0008180a563b2" + "'", str7.equals("285d7808f801d1f1fd17ae9abf8c257f98dd6def55b4696cd2a8de42ea13d48a8ed637a33c1b35eae71e18d0008180a563b2"));
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray6 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c1.setSeed(intArray6);
        double[] doubleArray13 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray19 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray13, doubleArray19);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray33 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray27, doubleArray33);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34);
        org.apache.commons.math3.random.Well19937c well19937c37 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c37.clear();
        double[] doubleArray44 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray50 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray44, doubleArray50);
        double[] doubleArray57 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray63 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray57, doubleArray63);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution65 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c37, doubleArray44, doubleArray64);
        boolean boolean66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray34, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution67 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray21, doubleArray34);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (10,000 >= 100)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        randomDataImpl2.reSeed((long) (-1));
        double double10 = randomDataImpl2.nextChiSquare((double) 1L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.09294902424688352d + "'", double10 == 0.09294902424688352d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        long[] longArray5 = new long[] { (short) -1, '4', 1, 25, ' ' };
        try {
            org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException8 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable2, (java.lang.Number) (short) -1, objArray7);
        org.apache.commons.math3.exception.MathInternalError mathInternalError9 = new org.apache.commons.math3.exception.MathInternalError(localizable1, objArray7);
        org.apache.commons.math3.exception.MathInternalError mathInternalError10 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray7);
        org.junit.Assert.assertNotNull(objArray7);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        well19937c1.clear();
//        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
//        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
//        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
//        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
//        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
//        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
//        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
//        double double30 = discreteRealDistribution29.getSupportUpperBound();
//        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
//        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
//        java.lang.IllegalStateException illegalStateException33 = discreteRealDistributionPair32.getSecond();
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator34 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int37 = randomDataGenerator34.nextZipf((int) (short) 10, (double) ' ');
//        double double40 = randomDataGenerator34.nextGaussian(10.0d, 105.42696159652844d);
//        int int43 = randomDataGenerator34.nextBinomial(0, (double) (byte) 1);
//        boolean boolean44 = discreteRealDistributionPair32.equals((java.lang.Object) (byte) 1);
//        java.lang.IllegalStateException illegalStateException45 = discreteRealDistributionPair32.getSecond();
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertNotNull(doubleArray15);
//        org.junit.Assert.assertNotNull(doubleArray21);
//        org.junit.Assert.assertNotNull(doubleArray27);
//        org.junit.Assert.assertNotNull(doubleArray28);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
//        org.junit.Assert.assertNotNull(illegalStateException33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + double40 + "' != '" + (-13.019780028987341d) + "'", double40 == (-13.019780028987341d));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(illegalStateException45);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            int int11 = randomDataImpl8.nextInt(100, 25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (100) must be strictly less than upper bound (25)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) (short) 1);
//        double double5 = randomDataImpl0.nextBeta((double) 10.0f, (double) '4');
//        try {
//            int int9 = randomDataImpl0.nextHypergeometric((int) (short) 1, (int) (byte) 0, 1394374653);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: sample size (1,394,374,653) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7" + "'", str2.equals("7"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.1996679961610914d + "'", double5 == 0.1996679961610914d);
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
//        double double6 = randomDataGenerator0.nextGaussian(10.0d, 105.42696159652844d);
//        long long9 = randomDataGenerator0.nextLong(1L, (long) 1394374653);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-85.89091474851703d) + "'", double6 == (-85.89091474851703d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1220434243L + "'", long9 == 1220434243L);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        well19937c1.clear();
        double double4 = well19937c1.nextDouble();
        float float5 = well19937c1.nextFloat();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.32465313981563204d + "'", double4 == 0.32465313981563204d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.6642053f + "'", float5 == 0.6642053f);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) (short) 1);
//        double double5 = randomDataImpl0.nextBeta((double) 10.0f, (double) '4');
//        try {
//            double double8 = randomDataImpl0.nextWeibull(44.70805190104936d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9" + "'", str2.equals("9"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.12407281425247228d + "'", double5 == 0.12407281425247228d);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (byte) 1, (int) '4');
        java.lang.Number number4 = dimensionMismatchException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1 + "'", number4.equals(1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray26);
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray26);
        double[] doubleArray32 = new double[] { (-1L), 39.525652590500485d, 0.32933264825411424d };
        double[][] doubleArray33 = new double[][] { doubleArray32 };
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray26, doubleArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10001.504886765792d + "'", double28 == 10001.504886765792d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        double double32 = discreteRealDistribution29.density((double) (short) 0);
        double double35 = discreteRealDistribution29.cumulativeProbability(0.0d, 9.699321047526673E-4d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double6 = randomDataImpl2.nextUniform(0.0d, 1012010.0d, false);
        randomDataImpl2.reSeed((long) (short) 0);
        randomDataImpl2.reSeedSecure();
        try {
            double double12 = randomDataImpl2.nextGaussian(1.0E-6d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 328552.22402481775d + "'", double6 == 328552.22402481775d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 0, (java.lang.Number) (short) 100, (int) (byte) 0);
        int int4 = nonMonotonicSequenceException3.getIndex();
        int int5 = nonMonotonicSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray12, (double) '#');
        double[] doubleArray21 = new double[] { 0.1845842603151447d, 0, 10.0f, 42.63446096761888d, 10.0d, 2132.4513068180036d };
        try {
            double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray12, doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 9900.822238582006d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (short) 1);
        double double5 = randomDataGenerator0.nextUniform((-2.454354035192198d), 0.30955021719333553d);
        double double7 = randomDataGenerator0.nextT((double) '#');
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2.253205282766861d) + "'", double5 == (-2.253205282766861d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.42978164783246015d) + "'", double7 == (-0.42978164783246015d));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (short) 1);
        long long4 = randomDataGenerator0.nextPoisson(0.12362632919669392d);
        int int7 = randomDataGenerator0.nextInt(0, (int) (short) 10);
        double double11 = randomDataGenerator0.nextUniform(9.347883475356515d, 2.7748698967446392E10d, false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.6737939463871254E10d + "'", double11 == 2.6737939463871254E10d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        boolean boolean30 = discreteRealDistribution29.isSupportLowerBoundInclusive();
        try {
            double double32 = discreteRealDistribution29.inverseCumulativeProbability(9702.240543161977d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 9,702.241 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
//        double double6 = randomDataGenerator0.nextGaussian(10.0d, 105.42696159652844d);
//        try {
//            int int9 = randomDataGenerator0.nextInt(1394374653, 35);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,394,374,653) must be strictly less than upper bound (35)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 50.85753565059901d + "'", double6 == 50.85753565059901d);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        double double8 = randomDataImpl2.nextChiSquare((double) 100);
        int int11 = randomDataImpl2.nextInt(0, (int) ' ');
        try {
            double double13 = randomDataImpl2.nextExponential((double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 105.42696159652844d + "'", double8 == 105.42696159652844d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double6 = randomDataImpl2.nextUniform(0.0d, 1012010.0d, false);
        double double9 = randomDataImpl2.nextCauchy(38384.253589064254d, 1.327000036267693d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 328552.22402481775d + "'", double6 == 328552.22402481775d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 38385.006112067575d + "'", double9 == 38385.006112067575d);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeedSecure();
//        double double3 = randomDataGenerator0.nextChiSquare(39.525652590500485d);
//        int int6 = randomDataGenerator0.nextSecureInt((int) (byte) -1, 0);
//        double double9 = randomDataGenerator0.nextWeibull((double) 0.23953891f, (double) 10L);
//        try {
//            randomDataGenerator0.setSecureAlgorithm("dc4f4680c5", "dc4f4680c5");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: dc4f4680c5");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 42.83341744446164d + "'", double3 == 42.83341744446164d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.051718084425754665d + "'", double9 == 0.051718084425754665d);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray26);
        double[] doubleArray33 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray39 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray33, doubleArray39);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40);
        double[] doubleArray47 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray53 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray47, doubleArray53);
        double double55 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray40, doubleArray53);
        double double56 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray26, doubleArray53);
        double[] doubleArray62 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray68 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray62, doubleArray68);
        double[] doubleArray75 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray81 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray82 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray75, doubleArray81);
        double[] doubleArray83 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray82);
        double double84 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray69, doubleArray83);
        double double85 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray83);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution86 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(doubleArray26, doubleArray83);
        double[] doubleArray87 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray83);
        double[] doubleArray89 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray87, (int) (byte) 100);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray87);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (10,000 >= 100)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1012010.0d + "'", double55 == 1012010.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 9900.0d + "'", double56 == 9900.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 10001.504886765792d + "'", double85 == 10001.504886765792d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0, 42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-244.6200608197496d), (java.lang.Number) 138.07687005673318d, true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (short) 10, 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (int) (byte) 0);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        double double8 = randomDataImpl2.nextT(0.09294902424688352d);
        try {
            double double10 = randomDataImpl2.nextExponential((-9.304958371878295E7d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-93,049,583.719)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 11.446697401807153d + "'", double8 == 11.446697401807153d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        discreteRealDistribution76.reseedRandomGenerator((long) 'a');
        double double79 = discreteRealDistribution76.getSupportUpperBound();
        boolean boolean80 = discreteRealDistribution76.isSupportUpperBoundInclusive();
        try {
            double[] doubleArray82 = discreteRealDistribution76.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of samples (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 10000.0d + "'", double79 == 10000.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            double double11 = randomDataGenerator8.nextUniform(9.699321047526673E-4d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0.001) must be strictly less than upper bound (-1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 4L, 38385.006112067575d, 138.07687005673318d, (double) 100, 0.15305822040981495d, (double) '4', 0.0d, (-0.5660023684082577d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 167355.67048140493d + "'", double8 == 167355.67048140493d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double9 = well19937c1.nextGaussian();
        well19937c1.setSeed((long) 8);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.32933264825411424d + "'", double9 == 0.32933264825411424d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(3, 8);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray6 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c1.setSeed(intArray6);
        double[] doubleArray13 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray19 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray13, doubleArray19);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray33 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray27, doubleArray33);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34);
        org.apache.commons.math3.random.Well19937c well19937c37 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c37.clear();
        double[] doubleArray44 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray50 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray44, doubleArray50);
        double[] doubleArray57 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray63 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray57, doubleArray63);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution65 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c37, doubleArray44, doubleArray64);
        boolean boolean66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray34, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution67 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray21, doubleArray34);
        java.util.ArrayList<org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.Double>> discreteRealDistributionPairList68 = new java.util.ArrayList<org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.Double>>();
        try {
            org.apache.commons.math3.distribution.DiscreteDistribution<org.apache.commons.math3.distribution.DiscreteRealDistribution> discreteRealDistributionDiscreteDistribution69 = new org.apache.commons.math3.distribution.DiscreteDistribution<org.apache.commons.math3.distribution.DiscreteRealDistribution>((org.apache.commons.math3.random.RandomGenerator) well19937c1, (java.util.List<org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.Double>>) discreteRealDistributionPairList68);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double6 = randomDataImpl2.nextUniform(0.0d, 1012010.0d, false);
        randomDataImpl2.reSeed((long) (short) 0);
        randomDataImpl2.reSeedSecure();
        double double12 = randomDataImpl2.nextGaussian((-2.0d), (double) 44L);
        try {
            long long15 = randomDataImpl2.nextLong((long) 733513190, (long) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (733,513,190) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 328552.22402481775d + "'", double6 == 328552.22402481775d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-3.913170299716576d) + "'", double12 == (-3.913170299716576d));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeedSecure((long) (short) 0);
        randomDataImpl8.reSeedSecure((long) (byte) 100);
        double double15 = randomDataImpl8.nextUniform((-1.2404509630364706d), (-0.6205530265987553d));
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.1638152566780704d) + "'", double15 == (-1.1638152566780704d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long9 = well19937c1.nextLong();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2280503348615191882L + "'", long9 == 2280503348615191882L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.Well19937c well19937c9 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c9);
        int[] intArray14 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c9.setSeed(intArray14);
        double double16 = org.apache.commons.math3.util.MathArrays.distance(intArray6, intArray14);
        int[] intArray17 = null;
        try {
            double double18 = org.apache.commons.math3.util.MathArrays.distance(intArray6, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
        boolean boolean34 = discreteRealDistributionPair32.equals((java.lang.Object) (-1));
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution35 = discreteRealDistributionPair32.getKey();
        double[] doubleArray37 = discreteRealDistribution35.sample(14);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(discreteRealDistribution35);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        double double8 = randomDataImpl2.nextT(0.09294902424688352d);
        try {
            double double11 = randomDataImpl2.nextWeibull((double) (byte) 1, (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 11.446697401807153d + "'", double8 == 11.446697401807153d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            int int2 = org.apache.commons.math3.util.MathArrays.distance1(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        double double8 = randomDataImpl2.nextChiSquare((double) 100);
        int int12 = randomDataImpl2.nextHypergeometric((int) 'a', 0, 10);
        try {
            double double15 = randomDataImpl2.nextUniform((double) (byte) 10, 0.32465313981563204d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10) must be strictly less than upper bound (0.325)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 105.42696159652844d + "'", double8 == 105.42696159652844d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 0, (java.lang.Number) (short) 100, (int) (byte) 0);
        int int4 = nonMonotonicSequenceException3.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = nonMonotonicSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double6 = randomDataImpl2.nextUniform(0.0d, 1012010.0d, false);
        int int10 = randomDataImpl2.nextHypergeometric(7, 0, 0);
        try {
            double double13 = randomDataImpl2.nextWeibull((-2.454354035192198d), (double) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-2.454)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 328552.22402481775d + "'", double6 == 328552.22402481775d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 0, (java.lang.Number) (short) 100, (int) (byte) 0);
        boolean boolean4 = nonMonotonicSequenceException3.getStrict();
        boolean boolean5 = nonMonotonicSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.32933264825411424d, (java.lang.Number) (short) -1, false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            double double11 = randomDataGenerator8.nextBeta((double) (byte) 0, (-1.1638152566780704d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.124, 0.876]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int int5 = randomDataImpl2.nextSecureInt((int) (byte) -1, (int) (byte) 10);
//        java.lang.String str7 = randomDataImpl2.nextSecureHexString(100);
//        randomDataImpl2.reSeed();
//        try {
//            java.lang.String str10 = randomDataImpl2.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "c48112af4ad08fe357e65f1ab6eee550fc9cbc7f5adb99a9042a129b8f6c6c59ad923830eb7dcb5623231b264ea172d34f87" + "'", str7.equals("c48112af4ad08fe357e65f1ab6eee550fc9cbc7f5adb99a9042a129b8f6c6c59ad923830eb7dcb5623231b264ea172d34f87"));
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double[] doubleArray5 = new double[] { (byte) 1, (-2.454354035192198d), ' ', 100L, 100.0f };
        double[] doubleArray11 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray17 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray11, doubleArray17);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray5, doubleArray18);
        double[] doubleArray26 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray32 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray26, doubleArray32);
        double[] doubleArray39 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray45 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray45);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray46);
        double double48 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray33, doubleArray47);
        double[] doubleArray54 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray60 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray54, doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray61);
        double[] doubleArray68 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray74 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray68, doubleArray74);
        double double76 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray61, doubleArray74);
        double double77 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray47, doubleArray74);
        boolean boolean78 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray18, doubleArray47);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException82 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0d, (java.lang.Number) (short) 0, (int) ' ');
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection83 = nonMonotonicSequenceException82.getDirection();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.util.MathArrays.OrderDirection, java.lang.Comparable<java.lang.String>> orderDirectionPair85 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.util.MathArrays.OrderDirection, java.lang.Comparable<java.lang.String>>(orderDirection83, (java.lang.Comparable<java.lang.String>) "5661f406fb");
        boolean boolean88 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray18, orderDirection83, true, false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1012010.0d + "'", double76 == 1012010.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 9900.0d + "'", double77 == 9900.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + orderDirection83 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection83.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextInt((int) (byte) -1, (int) (short) 10);
//        try {
//            int[] intArray6 = randomDataGenerator0.nextPermutation(0, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (-1");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray26);
        double[] doubleArray33 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray39 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray33, doubleArray39);
        double[] doubleArray46 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray52 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray46, doubleArray52);
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        boolean boolean55 = org.apache.commons.math3.util.MathArrays.equals(doubleArray33, doubleArray54);
        double double56 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray26, doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0d, (java.lang.Number) (short) 0, (int) ' ');
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = nonMonotonicSequenceException3.getDirection();
        int int5 = nonMonotonicSequenceException3.getIndex();
        java.lang.Number number6 = nonMonotonicSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 0 + "'", number6.equals((short) 0));
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        double double2 = randomDataGenerator0.nextT((double) (short) 10);
//        double double4 = randomDataGenerator0.nextT(0.1845842603151447d);
//        double double6 = randomDataGenerator0.nextChiSquare((double) 38L);
//        try {
//            double double10 = randomDataGenerator0.nextUniform(38384.253589064254d, (-106.42696159652844d), true);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (38,384.254) must be strictly less than upper bound (-106.427)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.16279339656996647d) + "'", double2 == (-0.16279339656996647d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.483016582745268d + "'", double4 == 12.483016582745268d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 31.133082070540482d + "'", double6 == 31.133082070540482d);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getNumericalMean();
        double double32 = discreteRealDistribution29.inverseCumulativeProbability(0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 97.2065955383123d + "'", double30 == 97.2065955383123d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        double double8 = randomDataImpl2.nextChiSquare((double) 100);
        int int11 = randomDataImpl2.nextInt(0, (int) ' ');
        try {
            double double13 = randomDataImpl2.nextT((-244.6200608197496d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-244.62)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 105.42696159652844d + "'", double8 == 105.42696159652844d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) (short) 1);
//        double double5 = randomDataImpl0.nextBeta((double) 10.0f, (double) '4');
//        double double8 = randomDataImpl0.nextGaussian((-106.42696159652844d), 100.0d);
//        try {
//            double double11 = randomDataImpl0.nextBeta((double) (-1.0f), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.533, 0.467]");
//        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3" + "'", str2.equals("3"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.12852704866289918d + "'", double5 == 0.12852704866289918d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-22.31147904762929d) + "'", double8 == (-22.31147904762929d));
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        try {
            double double32 = discreteRealDistribution29.probability((double) 5988793534754658721L, (-3.913170299716576d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (5,988,793,534,754,658,300) must be less than or equal to upper endpoint (-3.913)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection16 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException18 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection16, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection22 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException24 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection22, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection25 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException29 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 0.0f, 0);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection30 = nonMonotonicSequenceException29.getDirection();
        org.apache.commons.math3.util.MathArrays.OrderDirection[] orderDirectionArray31 = new org.apache.commons.math3.util.MathArrays.OrderDirection[] { orderDirection16, orderDirection22, orderDirection25, orderDirection30 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection35 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException37 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection35, false);
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.isMonotonic(orderDirectionArray31, orderDirection35, false);
        boolean boolean41 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray5, orderDirection35, false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(orderDirectionArray31);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        java.lang.Class<?> wildcardClass29 = doubleArray28.getClass();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
//        double double6 = randomDataGenerator0.nextGaussian(10.0d, 105.42696159652844d);
//        double double9 = randomDataGenerator0.nextBeta(10.0d, 10000.0d);
//        try {
//            int[] intArray12 = randomDataGenerator0.nextPermutation((int) (short) 0, 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (100) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 95.52617315398388d + "'", double6 == 95.52617315398388d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0010000440192531443d + "'", double9 == 0.0010000440192531443d);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
        randomDataGenerator0.reSeedSecure((long) '#');
        try {
            double double8 = randomDataGenerator0.nextF((double) (short) 10, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        double double2 = randomDataGenerator0.nextT((double) (short) 10);
//        double double4 = randomDataGenerator0.nextChiSquare((double) 0.23953891f);
//        try {
//            double double7 = randomDataGenerator0.nextUniform(10.000201086223035d, (-106.42696159652844d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10) must be strictly less than upper bound (-106.427)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1143575200129778d + "'", double2 == 1.1143575200129778d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.5780796263290694E-8d + "'", double4 == 1.5780796263290694E-8d);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            double double5 = randomDataImpl2.nextGaussian((double) 0.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (short) 0, 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray6 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c1.setSeed(intArray6);
        double[] doubleArray13 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray19 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray13, doubleArray19);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray33 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray27, doubleArray33);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34);
        org.apache.commons.math3.random.Well19937c well19937c37 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c37.clear();
        double[] doubleArray44 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray50 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray44, doubleArray50);
        double[] doubleArray57 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray63 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray57, doubleArray63);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution65 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c37, doubleArray44, doubleArray64);
        boolean boolean66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray34, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution67 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray21, doubleArray34);
        double[] doubleArray68 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        double[] doubleArray69 = null;
        try {
            double double70 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray21, doubleArray69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
//        well19937c1.setSeed(intArray6);
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        java.lang.String str11 = randomDataGenerator9.nextSecureHexString((int) 'a');
//        try {
//            int int14 = randomDataGenerator9.nextBinomial((int) (short) -1, (double) 0.23953891f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of trials (-1)");
//        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "55833871bdfaba1c1b009a3c2ca4f5b32253d759d5ccc214653b7ff7c13edb4036bd44b3156dac57b81713dede9eb8723" + "'", str11.equals("55833871bdfaba1c1b009a3c2ca4f5b32253d759d5ccc214653b7ff7c13edb4036bd44b3156dac57b81713dede9eb8723"));
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int[] intArray0 = null;
        try {
            int[] intArray1 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12);
        org.apache.commons.math3.random.Well19937c well19937c15 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c15.clear();
        double[] doubleArray22 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray28 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray28);
        double[] doubleArray35 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray41 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray35, doubleArray41);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution43 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c15, doubleArray22, doubleArray42);
        boolean boolean44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray12, doubleArray22);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray12, (double) 100L);
        double[] doubleArray47 = null;
        try {
            double double48 = org.apache.commons.math3.util.MathArrays.distance(doubleArray12, doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            long long11 = randomDataImpl8.nextLong(3325889825069335040L, (long) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (3,325,889,825,069,335,040) must be strictly less than upper bound (52)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double31 = discreteRealDistribution29.density((double) 32);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 2);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeedSecure();
//        double double3 = randomDataGenerator0.nextChiSquare(39.525652590500485d);
//        int int6 = randomDataGenerator0.nextSecureInt(1, 1394374653);
//        randomDataGenerator0.reSeedSecure((long) 32);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 33.07314309338826d + "'", double3 == 33.07314309338826d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 463846793 + "'", int6 == 463846793);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable3, (java.lang.Number) (short) -1, objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable2, objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, objArray8);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math3.exception.NotFiniteNumberException(number0, objArray8);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 0.0f, 0);
        java.lang.String str4 = nonMonotonicSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)" + "'", str4.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 7, (double) (byte) -1, (-111.1476792949898d), 5.7714331541721214E-6d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-7.000641481401292d) + "'", double4 == (-7.000641481401292d));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable6, (java.lang.Number) (short) -1, objArray11);
        org.apache.commons.math3.exception.MathInternalError mathInternalError13 = new org.apache.commons.math3.exception.MathInternalError(localizable5, objArray11);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable3, (java.lang.Number) 328552.22402481775d, objArray11);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable2, objArray11);
        org.apache.commons.math3.exception.MathInternalError mathInternalError16 = new org.apache.commons.math3.exception.MathInternalError(localizable1, objArray11);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray11);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (short) 1, (int) (short) 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException8 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable2, (java.lang.Number) (short) -1, objArray7);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) (-1.2404509630364706d), objArray7);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0, (java.lang.Number) (-1.0f));
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.String str5 = outOfRangeException3.toString();
        org.apache.commons.math3.random.Well19937c well19937c7 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c7.clear();
        double[] doubleArray14 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray20 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray14, doubleArray20);
        double[] doubleArray27 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray33 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray27, doubleArray33);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution35 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c7, doubleArray14, doubleArray34);
        double double36 = discreteRealDistribution35.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError37 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair38 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution35, (java.lang.IllegalStateException) mathInternalError37);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext39 = mathInternalError37.getContext();
        outOfRangeException3.addSuppressed((java.lang.Throwable) mathInternalError37);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext41 = mathInternalError37.getContext();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 0 out of [0, -1] range" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: 0 out of [0, -1] range"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 100.0d + "'", double36 == 100.0d);
        org.junit.Assert.assertNotNull(exceptionContext39);
        org.junit.Assert.assertNotNull(exceptionContext41);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int int5 = randomDataImpl2.nextSecureInt((int) (byte) -1, (int) (byte) 10);
//        java.lang.String str7 = randomDataImpl2.nextSecureHexString(100);
//        randomDataImpl2.reSeed();
//        try {
//            double double11 = randomDataImpl2.nextCauchy(0.0d, (-106.42696159652844d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-106.427)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "8ad12e7d478c78de96915cd783faddb90d2a24e8beae96539a686b8ea400b8313acdc90a62bb45f07478dd4cb496608bead9" + "'", str7.equals("8ad12e7d478c78de96915cd783faddb90d2a24e8beae96539a686b8ea400b8313acdc90a62bb45f07478dd4cb496608bead9"));
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 32, (java.lang.Number) 463846793, false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray15 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray21 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray15, doubleArray21);
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22);
        org.apache.commons.math3.random.Well19937c well19937c25 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c25.clear();
        double[] doubleArray32 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray38 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray32, doubleArray38);
        double[] doubleArray45 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray51 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray52 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray45, doubleArray51);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution53 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c25, doubleArray32, doubleArray52);
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray22, doubleArray32);
        org.apache.commons.math3.random.Well19937c well19937c56 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c56.clear();
        double[] doubleArray63 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray69 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray63, doubleArray69);
        double[] doubleArray76 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray82 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray83 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray76, doubleArray82);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution84 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c56, doubleArray63, doubleArray83);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution85 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray22, doubleArray83);
        boolean boolean86 = discreteRealDistribution85.isSupportConnected();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int5 = randomDataImpl2.nextBinomial((int) (byte) 1, (double) 0);
        double double8 = randomDataImpl2.nextF(56.14779571738535d, (double) 64L);
        try {
            int int11 = randomDataImpl2.nextZipf(100, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: exponent (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.1146327093968127d + "'", double8 == 1.1146327093968127d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        randomDataImpl2.reSeed((long) (-1));
        double double10 = randomDataImpl2.nextExponential(0.009699321047526674d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0144581791158443d + "'", double10 == 0.0144581791158443d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        long[] longArray7 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray12 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray17 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray22 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray27 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray32 = new long[] { 10, 100, 0L, (byte) 10 };
        long[][] longArray33 = new long[][] { longArray7, longArray12, longArray17, longArray22, longArray27, longArray32 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray33);
        org.apache.commons.math3.exception.MathInternalError mathInternalError35 = new org.apache.commons.math3.exception.MathInternalError(localizable2, (java.lang.Object[]) longArray33);
        org.apache.commons.math3.exception.MathInternalError mathInternalError36 = new org.apache.commons.math3.exception.MathInternalError(localizable1, (java.lang.Object[]) longArray33);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException37 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) longArray33);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext38 = mathArithmeticException37.getContext();
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray32);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertNotNull(exceptionContext38);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) (-1.0d));
        java.lang.Number number3 = notPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        try {
            int int4 = randomDataImpl0.nextHypergeometric(0, 25, 8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException6 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) (short) -1, objArray5);
        try {
            java.lang.String str7 = notFiniteNumberException6.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeedSecure((long) (short) 0);
        double double12 = randomDataImpl8.nextChiSquare(10.009789518835406d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 5.221994419736348d + "'", double12 == 5.221994419736348d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable4, (java.lang.Number) (short) -1, objArray9);
        org.apache.commons.math3.exception.MathInternalError mathInternalError11 = new org.apache.commons.math3.exception.MathInternalError(localizable3, objArray9);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable1, (java.lang.Number) 328552.22402481775d, objArray9);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException13 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 0.1845842603151447d, objArray9);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(1.0d, 0.07466132577245381d, 33.07314309338826d, (double) 1.0f, (double) 0.23953891f, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 33.147804419160714d + "'", double6 == 33.147804419160714d);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
//        double double6 = randomDataGenerator0.nextGaussian(10.0d, 105.42696159652844d);
//        try {
//            int int10 = randomDataGenerator0.nextHypergeometric(22, 1394374653, 1394374653);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (1,394,374,653) must be less than or equal to population size (22)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 86.81426816615486d + "'", double6 == 86.81426816615486d);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number0, (java.lang.Number) 26.56353953166036d, (int) (short) -1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = nonMonotonicSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long5 = randomDataImpl2.nextLong(0L, 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double[] doubleArray0 = null;
        org.apache.commons.math3.random.Well19937c well19937c2 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray7 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c2.setSeed(intArray7);
        double[] doubleArray14 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray20 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray14, doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        double[] doubleArray28 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray34 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray28, doubleArray34);
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray35);
        org.apache.commons.math3.random.Well19937c well19937c38 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c38.clear();
        double[] doubleArray45 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray51 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray52 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray45, doubleArray51);
        double[] doubleArray58 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray64 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray65 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray58, doubleArray64);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution66 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c38, doubleArray45, doubleArray65);
        boolean boolean67 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray35, doubleArray45);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution68 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c2, doubleArray22, doubleArray35);
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection73 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException75 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection73, false);
        double[][] doubleArray76 = new double[][] {};
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray22, orderDirection73, doubleArray76);
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray0, doubleArray76);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + orderDirection73 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection73.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray76);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        well19937c1.clear();
        int int10 = well19937c1.nextInt();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double14 = randomDataImpl11.nextGaussian((double) 0L, 9.699321047526673E-4d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 530971062 + "'", int10 == 530971062);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-8.964648047659643E-4d) + "'", double14 == (-8.964648047659643E-4d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        float[] floatArray0 = null;
        float[] floatArray2 = new float[] { 100.0f };
        float[] floatArray7 = new float[] { (-1), (-1L), (byte) 1, 10L };
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray2, floatArray7);
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(floatArray0, floatArray2);
        float[] floatArray15 = new float[] { (short) 0, 10, '#', (short) 1, (-1.0f) };
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equals(floatArray0, floatArray15);
        float[] floatArray17 = null;
        float[] floatArray19 = new float[] { 100.0f };
        float[] floatArray24 = new float[] { (-1), (-1L), (byte) 1, 10L };
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray19, floatArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(floatArray17, floatArray19);
        float[] floatArray28 = new float[] { 100.0f };
        float[] floatArray33 = new float[] { (-1), (-1L), (byte) 1, 10L };
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray28, floatArray33);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equals(floatArray19, floatArray33);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray0, floatArray19);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.apache.commons.math3.random.Well19937c well19937c0 = new org.apache.commons.math3.random.Well19937c();
//        double double1 = well19937c0.nextDouble();
//        well19937c0.setSeed((int) (short) 1);
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.25965495566128505d + "'", double1 == 0.25965495566128505d);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        long[] longArray7 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray12 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray17 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray22 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray27 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray32 = new long[] { 10, 100, 0L, (byte) 10 };
        long[][] longArray33 = new long[][] { longArray7, longArray12, longArray17, longArray22, longArray27, longArray32 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray33);
        org.apache.commons.math3.exception.MathInternalError mathInternalError35 = new org.apache.commons.math3.exception.MathInternalError(localizable2, (java.lang.Object[]) longArray33);
        org.apache.commons.math3.exception.MathInternalError mathInternalError36 = new org.apache.commons.math3.exception.MathInternalError(localizable1, (java.lang.Object[]) longArray33);
        org.apache.commons.math3.exception.MathInternalError mathInternalError37 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) longArray33);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray32);
        org.junit.Assert.assertNotNull(longArray33);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.Well19937c well19937c9 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c9);
        int[] intArray14 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c9.setSeed(intArray14);
        double double16 = org.apache.commons.math3.util.MathArrays.distance(intArray6, intArray14);
        org.apache.commons.math3.random.Well19937c well19937c17 = new org.apache.commons.math3.random.Well19937c(intArray6);
        long long18 = well19937c17.nextLong();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c17);
        try {
            java.lang.String str21 = randomDataImpl19.nextSecureHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2280503348615191882L + "'", long18 == 2280503348615191882L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        double double8 = randomDataImpl2.nextT(0.09294902424688352d);
        try {
            double double11 = randomDataImpl2.nextUniform(0.0d, (-7.000641481401292d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0) must be strictly less than upper bound (-7.001)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 11.446697401807153d + "'", double8 == 11.446697401807153d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double32 = discreteRealDistribution29.cumulativeProbability((double) 0, 0.0013733592917636712d);
        double double34 = discreteRealDistribution29.density((-13.019780028987341d));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 100L, (java.lang.Number) 100.0f, (java.lang.Number) (short) -1);
        org.apache.commons.math3.exception.MathInternalError mathInternalError4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) outOfRangeException3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 22, (java.lang.Number) 33.817840312133065d, true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12);
        double[] doubleArray19 = new double[] { (byte) 1, (-2.454354035192198d), ' ', 100L, 100.0f };
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32);
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray32);
        double[] doubleArray40 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray46 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray46);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double double62 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray47, doubleArray61);
        double[] doubleArray68 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray74 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray68, doubleArray74);
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray75);
        double[] doubleArray82 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray88 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray89 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray82, doubleArray88);
        double double90 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray75, doubleArray88);
        double double91 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray61, doubleArray88);
        double[] doubleArray92 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray32, doubleArray88);
        double double93 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray13, doubleArray32);
        double[] doubleArray94 = new double[] {};
        try {
            double[] doubleArray95 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray32, doubleArray94);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 1012010.0d + "'", double90 == 1012010.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 9900.0d + "'", double91 == 9900.0d);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 1.000301E8d + "'", double93 == 1.000301E8d);
        org.junit.Assert.assertNotNull(doubleArray94);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
//        double double6 = randomDataGenerator0.nextGaussian(10.0d, 105.42696159652844d);
//        try {
//            long long9 = randomDataGenerator0.nextLong((long) (byte) 100, 32L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (100) must be strictly less than upper bound (32)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 34.465777937878606d + "'", double6 == 34.465777937878606d);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable3, (java.lang.Number) (short) -1, objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable2, objArray8);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 0.23953891f, objArray8);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray8);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
        boolean boolean34 = discreteRealDistributionPair32.equals((java.lang.Object) (-1));
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution35 = discreteRealDistributionPair32.getKey();
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution36 = discreteRealDistributionPair32.getKey();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(discreteRealDistribution35);
        org.junit.Assert.assertNotNull(discreteRealDistribution36);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) (short) 1);
//        double double5 = randomDataImpl0.nextBeta((double) 10.0f, (double) '4');
//        double double8 = randomDataImpl0.nextGaussian((-106.42696159652844d), 100.0d);
//        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl0.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "f" + "'", str2.equals("f"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.22187043707631326d + "'", double5 == 0.22187043707631326d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-205.07083709666318d) + "'", double8 == (-205.07083709666318d));
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        double double8 = randomDataImpl2.nextChiSquare((double) 100);
        try {
            double double11 = randomDataImpl2.nextGaussian((double) 0.6642053f, (-90.62321083509698d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (-90.623)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 105.42696159652844d + "'", double8 == 105.42696159652844d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl2.reSeedSecure((long) (short) 0);
        try {
            randomDataImpl2.setSecureAlgorithm("c", "9");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 9");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        long[] longArray5 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray10 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray15 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray20 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray25 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray30 = new long[] { 10, 100, 0L, (byte) 10 };
        long[][] longArray31 = new long[][] { longArray5, longArray10, longArray15, longArray20, longArray25, longArray30 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray31);
        org.apache.commons.math3.exception.MathInternalError mathInternalError33 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) longArray31);
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray31);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertNotNull(longArray31);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double3 = well19937c1.nextDouble();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.32465313981563204d + "'", double3 == 0.32465313981563204d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (short) 1);
        double double5 = randomDataGenerator0.nextUniform((-2.454354035192198d), 0.30955021719333553d);
        try {
            int int8 = randomDataGenerator0.nextInt(1394374653, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,394,374,653) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2.253205282766861d) + "'", double5 == (-2.253205282766861d));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 44L, (-1.2404509630364706d), 0.0d, 0.0d, 93.64583598432536d, (-14.900295717310165d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1449.930491234778d) + "'", double6 == (-1449.930491234778d));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
        java.lang.IllegalStateException illegalStateException33 = discreteRealDistributionPair32.getSecond();
        java.lang.IllegalStateException illegalStateException34 = discreteRealDistributionPair32.getValue();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertNotNull(illegalStateException33);
        org.junit.Assert.assertNotNull(illegalStateException34);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        well19937c1.clear();
        long long4 = well19937c1.nextLong();
        boolean boolean5 = well19937c1.nextBoolean();
        int int7 = well19937c1.nextInt(14);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5988793534754658721L + "'", long4 == 5988793534754658721L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double6 = randomDataImpl2.nextUniform(0.0d, 1012010.0d, false);
        int int10 = randomDataImpl2.nextHypergeometric(7, 0, 0);
        try {
            double double13 = randomDataImpl2.nextCauchy((double) '#', (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 328552.22402481775d + "'", double6 == 328552.22402481775d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) (short) 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
        boolean boolean33 = discreteRealDistribution29.isSupportLowerBoundInclusive();
        try {
            double double36 = discreteRealDistribution29.probability((double) 3, (-2.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (3) must be less than or equal to upper endpoint (-2)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray6 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c1.setSeed(intArray6);
        double[] doubleArray13 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray19 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray13, doubleArray19);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray33 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray27, doubleArray33);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34);
        org.apache.commons.math3.random.Well19937c well19937c37 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c37.clear();
        double[] doubleArray44 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray50 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray44, doubleArray50);
        double[] doubleArray57 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray63 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray57, doubleArray63);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution65 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c37, doubleArray44, doubleArray64);
        boolean boolean66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray34, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution67 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray21, doubleArray34);
        double[] doubleArray68 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        double[] doubleArray74 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray80 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray81 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray74, doubleArray80);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution82 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(doubleArray68, doubleArray80);
        double double84 = discreteRealDistribution82.density(0.05126582292753777d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        discreteRealDistribution76.reseedRandomGenerator((long) 'a');
        double double79 = discreteRealDistribution76.getSupportUpperBound();
        boolean boolean80 = discreteRealDistribution76.isSupportUpperBoundInclusive();
        boolean boolean81 = discreteRealDistribution76.isSupportConnected();
        double double83 = discreteRealDistribution76.cumulativeProbability((double) 35);
        try {
            double double86 = discreteRealDistribution76.probability((double) 35, (-2.454354035192198d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (35) must be less than or equal to upper endpoint (-2.454)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 10000.0d + "'", double79 == 10000.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 9.699321047526673E-4d + "'", double83 == 9.699321047526673E-4d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException8 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable2, (java.lang.Number) (short) -1, objArray7);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, objArray7);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray7);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = mathIllegalStateException10.getContext();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(exceptionContext11);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeedSecure();
        double double12 = randomDataImpl8.nextBeta(8.996488039729147d, 0.1845842603151447d);
        double double15 = randomDataImpl8.nextBeta(81.35173968711932d, 67.54430218383669d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9493594565810611d + "'", double12 == 0.9493594565810611d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5982021689405124d + "'", double15 == 0.5982021689405124d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeedSecure((long) (short) 0);
        int[] intArray13 = randomDataImpl8.nextPermutation(52, 8);
        randomDataImpl8.reSeedSecure(1L);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = well19937c1.nextGaussian();
        int[] intArray37 = new int[] { (short) 1, 7, (short) 1, 100, 0, (byte) 100 };
        int[] intArray39 = org.apache.commons.math3.util.MathArrays.copyOf(intArray37, (int) 'a');
        well19937c1.setSeed(intArray37);
        double double41 = well19937c1.nextDouble();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-0.40892891016592103d) + "'", double30 == (-0.40892891016592103d));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.7039477090096311d + "'", double41 == 0.7039477090096311d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl2.reSeedSecure();
        try {
            double double5 = randomDataImpl2.nextExponential((-1.2404509630364706d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-1.24)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
//        double double6 = randomDataGenerator0.nextGaussian(10.0d, 105.42696159652844d);
//        int int9 = randomDataGenerator0.nextBinomial(0, (double) (byte) 1);
//        long long12 = randomDataGenerator0.nextLong((long) (-1), 0L);
//        int int15 = randomDataGenerator0.nextBinomial((int) 'a', 0.0d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 47.302073987842114d + "'", double6 == 47.302073987842114d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double32 = discreteRealDistribution29.cumulativeProbability((double) 0, 0.0013733592917636712d);
        boolean boolean33 = discreteRealDistribution29.isSupportUpperBoundInclusive();
        double double35 = discreteRealDistribution29.cumulativeProbability(0.09709622577147363d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 2, 0.0d, 9702.240543161977d, (-0.40892891016592103d), (-3.913170299716576d), (double) (short) 1, (double) (short) 10, 0.05126582292753777d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-3970.9271635532823d) + "'", double8 == (-3970.9271635532823d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (short) 10, (int) (byte) 10);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 0, (java.lang.Number) 0.30955021719333553d, (java.lang.Number) 10);
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        org.apache.commons.math3.exception.util.Localizable localizable9 = null;
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException10 = new org.apache.commons.math3.exception.NullArgumentException();
        double[] doubleArray16 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray22 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray16, doubleArray22);
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23);
        double[] doubleArray30 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray36 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray30, doubleArray36);
        double double38 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray23, doubleArray36);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator39 = new org.apache.commons.math3.random.RandomDataGenerator();
        java.lang.Object[] objArray40 = new java.lang.Object[] { nullArgumentException10, doubleArray23, randomDataGenerator39 };
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException41 = new org.apache.commons.math3.exception.NullArgumentException(localizable9, objArray40);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException42 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (short) 0, objArray40);
        java.lang.Throwable[] throwableArray43 = notFiniteNumberException42.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException44 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException6, localizable7, (java.lang.Object[]) throwableArray43);
        java.lang.Number number45 = outOfRangeException6.getLo();
        dimensionMismatchException2.addSuppressed((java.lang.Throwable) outOfRangeException6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1012010.0d + "'", double38 == 1012010.0d);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 0.30955021719333553d + "'", number45.equals(0.30955021719333553d));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection3, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = nonMonotonicSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math3.random.RandomGenerator randomGenerator0 = null;
        java.util.ArrayList<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.OutOfRangeException, java.lang.Double>> outOfRangeExceptionPairList1 = new java.util.ArrayList<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.OutOfRangeException, java.lang.Double>>();
        try {
            org.apache.commons.math3.distribution.DiscreteDistribution<org.apache.commons.math3.exception.OutOfRangeException> outOfRangeExceptionDiscreteDistribution2 = new org.apache.commons.math3.distribution.DiscreteDistribution<org.apache.commons.math3.exception.OutOfRangeException>(randomGenerator0, (java.util.List<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.OutOfRangeException, java.lang.Double>>) outOfRangeExceptionPairList1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        java.lang.Class<?> wildcardClass3 = randomDataImpl2.getClass();
        try {
            double double6 = randomDataImpl2.nextCauchy(8.238169641327561E-4d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (short) 1);
        randomDataGenerator0.reSeed();
        try {
            int int6 = randomDataGenerator0.nextSecureInt((int) '4', 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (52) must be strictly less than upper bound (5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 100L);
        java.lang.Class<?> wildcardClass2 = notPositiveException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray26);
        double[] doubleArray33 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray39 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray33, doubleArray39);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40);
        double[] doubleArray47 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray53 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray47, doubleArray53);
        double double55 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray40, doubleArray53);
        double double56 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray26, doubleArray53);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1012010.0d + "'", double55 == 1012010.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 9900.0d + "'", double56 == 9900.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        well19937c1.clear();
        int int10 = well19937c1.nextInt();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int13 = well19937c1.nextInt(99);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 530971062 + "'", int10 == 530971062);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) 0);
        try {
            int int5 = randomDataGenerator0.nextInt((int) (short) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (100) must be strictly less than upper bound (35)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 99);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12);
        double[] doubleArray19 = new double[] { (byte) 1, (-2.454354035192198d), ' ', 100L, 100.0f };
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32);
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray32);
        double[] doubleArray40 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray46 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray46);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double double62 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray47, doubleArray61);
        double[] doubleArray68 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray74 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray68, doubleArray74);
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray75);
        double[] doubleArray82 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray88 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray89 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray82, doubleArray88);
        double double90 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray75, doubleArray88);
        double double91 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray61, doubleArray88);
        double[] doubleArray92 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray32, doubleArray88);
        double double93 = org.apache.commons.math3.util.MathArrays.distance(doubleArray13, doubleArray88);
        double[] doubleArray94 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 1012010.0d + "'", double90 == 1012010.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 9900.0d + "'", double91 == 9900.0d);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 9900.822238582006d + "'", double93 == 9900.822238582006d);
        org.junit.Assert.assertNotNull(doubleArray94);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
//        double double6 = randomDataGenerator0.nextGaussian(10.0d, 105.42696159652844d);
//        int int9 = randomDataGenerator0.nextBinomial(0, (double) (byte) 1);
//        long long12 = randomDataGenerator0.nextLong((long) (-1), 0L);
//        try {
//            double double15 = randomDataGenerator0.nextGamma((-0.42978164783246015d), 33.07314309338826d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-0.43)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 297.7786958604938d + "'", double6 == 297.7786958604938d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        org.apache.commons.math3.random.Well19937c well19937c14 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray19 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c14.setSeed(intArray19);
        double[] doubleArray26 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray32 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray26, doubleArray32);
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray33);
        double[] doubleArray40 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray46 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray46);
        double[] doubleArray48 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray47);
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c50.clear();
        double[] doubleArray57 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray63 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray57, doubleArray63);
        double[] doubleArray70 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray76 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray77 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray70, doubleArray76);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution78 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, doubleArray57, doubleArray77);
        boolean boolean79 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray47, doubleArray57);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution80 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c14, doubleArray34, doubleArray47);
        double[] doubleArray81 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection85 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException87 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection85, false);
        double[][] doubleArray88 = new double[][] {};
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray34, orderDirection85, doubleArray88);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray11, doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + orderDirection85 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection85.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray88);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math3.random.Well19937c well19937c3 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
//        int[] intArray8 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
//        well19937c3.setSeed(intArray8);
//        org.apache.commons.math3.random.Well19937c well19937c10 = new org.apache.commons.math3.random.Well19937c(intArray8);
//        org.apache.commons.math3.random.Well19937c well19937c13 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c13);
//        int[] intArray18 = new int[] { (short) 100, (byte) 100, ' ' };
//        well19937c13.setSeed(intArray18);
//        org.apache.commons.math3.exception.util.Localizable localizable21 = null;
//        org.apache.commons.math3.exception.NullArgumentException nullArgumentException22 = new org.apache.commons.math3.exception.NullArgumentException();
//        double[] doubleArray28 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
//        double[] doubleArray34 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
//        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray28, doubleArray34);
//        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray35);
//        double[] doubleArray42 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
//        double[] doubleArray48 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
//        double[] doubleArray49 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray42, doubleArray48);
//        double double50 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray35, doubleArray48);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator51 = new org.apache.commons.math3.random.RandomDataGenerator();
//        java.lang.Object[] objArray52 = new java.lang.Object[] { nullArgumentException22, doubleArray35, randomDataGenerator51 };
//        org.apache.commons.math3.exception.NullArgumentException nullArgumentException53 = new org.apache.commons.math3.exception.NullArgumentException(localizable21, objArray52);
//        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException54 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (short) 0, objArray52);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator55 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator55.reSeed((long) (short) 1);
//        randomDataGenerator55.reSeed();
//        double double60 = randomDataGenerator55.nextChiSquare((double) 7);
//        java.lang.Object[] objArray62 = new java.lang.Object[] { well19937c10, 1.0d, well19937c13, objArray52, 7, (-1) };
//        org.apache.commons.math3.exception.NullArgumentException nullArgumentException63 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, objArray52);
//        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException64 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray52);
//        org.apache.commons.math3.exception.util.Localizable localizable65 = null;
//        org.apache.commons.math3.exception.util.Localizable localizable66 = null;
//        org.apache.commons.math3.exception.util.Localizable localizable67 = null;
//        java.lang.Object[] objArray72 = new java.lang.Object[] { 100, '4', 100.0d };
//        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException73 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable67, (java.lang.Number) (short) -1, objArray72);
//        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException74 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable66, objArray72);
//        try {
//            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException75 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException64, localizable65, objArray72);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertNotNull(doubleArray28);
//        org.junit.Assert.assertNotNull(doubleArray34);
//        org.junit.Assert.assertNotNull(doubleArray35);
//        org.junit.Assert.assertNotNull(doubleArray36);
//        org.junit.Assert.assertNotNull(doubleArray42);
//        org.junit.Assert.assertNotNull(doubleArray48);
//        org.junit.Assert.assertNotNull(doubleArray49);
//        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1012010.0d + "'", double50 == 1012010.0d);
//        org.junit.Assert.assertNotNull(objArray52);
//        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 4.8696315137552135d + "'", double60 == 4.8696315137552135d);
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertNotNull(objArray72);
//    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        double double2 = randomDataGenerator0.nextT((double) (short) 10);
//        double double4 = randomDataGenerator0.nextChiSquare((double) 0.23953891f);
//        randomDataGenerator0.reSeedSecure();
//        try {
//            double double8 = randomDataGenerator0.nextUniform((double) 733513190, (-111.1476792949898d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (733,513,190) must be strictly less than upper bound (-111.148)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.10297139808706605d + "'", double2 == 0.10297139808706605d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.7675760814034275E-6d + "'", double4 == 3.7675760814034275E-6d);
//    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
//        long long6 = randomDataGenerator0.nextLong((-1L), 5988793534754658721L);
//        randomDataGenerator0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5590325047021507584L + "'", long6 == 5590325047021507584L);
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeed((long) (short) 1);
//        randomDataGenerator0.reSeed();
//        double double5 = randomDataGenerator0.nextChiSquare((double) 7);
//        java.lang.String str7 = randomDataGenerator0.nextHexString(1);
//        randomDataGenerator0.reSeed();
//        try {
//            randomDataGenerator0.setSecureAlgorithm("8", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.8276197802082743d + "'", double5 == 3.8276197802082743d);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int int5 = randomDataImpl2.nextSecureInt((int) (byte) -1, (int) (byte) 10);
//        randomDataImpl2.reSeed(0L);
//        double double9 = randomDataImpl2.nextT(47.49753257822645d);
//        double double12 = randomDataImpl2.nextCauchy((double) (short) -1, 0.09294902424688352d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.6583111177123727d + "'", double9 == 0.6583111177123727d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.9724196550669874d) + "'", double12 == (-0.9724196550669874d));
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(25);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) (short) -1);
        try {
            double double13 = randomDataImpl8.nextF((double) 42L, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (short) 100, 0.32465313981563204d, 2.652745825556842d, 1.000301E8d, 897.2434883068374d, 0.0d, 0.0d, 2.6737939463871254E10d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6535446267034742E8d + "'", double8 == 2.6535446267034742E8d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        long[] longArray4 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray9 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray14 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray19 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray24 = new long[] { 10, 100, 0L, (byte) 10 };
        long[] longArray29 = new long[] { 10, 100, 0L, (byte) 10 };
        long[][] longArray30 = new long[][] { longArray4, longArray9, longArray14, longArray19, longArray24, longArray29 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray30);
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray30);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray29);
        org.junit.Assert.assertNotNull(longArray30);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray26);
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10001.504886765792d + "'", double28 == 10001.504886765792d);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        discreteRealDistribution76.reseedRandomGenerator((long) 'a');
        double double79 = discreteRealDistribution76.getSupportUpperBound();
        boolean boolean80 = discreteRealDistribution76.isSupportUpperBoundInclusive();
        boolean boolean81 = discreteRealDistribution76.isSupportConnected();
        double double83 = discreteRealDistribution76.cumulativeProbability((double) 35);
        try {
            double double86 = discreteRealDistribution76.cumulativeProbability(2.6737939463871254E10d, (-3970.9271635532823d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (26,737,939,463.871) must be less than or equal to upper endpoint (-3,970.927)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 10000.0d + "'", double79 == 10000.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 9.699321047526673E-4d + "'", double83 == 9.699321047526673E-4d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1220434243L, (java.lang.Number) 0.09294902424688352d, false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeedSecure();
        double double11 = randomDataImpl8.nextT((double) (short) 100);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.1638537524704287d) + "'", double11 == (-1.1638537524704287d));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 42L, false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray6 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray6);
        boolean boolean9 = well19937c8.nextBoolean();
        int int10 = well19937c8.nextInt();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-7187591) + "'", int10 == (-7187591));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        boolean boolean77 = well19937c1.nextBoolean();
        java.util.ArrayList<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathArithmeticException, java.lang.Double>> mathArithmeticExceptionPairList78 = new java.util.ArrayList<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathArithmeticException, java.lang.Double>>();
        try {
            org.apache.commons.math3.distribution.DiscreteDistribution<org.apache.commons.math3.exception.MathArithmeticException> mathArithmeticExceptionDiscreteDistribution79 = new org.apache.commons.math3.distribution.DiscreteDistribution<org.apache.commons.math3.exception.MathArithmeticException>((org.apache.commons.math3.random.RandomGenerator) well19937c1, (java.util.List<org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathArithmeticException, java.lang.Double>>) mathArithmeticExceptionPairList78);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 10 };
        well19937c1.nextBytes(byteArray4);
        well19937c1.setSeed((long) (byte) 10);
        org.junit.Assert.assertNotNull(byteArray4);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable5, (java.lang.Number) (short) -1, objArray10);
        org.apache.commons.math3.exception.MathInternalError mathInternalError12 = new org.apache.commons.math3.exception.MathInternalError(localizable4, objArray10);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException13 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable2, (java.lang.Number) 328552.22402481775d, objArray10);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, objArray10);
        org.apache.commons.math3.exception.MathInternalError mathInternalError15 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext16 = mathInternalError15.getContext();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(exceptionContext16);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 0, (java.lang.Number) 0.30955021719333553d, (java.lang.Number) 10);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException();
        double[] doubleArray13 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray19 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray13, doubleArray19);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray33 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray27, doubleArray33);
        double double35 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray20, doubleArray33);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator36 = new org.apache.commons.math3.random.RandomDataGenerator();
        java.lang.Object[] objArray37 = new java.lang.Object[] { nullArgumentException7, doubleArray20, randomDataGenerator36 };
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException38 = new org.apache.commons.math3.exception.NullArgumentException(localizable6, objArray37);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException39 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (short) 0, objArray37);
        java.lang.Throwable[] throwableArray40 = notFiniteNumberException39.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException3, localizable4, (java.lang.Object[]) throwableArray40);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 100L, (java.lang.Number) 100.0f, (java.lang.Number) (short) -1);
        java.lang.Number number46 = outOfRangeException45.getLo();
        mathIllegalStateException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException51 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 0.0f, 0);
        outOfRangeException45.addSuppressed((java.lang.Throwable) nonMonotonicSequenceException51);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection53 = nonMonotonicSequenceException51.getDirection();
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1012010.0d + "'", double35 == 1012010.0d);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 100.0f + "'", number46.equals(100.0f));
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection53.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        double double2 = randomDataGenerator0.nextT((double) (short) 10);
//        double double4 = randomDataGenerator0.nextChiSquare((double) 0.23953891f);
//        try {
//            double double7 = randomDataGenerator0.nextUniform(105.42696159652844d, (-111.1476792949898d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (105.427) must be strictly less than upper bound (-111.148)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.57905036837468d + "'", double2 == 2.57905036837468d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05917682532652845d + "'", double4 == 0.05917682532652845d);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeedSecure();
        double double12 = randomDataImpl8.nextBeta(8.996488039729147d, 0.1845842603151447d);
        try {
            double double15 = randomDataImpl8.nextGamma((double) 0.0f, (-111.1476792949898d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9493594565810611d + "'", double12 == 0.9493594565810611d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double5 = randomDataImpl2.nextGamma(11.446697401807153d, 2.3438407852575533d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 22.981618453278884d + "'", double5 == 22.981618453278884d);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
//        well19937c1.setSeed(intArray6);
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        randomDataImpl8.reSeedSecure((long) (short) 0);
//        int[] intArray13 = randomDataImpl8.nextPermutation(52, 8);
//        int int16 = randomDataImpl8.nextSecureInt(14, 733513190);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 414070727 + "'", int16 == 414070727);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            long long5 = randomDataGenerator2.nextSecureLong((long) 100, 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (100) must be strictly less than upper bound (100)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int int5 = randomDataImpl2.nextSecureInt((int) (byte) -1, (int) (byte) 10);
//        randomDataImpl2.reSeed();
//        try {
//            double double9 = randomDataImpl2.nextBeta(22.981618453278884d, (-0.9724196550669874d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.52, 0.48]");
//        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int int5 = randomDataImpl2.nextSecureInt((int) (byte) -1, (int) (byte) 10);
//        double double7 = randomDataImpl2.nextT(25.94170504848563d);
//        try {
//            long long9 = randomDataImpl2.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.460059626405916d) + "'", double7 == (-0.460059626405916d));
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray6 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c1.setSeed(intArray6);
        double[] doubleArray13 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray19 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray13, doubleArray19);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray33 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray27, doubleArray33);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34);
        org.apache.commons.math3.random.Well19937c well19937c37 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c37.clear();
        double[] doubleArray44 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray50 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray44, doubleArray50);
        double[] doubleArray57 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray63 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray57, doubleArray63);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution65 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c37, doubleArray44, doubleArray64);
        boolean boolean66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray34, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution67 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray21, doubleArray34);
        double[] doubleArray68 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        double[] doubleArray74 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray80 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray81 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray74, doubleArray80);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution82 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(doubleArray68, doubleArray80);
        double double84 = discreteRealDistribution82.probability(0.0d);
        boolean boolean85 = discreteRealDistribution82.isSupportUpperBoundInclusive();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = well19937c1.nextGaussian();
        boolean boolean31 = well19937c1.nextBoolean();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-0.40892891016592103d) + "'", double30 == (-0.40892891016592103d));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 3);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray26);
        double[] doubleArray33 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray39 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray33, doubleArray39);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40);
        double[] doubleArray47 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray53 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray47, doubleArray53);
        double double55 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray40, doubleArray53);
        double double56 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray26, doubleArray53);
        double[] doubleArray62 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray68 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray62, doubleArray68);
        double[] doubleArray75 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray81 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray82 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray75, doubleArray81);
        double[] doubleArray83 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray82);
        double double84 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray69, doubleArray83);
        double double85 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray83);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution86 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(doubleArray26, doubleArray83);
        double[] doubleArray87 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray83);
        double[] doubleArray89 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray87, (int) (byte) 100);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection90 = null;
        try {
            boolean boolean92 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray87, orderDirection90, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1012010.0d + "'", double55 == 1012010.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 9900.0d + "'", double56 == 9900.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 10001.504886765792d + "'", double85 == 10001.504886765792d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 10);
        double double2 = well19937c1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.40877566087838346d + "'", double2 == 0.40877566087838346d);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextInt((int) (byte) -1, (int) (short) 10);
//        java.lang.String str5 = randomDataGenerator0.nextHexString((int) (byte) 10);
//        try {
//            double double8 = randomDataGenerator0.nextUniform(328552.22402481775d, 3.1362296620555803d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (328,552.224) must be strictly less than upper bound (3.136)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "351b3c8660" + "'", str5.equals("351b3c8660"));
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        double double2 = randomDataGenerator0.nextT((double) (short) 10);
//        double double4 = randomDataGenerator0.nextChiSquare((double) 0.23953891f);
//        double double7 = randomDataGenerator0.nextGaussian((double) 10L, 0.009699321047526674d);
//        int int10 = randomDataGenerator0.nextInt((int) (byte) 0, (int) ' ');
//        double double14 = randomDataGenerator0.nextUniform((double) 0.0f, (double) 10L, false);
//        long long16 = randomDataGenerator0.nextPoisson(0.15305822040981495d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.3751174330960012d) + "'", double2 == (-1.3751174330960012d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 9.997852492206428d + "'", double7 == 9.997852492206428d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.757815886322547d + "'", double14 == 4.757815886322547d);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextInt((int) (byte) -1, (int) (short) 10);
//        java.lang.String str5 = randomDataGenerator0.nextHexString((int) (byte) 10);
//        randomDataGenerator0.reSeedSecure(0L);
//        double double10 = randomDataGenerator0.nextUniform((-3.913170299716576d), 42.23873472118208d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "b3c4f0a42e" + "'", str5.equals("b3c4f0a42e"));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 15.300986898775577d + "'", double10 == 15.300986898775577d);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        well19937c1.setSeed((int) (byte) -1);
        float float79 = well19937c1.nextFloat();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + float79 + "' != '" + 0.47397482f + "'", float79 == 0.47397482f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.Well19937c well19937c9 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c9);
        int[] intArray14 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c9.setSeed(intArray14);
        double double16 = org.apache.commons.math3.util.MathArrays.distance(intArray6, intArray14);
        org.apache.commons.math3.random.Well19937c well19937c17 = new org.apache.commons.math3.random.Well19937c(intArray6);
        double double18 = well19937c17.nextDouble();
        boolean boolean19 = well19937c17.nextBoolean();
        boolean boolean20 = well19937c17.nextBoolean();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.12362632919669392d + "'", double18 == 0.12362632919669392d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable3, (java.lang.Number) (short) -1, objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable2, objArray8);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 0.23953891f, objArray8);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 0.5982021689405124d, objArray8);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 10.0d);
        java.lang.Number number2 = notPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 25);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 25 + "'", int3 == 25);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        double double77 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray15);
        double[] doubleArray79 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray15, 42.2263536812546d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 10001.504886765792d + "'", double77 == 10001.504886765792d);
        org.junit.Assert.assertNotNull(doubleArray79);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        double double77 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray15);
        double[] doubleArray78 = null;
        try {
            org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution79 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(doubleArray15, doubleArray78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 10001.504886765792d + "'", double77 == 10001.504886765792d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (short) 10, (int) (byte) 10);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) (byte) 1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
        boolean boolean34 = discreteRealDistributionPair32.equals((java.lang.Object) (-1));
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution35 = discreteRealDistributionPair32.getKey();
        boolean boolean37 = discreteRealDistributionPair32.equals((java.lang.Object) (-1.0f));
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution38 = discreteRealDistributionPair32.getKey();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(discreteRealDistribution35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(discreteRealDistribution38);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeedSecure((long) (short) 0);
        randomDataImpl8.reSeedSecure();
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (short) 100, (int) (short) 10);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 463846793, (java.lang.Number) 64L, (java.lang.Number) 729.5798911980672d);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        double double2 = randomDataGenerator0.nextT((double) (short) 10);
//        double double4 = randomDataGenerator0.nextT(0.1845842603151447d);
//        int int7 = randomDataGenerator0.nextInt(14, 32);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.6947780131498877d) + "'", double2 == (-1.6947780131498877d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6351122299299421d + "'", double4 == 0.6351122299299421d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 14 + "'", int7 == 14);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) 0);
        try {
            int int5 = randomDataGenerator0.nextBinomial(530971062, 33.817840312133065d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 33.818 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        well19937c1.setSeed((long) (short) 10);
        org.junit.Assert.assertNotNull(intArray6);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeed((long) (short) 1);
//        randomDataGenerator0.reSeed();
//        double double5 = randomDataGenerator0.nextExponential(9900.0d);
//        long long8 = randomDataGenerator0.nextSecureLong((long) (byte) -1, 0L);
//        try {
//            int int11 = randomDataGenerator0.nextSecureInt((int) (byte) 10, 7);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10) must be strictly less than upper bound (7)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2724.148545444856d + "'", double5 == 2724.148545444856d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 2.7748698967446392E10d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            int int12 = randomDataGenerator8.nextHypergeometric(14, 1394374653, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (1,394,374,653) must be less than or equal to population size (14)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
        try {
            double double35 = discreteRealDistribution29.probability((double) 0.6642053f, (-1.1638537524704287d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (0.664) must be less than or equal to upper endpoint (-1.164)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        double double32 = discreteRealDistribution29.density((double) (short) 0);
        discreteRealDistribution29.reseedRandomGenerator((long) 8);
        double double36 = discreteRealDistribution29.inverseCumulativeProbability(0.2441728446604158d);
        try {
            double double38 = discreteRealDistribution29.inverseCumulativeProbability(1012010.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 1,012,010 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 99.99999885042723d + "'", double36 == 99.99999885042723d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 10000.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 38272.39835306744d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray6 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        org.apache.commons.math3.random.Well19937c well19937c11 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c11.clear();
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray31 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray37 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray31, doubleArray37);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution39 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c11, doubleArray18, doubleArray38);
        double double40 = discreteRealDistribution39.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError41 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair42 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution39, (java.lang.IllegalStateException) mathInternalError41);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution43 = discreteRealDistributionPair42.getKey();
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution44 = discreteRealDistributionPair42.getFirst();
        double double45 = randomDataImpl9.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) discreteRealDistribution44);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 100.0d + "'", double40 == 100.0d);
        org.junit.Assert.assertNotNull(discreteRealDistribution43);
        org.junit.Assert.assertNotNull(discreteRealDistribution44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 99.99999849535078d + "'", double45 == 99.99999849535078d);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextInt((int) (byte) -1, (int) (short) 10);
//        java.lang.String str5 = randomDataGenerator0.nextHexString((int) (byte) 10);
//        randomDataGenerator0.reSeedSecure(0L);
//        java.lang.String str9 = randomDataGenerator0.nextHexString((int) '4');
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ae05831a25" + "'", str5.equals("ae05831a25"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "b52eec3864b3ff56084772a445fb9da9a5654af9f6a46048e796" + "'", str9.equals("b52eec3864b3ff56084772a445fb9da9a5654af9f6a46048e796"));
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 2280503348615191882L, (java.lang.Number) 3, true);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException7 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable1, (java.lang.Number) (short) -1, objArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray6);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = mathIllegalStateException8.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = mathIllegalStateException8.getContext();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(exceptionContext10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray26);
        double[] doubleArray33 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray39 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray33, doubleArray39);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40);
        double[] doubleArray47 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray53 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray47, doubleArray53);
        double double55 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray40, doubleArray53);
        double double56 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray26, doubleArray53);
        double[] doubleArray62 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray68 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray62, doubleArray68);
        double[] doubleArray75 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray81 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray82 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray75, doubleArray81);
        double[] doubleArray83 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray82);
        double double84 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray69, doubleArray83);
        double double85 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray83);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution86 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(doubleArray26, doubleArray83);
        double[] doubleArray88 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray83, (-90.62321083509698d));
        double double89 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1012010.0d + "'", double55 == 1012010.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 9900.0d + "'", double56 == 9900.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 10001.504886765792d + "'", double85 == 10001.504886765792d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 10001.504886765792d + "'", double89 == 10001.504886765792d);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int int5 = randomDataImpl2.nextSecureInt((int) (byte) -1, (int) (byte) 10);
//        double double7 = randomDataImpl2.nextT(25.94170504848563d);
//        try {
//            randomDataImpl2.setSecureAlgorithm("hi!", "0");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 0");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.460059626405916d) + "'", double7 == (-0.460059626405916d));
//    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) (short) 1);
//        double double5 = randomDataImpl0.nextBeta((double) 10.0f, (double) '4');
//        double double7 = randomDataImpl0.nextChiSquare(38385.006112067575d);
//        double double10 = randomDataImpl0.nextGamma((double) '4', (double) 14);
//        java.lang.String str12 = randomDataImpl0.nextHexString(99);
//        try {
//            int int15 = randomDataImpl0.nextInt(25, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (25) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6" + "'", str2.equals("6"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.13655141469813792d + "'", double5 == 0.13655141469813792d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 38185.053190360515d + "'", double7 == 38185.053190360515d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 696.8755918949311d + "'", double10 == 696.8755918949311d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "d67c0e9d0e2ec93c5ff3beb794767f44976163b52a9d965c4ae765a8a84ecd150d414cf74abd292b908712278703a203100" + "'", str12.equals("d67c0e9d0e2ec93c5ff3beb794767f44976163b52a9d965c4ae765a8a84ecd150d414cf74abd292b908712278703a203100"));
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeedSecure();
//        double double3 = randomDataGenerator0.nextChiSquare(39.525652590500485d);
//        randomDataGenerator0.reSeed();
//        try {
//            double double6 = randomDataGenerator0.nextChiSquare((-1.0d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-0.5)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 38.398077397290166d + "'", double3 == 38.398077397290166d);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        well19937c1.clear();
        int[] intArray7 = new int[] { (short) 0, 7, ' ' };
        well19937c1.setSeed(intArray7);
        double double9 = well19937c1.nextGaussian();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.7890639983076418d) + "'", double9 == (-0.7890639983076418d));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 0.0f);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray12 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.random.Well19937c well19937c16 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c16.clear();
        double[] doubleArray23 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray29 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray23, doubleArray29);
        double[] doubleArray36 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray42 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray36, doubleArray42);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution44 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c16, doubleArray23, doubleArray43);
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray13, doubleArray23);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray13, (-2.253205282766861d));
        try {
            double double48 = org.apache.commons.math3.util.MathArrays.distance(doubleArray0, doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextInt((int) (byte) -1, (int) (short) 10);
//        java.lang.String str5 = randomDataGenerator0.nextHexString((int) (byte) 10);
//        java.lang.String str7 = randomDataGenerator0.nextSecureHexString(7);
//        int[] intArray10 = randomDataGenerator0.nextPermutation((int) (short) 100, 100);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a307c25e4f" + "'", str5.equals("a307c25e4f"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "8c4148a" + "'", str7.equals("8c4148a"));
//        org.junit.Assert.assertNotNull(intArray10);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1054269.6159652844d, (java.lang.Number) 2280503348615191882L, (int) 'a');
        int int4 = nonMonotonicSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) (short) 1);
//        double double5 = randomDataImpl0.nextBeta((double) 10.0f, (double) '4');
//        double double7 = randomDataImpl0.nextChiSquare(38385.006112067575d);
//        double double10 = randomDataImpl0.nextGamma((double) '4', (double) 14);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5" + "'", str2.equals("5"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08096121532093209d + "'", double5 == 0.08096121532093209d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 38011.69819126901d + "'", double7 == 38011.69819126901d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 599.5082356384979d + "'", double10 == 599.5082356384979d);
//    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int3 = randomDataGenerator0.nextZipf((int) (short) 10, (double) ' ');
//        double double6 = randomDataGenerator0.nextGaussian(10.0d, 105.42696159652844d);
//        int int9 = randomDataGenerator0.nextSecureInt(8, 35);
//        randomDataGenerator0.reSeedSecure(5988793534754658721L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-199.09436590417718d) + "'", double6 == (-199.09436590417718d));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 23 + "'", int9 == 23);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = mathArithmeticException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-106.42696159652844d), (java.lang.Number) 64L, (int) (byte) 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double[] doubleArray5 = new double[] { (byte) 1, (-2.454354035192198d), ' ', 100L, 100.0f };
        double[] doubleArray11 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray17 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray11, doubleArray17);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray5, doubleArray18);
        double[] doubleArray26 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray32 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray26, doubleArray32);
        double[] doubleArray39 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray45 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray45);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray46);
        double double48 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray33, doubleArray47);
        double[] doubleArray54 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray60 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray54, doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray61);
        double[] doubleArray68 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray74 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray68, doubleArray74);
        double double76 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray61, doubleArray74);
        double double77 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray47, doubleArray74);
        double[] doubleArray78 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray18, doubleArray74);
        double[] doubleArray84 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray90 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray91 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray84, doubleArray90);
        double[] doubleArray93 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray91, (double) '#');
        double double94 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray18, doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1012010.0d + "'", double76 == 1012010.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 9900.0d + "'", double77 == 9900.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 1.000301E8d + "'", double94 == 1.000301E8d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        double double32 = discreteRealDistribution29.density((double) (short) 0);
        discreteRealDistribution29.reseedRandomGenerator((long) 8);
        double double36 = discreteRealDistribution29.inverseCumulativeProbability(0.2441728446604158d);
        boolean boolean37 = discreteRealDistribution29.isSupportUpperBoundInclusive();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 99.99999885042723d + "'", double36 == 99.99999885042723d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 1.6383254778327327d, (java.lang.Number) 2.652745825556842d, (java.lang.Number) 8.996488039729147d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(1.0E-6d, 10.0d, (double) 0.47397482f, 2.3438407852575533d, 844.759715891043d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 84477.08252062787d + "'", double6 == 84477.08252062787d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.9724196550669874d), 9.997852492206428d, 9900.822238582006d, 0.6351122299299421d, 0.009699321047526674d, 38011.69819126901d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6647.098846132704d + "'", double6 == 6647.098846132704d);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextSecureInt((-1), (int) (byte) 100);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray6 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c1.setSeed(intArray6);
        double[] doubleArray13 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray19 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray13, doubleArray19);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray33 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray27, doubleArray33);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34);
        org.apache.commons.math3.random.Well19937c well19937c37 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c37.clear();
        double[] doubleArray44 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray50 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray44, doubleArray50);
        double[] doubleArray57 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray63 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray57, doubleArray63);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution65 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c37, doubleArray44, doubleArray64);
        boolean boolean66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray34, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution67 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray21, doubleArray34);
        double[] doubleArray68 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray68, (double) (short) 10);
        double[] doubleArray71 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray70);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.lang.String[] strArray3 = new java.lang.String[] { "1", "6", "d46543f007103015639091102cf419ed924aa9f7cd876c5941f8b7822b22c47eeefb3d15633b49bb034e27fe6a3d14f76f5b" };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection7, false);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray3, orderDirection7, true);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection15 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException17 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection15, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection21 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException23 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection21, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection24 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException28 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 0.0f, 0);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection29 = nonMonotonicSequenceException28.getDirection();
        org.apache.commons.math3.util.MathArrays.OrderDirection[] orderDirectionArray30 = new org.apache.commons.math3.util.MathArrays.OrderDirection[] { orderDirection15, orderDirection21, orderDirection24, orderDirection29 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection34 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException36 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection34, false);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.isMonotonic(orderDirectionArray30, orderDirection34, false);
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray3, orderDirection34, true);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(orderDirectionArray30);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 3);
        java.lang.Throwable[] throwableArray2 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int int5 = randomDataImpl2.nextSecureInt((int) (byte) -1, (int) (byte) 10);
//        double double7 = randomDataImpl2.nextT(25.94170504848563d);
//        org.apache.commons.math3.random.Well19937c well19937c9 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        well19937c9.clear();
//        double[] doubleArray16 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
//        double[] doubleArray22 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
//        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray16, doubleArray22);
//        double[] doubleArray29 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
//        double[] doubleArray35 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
//        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray29, doubleArray35);
//        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution37 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c9, doubleArray16, doubleArray36);
//        double double40 = discreteRealDistribution37.cumulativeProbability((double) 0, 0.0013733592917636712d);
//        boolean boolean41 = discreteRealDistribution37.isSupportLowerBoundInclusive();
//        double double42 = randomDataImpl2.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) discreteRealDistribution37);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.460059626405916d) + "'", double7 == (-0.460059626405916d));
//        org.junit.Assert.assertNotNull(doubleArray16);
//        org.junit.Assert.assertNotNull(doubleArray22);
//        org.junit.Assert.assertNotNull(doubleArray23);
//        org.junit.Assert.assertNotNull(doubleArray29);
//        org.junit.Assert.assertNotNull(doubleArray35);
//        org.junit.Assert.assertNotNull(doubleArray36);
//        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.util.ArrayList<org.apache.commons.math3.util.Pair<java.lang.CharSequence, java.lang.Double>> charSequencePairList0 = new java.util.ArrayList<org.apache.commons.math3.util.Pair<java.lang.CharSequence, java.lang.Double>>();
        try {
            org.apache.commons.math3.distribution.DiscreteDistribution<java.lang.CharSequence> charSequenceDiscreteDistribution1 = new org.apache.commons.math3.distribution.DiscreteDistribution<java.lang.CharSequence>((java.util.List<org.apache.commons.math3.util.Pair<java.lang.CharSequence, java.lang.Double>>) charSequencePairList0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        well19937c1.clear();
        float float4 = well19937c1.nextFloat();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double7 = randomDataGenerator5.nextExponential((double) 7);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.32465303f + "'", float4 == 0.32465303f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 9.249717141732795d + "'", double7 == 9.249717141732795d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        long[] longArray0 = new long[] {};
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray0);
        org.junit.Assert.assertNotNull(longArray0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        int[] intArray0 = null;
        org.apache.commons.math3.random.Well19937c well19937c2 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c2);
        int[] intArray7 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c2.setSeed(intArray7);
        int[] intArray9 = org.apache.commons.math3.util.MathArrays.copyOf(intArray7);
        org.apache.commons.math3.random.Well19937c well19937c11 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c11);
        int[] intArray16 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c11.setSeed(intArray16);
        org.apache.commons.math3.random.Well19937c well19937c19 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c19);
        int[] intArray24 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c19.setSeed(intArray24);
        double double26 = org.apache.commons.math3.util.MathArrays.distance(intArray16, intArray24);
        double double27 = org.apache.commons.math3.util.MathArrays.distance(intArray7, intArray24);
        org.apache.commons.math3.random.Well19937c well19937c29 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl30 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c29);
        int[] intArray34 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c29.setSeed(intArray34);
        int[] intArray36 = org.apache.commons.math3.util.MathArrays.copyOf(intArray34);
        int[] intArray41 = new int[] { 25, ' ', 1, 25 };
        int int42 = org.apache.commons.math3.util.MathArrays.distance1(intArray34, intArray41);
        int int43 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray7, intArray41);
        try {
            double double44 = org.apache.commons.math3.util.MathArrays.distance(intArray0, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 174 + "'", int42 == 174);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 75 + "'", int43 == 75);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException4 = new org.apache.commons.math3.exception.NullArgumentException();
        double[] doubleArray10 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray16 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray10, doubleArray16);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17);
        double[] doubleArray24 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray30 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray24, doubleArray30);
        double double32 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray17, doubleArray30);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator33 = new org.apache.commons.math3.random.RandomDataGenerator();
        java.lang.Object[] objArray34 = new java.lang.Object[] { nullArgumentException4, doubleArray17, randomDataGenerator33 };
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException35 = new org.apache.commons.math3.exception.NullArgumentException(localizable3, objArray34);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException36 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (short) 0, objArray34);
        org.apache.commons.math3.exception.MathInternalError mathInternalError37 = new org.apache.commons.math3.exception.MathInternalError(localizable1, objArray34);
        org.apache.commons.math3.exception.MathInternalError mathInternalError38 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray34);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1012010.0d + "'", double32 == 1012010.0d);
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        well19937c1.clear();
        float float4 = well19937c1.nextFloat();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double6 = well19937c1.nextGaussian();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.32465303f + "'", float4 == 0.32465303f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.7990429217424768d) + "'", double6 == (-0.7990429217424768d));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) 10, (java.lang.Number) 9, (java.lang.Number) 33.147804419160714d);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = outOfRangeException4.getContext();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 33.147804419160714d + "'", number6.equals(33.147804419160714d));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        well19937c1.clear();
        float float4 = well19937c1.nextFloat();
        int int5 = well19937c1.nextInt();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.32465303f + "'", float4 == 0.32465303f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1748310433 + "'", int5 == 1748310433);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double6 = randomDataImpl2.nextUniform(0.0d, 1012010.0d, false);
        double double8 = randomDataImpl2.nextExponential(31.931273192771652d);
        try {
            int int11 = randomDataImpl2.nextInt(3, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (3) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 328552.22402481775d + "'", double6 == 328552.22402481775d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.486570954085975d + "'", double8 == 10.486570954085975d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray26);
        java.lang.String[] strArray31 = new java.lang.String[] { "1", "6", "d46543f007103015639091102cf419ed924aa9f7cd876c5941f8b7822b22c47eeefb3d15633b49bb034e27fe6a3d14f76f5b" };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection35 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException37 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection35, false);
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray31, orderDirection35, true);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray26, orderDirection35, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not increasing (10,000 > 100)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.String[] strArray5 = new java.lang.String[] { "1", "6", "d46543f007103015639091102cf419ed924aa9f7cd876c5941f8b7822b22c47eeefb3d15633b49bb034e27fe6a3d14f76f5b" };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection9 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection9, false);
        boolean boolean13 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray5, orderDirection9, true);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) (short) 0, (java.lang.Object[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl2.reSeedSecure();
        try {
            double double6 = randomDataImpl2.nextGamma(2.4379925812719248E-5d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException8 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection6, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection12 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection12, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection15 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException19 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 0.0f, 0);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection20 = nonMonotonicSequenceException19.getDirection();
        org.apache.commons.math3.util.MathArrays.OrderDirection[] orderDirectionArray21 = new org.apache.commons.math3.util.MathArrays.OrderDirection[] { orderDirection6, orderDirection12, orderDirection15, orderDirection20 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection25 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException27 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection25, false);
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.isMonotonic(orderDirectionArray21, orderDirection25, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException31 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 81.35173968711932d, (java.lang.Number) (-7187591), 100, orderDirection25, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(orderDirectionArray21);
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 42.63446096761888d, (java.lang.Number) 9.347883475356515d, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 9.347883475356515d + "'", number4.equals(9.347883475356515d));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((-3970.9271635532823d), 31.931273192771652d, 0.09294902424688352d, 1.0d, 3.136469916217921d, 0.9493594565810611d, (double) 100L, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-126693.68950161821d) + "'", double8 == (-126693.68950161821d));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray12 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray12);
        double[] doubleArray19 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray25 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray19, doubleArray25);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        double double28 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray13, doubleArray27);
        double[] doubleArray34 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray40 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray34, doubleArray40);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41);
        double[] doubleArray48 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray54 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray48, doubleArray54);
        double double56 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray41, doubleArray54);
        double double57 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray27, doubleArray54);
        double[] doubleArray63 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray69 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray63, doubleArray69);
        double[] doubleArray76 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray82 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray83 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray76, doubleArray82);
        double[] doubleArray84 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray83);
        double double85 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray70, doubleArray84);
        double double86 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray84);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution87 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(doubleArray27, doubleArray84);
        double[] doubleArray89 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray84, (-90.62321083509698d));
        boolean boolean90 = org.apache.commons.math3.util.MathArrays.equals(doubleArray0, doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1012010.0d + "'", double56 == 1012010.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 9900.0d + "'", double57 == 9900.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 10001.504886765792d + "'", double86 == 10001.504886765792d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) (short) 1);
//        double double5 = randomDataImpl0.nextBeta((double) 10.0f, (double) '4');
//        double double8 = randomDataImpl0.nextGaussian((-106.42696159652844d), 100.0d);
//        double double11 = randomDataImpl0.nextUniform((double) 1L, (double) '#');
//        randomDataImpl0.reSeedSecure((long) (-1));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6" + "'", str2.equals("6"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.1324893915945104d + "'", double5 == 0.1324893915945104d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 33.6058863711542d + "'", double8 == 33.6058863711542d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 30.67653712453701d + "'", double11 == 30.67653712453701d);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeedSecure((long) (short) 0);
        int[] intArray13 = randomDataImpl8.nextPermutation(52, 8);
        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution14 = null;
        try {
            int int15 = randomDataImpl8.nextInversionDeviate(integerDistribution14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(22.981618453278884d, (double) (short) 0, (double) 'a', (double) 10L, 47.49753257822645d, 0.03006789524733269d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 971.4281508340689d + "'", double6 == 971.4281508340689d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException36 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 0, (java.lang.Number) (short) 100, (int) (byte) 0);
        int int37 = nonMonotonicSequenceException36.getIndex();
        boolean boolean38 = discreteRealDistributionPair32.equals((java.lang.Object) nonMonotonicSequenceException36);
        boolean boolean40 = discreteRealDistributionPair32.equals((java.lang.Object) "037ac0bc91eaf7c3da6a9f948d8c9034");
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 0, (java.lang.Number) 0.30955021719333553d, (java.lang.Number) 10);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException();
        double[] doubleArray13 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray19 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray13, doubleArray19);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray33 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray27, doubleArray33);
        double double35 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray20, doubleArray33);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator36 = new org.apache.commons.math3.random.RandomDataGenerator();
        java.lang.Object[] objArray37 = new java.lang.Object[] { nullArgumentException7, doubleArray20, randomDataGenerator36 };
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException38 = new org.apache.commons.math3.exception.NullArgumentException(localizable6, objArray37);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException39 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (short) 0, objArray37);
        java.lang.Throwable[] throwableArray40 = notFiniteNumberException39.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException3, localizable4, (java.lang.Object[]) throwableArray40);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 100L, (java.lang.Number) 100.0f, (java.lang.Number) (short) -1);
        java.lang.Number number46 = outOfRangeException45.getLo();
        mathIllegalStateException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException51 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 0.0f, 0);
        outOfRangeException45.addSuppressed((java.lang.Throwable) nonMonotonicSequenceException51);
        java.lang.Number number53 = nonMonotonicSequenceException51.getPrevious();
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1012010.0d + "'", double35 == 1012010.0d);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 100.0f + "'", number46.equals(100.0f));
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 0.0f + "'", number53.equals(0.0f));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray11 = randomDataImpl8.nextPermutation(271, 75);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (-1L));
        java.lang.Number number2 = notPositiveException1.getArgument();
        boolean boolean3 = notPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (-1L) + "'", number2.equals((-1L)));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution33 = discreteRealDistributionPair32.getKey();
        double double34 = discreteRealDistribution33.getNumericalMean();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertNotNull(discreteRealDistribution33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 97.2065955383123d + "'", double34 == 97.2065955383123d);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        double double2 = randomDataGenerator0.nextT((double) (short) 10);
//        double double4 = randomDataGenerator0.nextT(0.1845842603151447d);
//        double double6 = randomDataGenerator0.nextChiSquare(0.05126582292753777d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2251547770650185d + "'", double2 == 0.2251547770650185d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.793749153796434E8d + "'", double4 == 1.793749153796434E8d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.7697301603958806E-4d + "'", double6 == 4.7697301603958806E-4d);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        double double32 = discreteRealDistribution29.density((double) 7);
        double double33 = discreteRealDistribution29.sample();
        double[] doubleArray35 = discreteRealDistribution29.sample((int) '4');
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl2.reSeedSecure();
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int int5 = randomDataImpl2.nextSecureInt((int) (byte) -1, (int) (byte) 10);
//        double double7 = randomDataImpl2.nextT(25.94170504848563d);
//        double double10 = randomDataImpl2.nextCauchy(25.495620149117958d, 0.15305822040981495d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.460059626405916d) + "'", double7 == (-0.460059626405916d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 25.582417307036252d + "'", double10 == 25.582417307036252d);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        double double32 = discreteRealDistribution29.density((double) 7);
        double double33 = discreteRealDistribution29.sample();
        double double36 = discreteRealDistribution29.probability((-2.0d), 1.6383254778327327d);
        double double37 = discreteRealDistribution29.getSupportUpperBound();
        try {
            double double39 = discreteRealDistribution29.inverseCumulativeProbability((double) 19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 19 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.009699321047526674d + "'", double36 == 0.009699321047526674d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
//        well19937c1.setSeed(intArray6);
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        java.lang.String str11 = randomDataGenerator9.nextSecureHexString((int) 'a');
//        long long13 = randomDataGenerator9.nextPoisson(6157.48895650758d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "b7708c5c9872ca04d9ba1d452e71437cf9132bec8576236cd11fdbef9c3f8a2ade91c8d437376deabc153719c4baf4f14" + "'", str11.equals("b7708c5c9872ca04d9ba1d452e71437cf9132bec8576236cd11fdbef9c3f8a2ade91c8d437376deabc153719c4baf4f14"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 6083L + "'", long13 == 6083L);
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) (short) 10);
        java.lang.Number number3 = notPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double32 = discreteRealDistribution29.cumulativeProbability((double) 0, 0.0013733592917636712d);
        boolean boolean33 = discreteRealDistribution29.isSupportUpperBoundInclusive();
        double[] doubleArray35 = discreteRealDistribution29.sample((int) '4');
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        double double6 = randomDataImpl2.nextUniform(0.0d, 1012010.0d, false);
//        randomDataImpl2.reSeed((long) (short) 0);
//        randomDataImpl2.reSeedSecure();
//        long long12 = randomDataImpl2.nextSecureLong((long) (byte) 0, (long) 35);
//        try {
//            randomDataImpl2.setSecureAlgorithm("a307c25e4f", "ae05831a25");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: ae05831a25");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 328552.22402481775d + "'", double6 == 328552.22402481775d);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 27L + "'", long12 == 27L);
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (short) 1);
        long long4 = randomDataGenerator0.nextPoisson(0.12362632919669392d);
        double double7 = randomDataGenerator0.nextF(9.814901400173909d, 0.1845842603151447d);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 11.468116518815359d + "'", double7 == 11.468116518815359d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        float[] floatArray0 = null;
        float[] floatArray2 = new float[] { 100.0f };
        float[] floatArray7 = new float[] { (-1), (-1L), (byte) 1, 10L };
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray2, floatArray7);
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(floatArray0, floatArray2);
        float[] floatArray11 = new float[] { 100.0f };
        float[] floatArray16 = new float[] { (-1), (-1L), (byte) 1, 10L };
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray11, floatArray16);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equals(floatArray2, floatArray16);
        float[] floatArray25 = new float[] { 32, 1L, 8, 1394374653, 3, 5988793534754658721L };
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(floatArray2, floatArray25);
        float[] floatArray27 = null;
        float[] floatArray29 = new float[] { 100.0f };
        float[] floatArray34 = new float[] { (-1), (-1L), (byte) 1, 10L };
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray29, floatArray34);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equals(floatArray27, floatArray29);
        float[] floatArray38 = new float[] { 100.0f };
        float[] floatArray43 = new float[] { (-1), (-1L), (byte) 1, 10L };
        boolean boolean44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray38, floatArray43);
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equals(floatArray29, floatArray43);
        float[] floatArray52 = new float[] { 32, 1L, 8, 1394374653, 3, 5988793534754658721L };
        boolean boolean53 = org.apache.commons.math3.util.MathArrays.equals(floatArray29, floatArray52);
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equals(floatArray2, floatArray52);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeedSecure((long) (short) 0);
        int[] intArray13 = randomDataImpl8.nextPermutation(52, 8);
        int int17 = randomDataImpl8.nextHypergeometric(414070727, 6, (int) (byte) 1);
        double double20 = randomDataImpl8.nextUniform(0.009699321047526674d, 9.347883475356515d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 7.237424968505257d + "'", double20 == 7.237424968505257d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable4, (java.lang.Number) (short) -1, objArray9);
        org.apache.commons.math3.exception.MathInternalError mathInternalError11 = new org.apache.commons.math3.exception.MathInternalError(localizable3, objArray9);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable1, (java.lang.Number) 328552.22402481775d, objArray9);
        org.apache.commons.math3.exception.MathInternalError mathInternalError13 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray9);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int5 = randomDataImpl2.nextBinomial((int) (byte) 1, (double) 0);
        int int8 = randomDataImpl2.nextZipf((int) 'a', (double) (short) 10);
        long long10 = randomDataImpl2.nextPoisson(0.009699321047526674d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray6 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray6);
        org.apache.commons.math3.random.Well19937c well19937c9 = new org.apache.commons.math3.random.Well19937c(intArray6);
        int[] intArray11 = org.apache.commons.math3.util.MathArrays.copyOf(intArray6, 23);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        float float2 = well19937c1.nextFloat();
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        byte[] byteArray7 = new byte[] { (byte) 100, (byte) 10 };
        well19937c4.nextBytes(byteArray7);
        well19937c1.nextBytes(byteArray7);
        int int11 = well19937c1.nextInt(174);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.23953891f + "'", float2 == 0.23953891f);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 124 + "'", int11 == 124);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            randomDataImpl8.setSecureAlgorithm("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)", "b7708c5c9872ca04d9ba1d452e71437cf9132bec8576236cd11fdbef9c3f8a2ade91c8d437376deabc153719c4baf4f14");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: b7708c5c9872ca04d9ba1d452e71437cf9132bec8576236cd11fdbef9c3f8a2ade91c8d437376deabc153719c4baf4f14");
        } catch (java.security.NoSuchProviderException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 10.560703567075805d, (java.lang.Number) 1L, true);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) (short) 1);
//        double double5 = randomDataImpl0.nextBeta((double) 10.0f, (double) '4');
//        double double8 = randomDataImpl0.nextGaussian((-106.42696159652844d), 100.0d);
//        double double11 = randomDataImpl0.nextGamma((double) (byte) 1, (double) '4');
//        long long13 = randomDataImpl0.nextPoisson(39.525652590500485d);
//        randomDataImpl0.reSeedSecure(5988793534754658721L);
//        try {
//            double double18 = randomDataImpl0.nextWeibull(0.0d, (double) 2280503348615191882L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "b" + "'", str2.equals("b"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.18321268285757622d + "'", double5 == 0.18321268285757622d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-134.0108384509359d) + "'", double8 == (-134.0108384509359d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.35312443614148d + "'", double11 == 8.35312443614148d);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        float[] floatArray0 = null;
        org.apache.commons.math3.random.Well19937c well19937c2 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c2);
        double[] doubleArray9 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray15 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray9, doubleArray15);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        org.apache.commons.math3.random.Well19937c well19937c19 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c19.clear();
        double[] doubleArray26 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray32 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray26, doubleArray32);
        double[] doubleArray39 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray45 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray45);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c19, doubleArray26, doubleArray46);
        boolean boolean48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray16, doubleArray26);
        double[] doubleArray54 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray60 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray54, doubleArray60);
        double[] doubleArray67 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray73 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray67, doubleArray73);
        double[] doubleArray75 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray74);
        double double76 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray61, doubleArray75);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution77 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c2, doubleArray16, doubleArray61);
        double[] doubleArray79 = discreteRealDistribution77.sample((int) '4');
        double[] doubleArray80 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray79);
        org.apache.commons.math3.util.Pair<float[], double[]> floatArrayPair81 = new org.apache.commons.math3.util.Pair<float[], double[]>(floatArray0, doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable6, (java.lang.Number) (short) -1, objArray11);
        org.apache.commons.math3.exception.MathInternalError mathInternalError13 = new org.apache.commons.math3.exception.MathInternalError(localizable5, objArray11);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable3, (java.lang.Number) 328552.22402481775d, objArray11);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable2, objArray11);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException16 = new org.apache.commons.math3.exception.MathArithmeticException(localizable1, objArray11);
        org.apache.commons.math3.exception.MathInternalError mathInternalError17 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray11);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double6 = randomDataImpl2.nextUniform(0.0d, 1012010.0d, false);
        randomDataImpl2.reSeed((long) (short) 0);
        randomDataImpl2.reSeedSecure();
        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution10 = null;
        try {
            int int11 = randomDataImpl2.nextInversionDeviate(integerDistribution10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 328552.22402481775d + "'", double6 == 328552.22402481775d);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
//        well19937c1.setSeed(intArray6);
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
//        java.lang.String str11 = randomDataGenerator9.nextSecureHexString((int) 'a');
//        try {
//            double double14 = randomDataGenerator9.nextUniform(0.9493594565810611d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0.949) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "295b245a1dd50ca4e17338050868bcee76527585ddfb5ef69f8cc54286a370b37672dc3598bf75db4146f079f869fa7e7" + "'", str11.equals("295b245a1dd50ca4e17338050868bcee76527585ddfb5ef69f8cc54286a370b37672dc3598bf75db4146f079f869fa7e7"));
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) 0);
        try {
            double double4 = randomDataGenerator0.nextChiSquare(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.21812369031296122d, (double) 25, (-0.7890639983076418d), 0.6351122299299421d, 26.56353953166036d, (-111.1476792949898d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-2947.5238247424677d) + "'", double6 == (-2947.5238247424677d));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric(530971062, 5, 2);
        try {
            double double9 = randomDataImpl2.nextUniform(10.560703567075805d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10.561) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (short) 1);
        try {
            double double4 = randomDataGenerator0.nextT((-2.454354035192198d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-2.454)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-9.304958371878295E7d), (java.lang.Number) 1220434243L, false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        double double79 = discreteRealDistribution76.cumulativeProbability(0.21812369031296122d, (double) 4L);
        boolean boolean80 = discreteRealDistribution76.isSupportConnected();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0, (java.lang.Number) (-1.0f));
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0f) + "'", number4.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 0 + "'", number5.equals((byte) 0));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        discreteRealDistribution76.reseedRandomGenerator((long) 'a');
        double double79 = discreteRealDistribution76.getNumericalMean();
        double double82 = discreteRealDistribution76.cumulativeProbability(0.12362632919669392d, (double) 2280503348615191882L);
        boolean boolean83 = discreteRealDistribution76.isSupportConnected();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 9702.240543161977d + "'", double79 == 9702.240543161977d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.0d + "'", double82 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 1054269.6159652844d);
        try {
            java.lang.String str3 = notPositiveException2.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataGenerator8.reSeedSecure((long) 5);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, number1, (java.lang.Number) 9, (java.lang.Number) 9900.822238582006d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray15 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray21 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray15, doubleArray21);
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22);
        org.apache.commons.math3.random.Well19937c well19937c25 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c25.clear();
        double[] doubleArray32 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray38 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray32, doubleArray38);
        double[] doubleArray45 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray51 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray52 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray45, doubleArray51);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution53 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c25, doubleArray32, doubleArray52);
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray22, doubleArray32);
        org.apache.commons.math3.random.Well19937c well19937c56 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c56.clear();
        double[] doubleArray63 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray69 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray63, doubleArray69);
        double[] doubleArray76 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray82 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray83 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray76, doubleArray82);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution84 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c56, doubleArray63, doubleArray83);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution85 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray22, doubleArray83);
        well19937c1.clear();
        long long87 = well19937c1.nextLong();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 2280503348615191882L + "'", long87 == 2280503348615191882L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray6 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c1.setSeed(intArray6);
        double[] doubleArray13 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray19 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray13, doubleArray19);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray33 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray27, doubleArray33);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34);
        org.apache.commons.math3.random.Well19937c well19937c37 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c37.clear();
        double[] doubleArray44 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray50 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray44, doubleArray50);
        double[] doubleArray57 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray63 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray57, doubleArray63);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution65 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c37, doubleArray44, doubleArray64);
        boolean boolean66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray34, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution67 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray21, doubleArray34);
        double[] doubleArray68 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection72 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException74 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection72, false);
        double[][] doubleArray75 = new double[][] {};
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray21, orderDirection72, doubleArray75);
        org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray21);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + orderDirection72 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection72.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray75);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        well19937c1.clear();
        int[] intArray7 = new int[] { (short) 0, 7, ' ' };
        well19937c1.setSeed(intArray7);
        org.apache.commons.math3.random.Well19937c well19937c10 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray15 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c10.setSeed(intArray15);
        org.apache.commons.math3.random.Well19937c well19937c17 = new org.apache.commons.math3.random.Well19937c(intArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c(intArray15);
        int int19 = org.apache.commons.math3.util.MathArrays.distance1(intArray7, intArray15);
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        int[] intArray26 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c21.setSeed(intArray26);
        int[] intArray28 = org.apache.commons.math3.util.MathArrays.copyOf(intArray26);
        int[] intArray33 = new int[] { 25, ' ', 1, 25 };
        int int34 = org.apache.commons.math3.util.MathArrays.distance1(intArray26, intArray33);
        org.apache.commons.math3.random.Well19937c well19937c36 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl37 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c36);
        int[] intArray41 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c36.setSeed(intArray41);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl43 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c36);
        randomDataImpl43.reSeedSecure((long) (short) 0);
        int[] intArray48 = randomDataImpl43.nextPermutation(52, 8);
        int[] intArray55 = new int[] { (short) 1, 7, (short) 1, 100, 0, (byte) 100 };
        int[] intArray57 = org.apache.commons.math3.util.MathArrays.copyOf(intArray55, (int) 'a');
        int[] intArray58 = org.apache.commons.math3.util.MathArrays.copyOf(intArray57);
        int int59 = org.apache.commons.math3.util.MathArrays.distance1(intArray48, intArray58);
        int int60 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray33, intArray48);
        int int61 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray15, intArray33);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 42 + "'", int19 == 42);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 174 + "'", int34 == 174);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 271 + "'", int59 == 271);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 19 + "'", int60 == 19);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 33 + "'", int61 == 33);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray26);
        org.apache.commons.math3.random.Well19937c well19937c29 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray34 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c29.setSeed(intArray34);
        double[] doubleArray41 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray47 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray48 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray41, doubleArray47);
        double[] doubleArray49 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray48);
        double[] doubleArray55 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray61 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray61);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray62);
        org.apache.commons.math3.random.Well19937c well19937c65 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c65.clear();
        double[] doubleArray72 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray78 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray79 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray72, doubleArray78);
        double[] doubleArray85 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray91 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray92 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray85, doubleArray91);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution93 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c65, doubleArray72, doubleArray92);
        boolean boolean94 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray62, doubleArray72);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution95 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c29, doubleArray49, doubleArray62);
        double[] doubleArray96 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray49);
        double[] doubleArray97 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray26, doubleArray96);
        double[] doubleArray98 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertNotNull(doubleArray97);
        org.junit.Assert.assertNotNull(doubleArray98);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        float float11 = well19937c1.nextFloat();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.12362623f + "'", float11 == 0.12362623f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray26);
        org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 7.237424968505257d, (java.lang.Number) 0, 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = randomDataImpl2.nextHypergeometric((int) (short) 100, 100, (int) (byte) 10);
        double double8 = randomDataImpl2.nextChiSquare((double) 100);
        try {
            double double11 = randomDataImpl2.nextBeta(3.1362296620555803d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.595, 0.405]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 105.42696159652844d + "'", double8 == 105.42696159652844d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0, 124);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
        boolean boolean34 = discreteRealDistributionPair32.equals((java.lang.Object) (-1));
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution35 = discreteRealDistributionPair32.getKey();
        double double36 = discreteRealDistribution35.getSupportUpperBound();
        boolean boolean37 = discreteRealDistribution35.isSupportUpperBoundInclusive();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(discreteRealDistribution35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 100.0d + "'", double36 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeed((long) (short) 1);
//        long long4 = randomDataGenerator0.nextPoisson(0.12362632919669392d);
//        int int7 = randomDataGenerator0.nextInt(0, (int) (short) 10);
//        long long10 = randomDataGenerator0.nextSecureLong((long) (byte) 0, 1220434243L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 67317917L + "'", long10 == 67317917L);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100, '4', 100.0d };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable6, (java.lang.Number) (short) -1, objArray11);
        org.apache.commons.math3.exception.MathInternalError mathInternalError13 = new org.apache.commons.math3.exception.MathInternalError(localizable5, objArray11);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable3, (java.lang.Number) 328552.22402481775d, objArray11);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable2, objArray11);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException16 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 7.237424968505257d, objArray11);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 10 };
        well19937c1.nextBytes(byteArray4);
        int int6 = well19937c1.nextInt();
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1748310433 + "'", int6 == 1748310433);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (short) 1);
        randomDataGenerator0.reSeed();
        try {
            randomDataGenerator0.setSecureAlgorithm("bf5d6b565d89034d60a2c1e58714a953c3cc5fcd57e0b2941d4f", "6");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 6");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) (short) 1);
//        double double5 = randomDataImpl0.nextBeta((double) 10.0f, (double) '4');
//        double double8 = randomDataImpl0.nextGaussian((-106.42696159652844d), 100.0d);
//        double double12 = randomDataImpl0.nextUniform((double) (-1), 0.30955021719333553d, false);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "b" + "'", str2.equals("b"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.24273182813832292d + "'", double5 == 0.24273182813832292d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-89.18619508990221d) + "'", double8 == (-89.18619508990221d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.33899727054717527d) + "'", double12 == (-0.33899727054717527d));
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (-106.42696159652844d), (java.lang.Number) 10.0d, true);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0d + "'", number5.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double3 = well19937c1.nextDouble();
        long long4 = well19937c1.nextLong();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.07277703352123166d + "'", double3 == 0.07277703352123166d);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 6179557979701623951L + "'", long4 == 6179557979701623951L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0f, (java.lang.Number) 10L, true);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (short) 100, 97);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeedSecure((long) (short) 0);
        randomDataImpl8.reSeedSecure((long) (byte) 100);
        double double15 = randomDataImpl8.nextUniform((double) 9, 10000.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1244.150655004169d + "'", double15 == 1244.150655004169d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 11.306288201364886d, true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (-1.0f), (java.lang.Number) (-111.1476792949898d), false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-111.1476792949898d) + "'", number5.equals((-111.1476792949898d)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-111.1476792949898d) + "'", number6.equals((-111.1476792949898d)));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) 'a', 463846793);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        double double2 = randomDataGenerator0.nextT((double) (short) 10);
//        double double4 = randomDataGenerator0.nextChiSquare((double) 0.23953891f);
//        int int7 = randomDataGenerator0.nextZipf(35, 9.164146516064406d);
//        try {
//            double double10 = randomDataGenerator0.nextUniform((-0.7990429217424768d), (-9.304958371878295E7d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (-0.799) must be strictly less than upper bound (-93,049,583.719)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.579039145613508d + "'", double2 == 0.579039145613508d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        double double2 = randomDataGenerator0.nextT((double) (short) 10);
//        double double4 = randomDataGenerator0.nextT(0.1845842603151447d);
//        double double6 = randomDataGenerator0.nextChiSquare((double) 38L);
//        try {
//            double double9 = randomDataGenerator0.nextF((-0.7890639983076418d), (double) '4');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-0.789)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.39190971173927464d + "'", double2 == 0.39190971173927464d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0348422455112025d + "'", double4 == 1.0348422455112025d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 30.990927467966685d + "'", double6 == 30.990927467966685d);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        double[] doubleArray78 = discreteRealDistribution76.sample((int) '4');
        double[] doubleArray79 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray78);
        double[] doubleArray80 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        int[] intArray8 = org.apache.commons.math3.util.MathArrays.copyOf(intArray6);
        org.apache.commons.math3.random.Well19937c well19937c10 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c10);
        int[] intArray15 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c10.setSeed(intArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c18);
        int[] intArray23 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c18.setSeed(intArray23);
        double double25 = org.apache.commons.math3.util.MathArrays.distance(intArray15, intArray23);
        double double26 = org.apache.commons.math3.util.MathArrays.distance(intArray6, intArray23);
        int[] intArray27 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23);
        int[] intArray29 = org.apache.commons.math3.util.MathArrays.copyOf(intArray27, 0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c4.clear();
        double[] doubleArray11 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray17 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray11, doubleArray17);
        double[] doubleArray24 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray30 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray24, doubleArray30);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution32 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c4, doubleArray11, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        double[] doubleArray51 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray57 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray51, doubleArray57);
        double[] doubleArray59 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray58);
        boolean boolean60 = org.apache.commons.math3.util.MathArrays.equals(doubleArray38, doubleArray59);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution61 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray11, doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = well19937c1.nextGaussian();
        int[] intArray37 = new int[] { (short) 1, 7, (short) 1, 100, 0, (byte) 100 };
        int[] intArray39 = org.apache.commons.math3.util.MathArrays.copyOf(intArray37, (int) 'a');
        well19937c1.setSeed(intArray37);
        org.apache.commons.math3.random.Well19937c well19937c42 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl43 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c42);
        org.apache.commons.math3.random.Well19937c well19937c45 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        byte[] byteArray48 = new byte[] { (byte) 100, (byte) 10 };
        well19937c45.nextBytes(byteArray48);
        well19937c42.nextBytes(byteArray48);
        well19937c1.nextBytes(byteArray48);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-0.40892891016592103d) + "'", double30 == (-0.40892891016592103d));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(byteArray48);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray15 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray21 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray15, doubleArray21);
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22);
        org.apache.commons.math3.random.Well19937c well19937c25 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c25.clear();
        double[] doubleArray32 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray38 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray32, doubleArray38);
        double[] doubleArray45 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray51 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray52 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray45, doubleArray51);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution53 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c25, doubleArray32, doubleArray52);
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray22, doubleArray32);
        org.apache.commons.math3.random.Well19937c well19937c56 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c56.clear();
        double[] doubleArray63 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray69 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray63, doubleArray69);
        double[] doubleArray76 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray82 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray83 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray76, doubleArray82);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution84 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c56, doubleArray63, doubleArray83);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution85 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray22, doubleArray83);
        double[] doubleArray86 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray86);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.02183564980686696d, (java.lang.Number) 10000.0d, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.02183564980686696d + "'", number4.equals(0.02183564980686696d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext33 = mathInternalError31.getContext();
        org.apache.commons.math3.exception.MathInternalError mathInternalError34 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) mathInternalError31);
        java.lang.Throwable[] throwableArray35 = mathInternalError31.getSuppressed();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertNotNull(exceptionContext33);
        org.junit.Assert.assertNotNull(throwableArray35);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 1, (long) 7);
//        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        well19937c5.clear();
//        double[] doubleArray12 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
//        double[] doubleArray18 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
//        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray12, doubleArray18);
//        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
//        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
//        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
//        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution33 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c5, doubleArray12, doubleArray32);
//        double double34 = discreteRealDistribution33.getSupportUpperBound();
//        org.apache.commons.math3.exception.MathInternalError mathInternalError35 = new org.apache.commons.math3.exception.MathInternalError();
//        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair36 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution33, (java.lang.IllegalStateException) mathInternalError35);
//        double double37 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) discreteRealDistribution33);
//        try {
//            int int40 = randomDataImpl0.nextPascal(33, 1.1146327093968127d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 1.115 out of [0, 1] range");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertNotNull(doubleArray12);
//        org.junit.Assert.assertNotNull(doubleArray18);
//        org.junit.Assert.assertNotNull(doubleArray19);
//        org.junit.Assert.assertNotNull(doubleArray25);
//        org.junit.Assert.assertNotNull(doubleArray31);
//        org.junit.Assert.assertNotNull(doubleArray32);
//        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.0d + "'", double34 == 100.0d);
//        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 99.99999897765994d + "'", double37 == 99.99999897765994d);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((-7187591), 42);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.random.Well19937c well19937c18 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c18.clear();
        double[] doubleArray25 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray31 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray31);
        double[] doubleArray38 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray44 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray44);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c18, doubleArray25, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray25);
        double[] doubleArray53 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray59 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray53, doubleArray59);
        double[] doubleArray66 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray72 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray66, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73);
        double double75 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray74);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray15, doubleArray60);
        discreteRealDistribution76.reseedRandomGenerator((long) 'a');
        double double79 = discreteRealDistribution76.getNumericalMean();
        java.lang.Class<?> wildcardClass80 = discreteRealDistribution76.getClass();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 9702.240543161977d + "'", double79 == 9702.240543161977d);
        org.junit.Assert.assertNotNull(wildcardClass80);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 0, (java.lang.Number) 0.30955021719333553d, (java.lang.Number) 10);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException8 = new org.apache.commons.math3.exception.NullArgumentException();
        double[] doubleArray14 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray20 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray14, doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        double[] doubleArray28 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray34 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray21, doubleArray34);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator37 = new org.apache.commons.math3.random.RandomDataGenerator();
        java.lang.Object[] objArray38 = new java.lang.Object[] { nullArgumentException8, doubleArray21, randomDataGenerator37 };
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException39 = new org.apache.commons.math3.exception.NullArgumentException(localizable7, objArray38);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException40 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (short) 0, objArray38);
        java.lang.Throwable[] throwableArray41 = notFiniteNumberException40.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException42 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException4, localizable5, (java.lang.Object[]) throwableArray41);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException43 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) throwableArray41);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1012010.0d + "'", double36 == 1012010.0d);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(throwableArray41);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.6583111177123727d, 0.0d, 11.446697401807153d, (double) 97, 1.000301E8d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0003121032964797E8d + "'", double6 == 1.0003121032964797E8d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        double[] doubleArray7 = new double[] { (byte) 1, (-2.454354035192198d), ' ', 100L, 100.0f };
        double[] doubleArray13 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray19 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray13, doubleArray19);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray7, doubleArray20);
        org.apache.commons.math3.random.Well19937c well19937c24 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray29 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c24.setSeed(intArray29);
        double[] doubleArray36 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray42 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray36, doubleArray42);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray43);
        double[] doubleArray50 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray56 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray57 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray50, doubleArray56);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray57);
        org.apache.commons.math3.random.Well19937c well19937c60 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c60.clear();
        double[] doubleArray67 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray73 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray67, doubleArray73);
        double[] doubleArray80 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray86 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray87 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray80, doubleArray86);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution88 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c60, doubleArray67, doubleArray87);
        boolean boolean89 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray57, doubleArray67);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution90 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c24, doubleArray44, doubleArray57);
        double[] doubleArray91 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        java.lang.Class<?> wildcardClass92 = doubleArray44.getClass();
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution93 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray22, doubleArray44);
        int int95 = well19937c1.nextInt(174);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(wildcardClass92);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1 + "'", int95 == 1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            long long11 = randomDataGenerator9.nextPoisson(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        double[] doubleArray35 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray41 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray35, doubleArray41);
        double[] doubleArray48 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray54 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray48, doubleArray54);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray55);
        boolean boolean57 = org.apache.commons.math3.util.MathArrays.equals(doubleArray35, doubleArray56);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray29, doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        well19937c1.clear();
//        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
//        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
//        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
//        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
//        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
//        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
//        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
//        double double30 = discreteRealDistribution29.getSupportUpperBound();
//        org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError();
//        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair32 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistribution29, (java.lang.IllegalStateException) mathInternalError31);
//        java.lang.IllegalStateException illegalStateException33 = discreteRealDistributionPair32.getSecond();
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator34 = new org.apache.commons.math3.random.RandomDataGenerator();
//        int int37 = randomDataGenerator34.nextZipf((int) (short) 10, (double) ' ');
//        double double40 = randomDataGenerator34.nextGaussian(10.0d, 105.42696159652844d);
//        int int43 = randomDataGenerator34.nextBinomial(0, (double) (byte) 1);
//        boolean boolean44 = discreteRealDistributionPair32.equals((java.lang.Object) (byte) 1);
//        org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException> discreteRealDistributionPair45 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.distribution.DiscreteRealDistribution, java.lang.IllegalStateException>(discreteRealDistributionPair32);
//        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution46 = discreteRealDistributionPair45.getKey();
//        java.lang.IllegalStateException illegalStateException47 = discreteRealDistributionPair45.getValue();
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertNotNull(doubleArray15);
//        org.junit.Assert.assertNotNull(doubleArray21);
//        org.junit.Assert.assertNotNull(doubleArray27);
//        org.junit.Assert.assertNotNull(doubleArray28);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
//        org.junit.Assert.assertNotNull(illegalStateException33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + double40 + "' != '" + (-48.34680342449353d) + "'", double40 == (-48.34680342449353d));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(discreteRealDistribution46);
//        org.junit.Assert.assertNotNull(illegalStateException47);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.clear();
        double[] doubleArray8 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray14 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray27 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray27);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, doubleArray8, doubleArray28);
        double double30 = discreteRealDistribution29.getSupportUpperBound();
        double double32 = discreteRealDistribution29.density((double) 7);
        double double33 = discreteRealDistribution29.sample();
        double double36 = discreteRealDistribution29.probability((-2.0d), 1.6383254778327327d);
        try {
            double double38 = discreteRealDistribution29.inverseCumulativeProbability((double) 3325889825069335040L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 3,325,889,825,069,335,000 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.009699321047526674d + "'", double36 == 0.009699321047526674d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 0.5982021689405124d, (java.lang.Number) 0.012586043473500211d, 733513190);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0d, (java.lang.Number) (byte) 100, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getArgument();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0d + "'", number5.equals(1.0d));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeedSecure();
//        double double3 = randomDataGenerator0.nextChiSquare(39.525652590500485d);
//        double double6 = randomDataGenerator0.nextWeibull((double) 1220434243L, 10.000201086223035d);
//        try {
//            int[] intArray9 = randomDataGenerator0.nextPermutation((int) (byte) 1, 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (10) exceeds permuation domain (1)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.95904619189162d + "'", double3 == 51.95904619189162d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.000201091380527d + "'", double6 == 10.000201091380527d);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int5 = randomDataImpl2.nextBinomial((int) (byte) 1, (double) 0);
        double double8 = randomDataImpl2.nextF(56.14779571738535d, (double) 64L);
        double double12 = randomDataImpl2.nextUniform(2.4379925812719248E-5d, (double) 19, true);
        randomDataImpl2.reSeed(0L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.1146327093968127d + "'", double8 == 1.1146327093968127d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 11.306288201364886d + "'", double12 == 11.306288201364886d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 6083L, (java.lang.Number) 9.347883475356515d, 0, orderDirection3, false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 138.07687005673318d, 0.9493594565810611d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 94.9359456581061d + "'", double4 == 94.9359456581061d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double[] doubleArray5 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray11 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray11);
        double[] doubleArray18 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray24 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray18, doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray26);
        java.lang.Class<?> wildcardClass28 = doubleArray12.getClass();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        long[] longArray0 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.random.Well19937c well19937c3 = new org.apache.commons.math3.random.Well19937c((long) (short) 10);
        int[] intArray8 = new int[] { (short) -1, (-1), (byte) -1, (byte) 10 };
        well19937c3.setSeed(intArray8);
        double[] doubleArray15 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray21 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray15, doubleArray21);
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22);
        double[] doubleArray29 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray35 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray29, doubleArray35);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36);
        org.apache.commons.math3.random.Well19937c well19937c39 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c39.clear();
        double[] doubleArray46 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray52 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray46, doubleArray52);
        double[] doubleArray59 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray65 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray66 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray59, doubleArray65);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution67 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c39, doubleArray46, doubleArray66);
        boolean boolean68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray36, doubleArray46);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution69 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c3, doubleArray23, doubleArray36);
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection74 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException76 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10001.504886765792d, (java.lang.Number) (-1), (int) ' ', orderDirection74, false);
        double[][] doubleArray77 = new double[][] {};
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray23, orderDirection74, doubleArray77);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, (java.lang.Object[]) doubleArray77);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException80 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray77);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + orderDirection74 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection74.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray77);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray6 = new int[] { (short) 100, (byte) 100, ' ' };
        well19937c1.setSeed(intArray6);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) (short) -1);
        double double13 = randomDataImpl8.nextGaussian(0.0d, 10001.504886765792d);
        try {
            int int16 = randomDataImpl8.nextZipf(9, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: exponent (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 897.2434883068374d + "'", double13 == 897.2434883068374d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 2.7748698967446392E10d, (java.lang.Number) 138.07687005673318d, false);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        randomDataGenerator0.reSeedSecure();
//        double double3 = randomDataGenerator0.nextChiSquare(39.525652590500485d);
//        int int6 = randomDataGenerator0.nextSecureInt((int) (byte) -1, 0);
//        double double9 = randomDataGenerator0.nextWeibull((double) 0.23953891f, (double) 10L);
//        try {
//            randomDataGenerator0.setSecureAlgorithm("4", "0");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 0");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 29.43613849268058d + "'", double3 == 29.43613849268058d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 328.553400556601d + "'", double9 == 328.553400556601d);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int5 = randomDataImpl2.nextBinomial((int) (byte) 1, (double) 0);
        double double8 = randomDataImpl2.nextF(56.14779571738535d, (double) 64L);
        double double12 = randomDataImpl2.nextUniform(2.4379925812719248E-5d, (double) 19, true);
        double double15 = randomDataImpl2.nextF(22.981618453278884d, 31.931273192771652d);
        org.apache.commons.math3.random.Well19937c well19937c17 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c17.clear();
        double[] doubleArray24 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray30 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray24, doubleArray30);
        double[] doubleArray37 = new double[] { 10.0f, (short) 100, (short) 10, 1.0f, 10 };
        double[] doubleArray43 = new double[] { 10.0f, 100, 10L, 100.0d, 1.0d };
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray37, doubleArray43);
        org.apache.commons.math3.distribution.DiscreteRealDistribution discreteRealDistribution45 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c17, doubleArray24, doubleArray44);
        double double48 = discreteRealDistribution45.cumulativeProbability((double) 0, 0.0013733592917636712d);
        double double49 = discreteRealDistribution45.getSupportUpperBound();
        double double50 = randomDataImpl2.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) discreteRealDistribution45);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.1146327093968127d + "'", double8 == 1.1146327093968127d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 11.306288201364886d + "'", double12 == 11.306288201364886d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.7462806544668126d + "'", double15 == 0.7462806544668126d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 100.0d + "'", double49 == 100.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 99.99999859861802d + "'", double50 == 99.99999859861802d);
    }
}

