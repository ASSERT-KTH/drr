import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 52.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double double3 = arrayRealVector2.getL1Norm();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7, 97);
        org.apache.commons.math3.optim.nonlinear.vector.Target target12 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray11);
        double[] doubleArray13 = target12.getTarget();
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition14 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray0, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray7 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = diagonalMatrix10.copy();
        double[][] doubleArray12 = diagonalMatrix10.getData();
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException13 = new org.apache.commons.math3.exception.MathArithmeticException(localizable1, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix2.add(openMapRealMatrix9);
        try {
            openMapRealMatrix9.addToEntry(247, 74, 254.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (247)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor3.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double11 = openMapRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        int int12 = openMapRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(247, (int) (byte) 100);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix17 = openMapRealMatrix2.multiply(realMatrix16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 52 != 247");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray11 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray15 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition17 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray11, doubleArray15, (double) (byte) 10);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray15);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair19 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray15);
        org.apache.commons.math3.exception.util.Localizable localizable20 = null;
        double[] doubleArray26 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = diagonalMatrix29.copy();
        double[][] doubleArray31 = diagonalMatrix29.getData();
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException32 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable20, (java.lang.Object[]) doubleArray31);
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray15, doubleArray31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) (short) 1);
        double[] doubleArray2 = diagonalMatrix1.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double[] doubleArray1 = new double[] { (byte) 10 };
        double[] doubleArray3 = new double[] { (byte) 10 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray4);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray4, 0.0d, 403.4287934927351d, 6.5481924191803085d, 3.982441812995697E30d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: equal vertices 1 and 0 in simplex configuration");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double[] doubleArray3 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray7 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray3, doubleArray7, (double) (byte) 10);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10);
        double[][] doubleArray12 = diagonalMatrix11.getData();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix(10, (-381728948), doubleArray12, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -381,728,948 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double[] doubleArray2 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray6 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray2, doubleArray6, (double) (byte) 10);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray6);
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapSubtractToSelf(3.8146972656435034E-6d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        boolean boolean16 = array2DRowRealMatrix15.isSquare();
        double double17 = array2DRowRealMatrix15.getFrobeniusNorm();
        try {
            double double20 = array2DRowRealMatrix15.getEntry(0, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 200.50935140287098d + "'", double17 == 200.50935140287098d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray1, doubleArray30, true);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double[] doubleArray6 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (-1L));
        arrayRealVector7.set((double) (byte) 0);
        boolean boolean12 = arrayRealVector7.isNaN();
        boolean boolean13 = arrayRealVector7.isNaN();
        double[] doubleArray20 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        double[] doubleArray28 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28);
        org.apache.commons.math3.optim.PointValuePair pointValuePair31 = new org.apache.commons.math3.optim.PointValuePair(doubleArray28, (double) (byte) -1);
        boolean boolean33 = pointValuePair31.equals((java.lang.Object) 0);
        java.lang.Object obj34 = null;
        boolean boolean35 = pointValuePair31.equals(obj34);
        double[] doubleArray36 = pointValuePair31.getPoint();
        double[] doubleArray37 = pointValuePair31.getKey();
        boolean boolean38 = array2DRowRealMatrix22.equals((java.lang.Object) doubleArray37);
        int int39 = org.apache.commons.math3.util.MathUtils.hash(doubleArray37);
        org.apache.commons.math3.optim.PointValuePair pointValuePair41 = new org.apache.commons.math3.optim.PointValuePair(doubleArray37, (double) 2147483647);
        arrayRealVector7.setSubVector((int) (short) 0, doubleArray37);
        double[] doubleArray46 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray46);
        double[] doubleArray50 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray54 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition56 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray50, doubleArray54, (double) (byte) 10);
        double[] doubleArray57 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray54);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition59 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray46, doubleArray57, (double) (byte) -1);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair60 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray37, doubleArray57);
        double[] doubleArray66 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray67 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray66);
        org.apache.commons.math3.optim.PointValuePair pointValuePair69 = new org.apache.commons.math3.optim.PointValuePair(doubleArray66, (double) (byte) -1);
        java.lang.Double double70 = pointValuePair69.getSecond();
        double[] doubleArray71 = pointValuePair69.getFirst();
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair72 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray57, doubleArray71);
        double[] doubleArray73 = pointVectorValuePair72.getKey();
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 32, doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1809524577) + "'", int39 == (-1809524577));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.copy();
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16);
        java.lang.Number number20 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException22 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number20, 97);
        int int23 = nonMonotonicSequenceException22.getIndex();
        java.lang.Number number24 = nonMonotonicSequenceException22.getPrevious();
        int int25 = nonMonotonicSequenceException22.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection26 = nonMonotonicSequenceException22.getDirection();
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray16, orderDirection26, false, false);
        double[] doubleArray30 = diagonalMatrix8.operate(doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor32 = null;
        try {
            double double35 = arrayRealVector31.walkInOptimizedOrder(realVectorPreservingVisitor32, 32, 4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 97 + "'", int23 == 97);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 97 + "'", int25 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        double[] doubleArray33 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray37 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition39 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray33, doubleArray37, (double) (byte) 10);
        double[] doubleArray40 = eigenDecomposition39.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray40);
        double[] doubleArray43 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray47 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray43, doubleArray47, (double) (byte) 10);
        double[] doubleArray50 = eigenDecomposition49.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray50);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix41, (org.apache.commons.math3.linear.AnyMatrix) realMatrix51);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = array2DRowRealMatrix15.multiply(realMatrix41);
        double[][] doubleArray54 = array2DRowRealMatrix15.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = array2DRowRealMatrix15.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = array2DRowRealMatrix7.add(array2DRowRealMatrix15);
        boolean boolean59 = array2DRowRealMatrix15.isSquare();
        int int60 = array2DRowRealMatrix15.getRowDimension();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 5 + "'", int60 == 5);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((-0.8414709848078965d), pointVectorValuePairConvergenceChecker1, (double) 52, (double) 0.0f, 2.3978952727983707d, 2.3978952727983707d);
        int int7 = levenbergMarquardtOptimizer6.getMaxEvaluations();
        try {
            double double8 = levenbergMarquardtOptimizer6.getRMS();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (-0.012233790557032886d), (java.lang.Number) 247, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 247 + "'", number4.equals(247));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (-1809524577), (long) 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (-1555302186), (float) 74);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double3 = bracketFinder2.getHi();
        double[] doubleArray9 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector10.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType16 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        bracketFinder2.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc14, goalType16, (-0.0d), (double) 1.0f);
        double double20 = bracketFinder2.getHi();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertTrue("'" + goalType16 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType16.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0000061723098754d + "'", double20 == 1.0000061723098754d);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test022");
//        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
//        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
//        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
//        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner5 = null;
//        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4, preconditioner5);
//        org.apache.commons.math3.optim.MaxEval maxEval8 = new org.apache.commons.math3.optim.MaxEval((int) '#');
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math3.random.MersenneTwister();
//        float float10 = mersenneTwister9.nextFloat();
//        boolean boolean11 = mersenneTwister9.nextBoolean();
//        org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator> maxEvalPair12 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator>(maxEval8, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister9);
//        int int13 = maxEval8.getMaxEval();
//        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray14 = new org.apache.commons.math3.optim.OptimizationData[] { maxEval8 };
//        try {
//            org.apache.commons.math3.optim.PointValuePair pointValuePair15 = nonLinearConjugateGradientOptimizer6.optimize(optimizationDataArray14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.78915215f + "'", float10 == 0.78915215f);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
//        org.junit.Assert.assertNotNull(optimizationDataArray14);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix2.add(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix13.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix13);
        org.apache.commons.math3.linear.RealVector realVector20 = openMapRealMatrix18.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix21 = openMapRealMatrix2.subtract(openMapRealMatrix18);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor22 = null;
        try {
            double double27 = openMapRealMatrix18.walkInColumnOrder(realMatrixChangingVisitor22, (-1), (int) (short) 100, (int) '#', 21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(openMapRealMatrix21);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix2.add(openMapRealMatrix9);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix9, (-1773261632), 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,773,261,632)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double[] doubleArray3 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray3);
        double[] doubleArray7 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray11 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition13 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray7, doubleArray11, (double) (byte) 10);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray11);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition16 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray3, doubleArray14, (double) (byte) -1);
        double[] doubleArray17 = eigenDecomposition16.getImagEigenvalues();
        double double18 = eigenDecomposition16.getDeterminant();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-100.00000000000003d) + "'", double18 == (-100.00000000000003d));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector6.equals((java.lang.Object) 10);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector19.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector6.combine((double) (-1809524577), (-1.0d), (org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat27 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat28 = realMatrixFormat27.getFormat();
        boolean boolean29 = arrayRealVector19.equals((java.lang.Object) realMatrixFormat27);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(realMatrixFormat27);
        org.junit.Assert.assertNotNull(numberFormat28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector16.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector16.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector6.append(realVector22);
        double[] doubleArray29 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.mapDivideToSelf((double) (-1L));
        boolean boolean33 = arrayRealVector30.isNaN();
        double[] doubleArray39 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.mapDivideToSelf((double) (-1L));
        boolean boolean43 = arrayRealVector40.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc45 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector40.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc45);
        double double47 = arrayRealVector30.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector40.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector6.append(arrayRealVector40);
        double double51 = arrayRealVector6.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector6.mapSubtractToSelf(2.718281828459045d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 100);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector6.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + (-97.0d) + "'", double51 == (-97.0d));
        org.junit.Assert.assertNotNull(realVector53);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(0.7262694092379458d, 0.0d, 0.0d, (double) (byte) 1, (double) 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 93);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray13 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition15 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray9, doubleArray13, (double) (byte) 10);
        double[] doubleArray16 = eigenDecomposition15.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray16);
        double double18 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray16);
        double[] doubleArray19 = array2DRowRealMatrix7.operate(doubleArray16);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.012233790557032886d + "'", double18 == 0.012233790557032886d);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        double[] doubleArray7 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) (short) 10, doubleArray8);
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray8, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.scale((double) 'a', doubleArray15);
        double[] doubleArray24 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition26 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray18, doubleArray25);
        double[] doubleArray32 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        double[] doubleArray41 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector42.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector48 = arrayRealVector42.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector42, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33, arrayRealVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25, doubleArray33);
        boolean boolean53 = arrayRealVector52.isInfinite();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition2 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix0, 1.2554203470773362E58d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.RealVector realVector9 = openMapRealMatrix7.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix12.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix12);
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix17.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix20 = openMapRealMatrix7.add(openMapRealMatrix17);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = openMapRealMatrix7.scalarAdd(6.548192419180309d);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector6.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector6.unitVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.copy();
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean23 = arrayRealVector19.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.append((double) (short) 100);
        double double26 = arrayRealVector12.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double[] doubleArray32 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, false);
        double double35 = arrayRealVector34.getMaxValue();
        double[] doubleArray41 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.mapDivideToSelf((double) (-1L));
        boolean boolean45 = arrayRealVector42.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc47 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector42.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc47);
        org.apache.commons.math3.analysis.function.Sinc sinc50 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector42.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc50);
        double double52 = arrayRealVector34.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector12.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor54 = null;
        try {
            double double55 = arrayRealVector12.walkInOptimizedOrder(realVectorChangingVisitor54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.0d + "'", double35 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 252.05440211108893d + "'", double52 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector53);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(74, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 74 + "'", int2 == 74);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        long long2 = org.apache.commons.math3.util.FastMath.max(0L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        arrayRealVector6.set((double) (byte) 0);
        boolean boolean11 = arrayRealVector6.isNaN();
        boolean boolean12 = arrayRealVector6.isNaN();
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        arrayRealVector19.set((double) (byte) 0);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.mapAdd((double) 100.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector6.subtract(realVector25);
        boolean boolean27 = arrayRealVector6.isNaN();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        arrayRealVector12.unitize();
        double[] doubleArray19 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19, false);
        double[] doubleArray27 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, false);
        double[] doubleArray35 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector36.mapDivideToSelf((double) (-1L));
        boolean boolean40 = arrayRealVector36.equals((java.lang.Object) 10);
        double double41 = arrayRealVector29.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        double[] doubleArray49 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray49);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector50.mapDivideToSelf((double) (-1L));
        boolean boolean54 = arrayRealVector50.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector56 = arrayRealVector50.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector50.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector36.combine((double) (byte) 0, (double) (-1L), realVector58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = arrayRealVector21.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, (org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.RealVector realVector63 = arrayRealVector61.mapSubtract(91.72376348103771d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 246.6779276708802d + "'", double41 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(realVector63);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 97, (java.lang.Number) 22025.465794806718d, false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker6 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 0L, 0.8414709848078965d);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 100.0f, 5557.690612768985d, (double) 10L, 0.28943395614624023d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 1.0d, 2.718281828459045d, 2.3978952727983707d, 18918.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-3.141592653589793d), (java.lang.Number) (-1023), false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.apache.commons.math3.random.RandomGenerator randomGenerator5 = null;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math3.random.MersenneTwister();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker17 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(1378221360, 0.0d, true, 1378221360, 4, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister12, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker17);
        double double19 = simpleValueChecker17.getAbsoluteThreshold();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1023), (double) 4, true, 97, (int) ' ', randomGenerator5, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.0d + "'", double19 == 10.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        int[] intArray5 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
        int[] intArray11 = new int[] { 97, 1, 100, (byte) 100, 52 };
        int int12 = org.apache.commons.math3.util.MathArrays.distance1(intArray5, intArray11);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math3.random.MersenneTwister(intArray11);
        double double14 = mersenneTwister13.nextDouble();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 247 + "'", int12 == 247);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.6657680855096155d + "'", double14 == 0.6657680855096155d);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test045");
//        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
//        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 0L, 0.8414709848078965d);
//        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula4 = null;
//        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker5 = null;
//        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver8 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
//        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner9 = null;
//        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula4, pointValuePairConvergenceChecker5, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver8, preconditioner9);
//        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver8);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math3.random.MersenneTwister();
//        float float18 = mersenneTwister17.nextFloat();
//        byte[] byteArray24 = new byte[] { (byte) -1, (byte) 100, (byte) 0, (byte) 10, (byte) 100 };
//        mersenneTwister17.nextBytes(byteArray24);
//        long long26 = mersenneTwister17.nextLong();
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister33 = new org.apache.commons.math3.random.MersenneTwister();
//        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker38 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
//        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer39 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(1378221360, 0.0d, true, 1378221360, 4, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister33, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker38);
//        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer40 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(12, 0.0d, true, 10, (int) (short) 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister17, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker38);
//        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula41 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister47 = new org.apache.commons.math3.random.MersenneTwister();
//        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker52 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
//        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer53 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(1378221360, 0.0d, true, 1378221360, 4, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister47, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker52);
//        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer54 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker52);
//        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver56 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) (-1L));
//        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer57 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula41, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker52, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver56);
//        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner58 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
//        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer59 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker38, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver56, (org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner) identityPreconditioner58);
//        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
//        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.7732482f + "'", float18 == 0.7732482f);
//        org.junit.Assert.assertNotNull(byteArray24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 648640953086672520L + "'", long26 == 648640953086672520L);
//        org.junit.Assert.assertTrue("'" + formula41 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula41.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector6.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector6.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, true);
        try {
            double double16 = arrayRealVector6.getEntry(9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (9)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, (int) (byte) 10);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        arrayRealVector6.set((double) (byte) 0);
        boolean boolean11 = arrayRealVector6.isNaN();
        boolean boolean12 = arrayRealVector6.isNaN();
        double[] doubleArray19 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        org.apache.commons.math3.optim.PointValuePair pointValuePair30 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) (byte) -1);
        boolean boolean32 = pointValuePair30.equals((java.lang.Object) 0);
        java.lang.Object obj33 = null;
        boolean boolean34 = pointValuePair30.equals(obj33);
        double[] doubleArray35 = pointValuePair30.getPoint();
        double[] doubleArray36 = pointValuePair30.getKey();
        boolean boolean37 = array2DRowRealMatrix21.equals((java.lang.Object) doubleArray36);
        int int38 = org.apache.commons.math3.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math3.optim.PointValuePair pointValuePair40 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, (double) 2147483647);
        arrayRealVector6.setSubVector((int) (short) 0, doubleArray36);
        double[] doubleArray45 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray45);
        double[] doubleArray49 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray53 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition55 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray49, doubleArray53, (double) (byte) 10);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray53);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition58 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray45, doubleArray56, (double) (byte) -1);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray36, doubleArray56);
        double[] doubleArray65 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray66 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray65);
        org.apache.commons.math3.optim.PointValuePair pointValuePair68 = new org.apache.commons.math3.optim.PointValuePair(doubleArray65, (double) (byte) -1);
        java.lang.Double double69 = pointValuePair68.getSecond();
        double[] doubleArray70 = pointValuePair68.getFirst();
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair71 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray56, doubleArray70);
        double[] doubleArray72 = pointVectorValuePair71.getKey();
        double[] doubleArray73 = pointVectorValuePair71.getPoint();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1809524577) + "'", int38 == (-1809524577));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + (-1.0d) + "'", double69.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { (-1) };
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 10, 52, 100 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException8 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray3, intArray7);
        org.apache.commons.math3.exception.util.Localizable localizable9 = null;
        java.lang.Number number10 = null;
        org.apache.commons.math3.exception.util.Localizable localizable11 = null;
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { (-1) };
        java.lang.Integer[] intArray17 = new java.lang.Integer[] { 10, 52, 100 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException18 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable11, intArray13, intArray17);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException19 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable9, number10, (java.lang.Object[]) intArray17);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException20 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray3, intArray17);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) 0.013082147f);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray1, doubleArray30, true);
        double[] doubleArray34 = pointVectorValuePair33.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test052");
//        org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval((int) '#');
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister();
//        float float3 = mersenneTwister2.nextFloat();
//        boolean boolean4 = mersenneTwister2.nextBoolean();
//        org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator> maxEvalPair5 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator>(maxEval1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister2);
//        int int7 = mersenneTwister2.nextInt((int) (byte) 100);
//        mersenneTwister2.setSeed((-1555302186L));
//        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.9949522f + "'", float3 == 0.9949522f);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 30 + "'", int7 == 30);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix7);
        boolean boolean9 = openMapRealMatrix7.isTransposable();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector16.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        double double23 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector16.copy();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector16.getSubVector((int) (byte) 1, (int) (short) 1);
        org.apache.commons.math3.analysis.function.Sinc sinc28 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector16.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc28);
        java.io.ObjectOutputStream objectOutputStream30 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16, objectOutputStream30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double3 = bracketFinder2.getHi();
        double double4 = bracketFinder2.getLo();
        org.apache.commons.math3.analysis.function.Sinc sinc6 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder2.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc6, goalType7, (double) '4', (double) 'a');
        double[] doubleArray16 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) (-1L));
        double[] doubleArray25 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) (-1L));
        boolean boolean30 = arrayRealVector26.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector26.append((double) (short) 100);
        double double33 = arrayRealVector17.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        double[] doubleArray39 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.mapDivideToSelf((double) (-1L));
        boolean boolean43 = arrayRealVector40.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc45 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector40.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc45);
        org.apache.commons.math3.analysis.function.Sinc sinc48 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector40.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector26.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc48);
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder53 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double54 = bracketFinder53.getHi();
        double double55 = bracketFinder53.getLo();
        org.apache.commons.math3.analysis.function.Sinc sinc57 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType58 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder53.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc57, goalType58, (double) '4', (double) 'a');
        bracketFinder2.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc48, goalType58, (double) 100, 0.0d);
        double double65 = bracketFinder2.getFLo();
        double double66 = bracketFinder2.getMid();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType7 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType7.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 18918.0d + "'", double33 == 18918.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType58 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType58.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + (-0.006179939774976235d) + "'", double65 == (-0.006179939774976235d));
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Double[] doubleArray1 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        org.apache.commons.math3.exception.MathInternalError mathInternalError3 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948968d + "'", double1 == 1.5707963267948968d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor(32, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.copy();
        double[][] doubleArray10 = diagonalMatrix8.getData();
        double[] doubleArray11 = diagonalMatrix8.getDataRef();
        diagonalMatrix8.multiplyEntry(10, 0, 97.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix7, 0, (int) (byte) 1);
        int int11 = openMapRealMatrix7.getColumnDimension();
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean23 = arrayRealVector19.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.append((double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat27 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        boolean boolean28 = arrayRealVector26.equals((java.lang.Object) realMatrixFormat27);
        java.text.ParsePosition parsePosition30 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix31 = realMatrixFormat27.parse(",", parsePosition30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(realMatrixFormat27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor16 = null;
        try {
            double double21 = array2DRowRealMatrix15.walkInRowOrder(realMatrixChangingVisitor16, 50, 99, 97, 74);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (50)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.apache.commons.math3.random.RandomGenerator randomGenerator5 = null;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math3.random.MersenneTwister();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker17 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(1378221360, 0.0d, true, 1378221360, 4, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister12, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker17);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker17);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(9, 0.7894702148849957d, false, (-1), 0, randomGenerator5, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker17);
        double double21 = simpleValueChecker17.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector16.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        double double23 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector16.mapAdd((double) (short) 1);
        double[] doubleArray31 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector32.mapDivideToSelf((double) (-1L));
        boolean boolean35 = arrayRealVector32.isNaN();
        double[] doubleArray41 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector42.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector48 = arrayRealVector42.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector32.append(realVector48);
        double[] doubleArray55 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray55);
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector56.mapDivideToSelf((double) (-1L));
        boolean boolean59 = arrayRealVector56.isNaN();
        double[] doubleArray65 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray65);
        org.apache.commons.math3.linear.RealVector realVector68 = arrayRealVector66.mapDivideToSelf((double) (-1L));
        boolean boolean69 = arrayRealVector66.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc71 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = arrayRealVector66.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc71);
        double double73 = arrayRealVector56.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector66);
        org.apache.commons.math3.linear.RealVector realVector75 = arrayRealVector66.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = arrayRealVector32.append(arrayRealVector66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = arrayRealVector16.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector66);
        org.apache.commons.math3.linear.RealVector realVector79 = arrayRealVector77.append((double) 74);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(arrayRealVector72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(realVector75);
        org.junit.Assert.assertNotNull(arrayRealVector76);
        org.junit.Assert.assertNotNull(arrayRealVector77);
        org.junit.Assert.assertNotNull(realVector79);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        double double2 = org.apache.commons.math3.util.FastMath.pow(5557.690612768985d, 0.38108765337432393d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 26.73825164685366d + "'", double2 == 26.73825164685366d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor3.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double11 = openMapRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        double double12 = defaultRealMatrixPreservingVisitor3.end();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector6.getSubVector(0, 4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(4, (int) (byte) 10, (double) 10);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (97x52) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix15.copy();
        double[] doubleArray18 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray22 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray18, doubleArray22, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver25 = eigenDecomposition24.getSolver();
        double[] doubleArray26 = eigenDecomposition24.getImagEigenvalues();
        boolean boolean27 = array2DRowRealMatrix15.equals((java.lang.Object) eigenDecomposition24);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = eigenDecomposition24.getD();
        double[] doubleArray29 = eigenDecomposition24.getImagEigenvalues();
        try {
            org.apache.commons.math3.linear.RealVector realVector31 = eigenDecomposition24.getEigenvector((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(decompositionSolver25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double double1 = org.apache.commons.math3.util.FastMath.log(4.342925101645957d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4685481076397466d + "'", double1 == 1.4685481076397466d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray8, (double) ' ', (double) '4');
        double[] doubleArray18 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray24 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray25 = new double[][] { doubleArray18, doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix28.copy();
        double[] doubleArray31 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray35 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition37 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray31, doubleArray35, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver38 = eigenDecomposition37.getSolver();
        double[] doubleArray39 = eigenDecomposition37.getImagEigenvalues();
        boolean boolean40 = array2DRowRealMatrix28.equals((java.lang.Object) eigenDecomposition37);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = eigenDecomposition37.getD();
        double[] doubleArray42 = eigenDecomposition37.getImagEigenvalues();
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition43 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray8, doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(decompositionSolver38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = eigenDecomposition7.getVT();
        try {
            double double11 = eigenDecomposition7.getImagEigenvalue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean23 = arrayRealVector19.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.append((double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double[] doubleArray32 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.mapDivideToSelf((double) (-1L));
        boolean boolean37 = arrayRealVector33.equals((java.lang.Object) 10);
        double double38 = arrayRealVector12.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector12.mapMultiplyToSelf((double) ' ');
        org.apache.commons.math3.linear.RealVector realVector42 = realVector40.mapMultiply((double) (-1555302186));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-7.175711493801343E-17d) + "'", double38 == (-7.175711493801343E-17d));
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(realVector42);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient objectiveFunctionGradient1 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient(multivariateVectorFunction0);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction2 = objectiveFunctionGradient1.getObjectiveFunctionGradient();
        org.junit.Assert.assertNull(multivariateVectorFunction2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double double8 = arrayRealVector7.getMaxValue();
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector15.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc20 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc20);
        org.apache.commons.math3.analysis.function.Sinc sinc23 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector15.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc23);
        double double25 = arrayRealVector7.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector24.copy();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat27 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat28 = realVectorFormat27.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = realVectorFormat27.parse("{0; -0; 1; 1; 0}");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector24.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        double[] doubleArray39 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39, false);
        double double42 = arrayRealVector41.getMaxValue();
        double[] doubleArray48 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray48);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector49.mapDivideToSelf((double) (-1L));
        boolean boolean52 = arrayRealVector49.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc54 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector49.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc54);
        org.apache.commons.math3.analysis.function.Sinc sinc57 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector49.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc57);
        double double59 = arrayRealVector41.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = arrayRealVector58.copy();
        java.lang.Class<?> wildcardClass61 = arrayRealVector58.getClass();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector30.combine(0.0d, (double) (-1809524577), (org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 252.05440211108893d + "'", double25 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(realVectorFormat27);
        org.junit.Assert.assertNotNull(numberFormat28);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 252.05440211108893d + "'", double59 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector60);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(arrayRealVector62);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat2 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat1);
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double3 = bracketFinder2.getHi();
        double[] doubleArray9 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector10.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType16 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        bracketFinder2.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc14, goalType16, (-0.0d), (double) 1.0f);
        int int20 = bracketFinder2.getMaxEvaluations();
        double double21 = bracketFinder2.getLo();
        double double22 = bracketFinder2.getFLo();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertTrue("'" + goalType16 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType16.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.8414709848078965d + "'", double22 == 0.8414709848078965d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { 4, 52, 2147483647, 97, 97 };
        java.lang.Integer[] intArray15 = new java.lang.Integer[] { 52, 100, 2147483647, 4, 100, 2147483647 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException16 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable2, intArray8, intArray15);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathArithmeticException0, localizable1, (java.lang.Object[]) intArray15);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException18 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.util.Localizable localizable19 = null;
        org.apache.commons.math3.exception.util.Localizable localizable20 = null;
        java.lang.Integer[] intArray26 = new java.lang.Integer[] { 4, 52, 2147483647, 97, 97 };
        java.lang.Integer[] intArray33 = new java.lang.Integer[] { 52, 100, 2147483647, 4, 100, 2147483647 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException34 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable20, intArray26, intArray33);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException35 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathArithmeticException18, localizable19, (java.lang.Object[]) intArray33);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException36 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray15, intArray33);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray13 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition15 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray9, doubleArray13, (double) (byte) 10);
        double[] doubleArray16 = eigenDecomposition15.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray16);
        double double18 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray16);
        double[] doubleArray19 = array2DRowRealMatrix7.operate(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix7.copy();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.012233790557032886d + "'", double18 == 0.012233790557032886d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(0.012233790557032886d, (double) 10L);
        double double3 = simpleUnivariateValueChecker2.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 0.04532051f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5966739978987676d + "'", double1 == 2.5966739978987676d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 'a', 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10671.0d, (java.lang.Number) 1.67848858E9f, 93, orderDirection3, true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        boolean boolean9 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix7, (double) (byte) 0);
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = diagonalMatrix18.copy();
        double[][] doubleArray20 = diagonalMatrix18.getData();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor21.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double29 = defaultRealMatrixPreservingVisitor21.end();
        double double30 = diagonalMatrix18.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        defaultRealMatrixPreservingVisitor21.visit(0, 1378221360, 1.7763568394002505E-15d);
        try {
            double double39 = array2DRowRealMatrix7.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21, 0, (int) (short) -1, 3, (-1773261632));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        float[] floatArray0 = null;
        float[] floatArray1 = new float[] {};
        boolean boolean2 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray0, floatArray1);
        float[] floatArray3 = null;
        float[] floatArray4 = new float[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray3, floatArray4);
        boolean boolean6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray0, floatArray4);
        float[] floatArray7 = new float[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equals(floatArray4, floatArray7);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula2 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker3 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver6 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula2, pointValuePairConvergenceChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver6);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner8 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer9 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver6, preconditioner8);
        int int10 = brentSolver6.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        arrayRealVector6.set((double) (byte) 0);
        boolean boolean11 = arrayRealVector6.isNaN();
        boolean boolean12 = arrayRealVector6.isNaN();
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        arrayRealVector19.set((double) (byte) 0);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.mapAdd((double) 100.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector6.subtract(realVector25);
        org.apache.commons.math3.linear.RealVector realVector28 = realVector25.mapAdd((double) 6L);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(realVector28);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test089");
//        org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval((int) '#');
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister();
//        float float3 = mersenneTwister2.nextFloat();
//        boolean boolean4 = mersenneTwister2.nextBoolean();
//        org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator> maxEvalPair5 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator>(maxEval1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister2);
//        int int7 = mersenneTwister2.nextInt((int) (byte) 100);
//        int int8 = mersenneTwister2.nextInt();
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math3.random.MersenneTwister();
//        float float10 = mersenneTwister9.nextFloat();
//        byte[] byteArray16 = new byte[] { (byte) -1, (byte) 100, (byte) 0, (byte) 10, (byte) 100 };
//        mersenneTwister9.nextBytes(byteArray16);
//        mersenneTwister2.nextBytes(byteArray16);
//        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.7327765f + "'", float3 == 0.7327765f);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-157269966) + "'", int8 == (-157269966));
//        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.4619428f + "'", float10 == 0.4619428f);
//        org.junit.Assert.assertNotNull(byteArray16);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        double[] doubleArray14 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14);
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) -1);
        boolean boolean19 = pointValuePair17.equals((java.lang.Object) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = pointValuePair17.equals(obj20);
        double[] doubleArray22 = pointValuePair17.getPoint();
        double[] doubleArray23 = pointValuePair17.getKey();
        boolean boolean24 = array2DRowRealMatrix8.equals((java.lang.Object) doubleArray23);
        double[] doubleArray26 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray30 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition32 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray26, doubleArray30, (double) (byte) 10);
        double[] doubleArray33 = eigenDecomposition32.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray33);
        double[] doubleArray36 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray40 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition42 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray36, doubleArray40, (double) (byte) 10);
        double[] doubleArray43 = eigenDecomposition42.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray43);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix34, (org.apache.commons.math3.linear.AnyMatrix) realMatrix44);
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = array2DRowRealMatrix8.multiply(realMatrix34);
        double[][] doubleArray47 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray47);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex53 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray47, 22026.0d, (double) 9, (double) (short) 0, (double) 0.8993244f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 0);
        incrementor1.incrementCount((int) (byte) 0);
        try {
            incrementor1.incrementCount(12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test092");
//        int[] intArray1 = new int[] { 100 };
//        int[] intArray4 = new int[] { 100, 97 };
//        int int5 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray1, intArray4);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister();
//        float float7 = mersenneTwister6.nextFloat();
//        int[] intArray13 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
//        int[] intArray19 = new int[] { 97, 1, 100, (byte) 100, 52 };
//        int int20 = org.apache.commons.math3.util.MathArrays.distance1(intArray13, intArray19);
//        mersenneTwister6.setSeed(intArray13);
//        int int22 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray1, intArray13);
//        org.junit.Assert.assertNotNull(intArray1);
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5286374f + "'", float7 == 0.5286374f);
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 247 + "'", int20 == 247);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 99 + "'", int22 == 99);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix2.add(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix13.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix13);
        org.apache.commons.math3.linear.RealVector realVector20 = openMapRealMatrix18.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix21 = openMapRealMatrix2.subtract(openMapRealMatrix18);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSymmetric((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix21, 3.8146972656249996E-6d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (97x52) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(openMapRealMatrix21);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((-0.001046155115639312d), 10671.0d, (-381728948));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double2 = org.apache.commons.math3.util.FastMath.max(0.0d, 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8414709848078965d + "'", double2 == 0.8414709848078965d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((-0.012233790557032886d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.012233180267572585d) + "'", double1 == (-0.012233180267572585d));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[][] doubleArray24 = array2DRowRealMatrix7.getData();
        try {
            array2DRowRealMatrix7.addToEntry((int) '#', (int) (short) 10, (double) 0.04532051f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.RealVector realVector9 = openMapRealMatrix7.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix12.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix12);
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix17.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix20 = openMapRealMatrix7.add(openMapRealMatrix17);
        try {
            openMapRealMatrix20.multiplyEntry((int) 'a', (int) ' ', 0.38108765337432393d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealMatrix20);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 0.9145533f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer();
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray6, (double) (byte) -1);
        boolean boolean11 = pointValuePair9.equals((java.lang.Object) 0);
        java.lang.Object obj12 = null;
        boolean boolean13 = pointValuePair9.equals(obj12);
        double[] doubleArray14 = pointValuePair9.getPoint();
        double[] doubleArray18 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray18);
        double[] doubleArray22 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray26 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray22, doubleArray26, (double) (byte) 10);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray26);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray18, doubleArray29, (double) (byte) -1);
        boolean boolean32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        try {
            double[][] doubleArray34 = levenbergMarquardtOptimizer0.computeCovariances(doubleArray14, 0.17453292519943295d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight32 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        double[] doubleArray33 = array2DRowRealMatrix7.operate(doubleArray25);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix7.power(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (5x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition11 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix9, (double) 0);
        double double12 = lUDecomposition11.getDeterminant();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = lUDecomposition11.getL();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.012233790557032886d) + "'", double12 == (-0.012233790557032886d));
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double[] doubleArray2 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray6 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray2, doubleArray6, (double) (byte) 10);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        double[] doubleArray16 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) (-1L));
        boolean boolean21 = arrayRealVector17.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        double[] doubleArray23 = arrayRealVector17.getDataRef();
        try {
            double[] doubleArray24 = diagonalMatrix10.operate(doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) 247.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(0.957118376469154d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.012233790557032886d), (java.lang.Number) (-1L), (java.lang.Number) 1L);
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2005.3522829578812d + "'", double1 == 2005.3522829578812d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(5, (int) (short) 1, 16, (int) (byte) 10);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        double[] doubleArray12 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray16 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition18 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray12, doubleArray16, (double) (byte) 10);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray16);
        double double20 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray16);
        double double21 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray8, doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double29 = diagonalMatrix23.walkInOptimizedOrder(realMatrixChangingVisitor24, 3, 97, 9, 4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (3)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.4142135623730951d + "'", double20 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.9877662094429671d + "'", double21 == 0.9877662094429671d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix48 = array2DRowRealMatrix7.createMatrix((int) (byte) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        double double2 = org.apache.commons.math3.util.FastMath.pow(2.787593149816328E42d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifySequence((double) (short) 1, 0.28943395614624023d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1, 0.289]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "{", "{", "", "[", "{");
        java.lang.String str7 = realMatrixFormat6.getPrefix();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix2.add(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix13.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix13);
        org.apache.commons.math3.linear.RealVector realVector20 = openMapRealMatrix18.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix21 = openMapRealMatrix2.subtract(openMapRealMatrix18);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition23 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix2, (double) 4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (97x52) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(openMapRealMatrix21);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight32 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        double[] doubleArray33 = array2DRowRealMatrix7.operate(doubleArray25);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor34 = null;
        try {
            double double35 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { (byte) 10 };
        double[] doubleArray8 = new double[] { (byte) 10 };
        double[][] doubleArray9 = new double[][] { doubleArray6, doubleArray8 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9, false);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, 0.0d, 3.141592653589793d, (double) 97, (double) 247, (java.lang.Object[]) doubleArray9);
        double double13 = noBracketingException12.getFLo();
        double double14 = noBracketingException12.getFHi();
        double double15 = noBracketingException12.getFLo();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 97.0d + "'", double13 == 97.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 247.0d + "'", double14 == 247.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 97.0d + "'", double15 == 97.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number1, 97);
        int int4 = nonMonotonicSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonicSequenceException3.getPrevious();
        int int6 = nonMonotonicSequenceException3.getIndex();
        java.lang.Number number7 = nonMonotonicSequenceException3.getPrevious();
        java.lang.Number number8 = nonMonotonicSequenceException3.getArgument();
        java.lang.Number number9 = nonMonotonicSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0f + "'", number8.equals(1.0f));
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) '4');
        double[] doubleArray8 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray16 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray24 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24);
        org.apache.commons.math3.optim.PointValuePair pointValuePair27 = new org.apache.commons.math3.optim.PointValuePair(doubleArray24, (double) (byte) -1);
        boolean boolean29 = pointValuePair27.equals((java.lang.Object) 0);
        java.lang.Object obj30 = null;
        boolean boolean31 = pointValuePair27.equals(obj30);
        double[] doubleArray32 = pointValuePair27.getPoint();
        double[] doubleArray33 = pointValuePair27.getKey();
        boolean boolean34 = array2DRowRealMatrix18.equals((java.lang.Object) doubleArray33);
        double[] doubleArray36 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray40 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition42 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray36, doubleArray40, (double) (byte) 10);
        double[] doubleArray43 = eigenDecomposition42.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray43);
        double[] doubleArray46 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray50 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition52 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray46, doubleArray50, (double) (byte) 10);
        double[] doubleArray53 = eigenDecomposition52.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray53);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix44, (org.apache.commons.math3.linear.AnyMatrix) realMatrix54);
        org.apache.commons.math3.linear.RealMatrix realMatrix56 = array2DRowRealMatrix18.multiply(realMatrix44);
        double[][] doubleArray57 = array2DRowRealMatrix18.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = array2DRowRealMatrix18.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = array2DRowRealMatrix10.add(array2DRowRealMatrix18);
        try {
            diagonalMatrix1.setRowMatrix(50, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x1 but expected 1x52");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix61);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) (short) 10, (double) 'a', (double) (short) 10);
        double double4 = searchInterval3.getStartValue();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, 3.141592653589793d, 97);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.copy();
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8);
        int int11 = diagonalMatrix8.getRowDimension();
        diagonalMatrix8.multiplyEntry((int) (short) 10, (int) (short) 100, 254.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition10 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix7, 0.7894702148849957d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (5x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) (-1773261632), (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.77326144E9f) + "'", float2 == (-1.77326144E9f));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { (byte) 10 };
        double[] doubleArray8 = new double[] { (byte) 10 };
        double[][] doubleArray9 = new double[][] { doubleArray6, doubleArray8 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9, false);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, 0.0d, 3.141592653589793d, (double) 97, (double) 247, (java.lang.Object[]) doubleArray9);
        double double13 = noBracketingException12.getLo();
        double double14 = noBracketingException12.getLo();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        arrayRealVector6.set((double) (byte) 0);
        boolean boolean11 = arrayRealVector6.isNaN();
        double[] doubleArray18 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18, false);
        double[] doubleArray26 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.mapDivideToSelf((double) (-1L));
        double[] doubleArray35 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector36.mapDivideToSelf((double) (-1L));
        boolean boolean40 = arrayRealVector36.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector36.append((double) (short) 100);
        double double43 = arrayRealVector27.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        double[] doubleArray49 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray49);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector50.mapDivideToSelf((double) (-1L));
        boolean boolean53 = arrayRealVector50.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc55 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector50.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc55);
        org.apache.commons.math3.analysis.function.Sinc sinc58 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector50.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = arrayRealVector36.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = arrayRealVector20.add((org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        arrayRealVector6.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        double[] doubleArray63 = arrayRealVector6.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 18918.0d + "'", double43 == 18918.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(arrayRealVector56);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertNotNull(arrayRealVector60);
        org.junit.Assert.assertNotNull(arrayRealVector61);
        org.junit.Assert.assertNotNull(doubleArray63);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0d, (-0.012233180267572585d), (-157269966));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector15.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.append((double) (short) 100);
        double double22 = arrayRealVector6.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector6.mapSubtractToSelf(3.982441812995697E30d);
        double[] doubleArray30 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.analysis.function.Sinc sinc35 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector31.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc35);
        double[] doubleArray42 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42, false);
        double[] doubleArray50 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50, false);
        double[] doubleArray58 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray58);
        org.apache.commons.math3.linear.RealVector realVector61 = arrayRealVector59.mapDivideToSelf((double) (-1L));
        boolean boolean63 = arrayRealVector59.equals((java.lang.Object) 10);
        double double64 = arrayRealVector52.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector59);
        double[] doubleArray72 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray72);
        org.apache.commons.math3.linear.RealVector realVector75 = arrayRealVector73.mapDivideToSelf((double) (-1L));
        boolean boolean77 = arrayRealVector73.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector79 = arrayRealVector73.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector81 = arrayRealVector73.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = arrayRealVector59.combine((double) (byte) 0, (double) (-1L), realVector81);
        org.apache.commons.math3.linear.RealMatrix realMatrix83 = arrayRealVector44.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector59);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector36, arrayRealVector59);
        org.apache.commons.math3.linear.RealVector realVector85 = arrayRealVector6.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.RealVector realVector87 = arrayRealVector36.mapDivideToSelf((double) (-1809524577));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 18918.0d + "'", double22 == 18918.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realVector61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 246.6779276708802d + "'", double64 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realVector75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertNotNull(realVector81);
        org.junit.Assert.assertNotNull(arrayRealVector82);
        org.junit.Assert.assertNotNull(realMatrix83);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertNotNull(realVector87);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector16.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        double double23 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector16.copy();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector16.getSubVector((int) (byte) 1, (int) (short) 1);
        org.apache.commons.math3.analysis.function.Sinc sinc28 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector16.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc28);
        try {
            double[] doubleArray34 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc28, 0.6135536048441389d, (double) 97.0f, 0.28943395614624023d, 4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [97, 0.614]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(3.8146972656249996E-6d, 0.5288560945221015d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.8146972656249996E-6d + "'", double2 == 3.8146972656249996E-6d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 36, (java.lang.Number) 14.177446878757825d, true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double double8 = arrayRealVector7.getMaxValue();
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector15.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc20 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc20);
        org.apache.commons.math3.analysis.function.Sinc sinc23 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector15.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc23);
        double double25 = arrayRealVector7.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector24.copy();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat27 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat28 = realVectorFormat27.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = realVectorFormat27.parse("{0; -0; 1; 1; 0}");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector24.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        double[] doubleArray37 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37);
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector38.mapDivideToSelf((double) (-1L));
        boolean boolean41 = arrayRealVector38.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc43 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector38.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc43);
        double double45 = arrayRealVector44.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector31.add((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 252.05440211108893d + "'", double25 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(realVectorFormat27);
        org.junit.Assert.assertNotNull(numberFormat28);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.4142135623730951d + "'", double45 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(arrayRealVector46);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix7);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix11.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix16 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix11);
        org.apache.commons.math3.linear.RealVector realVector18 = openMapRealMatrix16.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix21.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix26 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix21);
        org.apache.commons.math3.linear.RealVector realVector28 = openMapRealMatrix26.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix29 = openMapRealMatrix16.add(openMapRealMatrix26);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor30 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor30.start(0, 247, 1, (int) (short) -1, 0, 0);
        double double38 = openMapRealMatrix26.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor30);
        int int39 = openMapRealMatrix26.getColumnDimension();
        boolean boolean41 = openMapRealMatrix26.equals((java.lang.Object) "");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix42 = openMapRealMatrix7.subtract(openMapRealMatrix26);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(openMapRealMatrix29);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 52 + "'", int39 == 52);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix42);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double3 = bracketFinder2.getHi();
        double[] doubleArray9 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector10.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType16 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        bracketFinder2.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc14, goalType16, (-0.0d), (double) 1.0f);
        double double20 = bracketFinder2.getFLo();
        double double21 = bracketFinder2.getHi();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertTrue("'" + goalType16 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType16.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.8414709848078965d + "'", double20 == 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0000061723098754d + "'", double21 == 1.0000061723098754d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(6, 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = openMapRealMatrix2.createMatrix(9, 5);
        org.junit.Assert.assertNotNull(openMapRealMatrix5);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.39f, (float) 97, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(1.4153232443518473d, 2.718281828459045d);
        int int3 = simplexOptimizer2.getMaxIterations();
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray4 = new org.apache.commons.math3.optim.OptimizationData[] {};
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair5 = simplexOptimizer2.optimize(optimizationDataArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertNotNull(optimizationDataArray4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval(52);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula2 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker3 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver6 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula2, pointValuePairConvergenceChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver6);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner8 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer9 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver6, preconditioner8);
        int int10 = brentSolver6.getEvaluations();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test141");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math3.random.MersenneTwister();
//        float float6 = mersenneTwister5.nextFloat();
//        byte[] byteArray12 = new byte[] { (byte) -1, (byte) 100, (byte) 0, (byte) 10, (byte) 100 };
//        mersenneTwister5.nextBytes(byteArray12);
//        long long14 = mersenneTwister5.nextLong();
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math3.random.MersenneTwister();
//        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker26 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
//        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer27 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(1378221360, 0.0d, true, 1378221360, 4, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister21, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker26);
//        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer28 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(12, 0.0d, true, 10, (int) (short) 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister5, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker26);
//        java.util.List<java.lang.Double> doubleList29 = cMAESOptimizer28.getStatisticsSigmaHistory();
//        java.util.List<java.lang.Double> doubleList30 = cMAESOptimizer28.getStatisticsSigmaHistory();
//        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.3241912f + "'", float6 == 0.3241912f);
//        org.junit.Assert.assertNotNull(byteArray12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-6972347676542765804L) + "'", long14 == (-6972347676542765804L));
//        org.junit.Assert.assertNotNull(doubleList29);
//        org.junit.Assert.assertNotNull(doubleList30);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        double[][] doubleArray9 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.exception.ZeroException zeroException10 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        double[] doubleArray14 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22);
        org.apache.commons.math3.optim.PointValuePair pointValuePair25 = new org.apache.commons.math3.optim.PointValuePair(doubleArray22, (double) (byte) -1);
        boolean boolean27 = pointValuePair25.equals((java.lang.Object) 0);
        java.lang.Object obj28 = null;
        boolean boolean29 = pointValuePair25.equals(obj28);
        double[] doubleArray30 = pointValuePair25.getPoint();
        double[] doubleArray31 = pointValuePair25.getKey();
        boolean boolean32 = array2DRowRealMatrix16.equals((java.lang.Object) doubleArray31);
        double[] doubleArray34 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray38 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition40 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray34, doubleArray38, (double) (byte) 10);
        double[] doubleArray41 = eigenDecomposition40.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray41);
        double[] doubleArray44 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray48 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition50 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray44, doubleArray48, (double) (byte) 10);
        double[] doubleArray51 = eigenDecomposition50.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray51);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix42, (org.apache.commons.math3.linear.AnyMatrix) realMatrix52);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = array2DRowRealMatrix16.multiply(realMatrix42);
        double[][] doubleArray55 = array2DRowRealMatrix16.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix58 = array2DRowRealMatrix16.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = array2DRowRealMatrix8.add(array2DRowRealMatrix16);
        boolean boolean60 = array2DRowRealMatrix16.isSquare();
        double[][] doubleArray61 = array2DRowRealMatrix16.getData();
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException62 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.copy();
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16);
        java.lang.Number number20 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException22 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number20, 97);
        int int23 = nonMonotonicSequenceException22.getIndex();
        java.lang.Number number24 = nonMonotonicSequenceException22.getPrevious();
        int int25 = nonMonotonicSequenceException22.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection26 = nonMonotonicSequenceException22.getDirection();
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray16, orderDirection26, false, false);
        double[] doubleArray30 = diagonalMatrix8.operate(doubleArray16);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex33 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray16, (double) (-1), 22025.999999999996d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 97 + "'", int23 == 97);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 97 + "'", int25 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double[] doubleArray6 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector7.isNaN();
        double[] doubleArray16 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) (-1L));
        boolean boolean20 = arrayRealVector17.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc22 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector17.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc22);
        double double24 = arrayRealVector7.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector17.mapDivideToSelf((double) 1);
        double[] doubleArray27 = arrayRealVector17.getDataRef();
        double[] doubleArray33 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray33);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34);
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34, 97);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds39 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray27, doubleArray34);
        double[] doubleArray40 = simpleBounds39.getLower();
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 0.19685411f, doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        double[] doubleArray9 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray13 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition15 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray9, doubleArray13, (double) (byte) 10);
        double[] doubleArray16 = eigenDecomposition15.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16);
        double[][] doubleArray18 = diagonalMatrix17.getData();
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix19 = openMapRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 97x52 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat2 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat1);
        java.lang.String str3 = realVectorFormat2.getPrefix();
        java.text.ParsePosition parsePosition5 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = realVectorFormat2.parse("", parsePosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{" + "'", str3.equals("{"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor(5, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException3 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 3.8146972656435034E-6d, objArray2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        arrayRealVector6.set((double) (byte) 0);
        boolean boolean11 = arrayRealVector6.isNaN();
        boolean boolean12 = arrayRealVector6.isNaN();
        double[] doubleArray19 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        org.apache.commons.math3.optim.PointValuePair pointValuePair30 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) (byte) -1);
        boolean boolean32 = pointValuePair30.equals((java.lang.Object) 0);
        java.lang.Object obj33 = null;
        boolean boolean34 = pointValuePair30.equals(obj33);
        double[] doubleArray35 = pointValuePair30.getPoint();
        double[] doubleArray36 = pointValuePair30.getKey();
        boolean boolean37 = array2DRowRealMatrix21.equals((java.lang.Object) doubleArray36);
        int int38 = org.apache.commons.math3.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math3.optim.PointValuePair pointValuePair40 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, (double) 2147483647);
        arrayRealVector6.setSubVector((int) (short) 0, doubleArray36);
        double[] doubleArray45 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray45);
        double[] doubleArray49 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray53 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition55 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray49, doubleArray53, (double) (byte) 10);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray53);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition58 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray45, doubleArray56, (double) (byte) -1);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray36, doubleArray56);
        double[] doubleArray65 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray66 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray65);
        org.apache.commons.math3.optim.PointValuePair pointValuePair68 = new org.apache.commons.math3.optim.PointValuePair(doubleArray65, (double) (byte) -1);
        java.lang.Double double69 = pointValuePair68.getSecond();
        double[] doubleArray70 = pointValuePair68.getFirst();
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair71 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray56, doubleArray70);
        boolean boolean73 = pointVectorValuePair71.equals((java.lang.Object) 4.342925101645957d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1809524577) + "'", int38 == (-1809524577));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + (-1.0d) + "'", double69.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(99.0d, (double) 0.5105547f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 98.99999999999999d + "'", double2 == 98.99999999999999d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6, 97);
        org.apache.commons.math3.optim.PointValuePair pointValuePair13 = new org.apache.commons.math3.optim.PointValuePair(doubleArray10, 2.787593149816328E42d, false);
        double[] doubleArray19 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10, doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double double17 = sinc14.value((double) 0.5105547f);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction18 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction19 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.957118376469154d + "'", double17 == 0.957118376469154d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifySequence((double) 0.053712964f, 0.0d, 7.909921332671597E-4d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0.054, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = realMatrixFormat0.parse(",");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \",\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.Array2DRowRealMatrix");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double[] doubleArray23 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.mapDivideToSelf((double) (-1L));
        boolean boolean27 = arrayRealVector24.isNaN();
        double[] doubleArray28 = arrayRealVector24.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector15.combineToSelf(0.0d, (-0.012233180267572585d), (org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        double[][] doubleArray10 = diagonalMatrix9.getData();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) (-1.55530214E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.555302144E9d) + "'", double1 == (-1.555302144E9d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula1 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker5 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula1, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker11 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver15 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 'a', (double) (short) 10, (double) (-1));
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer16 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver15);
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) (-157269966), 247, 50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 50, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 30, (java.lang.Number) 6.283185307179586d, true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(6.691673596021348E41d, (double) 0.46547258f, (double) 0.9949522f, (-1.0d), (double) 12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double double1 = org.apache.commons.math3.util.FastMath.exp(10671.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer5 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4);
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder9 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double10 = bracketFinder9.getHi();
        double[] doubleArray16 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector17.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType23 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        bracketFinder9.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc21, goalType23, (-0.0d), (double) 1.0f);
        try {
            double double30 = brentSolver4.solve(0, (org.apache.commons.math3.analysis.UnivariateFunction) sinc21, (double) 0.3820138f, (double) 0.013082147f, 1.733816411287911d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1.734, 0.013]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + goalType23 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType23.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 0.18379879f, 1872882.0d, (double) 0.053712964f, (double) 21, (double) 0.15928364f, 0.7262694092379458d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 344234.6890267067d + "'", double6 == 344234.6890267067d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        boolean boolean10 = pointValuePair8.equals((java.lang.Object) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = pointValuePair8.equals(obj11);
        double[] doubleArray13 = pointValuePair8.getPoint();
        java.lang.Double double14 = pointValuePair8.getValue();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14.equals((-1.0d)));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace(", ", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(number1, (java.lang.Number) 10L, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        float float2 = org.apache.commons.math3.util.FastMath.max(10.0f, 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(0);
        org.apache.commons.math3.linear.RealVector realVector2 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector1.subtract(realVector2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 93);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 93.00001f + "'", float1 == 93.00001f);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) (short) 10, doubleArray7);
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray7, doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray14);
        java.io.ObjectOutputStream objectOutputStream18 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix(realMatrix17, objectOutputStream18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver8 = eigenDecomposition7.getSolver();
        double[] doubleArray9 = eigenDecomposition7.getImagEigenvalues();
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.optim.PointValuePair pointValuePair18 = new org.apache.commons.math3.optim.PointValuePair(doubleArray15, (double) (byte) -1);
        boolean boolean20 = pointValuePair18.equals((java.lang.Object) 0);
        java.lang.Object obj21 = null;
        boolean boolean22 = pointValuePair18.equals(obj21);
        double[] doubleArray23 = pointValuePair18.getPoint();
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        int[] intArray31 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
        int[] intArray37 = new int[] { 97, 1, 100, (byte) 100, 52 };
        int int38 = org.apache.commons.math3.util.MathArrays.distance1(intArray31, intArray37);
        int[] intArray39 = org.apache.commons.math3.util.MathArrays.copyOf(intArray31);
        int[] intArray40 = null;
        org.apache.commons.math3.exception.util.Localizable localizable41 = null;
        org.apache.commons.math3.exception.util.Localizable localizable42 = null;
        double[] doubleArray48 = new double[] { (byte) 10 };
        double[] doubleArray50 = new double[] { (byte) 10 };
        double[][] doubleArray51 = new double[][] { doubleArray48, doubleArray50 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray51, false);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException54 = new org.apache.commons.math3.exception.NoBracketingException(localizable42, 0.0d, 3.141592653589793d, (double) 97, (double) 247, (java.lang.Object[]) doubleArray51);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable41, (java.lang.Object[]) doubleArray51);
        try {
            array2DRowRealMatrix25.copySubMatrix(intArray39, intArray40, doubleArray51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(decompositionSolver8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 247 + "'", int38 == 247);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector16.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        double double23 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector16.copy();
        double[] doubleArray30 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, false);
        double[] doubleArray38 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector39.mapDivideToSelf((double) (-1L));
        boolean boolean43 = arrayRealVector39.equals((java.lang.Object) 10);
        double double44 = arrayRealVector32.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        double[] doubleArray52 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray52);
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector53.mapDivideToSelf((double) (-1L));
        boolean boolean57 = arrayRealVector53.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector53.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector61 = arrayRealVector53.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector39.combine((double) (byte) 0, (double) (-1L), realVector61);
        double double63 = arrayRealVector39.getNorm();
        boolean boolean64 = arrayRealVector39.isInfinite();
        double double65 = arrayRealVector16.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 246.6779276708802d + "'", double44 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(realVector61);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 137.5427206361718d + "'", double63 == 137.5427206361718d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        double[] doubleArray33 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray37 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition39 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray33, doubleArray37, (double) (byte) 10);
        double[] doubleArray40 = eigenDecomposition39.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray40);
        double[] doubleArray43 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray47 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray43, doubleArray47, (double) (byte) 10);
        double[] doubleArray50 = eigenDecomposition49.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray50);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix41, (org.apache.commons.math3.linear.AnyMatrix) realMatrix51);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = array2DRowRealMatrix15.multiply(realMatrix41);
        double[][] doubleArray54 = array2DRowRealMatrix15.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = array2DRowRealMatrix15.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = array2DRowRealMatrix7.add(array2DRowRealMatrix15);
        try {
            array2DRowRealMatrix58.addToEntry(16, 3, (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (16)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix58);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 52, 1.734723475976807E-18d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.RealVector realVector9 = openMapRealMatrix7.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix12.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix12);
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix17.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix20 = openMapRealMatrix7.add(openMapRealMatrix17);
        int int21 = openMapRealMatrix20.getColumnDimension();
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealMatrix20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.apache.commons.math3.random.RandomGenerator randomGenerator5 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker7 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(247, 0.0d, true, (int) (byte) -1, (int) '#', randomGenerator5, true, pointValuePairConvergenceChecker7);
        java.util.List<java.lang.Double> doubleList9 = cMAESOptimizer8.getStatisticsSigmaHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList10 = cMAESOptimizer8.getStatisticsDHistory();
        int int11 = cMAESOptimizer8.getEvaluations();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep13 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep((-1.0d));
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction14 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction objectiveFunction15 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction(multivariateFunction14);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray16 = new org.apache.commons.math3.optim.OptimizationData[] { bracketingStep13, objectiveFunction15 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair17 = cMAESOptimizer8.optimize(optimizationDataArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleList9);
        org.junit.Assert.assertNotNull(realMatrixList10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(optimizationDataArray16);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        double[] doubleArray12 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray16 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition18 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray12, doubleArray16, (double) (byte) 10);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray16);
        double double20 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray16);
        double double21 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray8, doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(12, 0.7262694092379458d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapSubtract((double) (byte) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.4142135623730951d + "'", double20 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.9877662094429671d + "'", double21 == 0.9877662094429671d);
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        double[][] doubleArray46 = array2DRowRealMatrix7.getData();
        int int47 = array2DRowRealMatrix7.getRowDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix49 = array2DRowRealMatrix7.getRowMatrix((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 5 + "'", int47 == 5);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector16.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        double double23 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector16.mapDivideToSelf((double) 1);
        double[] doubleArray26 = arrayRealVector16.getDataRef();
        double[] doubleArray32 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, false);
        double[] doubleArray40 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, false);
        double[] doubleArray48 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray48);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector49.mapDivideToSelf((double) (-1L));
        boolean boolean53 = arrayRealVector49.equals((java.lang.Object) 10);
        double double54 = arrayRealVector42.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        double[] doubleArray62 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray62);
        org.apache.commons.math3.linear.RealVector realVector65 = arrayRealVector63.mapDivideToSelf((double) (-1L));
        boolean boolean67 = arrayRealVector63.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector69 = arrayRealVector63.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector71 = arrayRealVector63.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = arrayRealVector49.combine((double) (byte) 0, (double) (-1L), realVector71);
        org.apache.commons.math3.linear.RealMatrix realMatrix73 = arrayRealVector34.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = arrayRealVector16.add((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        double[] doubleArray75 = arrayRealVector74.toArray();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 246.6779276708802d + "'", double54 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertNotNull(arrayRealVector72);
        org.junit.Assert.assertNotNull(realMatrix73);
        org.junit.Assert.assertNotNull(arrayRealVector74);
        org.junit.Assert.assertNotNull(doubleArray75);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6, 97);
        org.apache.commons.math3.optim.nonlinear.vector.Target target11 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray10);
        double[] doubleArray12 = target11.getTarget();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray12);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition14 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(10, (-1555302186), (double) (byte) 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 52.0f, number2, (java.lang.Number) (-0.012233790557032886d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor3.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double11 = openMapRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor15 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor15.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double23 = openMapRealMatrix14.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor15);
        int int24 = openMapRealMatrix14.getRowDimension();
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix14, 0);
        org.apache.commons.math3.linear.RealVector realVector28 = openMapRealMatrix14.getColumnVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix29 = openMapRealMatrix2.subtract(openMapRealMatrix14);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 97 + "'", int24 == 97);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(openMapRealMatrix29);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver3 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 'a', (double) (short) 10, (double) (-1));
        double double4 = brentSolver3.getStartValue();
        double double5 = brentSolver3.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number1, 97);
        java.lang.Number number4 = nonMonotonicSequenceException3.getPrevious();
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray7 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray13 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        double[][] doubleArray15 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray14);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14, true);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math3.exception.ConvergenceException convergenceException19 = new org.apache.commons.math3.exception.ConvergenceException(localizable0, (java.lang.Object[]) doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection11 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 0.15928364f, (java.lang.Number) 0.9326714f, 32, orderDirection11, true);
        org.apache.commons.math3.exception.util.Localizable localizable14 = null;
        double[] doubleArray17 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray21 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition23 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray17, doubleArray21, (double) (byte) 10);
        double[] doubleArray24 = eigenDecomposition23.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix25 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24);
        double[][] doubleArray26 = diagonalMatrix25.getData();
        double[][] doubleArray27 = diagonalMatrix25.getData();
        double[][] doubleArray28 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray27);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException29 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable14, (java.lang.Number) (-49.90884964603208d), (java.lang.Object[]) doubleArray28);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray1, orderDirection11, doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.4153232443518473d, (double) Float.NaN, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        int int6 = brentOptimizer5.getIterations();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker7 = brentOptimizer5.getConvergenceChecker();
        double double8 = brentOptimizer5.getMin();
        double double9 = brentOptimizer5.getMax();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(univariatePointValuePairConvergenceChecker7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d);
        double double2 = brentSolver1.getMin();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder6 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double7 = bracketFinder6.getHi();
        double double8 = bracketFinder6.getLo();
        org.apache.commons.math3.analysis.function.Sinc sinc10 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType11 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder6.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc10, goalType11, (double) '4', (double) 'a');
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction15 = sinc10.derivative();
        try {
            double double17 = brentSolver1.solve((-1773261632), univariateFunction15, (double) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (-1,773,261,632) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType11 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType11.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(univariateFunction15);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            double double10 = array2DRowRealMatrix7.getEntry(9, 50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (9)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 7.6293945E-6f, (double) (byte) 10);
        double double3 = simpleUnivariateValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.62939453125E-6d + "'", double3 == 7.62939453125E-6d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker6 = new org.apache.commons.math3.optim.SimpleValueChecker((-0.006179939774976235d), 0.0d);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 10.0f, (double) (short) -1, 12.0d, (double) (-1.0f), (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver8 = eigenDecomposition7.getSolver();
        double[] doubleArray9 = eigenDecomposition7.getImagEigenvalues();
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.optim.PointValuePair pointValuePair18 = new org.apache.commons.math3.optim.PointValuePair(doubleArray15, (double) (byte) -1);
        boolean boolean20 = pointValuePair18.equals((java.lang.Object) 0);
        java.lang.Object obj21 = null;
        boolean boolean22 = pointValuePair18.equals(obj21);
        double[] doubleArray23 = pointValuePair18.getPoint();
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor26 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor26.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double34 = defaultRealMatrixPreservingVisitor26.end();
        try {
            double double39 = array2DRowRealMatrix25.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor26, (int) (short) 0, 0, 21, 1678488564);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (21)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(decompositionSolver8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) (short) 0, (double) ' ');
        double[] doubleArray9 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.mapDivideToSelf((double) (-1L));
        boolean boolean13 = arrayRealVector10.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc15 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector10.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc15);
        try {
            double double20 = brentSolver2.solve(0, (org.apache.commons.math3.analysis.UnivariateFunction) sinc15, (double) 93.00001f, (double) 0.7327765f, 3.296908309475615d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [93, 3.297]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(arrayRealVector16);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double[] doubleArray7 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) (short) 10, doubleArray8);
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.scale(7.909921332671597E-4d, doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target11 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        double[][] doubleArray46 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = array2DRowRealMatrix7.createMatrix((int) ' ', 4);
        double[][] doubleArray50 = array2DRowRealMatrix7.getData();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7, 97);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.scale(1.4153232443518473d, doubleArray11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean22 = arrayRealVector19.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc24 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector19.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc24);
        org.apache.commons.math3.analysis.function.Sinc sinc27 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector19.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc27);
        double[] doubleArray30 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray34 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition36 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray30, doubleArray34, (double) (byte) 10);
        double[] doubleArray37 = eigenDecomposition36.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, doubleArray37);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, doubleArray37);
        try {
            org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -0.012 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix39);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        double[] doubleArray2 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray6 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray2, doubleArray6, (double) (byte) 10);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray6);
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, doubleArray16);
        arrayRealVector17.addToEntry(1, 246.6779276708802d);
        int int21 = arrayRealVector17.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7, 97);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.scale(1.4153232443518473d, doubleArray11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean22 = arrayRealVector19.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc24 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector19.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc24);
        org.apache.commons.math3.analysis.function.Sinc sinc27 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector19.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc27);
        double[] doubleArray30 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray34 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition36 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray30, doubleArray34, (double) (byte) 10);
        double[] doubleArray37 = eigenDecomposition36.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, doubleArray37);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, doubleArray37);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight42 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix41);
        double[] doubleArray44 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray48 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition50 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray44, doubleArray48, (double) (byte) 10);
        double[] doubleArray51 = eigenDecomposition50.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray51);
        double[][] doubleArray53 = diagonalMatrix52.getData();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix54 = diagonalMatrix41.add(diagonalMatrix52);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(diagonalMatrix54);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) (-1555302186));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.55530202E9f) + "'", float1 == (-1.55530202E9f));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        int[] intArray1 = new int[] { 100 };
        int[] intArray4 = new int[] { 100, 97 };
        int int5 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray1, intArray4);
        int[] intArray11 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
        int[] intArray17 = new int[] { 97, 1, 100, (byte) 100, 52 };
        int int18 = org.apache.commons.math3.util.MathArrays.distance1(intArray11, intArray17);
        double double19 = org.apache.commons.math3.util.MathArrays.distance(intArray1, intArray11);
        int[] intArray25 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
        int[] intArray31 = new int[] { 97, 1, 100, (byte) 100, 52 };
        int int32 = org.apache.commons.math3.util.MathArrays.distance1(intArray25, intArray31);
        int[] intArray33 = org.apache.commons.math3.util.MathArrays.copyOf(intArray25);
        int int34 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray1, intArray25);
        int[] intArray35 = org.apache.commons.math3.util.MathArrays.copyOf(intArray1);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister36 = new org.apache.commons.math3.random.MersenneTwister(intArray35);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 247 + "'", int18 == 247);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 99.0d + "'", double19 == 99.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 247 + "'", int32 == 247);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 99 + "'", int34 == 99);
        org.junit.Assert.assertNotNull(intArray35);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) (short) 0, (double) ' ');
        double double3 = brentSolver2.getStartValue();
        double[] doubleArray10 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapDivideToSelf((double) (-1L));
        boolean boolean14 = arrayRealVector11.isNaN();
        double[] doubleArray20 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapDivideToSelf((double) (-1L));
        boolean boolean24 = arrayRealVector21.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc26 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector21.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc26);
        double double28 = arrayRealVector11.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector21.copy();
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector21.getSubVector((int) (byte) 1, (int) (short) 1);
        org.apache.commons.math3.analysis.function.Sinc sinc33 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector21.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc33);
        try {
            double double36 = brentSolver2.solve(9, (org.apache.commons.math3.analysis.UnivariateFunction) sinc33, 1.4142135623730951d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [�, �], values: [�, �]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(arrayRealVector34);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 100L, (float) 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix15.copy();
        double[] doubleArray22 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, false);
        double[] doubleArray30 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) (-1L));
        boolean boolean35 = arrayRealVector31.equals((java.lang.Object) 10);
        double double36 = arrayRealVector24.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double[] doubleArray44 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray44);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector45.mapDivideToSelf((double) (-1L));
        boolean boolean49 = arrayRealVector45.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector45.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector45.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector31.combine((double) (byte) 0, (double) (-1L), realVector53);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix15, realVector53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 246.6779276708802d + "'", double36 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(arrayRealVector54);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyInterval((double) 'a', 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [97, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number1, 97);
        int int4 = nonMonotonicSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonicSequenceException3.getPrevious();
        int int6 = nonMonotonicSequenceException3.getIndex();
        java.lang.Number number7 = nonMonotonicSequenceException3.getPrevious();
        java.lang.Number number8 = nonMonotonicSequenceException3.getArgument();
        boolean boolean9 = nonMonotonicSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0f + "'", number8.equals(1.0f));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 100L);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        java.lang.Number number3 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 100L + "'", number2.equals(100L));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100L + "'", number3.equals(100L));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.4153232443518473d, (double) Float.NaN, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        int int6 = brentOptimizer5.getIterations();
        int int7 = brentOptimizer5.getMaxIterations();
        double double8 = brentOptimizer5.getStartValue();
        int int9 = brentOptimizer5.getEvaluations();
        int int10 = brentOptimizer5.getEvaluations();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker11 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(1378221360, 0.0d, true, 1378221360, 4, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver15 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) (-1L));
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer16 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver15);
        int int17 = brentSolver15.getEvaluations();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 4, 52, 2147483647, 97, 97 };
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { 52, 100, 2147483647, 4, 100, 2147483647 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException15 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray7, intArray14);
        org.apache.commons.math3.exception.ConvergenceException convergenceException16 = new org.apache.commons.math3.exception.ConvergenceException(localizable0, (java.lang.Object[]) intArray7);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext17 = convergenceException16.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext18 = convergenceException16.getContext();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(exceptionContext17);
        org.junit.Assert.assertNotNull(exceptionContext18);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) '4');
        incrementor1.incrementCount((-1023));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance(0.0d, 1.733816411287911d, (double) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7, 97);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.scale(1.4153232443518473d, doubleArray11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean22 = arrayRealVector19.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc24 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector19.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc24);
        org.apache.commons.math3.analysis.function.Sinc sinc27 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector19.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc27);
        double[] doubleArray30 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray34 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition36 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray30, doubleArray34, (double) (byte) 10);
        double[] doubleArray37 = eigenDecomposition36.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, doubleArray37);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, doubleArray37);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37);
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = diagonalMatrix41.scalarAdd((double) 35);
        double[] doubleArray49 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray50 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray49);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray50);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray50);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = diagonalMatrix52.transpose();
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix54 = diagonalMatrix41.subtract(diagonalMatrix52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 5x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix53);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(12, 0.7262694092379458d);
        double[] doubleArray8 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, false);
        double double11 = arrayRealVector10.getMaxValue();
        double[] doubleArray17 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.mapDivideToSelf((double) (-1L));
        boolean boolean21 = arrayRealVector18.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc23 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector18.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc23);
        org.apache.commons.math3.analysis.function.Sinc sinc26 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector18.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc26);
        double double28 = arrayRealVector10.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector27.copy();
        java.lang.Class<?> wildcardClass30 = arrayRealVector27.getClass();
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector27.mapAdd((double) 0.9326714f);
        double[] doubleArray38 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38);
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector39.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.analysis.function.Sinc sinc43 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector39.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc43);
        double[] doubleArray50 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50, false);
        double[] doubleArray58 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray58, false);
        double[] doubleArray66 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray66);
        org.apache.commons.math3.linear.RealVector realVector69 = arrayRealVector67.mapDivideToSelf((double) (-1L));
        boolean boolean71 = arrayRealVector67.equals((java.lang.Object) 10);
        double double72 = arrayRealVector60.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector67);
        double[] doubleArray80 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray80);
        org.apache.commons.math3.linear.RealVector realVector83 = arrayRealVector81.mapDivideToSelf((double) (-1L));
        boolean boolean85 = arrayRealVector81.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector87 = arrayRealVector81.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector89 = arrayRealVector81.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = arrayRealVector67.combine((double) (byte) 0, (double) (-1L), realVector89);
        org.apache.commons.math3.linear.RealMatrix realMatrix91 = arrayRealVector52.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector92 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector44, arrayRealVector67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector93 = new org.apache.commons.math3.linear.ArrayRealVector(realVector32, arrayRealVector92);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector94 = arrayRealVector2.add((org.apache.commons.math3.linear.RealVector) arrayRealVector92);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 12 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 252.05440211108893d + "'", double28 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 246.6779276708802d + "'", double72 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(realVector87);
        org.junit.Assert.assertNotNull(realVector89);
        org.junit.Assert.assertNotNull(arrayRealVector90);
        org.junit.Assert.assertNotNull(realMatrix91);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        long long1 = org.apache.commons.math3.util.FastMath.round(254.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 254L + "'", long1 == 254L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        long long2 = org.apache.commons.math3.util.FastMath.max((-1555302186L), 719869072105511355L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 719869072105511355L + "'", long2 == 719869072105511355L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        double[] doubleArray33 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray37 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition39 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray33, doubleArray37, (double) (byte) 10);
        double[] doubleArray40 = eigenDecomposition39.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray40);
        double[] doubleArray43 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray47 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray43, doubleArray47, (double) (byte) 10);
        double[] doubleArray50 = eigenDecomposition49.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray50);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix41, (org.apache.commons.math3.linear.AnyMatrix) realMatrix51);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = array2DRowRealMatrix15.multiply(realMatrix41);
        double[][] doubleArray54 = array2DRowRealMatrix15.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = array2DRowRealMatrix15.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = array2DRowRealMatrix7.add(array2DRowRealMatrix15);
        boolean boolean59 = array2DRowRealMatrix15.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix62 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix62.multiplyEntry(0, (int) ' ', (double) (short) 1);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix15.preMultiply((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix62);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 52 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double[] doubleArray21 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) (-1L));
        boolean boolean25 = arrayRealVector22.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc27 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector22.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc27);
        org.apache.commons.math3.analysis.function.Sinc sinc30 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector22.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc30);
        double double33 = sinc30.value((double) 0.5105547f);
        double double36 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc30, 97.0d, 2.5108406941546723E58d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc30);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor38 = null;
        try {
            double double39 = arrayRealVector15.walkInOptimizedOrder(realVectorChangingVisitor38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.957118376469154d + "'", double33 == 0.957118376469154d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.2554203470773362E58d + "'", double36 == 1.2554203470773362E58d);
        org.junit.Assert.assertNotNull(arrayRealVector37);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray1, doubleArray30, true);
        double[] doubleArray34 = pointVectorValuePair33.getValueRef();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double[] doubleArray13 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector14.equals((java.lang.Object) 10);
        double double19 = arrayRealVector7.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor20 = null;
        try {
            double double23 = arrayRealVector7.walkInOptimizedOrder(realVectorChangingVisitor20, 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 246.6779276708802d + "'", double19 == 246.6779276708802d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = diagonalMatrix16.copy();
        double[][] doubleArray18 = diagonalMatrix16.getData();
        double[] doubleArray19 = diagonalMatrix16.getDataRef();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x1 but expected 5x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor3.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double11 = openMapRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        int int12 = openMapRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 0);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = openMapRealMatrix2.transpose();
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        java.lang.Double double25 = pointValuePair24.getSecond();
        double[] doubleArray26 = pointValuePair24.getKey();
        java.lang.Double double27 = pointValuePair24.getSecond();
        boolean boolean28 = openMapRealMatrix2.equals((java.lang.Object) pointValuePair24);
        double[] doubleArray29 = pointValuePair24.getPoint();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-1.0d) + "'", double25.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) (short) 10, (double) 'a', (double) (short) 10);
        double double4 = searchInterval3.getMax();
        double double5 = searchInterval3.getMax();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.0d + "'", double4 == 97.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        arrayRealVector6.set((double) (byte) 0);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector6.mapAdd((double) 100.0f);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean23 = arrayRealVector19.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector19.mapDivide((double) '4');
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector6.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        arrayRealVector12.unitize();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor14 = null;
        try {
            double double15 = arrayRealVector12.walkInOptimizedOrder(realVectorPreservingVisitor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction13 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.9657491536246592d, 0.9836065573770492d, 22025.999999999996d, 252.05440211108893d, 1.5707963267948968d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5551749.640019718d + "'", double6 == 5551749.640019718d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector16.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        double double23 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector16.mapAdd((double) (short) 1);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor26 = null;
        try {
            double double29 = arrayRealVector16.walkInOptimizedOrder(realVectorPreservingVisitor26, (-1), 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(realVector25);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, 0.9075712110370514d, (double) 0.04532051f, 1.7763568394002505E-15d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        arrayRealVector12.unitize();
        double[] doubleArray19 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19, false);
        double[] doubleArray27 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, false);
        double[] doubleArray35 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector36.mapDivideToSelf((double) (-1L));
        boolean boolean40 = arrayRealVector36.equals((java.lang.Object) 10);
        double double41 = arrayRealVector29.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        double[] doubleArray49 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray49);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector50.mapDivideToSelf((double) (-1L));
        boolean boolean54 = arrayRealVector50.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector56 = arrayRealVector50.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector50.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector36.combine((double) (byte) 0, (double) (-1L), realVector58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = arrayRealVector21.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, (org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        double double62 = arrayRealVector61.getNorm();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 246.6779276708802d + "'", double41 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 137.54635582231904d + "'", double62 == 137.54635582231904d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 97);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double[] doubleArray7 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) (short) 10, doubleArray8);
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray8, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.scale((double) 'a', doubleArray15);
        double[] doubleArray24 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition26 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray18, doubleArray25);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver27 = eigenDecomposition26.getSolver();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(decompositionSolver27);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        long long1 = org.apache.commons.math3.util.FastMath.round(3.8146972656435034E-6d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver3 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) '#', (-1.0d), (double) 97);
        int int4 = brentSolver3.getEvaluations();
        double double5 = brentSolver3.getFunctionValueAccuracy();
        double double6 = brentSolver3.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.0d + "'", double6 == 35.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector16.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector16.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector6.append(realVector22);
        double[] doubleArray29 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.mapDivideToSelf((double) (-1L));
        boolean boolean33 = arrayRealVector30.isNaN();
        double[] doubleArray39 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.mapDivideToSelf((double) (-1L));
        boolean boolean43 = arrayRealVector40.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc45 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector40.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc45);
        double double47 = arrayRealVector30.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector40.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector6.append(arrayRealVector40);
        double double51 = arrayRealVector6.getMaxValue();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + (-0.0d) + "'", double51 == (-0.0d));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean22 = arrayRealVector19.isNaN();
        double[] doubleArray28 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapDivideToSelf((double) (-1L));
        boolean boolean32 = arrayRealVector29.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc34 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector29.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc34);
        double double36 = arrayRealVector19.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector29.copy();
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector29.getSubVector((int) (byte) 1, (int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector29);
        double[] doubleArray47 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector48.mapDivideToSelf((double) (-1L));
        boolean boolean51 = arrayRealVector48.isNaN();
        double[] doubleArray57 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray57);
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector58.mapDivideToSelf((double) (-1L));
        boolean boolean61 = arrayRealVector58.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc63 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = arrayRealVector58.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc63);
        double double65 = arrayRealVector48.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        org.apache.commons.math3.linear.RealVector realVector67 = arrayRealVector48.mapMultiplyToSelf((double) 99);
        double double68 = arrayRealVector29.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        try {
            arrayRealVector29.setEntry((int) (short) -1, 3.814697265625E-6d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(arrayRealVector64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1872882.0d + "'", double68 == 1872882.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 0.3820138f, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3820137977600098d + "'", double2 == 0.3820137977600098d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        try {
            org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (52x97) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        arrayRealVector6.set((double) (byte) 0);
        boolean boolean11 = arrayRealVector6.isNaN();
        boolean boolean12 = arrayRealVector6.isNaN();
        double[] doubleArray19 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        org.apache.commons.math3.optim.PointValuePair pointValuePair30 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) (byte) -1);
        boolean boolean32 = pointValuePair30.equals((java.lang.Object) 0);
        java.lang.Object obj33 = null;
        boolean boolean34 = pointValuePair30.equals(obj33);
        double[] doubleArray35 = pointValuePair30.getPoint();
        double[] doubleArray36 = pointValuePair30.getKey();
        boolean boolean37 = array2DRowRealMatrix21.equals((java.lang.Object) doubleArray36);
        int int38 = org.apache.commons.math3.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math3.optim.PointValuePair pointValuePair40 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, (double) 2147483647);
        arrayRealVector6.setSubVector((int) (short) 0, doubleArray36);
        double[] doubleArray45 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray45);
        double[] doubleArray49 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray53 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition55 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray49, doubleArray53, (double) (byte) 10);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray53);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition58 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray45, doubleArray56, (double) (byte) -1);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray36, doubleArray56);
        double[] doubleArray65 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray66 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray65);
        org.apache.commons.math3.optim.PointValuePair pointValuePair68 = new org.apache.commons.math3.optim.PointValuePair(doubleArray65, (double) (byte) -1);
        java.lang.Double double69 = pointValuePair68.getSecond();
        double[] doubleArray70 = pointValuePair68.getFirst();
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair71 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray56, doubleArray70);
        double[] doubleArray72 = pointVectorValuePair71.getKey();
        double[] doubleArray73 = pointVectorValuePair71.getValueRef();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma74 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray73);
        double[] doubleArray75 = sigma74.getSigma();
        double[] doubleArray76 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray75, doubleArray76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1809524577) + "'", int38 == (-1809524577));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + (-1.0d) + "'", double69.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        double double7 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray5);
        try {
            org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 137.5427206361718d + "'", double7 == 137.5427206361718d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector15.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.append((double) (short) 100);
        double double22 = arrayRealVector6.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        double[] doubleArray28 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapDivideToSelf((double) (-1L));
        boolean boolean32 = arrayRealVector29.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc34 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector29.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc34);
        org.apache.commons.math3.analysis.function.Sinc sinc37 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector29.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc37);
        try {
            double double43 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc37, 0.0d, (double) 0.0f, 1.7763568394002505E-15d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 18918.0d + "'", double22 == 18918.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver8 = eigenDecomposition7.getSolver();
        double[] doubleArray9 = eigenDecomposition7.getImagEigenvalues();
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.optim.PointValuePair pointValuePair18 = new org.apache.commons.math3.optim.PointValuePair(doubleArray15, (double) (byte) -1);
        boolean boolean20 = pointValuePair18.equals((java.lang.Object) 0);
        java.lang.Object obj21 = null;
        boolean boolean22 = pointValuePair18.equals(obj21);
        double[] doubleArray23 = pointValuePair18.getPoint();
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray23);
        double[] doubleArray26 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray30 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition32 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray26, doubleArray30, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver33 = eigenDecomposition32.getSolver();
        double[] doubleArray34 = eigenDecomposition32.getImagEigenvalues();
        double[] doubleArray40 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40);
        org.apache.commons.math3.optim.PointValuePair pointValuePair43 = new org.apache.commons.math3.optim.PointValuePair(doubleArray40, (double) (byte) -1);
        boolean boolean45 = pointValuePair43.equals((java.lang.Object) 0);
        java.lang.Object obj46 = null;
        boolean boolean47 = pointValuePair43.equals(obj46);
        double[] doubleArray48 = pointValuePair43.getPoint();
        boolean boolean49 = org.apache.commons.math3.util.MathArrays.equals(doubleArray34, doubleArray48);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray48, false);
        double double53 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray9, doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(decompositionSolver8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(decompositionSolver33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 10.0d + "'", double53 == 10.0d);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test249");
//        org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval((int) '#');
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister();
//        float float3 = mersenneTwister2.nextFloat();
//        boolean boolean4 = mersenneTwister2.nextBoolean();
//        org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator> maxEvalPair5 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator>(maxEval1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister2);
//        int int7 = mersenneTwister2.nextInt((int) (byte) 100);
//        mersenneTwister2.clear();
//        int[] intArray14 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
//        int[] intArray20 = new int[] { 97, 1, 100, (byte) 100, 52 };
//        int int21 = org.apache.commons.math3.util.MathArrays.distance1(intArray14, intArray20);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math3.random.MersenneTwister(intArray20);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math3.random.MersenneTwister();
//        float float24 = mersenneTwister23.nextFloat();
//        byte[] byteArray30 = new byte[] { (byte) -1, (byte) 100, (byte) 0, (byte) 10, (byte) 100 };
//        mersenneTwister23.nextBytes(byteArray30);
//        mersenneTwister22.nextBytes(byteArray30);
//        mersenneTwister2.nextBytes(byteArray30);
//        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.35003662f + "'", float3 == 0.35003662f);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 79 + "'", int7 == 79);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(intArray20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 247 + "'", int21 == 247);
//        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.805184f + "'", float24 == 0.805184f);
//        org.junit.Assert.assertNotNull(byteArray30);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        java.lang.String str2 = realMatrixFormat0.getRowSeparator();
        double[] doubleArray4 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray8 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray4, doubleArray8, (double) (byte) 10);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray11);
        double[] doubleArray14 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray18 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition20 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray14, doubleArray18, (double) (byte) 10);
        double[] doubleArray21 = eigenDecomposition20.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray21);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix12, (org.apache.commons.math3.linear.AnyMatrix) realMatrix22);
        java.lang.String str24 = realMatrixFormat0.format(realMatrix22);
        java.text.NumberFormat numberFormat25 = realMatrixFormat0.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat26 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat25);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat27 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat25);
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "[-0.0122337906]" + "'", str24.equals("[-0.0122337906]"));
        org.junit.Assert.assertNotNull(numberFormat25);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval2 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) 0.68517196f, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 0.685 is larger than, or equal to, the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray12, 12.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.RealVector realVector9 = openMapRealMatrix7.getColumnVector((int) (short) 10);
        try {
            org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (52x97) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        int[] intArray5 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
        int[] intArray11 = new int[] { 97, 1, 100, (byte) 100, 52 };
        int int12 = org.apache.commons.math3.util.MathArrays.distance1(intArray5, intArray11);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math3.random.MersenneTwister(intArray11);
        mersenneTwister13.setSeed((long) (-381728948));
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 247 + "'", int12 == 247);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 0.22463548f, (double) 3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 1.1920929E-7f, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 100);
        java.lang.Object obj2 = null;
        boolean boolean3 = arrayRealVector1.equals(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter(0.9949522f, 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.99495226f + "'", float2 == 0.99495226f);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        org.apache.commons.math3.random.RandomGenerator randomGenerator5 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker7 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(247, 0.0d, true, (int) (byte) -1, (int) '#', randomGenerator5, true, pointValuePairConvergenceChecker7);
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList9 = cMAESOptimizer8.getStatisticsDHistory();
        int int10 = cMAESOptimizer8.getEvaluations();
        int int11 = cMAESOptimizer8.getIterations();
        org.junit.Assert.assertNotNull(realMatrixList9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math3.random.MersenneTwister();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker10 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(1378221360, 0.0d, true, 1378221360, 4, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister5, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker10);
        int[] intArray17 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
        int[] intArray23 = new int[] { 97, 1, 100, (byte) 100, 52 };
        int int24 = org.apache.commons.math3.util.MathArrays.distance1(intArray17, intArray23);
        mersenneTwister5.setSeed(intArray17);
        float float26 = mersenneTwister5.nextFloat();
        mersenneTwister5.clear();
        double double28 = mersenneTwister5.nextDouble();
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 247 + "'", int24 == 247);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.8993244f + "'", float26 == 0.8993244f);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.47607559929464793d + "'", double28 == 0.47607559929464793d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) (-1809524577));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(4, (int) (byte) 10, (double) 10);
        double[] doubleArray12 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[] doubleArray20 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        double[] doubleArray28 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28);
        org.apache.commons.math3.optim.PointValuePair pointValuePair31 = new org.apache.commons.math3.optim.PointValuePair(doubleArray28, (double) (byte) -1);
        boolean boolean33 = pointValuePair31.equals((java.lang.Object) 0);
        java.lang.Object obj34 = null;
        boolean boolean35 = pointValuePair31.equals(obj34);
        double[] doubleArray36 = pointValuePair31.getPoint();
        double[] doubleArray37 = pointValuePair31.getKey();
        boolean boolean38 = array2DRowRealMatrix22.equals((java.lang.Object) doubleArray37);
        double[] doubleArray40 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray44 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition46 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray40, doubleArray44, (double) (byte) 10);
        double[] doubleArray47 = eigenDecomposition46.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix48 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray47);
        double[] doubleArray50 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray54 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition56 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray50, doubleArray54, (double) (byte) 10);
        double[] doubleArray57 = eigenDecomposition56.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix58 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray57);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix48, (org.apache.commons.math3.linear.AnyMatrix) realMatrix58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = array2DRowRealMatrix22.multiply(realMatrix48);
        double[][] doubleArray61 = array2DRowRealMatrix22.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = array2DRowRealMatrix22.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix14.add(array2DRowRealMatrix22);
        boolean boolean66 = array2DRowRealMatrix22.isSquare();
        double[][] doubleArray67 = array2DRowRealMatrix22.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix22.createMatrix((int) '4', (int) ' ');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor71 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor71.start(0, 247, 1, (int) (short) -1, 0, 0);
        double double79 = defaultRealMatrixPreservingVisitor71.end();
        double double80 = array2DRowRealMatrix22.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor71);
        try {
            double double85 = openMapRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor71, (int) (short) 1, 32, (-157269966), 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-157,269,966)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realMatrix48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        org.apache.commons.math3.random.RandomGenerator randomGenerator5 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker7 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(247, 0.0d, true, (int) (byte) -1, (int) '#', randomGenerator5, true, pointValuePairConvergenceChecker7);
        int int9 = cMAESOptimizer8.getEvaluations();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList10 = cMAESOptimizer8.getStatisticsDHistory();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(realMatrixList10);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.4153232443518473d, (double) Float.NaN, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        int int6 = brentOptimizer5.getEvaluations();
        int int7 = brentOptimizer5.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray10 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray16 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray17 = new double[][] { doubleArray10, doubleArray16 };
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17, true);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException22 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable3, (java.lang.Object[]) doubleArray17);
        double[] doubleArray28 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28);
        org.apache.commons.math3.optim.PointValuePair pointValuePair31 = new org.apache.commons.math3.optim.PointValuePair(doubleArray28, (double) (byte) -1);
        boolean boolean33 = pointValuePair31.equals((java.lang.Object) 0);
        java.lang.Object obj34 = null;
        boolean boolean35 = pointValuePair31.equals(obj34);
        double[] doubleArray36 = pointValuePair31.getPoint();
        double[] doubleArray37 = pointValuePair31.getPoint();
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker40 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 0, (double) 1);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat41 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat42 = realMatrixFormat41.getFormat();
        java.lang.String str43 = realMatrixFormat41.getRowSeparator();
        double[] doubleArray45 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray49 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition51 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray45, doubleArray49, (double) (byte) 10);
        double[] doubleArray52 = eigenDecomposition51.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray52);
        double[] doubleArray55 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray59 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition61 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray55, doubleArray59, (double) (byte) 10);
        double[] doubleArray62 = eigenDecomposition61.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix63 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray62);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix53, (org.apache.commons.math3.linear.AnyMatrix) realMatrix63);
        java.lang.String str65 = realMatrixFormat41.format(realMatrix63);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException70 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 1, 0, 52, 10);
        int int71 = matrixDimensionMismatchException70.getExpectedRowDimension();
        int int72 = matrixDimensionMismatchException70.getWrongColumnDimension();
        int int73 = matrixDimensionMismatchException70.getExpectedRowDimension();
        java.lang.Object[] objArray75 = new java.lang.Object[] { localizable3, pointValuePair31, (short) 0, realMatrix63, int73, (-7.175711493801343E-17d) };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException76 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (-0.006179939774976235d), objArray75);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException77 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 1378221360, objArray75);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrixFormat41);
        org.junit.Assert.assertNotNull(numberFormat42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "; " + "'", str43.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "[-0.0122337906]" + "'", str65.equals("[-0.0122337906]"));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 52 + "'", int71 == 52);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 52 + "'", int73 == 52);
        org.junit.Assert.assertNotNull(objArray75);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor0 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor0.start(0, 247, 1, (int) (short) -1, 0, 0);
        double double8 = defaultRealMatrixPreservingVisitor0.end();
        defaultRealMatrixPreservingVisitor0.start(99, (-1773261632), 99, 2147483647, 0, 2147483647);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double[] doubleArray21 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) (-1L));
        double[] doubleArray30 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) (-1L));
        boolean boolean35 = arrayRealVector31.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector31.append((double) (short) 100);
        double double38 = arrayRealVector22.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double[] doubleArray44 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray44);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector45.mapDivideToSelf((double) (-1L));
        boolean boolean48 = arrayRealVector45.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc50 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector45.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc50);
        org.apache.commons.math3.analysis.function.Sinc sinc53 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector45.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector31.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc53);
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector56.mapAddToSelf(0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 18918.0d + "'", double38 == 18918.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(arrayRealVector56);
        org.junit.Assert.assertNotNull(realVector58);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean23 = arrayRealVector19.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.append((double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double[] doubleArray32 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.mapDivideToSelf((double) (-1L));
        boolean boolean37 = arrayRealVector33.equals((java.lang.Object) 10);
        double double38 = arrayRealVector12.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        boolean boolean39 = arrayRealVector12.isNaN();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-7.175711493801343E-17d) + "'", double38 == (-7.175711493801343E-17d));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number1, 97);
        boolean boolean4 = nonMonotonicSequenceException3.getStrict();
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException7 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) ' ', (int) (short) -1);
        int int8 = nonSquareMatrixException7.getDimension();
        nonMonotonicSequenceException3.addSuppressed((java.lang.Throwable) nonSquareMatrixException7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(6.283185307179586d, (-0.2105297851150043d), (-157269966));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector15.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.append((double) (short) 100);
        double double22 = arrayRealVector6.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        double[] doubleArray28 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapDivideToSelf((double) (-1L));
        boolean boolean32 = arrayRealVector29.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc34 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector29.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc34);
        org.apache.commons.math3.analysis.function.Sinc sinc37 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector29.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc37);
        java.io.ObjectOutputStream objectOutputStream40 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector39, objectOutputStream40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 18918.0d + "'", double22 == 18918.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int1 = bracketFinder0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(22026.0d, 0.0d, (double) '4', (double) 0L, 32.0d);
        double double6 = levenbergMarquardtOptimizer5.getChiSquare();
        double[] doubleArray7 = levenbergMarquardtOptimizer5.getLowerBound();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(doubleArray7);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        boolean boolean10 = pointValuePair8.equals((java.lang.Object) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = pointValuePair8.equals(obj11);
        double[] doubleArray13 = pointValuePair8.getPoint();
        double[] doubleArray14 = pointValuePair8.getKey();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math3.linear.OpenMapRealMatrix(6, 10);
        boolean boolean18 = pointValuePair8.equals((java.lang.Object) openMapRealMatrix17);
        double[] doubleArray19 = pointValuePair8.getFirst();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 1, 0, 52, 10);
        int int5 = matrixDimensionMismatchException4.getExpectedRowDimension();
        int int6 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int7 = matrixDimensionMismatchException4.getExpectedRowDimension();
        int int8 = matrixDimensionMismatchException4.getWrongRowDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        float float2 = org.apache.commons.math3.util.Precision.round((float) 35, (int) (byte) 100);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.085536923187668d + "'", double1 == 20.085536923187668d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math3.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, (double) (-157269966), (double) 36, 7.211102550927978d, (double) 648640953086672520L, objArray5);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        double[][] doubleArray10 = diagonalMatrix9.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double12 = diagonalMatrix9.walkInRowOrder(realMatrixChangingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(97);
        int int2 = nelderMeadSimplex1.getDimension();
        int int3 = nelderMeadSimplex1.getDimension();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math3.random.MersenneTwister();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker10 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(1378221360, 0.0d, true, 1378221360, 4, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister5, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker10);
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList12 = cMAESOptimizer11.getStatisticsMeanHistory();
        org.junit.Assert.assertNotNull(realMatrixList12);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(99);
        double[] doubleArray7 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = diagonalMatrix10.copy();
        double[] doubleArray17 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        java.lang.Number number22 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException24 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number22, 97);
        int int25 = nonMonotonicSequenceException24.getIndex();
        java.lang.Number number26 = nonMonotonicSequenceException24.getPrevious();
        int int27 = nonMonotonicSequenceException24.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection28 = nonMonotonicSequenceException24.getDirection();
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray18, orderDirection28, false, false);
        double[] doubleArray32 = diagonalMatrix10.operate(doubleArray18);
        double[] doubleArray38 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38, false);
        double[] doubleArray41 = diagonalMatrix10.operate(doubleArray38);
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = diagonalMatrix1.multiply(diagonalMatrix10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 99 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 97 + "'", int25 == 97);
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 97 + "'", int27 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) (-1555302186), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker6 = new org.apache.commons.math3.optim.SimpleValueChecker((-0.006179939774976235d), 0.0d);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(14.177446878757825d, (double) (-1555302186), 1.733816411287911d, 0.0d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1,555,302,186 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double[] doubleArray13 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector14.equals((java.lang.Object) 10);
        double double19 = arrayRealVector7.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double[] doubleArray27 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapDivideToSelf((double) (-1L));
        boolean boolean32 = arrayRealVector28.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector28.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector28.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector14.combine((double) (byte) 0, (double) (-1L), realVector36);
        double double38 = arrayRealVector14.getNorm();
        boolean boolean39 = arrayRealVector14.isInfinite();
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector14.mapAddToSelf((-0.006179939774976235d));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(12, 0.7262694092379458d);
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector44.mapSubtract((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = arrayRealVector14.outerProduct(realVector46);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 246.6779276708802d + "'", double19 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 137.5427206361718d + "'", double38 == 137.5427206361718d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(realMatrix47);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker4 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) (short) 1, (double) (byte) 0, 100);
        double double5 = simpleVectorValueChecker4.getAbsoluteThreshold();
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer10 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(97.0d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker4, 5557.690612768985d, 1.734723475976807E-18d, (double) 719869072105511355L, (double) 6L);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer11 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor3.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double11 = openMapRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        int int12 = openMapRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = openMapRealMatrix2.transpose();
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition15 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix13, (double) 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (52x97) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("{0; -0; 1; 1; 0}", "hi!", "{-97; -10; -0; -0; -97}", ",", "}", ", ");
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 1, 0, 52, 10);
        int int5 = matrixDimensionMismatchException4.getExpectedRowDimension();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula2 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker3 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver6 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula2, pointValuePairConvergenceChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver6);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver6);
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        double double13 = brentSolver6.solve(52, (org.apache.commons.math3.analysis.UnivariateFunction) sinc11, 6.691673596021348E41d);
        double double14 = brentSolver6.getAbsoluteAccuracy();
        int int15 = brentSolver6.getEvaluations();
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 6.691673596021348E41d + "'", double13 == 6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((long) (byte) 1);
        double double2 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1129943035738381d + "'", double2 == 0.1129943035738381d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math3.exception.NullArgumentException();
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        long[] longArray5 = new long[] { (-1555302186), 21, 0L, (-1555302186L), 97 };
        try {
            org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: -1,555,302,186 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double double8 = arrayRealVector7.getMaxValue();
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector15.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc20 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc20);
        org.apache.commons.math3.analysis.function.Sinc sinc23 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector15.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc23);
        double double25 = arrayRealVector7.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector24.copy();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor27 = null;
        try {
            double double28 = arrayRealVector26.walkInOptimizedOrder(realVectorChangingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 252.05440211108893d + "'", double25 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector26);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        double[][] doubleArray10 = diagonalMatrix9.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray10);
        try {
            org.apache.commons.math3.linear.RealVector realVector13 = blockRealMatrix11.getRowVector(97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) 1265531214499023402L, 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6881171418161356E43d + "'", double2 == 2.6881171418161356E43d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) 1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException1 = new org.apache.commons.math3.exception.MathArithmeticException();
        mathArithmeticException0.addSuppressed((java.lang.Throwable) mathArithmeticException1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = mathArithmeticException1.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = mathArithmeticException1.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = mathArithmeticException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test302");
//        int[] intArray1 = new int[] { 100 };
//        int[] intArray4 = new int[] { 100, 97 };
//        int int5 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray1, intArray4);
//        int[] intArray7 = new int[] { 100 };
//        int[] intArray10 = new int[] { 100, 97 };
//        int int11 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray7, intArray10);
//        double double12 = org.apache.commons.math3.util.MathArrays.distance(intArray1, intArray7);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math3.random.MersenneTwister();
//        float float14 = mersenneTwister13.nextFloat();
//        int[] intArray20 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
//        int[] intArray26 = new int[] { 97, 1, 100, (byte) 100, 52 };
//        int int27 = org.apache.commons.math3.util.MathArrays.distance1(intArray20, intArray26);
//        mersenneTwister13.setSeed(intArray20);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister29 = new org.apache.commons.math3.random.MersenneTwister(intArray20);
//        int int30 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray1, intArray20);
//        org.junit.Assert.assertNotNull(intArray1);
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.28190768f + "'", float14 == 0.28190768f);
//        org.junit.Assert.assertNotNull(intArray20);
//        org.junit.Assert.assertNotNull(intArray26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 247 + "'", int27 == 247);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 99 + "'", int30 == 99);
//    }
//}

