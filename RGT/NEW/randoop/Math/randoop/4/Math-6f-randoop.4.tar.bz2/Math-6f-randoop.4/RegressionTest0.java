import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) (byte) 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector(realVector0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double[] doubleArray3 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray3);
        double[] doubleArray8 = new double[] { (-1.0f), 100.0f, 0.0d };
        try {
            double double9 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray3, doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double[] doubleArray3 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray3);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval(0.0d, (double) (byte) -1, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.ParsePosition parsePosition2 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = realVectorFormat0.parse("hi!", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (short) -1, (float) (byte) 100, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        org.apache.commons.math3.linear.RealVector realVector1 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, realVector1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 1L, 100.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = realMatrixFormat0.format(realMatrix1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isSequence((double) 100.0f, (double) 10L, (double) 10L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(realMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException3 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, number1, objArray2);
        java.lang.Number number4 = notFiniteNumberException3.getArgument();
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) 'a', 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        org.apache.commons.math3.linear.AnyMatrix anyMatrix1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible(anyMatrix0, anyMatrix1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer5 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray6 = null;
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair7 = nonLinearConjugateGradientOptimizer5.optimize(optimizationDataArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        try {
            double double4 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, (double) (byte) 10, (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [10, 4.5]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker2 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((-0.012233790557032886d), (double) (short) -1, pointValuePairConvergenceChecker2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -0.012 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair4 = null;
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair5 = null;
        try {
            boolean boolean6 = simpleUnivariateValueChecker2.converged((int) 'a', univariatePointValuePair4, univariatePointValuePair5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval2 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) 10, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        double[] doubleArray6 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem(realMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(0, 10.0d, 10.0d, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (byte) 0, (float) '4', (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        try {
            org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) (-1L), (double) (byte) 1, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 97, 0.0d, (-0.012233790557032886d), (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.apache.commons.math3.linear.BlockRealMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 0L, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (short) -1, 97);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0f, 100.0f, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval2 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) 1L, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex(anyMatrix0, 97, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, number1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.lang.Integer[] intArray0 = null;
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 52, (-1) };
        try {
            org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException4 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray0, intArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double2 = org.apache.commons.math3.util.FastMath.pow((-0.012233790557032886d), 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.012233790557032886d) + "'", double2 == (-0.012233790557032886d));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        int[] intArray3 = new int[] { (short) 0, (short) -1 };
        int[] intArray7 = new int[] { (byte) 0, 52, '4' };
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex(anyMatrix0, intArray3, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSymmetric(realMatrix0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.blockInverse(realMatrix0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, (int) '#', 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 132 is larger than the maximum (5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(100, (int) (short) -1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) '#', (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection9 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5, orderDirection9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray1);
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix0 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix1 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) (short) 10, (double) 1.0f, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        try {
            double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray5, doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9075712110370514d + "'", double1 == 0.9075712110370514d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double[] doubleArray4 = new double[] { (byte) 0, ' ', (byte) 10, 100L };
        double[] doubleArray9 = new double[] { (byte) 0, ' ', (byte) 10, 100L };
        double[][] doubleArray10 = new double[][] { doubleArray4, doubleArray9 };
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = realMatrixFormat0.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(10.0d, 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.lang.String str1 = realVectorFormat0.getPrefix();
        java.text.ParsePosition parsePosition3 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = realVectorFormat0.parse("", parsePosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = null;
        double[] doubleArray9 = new double[] { (byte) 1 };
        double[] doubleArray11 = new double[] { (byte) 1 };
        double[] doubleArray13 = new double[] { (byte) 1 };
        double[] doubleArray15 = new double[] { (byte) 1 };
        double[] doubleArray17 = new double[] { (byte) 1 };
        double[][] doubleArray18 = new double[][] { doubleArray9, doubleArray11, doubleArray13, doubleArray15, doubleArray17 };
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, orderDirection7, doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector15.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.append((double) (short) 100);
        double double22 = arrayRealVector6.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor23 = null;
        try {
            double double24 = arrayRealVector15.walkInOptimizedOrder(realVectorChangingVisitor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 18918.0d + "'", double22 == 18918.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((-1.0d), 0.0d, 0.0d, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        double[] doubleArray6 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (-1L));
        boolean boolean11 = arrayRealVector7.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector7.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector7.mapDivide((double) '4');
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem(realMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isSequence(0.0d, (double) (short) -1, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.blockInverse(realMatrix0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        org.apache.commons.math3.linear.AnyMatrix anyMatrix1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible(anyMatrix0, anyMatrix1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, (int) (byte) 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 10 is larger than the maximum (5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector6.equals((java.lang.Object) 10);
        java.io.ObjectOutputStream objectOutputStream11 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6, objectOutputStream11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 52, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((double) (byte) -1, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double3 = sinc1.value((double) '#');
        boolean boolean6 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, 246.6779276708802d, 97.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.012233790557032886d) + "'", double3 == (-0.012233790557032886d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.String[] strArray5 = new java.lang.String[] { "", "; ", "", "", "hi!" };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = null;
        try {
            boolean boolean8 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray5, orderDirection6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int1 = org.apache.commons.math3.util.FastMath.abs((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) 3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8146972656435034E-6d + "'", double1 == 3.8146972656435034E-6d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector15.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.append((double) (short) 100);
        double double22 = arrayRealVector6.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector23 = null;
        try {
            double double24 = arrayRealVector6.getL1Distance(realVector23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 18918.0d + "'", double22 == 18918.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(true);
        try {
            double[] doubleArray5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, (double) 97, 10.0d, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [97, 1]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double0 = org.apache.commons.math3.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 'a', 0.0d, (double) '4', 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector6.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector6.append((double) (short) 100);
        int int13 = realVector12.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyInterval((-0.012233790557032886d), 97.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 0.0f, (double) ' ', (double) (byte) -1, (double) (-1), (double) 10, 97.0d, 97.0d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10671.0d + "'", double8 == 10671.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 100L, 0.0f, 10.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.String[] strArray6 = new java.lang.String[] { "{", "[", "[", "[", "; ", "" };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = null;
        try {
            boolean boolean9 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray6, orderDirection7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(0, 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        try {
            org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -0.012 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.lang.String[] strArray5 = new java.lang.String[] { "[-0.0122337906]", "[-0.0122337906]", "[", "; ", "" };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = null;
        try {
            boolean boolean8 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray5, orderDirection6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector15.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.append((double) (short) 100);
        double double22 = arrayRealVector6.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor23 = null;
        try {
            double double26 = arrayRealVector15.walkInOptimizedOrder(realVectorPreservingVisitor23, (int) ' ', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 18918.0d + "'", double22 == 18918.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        try {
            double double10 = eigenDecomposition7.getRealEigenvalue((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer5 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4);
        double[] doubleArray12 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapDivideToSelf((double) (-1L));
        boolean boolean16 = arrayRealVector13.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc18 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector13.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc18);
        try {
            double double21 = brentSolver4.solve((int) (short) 0, (org.apache.commons.math3.analysis.UnivariateFunction) sinc18, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (0) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(arrayRealVector19);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor1 = null;
        try {
            double double2 = arrayRealVector0.walkInDefaultOrder(realVectorChangingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (byte) 100, (float) '#', (float) (-1L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        double double9 = eigenDecomposition7.getDeterminant();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.012233790557032886d) + "'", double9 == (-0.012233790557032886d));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        double[] doubleArray2 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray6 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray2, doubleArray6, (double) (byte) 10);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError2 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.211102550927978d + "'", double1 == 7.211102550927978d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean23 = arrayRealVector19.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.append((double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor27 = null;
        try {
            double double30 = arrayRealVector26.walkInOptimizedOrder(realVectorChangingVisitor27, (int) '#', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector6.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor11 = null;
        try {
            double double14 = arrayRealVector6.walkInDefaultOrder(realVectorPreservingVisitor11, (int) (byte) 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int2 = org.apache.commons.math3.util.FastMath.max(100, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor8 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double13 = array2DRowRealMatrix7.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor8, (int) (short) 100, (int) (short) 10, (int) (byte) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        java.lang.String str2 = realMatrixFormat0.getRowSeparator();
        double[] doubleArray4 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray8 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray4, doubleArray8, (double) (byte) 10);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray11);
        double[] doubleArray14 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray18 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition20 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray14, doubleArray18, (double) (byte) 10);
        double[] doubleArray21 = eigenDecomposition20.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray21);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix12, (org.apache.commons.math3.linear.AnyMatrix) realMatrix22);
        java.lang.String str24 = realMatrixFormat0.format(realMatrix22);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix22, (int) (byte) -1, (int) (byte) 10, (int) (byte) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "[-0.0122337906]" + "'", str24.equals("[-0.0122337906]"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 10L, (float) (byte) -1, 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix17 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x1 but expected 5x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) (short) 1, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(true);
        try {
            double[] doubleArray5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, (double) (-1L), 100.0d, (double) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [100, -1]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        java.lang.String str2 = realMatrixFormat0.getPrefix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = realMatrixFormat0.parse("hi!");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"hi!\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.Array2DRowRealMatrix");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[" + "'", str2.equals("["));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 52.0f, (double) (-1L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double3 = org.apache.commons.math3.util.Precision.round((double) 3.8146973E-6f, (int) (byte) 0, 4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math3.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector16.isNaN();
        double[] doubleArray25 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) (-1L));
        boolean boolean29 = arrayRealVector26.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc31 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector26.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc31);
        double double33 = arrayRealVector16.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.copy();
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem(realMatrix9, (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector34);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray30 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, false);
        double[] doubleArray38 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38, false);
        double[] doubleArray46 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray46);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector47.mapDivideToSelf((double) (-1L));
        boolean boolean51 = arrayRealVector47.equals((java.lang.Object) 10);
        double double52 = arrayRealVector40.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        double[] doubleArray60 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray60);
        org.apache.commons.math3.linear.RealVector realVector63 = arrayRealVector61.mapDivideToSelf((double) (-1L));
        boolean boolean65 = arrayRealVector61.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector67 = arrayRealVector61.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector69 = arrayRealVector61.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector47.combine((double) (byte) 0, (double) (-1L), realVector69);
        org.apache.commons.math3.linear.RealMatrix realMatrix71 = arrayRealVector32.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        try {
            array2DRowRealMatrix7.setColumnMatrix((int) (byte) 100, realMatrix71);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 246.6779276708802d + "'", double52 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(realVector63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertNotNull(arrayRealVector70);
        org.junit.Assert.assertNotNull(realMatrix71);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 0L, 2.3978952727983707d, 3.141592653589793d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3.141592653589793d) + "'", double4 == (-3.141592653589793d));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((-0.012233790557032886d), 97, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        double[] doubleArray9 = null;
        try {
            double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray5, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 1L, (java.lang.Number) (-1L), (java.lang.Number) (byte) 100);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer5 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4);
        org.apache.commons.math3.analysis.function.Sinc sinc8 = new org.apache.commons.math3.analysis.function.Sinc(true);
        try {
            double double10 = brentSolver4.solve(0, (org.apache.commons.math3.analysis.UnivariateFunction) sinc8, (double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (0) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double29 = array2DRowRealMatrix7.walkInColumnOrder(realMatrixChangingVisitor24, 0, 4, (int) ' ', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        try {
            arrayRealVector6.setEntry((int) 'a', (double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.String[] strArray4 = new java.lang.String[] { "{", "[-0.0122337906]", "[-0.0122337906]", "" };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = null;
        try {
            boolean boolean7 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray4, orderDirection5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(3.141592653589793d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.982441812995697E30d + "'", double2 == 3.982441812995697E30d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker4 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (byte) 1, 0.0d, (double) 247, 0.0d, pointValuePairConvergenceChecker4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        arrayRealVector6.set((double) (byte) 0);
        int int11 = arrayRealVector6.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.lang.String[] strArray4 = new java.lang.String[] { "", "[-0.0122337906]", "[-0.0122337906]", "[-0.0122337906]" };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = null;
        try {
            boolean boolean7 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray4, orderDirection5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (short) 0, (float) 'a', (float) 97);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(3.141592653589793d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.296908309475615d + "'", double2 == 3.296908309475615d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.0d, 10.0d, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(3.141592653589793d, 10671.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        try {
            double[] doubleArray25 = array2DRowRealMatrix7.getRow(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math3.exception.NoDataException noDataException0 = new org.apache.commons.math3.exception.NoDataException();
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        try {
            diagonalMatrix8.setColumn((int) 'a', doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(97);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator3 = null;
        try {
            nelderMeadSimplex1.iterate(multivariateFunction2, pointValuePairComparator3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        boolean boolean10 = pointValuePair8.equals((java.lang.Object) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = pointValuePair8.equals(obj11);
        double[] doubleArray13 = pointValuePair8.getPoint();
        double[] doubleArray20 = new double[] { 2.718281828459045d, 3.296908309475615d, 3.8146972656435034E-6d, 2.718281828459045d, (-3.141592653589793d), 10 };
        double[] doubleArray27 = new double[] { 2.718281828459045d, 3.296908309475615d, 3.8146972656435034E-6d, 2.718281828459045d, (-3.141592653589793d), 10 };
        double[][] doubleArray28 = new double[][] { doubleArray20, doubleArray27 };
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray13, doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(247, (int) (byte) 100);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix7.multiply(realMatrix10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 247");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray13 = new double[] {};
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[] doubleArray16 = new double[] {};
        double[][] doubleArray17 = new double[][] { doubleArray12, doubleArray13, doubleArray14, doubleArray15, doubleArray16 };
        try {
            array2DRowRealMatrix7.copySubMatrix((int) (byte) -1, (int) (short) 1, (int) (short) 10, (int) 'a', doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[][] doubleArray24 = null;
        try {
            array2DRowRealMatrix7.setSubMatrix(doubleArray24, 0, 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double2 = org.apache.commons.math3.util.FastMath.pow((-1.0d), 10671.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(0.0d, (double) (short) 1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 4, 3.141592653589793d, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        try {
            diagonalMatrix9.setEntry(4, (-1), (double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 35 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { ' ' };
        double[] doubleArray12 = new double[] { ' ' };
        double[] doubleArray14 = new double[] { ' ' };
        double[] doubleArray16 = new double[] { ' ' };
        double[][] doubleArray17 = new double[][] { doubleArray10, doubleArray12, doubleArray14, doubleArray16 };
        try {
            diagonalMatrix8.setSubMatrix(doubleArray17, (int) (byte) 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner5 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4, preconditioner5);
        int int7 = brentSolver4.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = realVectorFormat0.parse("[");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"[\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        double[] doubleArray15 = new double[] { 3.296908309475615d, 3.982441812995697E30d, (short) 0, 4, 3.141592653589793d };
        double[] doubleArray21 = new double[] { 3.296908309475615d, 3.982441812995697E30d, (short) 0, 4, 3.141592653589793d };
        double[] doubleArray27 = new double[] { 3.296908309475615d, 3.982441812995697E30d, (short) 0, 4, 3.141592653589793d };
        double[][] doubleArray28 = new double[][] { doubleArray15, doubleArray21, doubleArray27 };
        try {
            diagonalMatrix9.setSubMatrix(doubleArray28, 0, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance(0.0d, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException3 = new org.apache.commons.math3.exception.MathArithmeticException(localizable1, objArray2);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException4 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, objArray2);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 247);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector16.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        double double23 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor24 = null;
        try {
            double double27 = arrayRealVector16.walkInDefaultOrder(realVectorPreservingVisitor24, (int) (short) -1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        double[] doubleArray14 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15);
        try {
            double double18 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray1, doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            boolean boolean2 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric(realMatrix0, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) (short) 1, (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        double[] doubleArray18 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) (short) 10, doubleArray19);
        double[] doubleArray26 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray19, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.scale((double) 'a', doubleArray26);
        try {
            diagonalMatrix9.setRow((int) (byte) 10, doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray14 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition16 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray10, doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = eigenDecomposition16.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray17);
        diagonalMatrix18.multiplyEntry(0, (int) 'a', 7.211102550927978d);
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = diagonalMatrix8.add(diagonalMatrix18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x5 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        try {
            org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(0.0d, 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((-3.141592653589793d), 0.9075712110370514d, (double) 'a', (double) (-1L));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-99.85121904920359d) + "'", double4 == (-99.85121904920359d));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor13 = null;
        try {
            double double16 = arrayRealVector6.walkInOptimizedOrder(realVectorChangingVisitor13, (int) '#', 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math3.random.RandomGenerator randomGenerator5 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker7 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(247, 0.0d, true, (int) (byte) -1, (int) '#', randomGenerator5, true, pointValuePairConvergenceChecker7);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction objectiveFunction10 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction(multivariateFunction9);
        double[] doubleArray12 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray16 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition18 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray12, doubleArray16, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight19 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = weight19.getWeight();
        org.apache.commons.math3.optim.univariate.SearchInterval searchInterval24 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) (short) 10, (double) 'a', (double) (short) 10);
        double double25 = searchInterval24.getMin();
        double[] doubleArray27 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray31 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition33 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray27, doubleArray31, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight34 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray27);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = weight34.getWeight();
        double[] doubleArray37 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray41 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition43 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray37, doubleArray41, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight44 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray37);
        double[] doubleArray46 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray50 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition52 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray46, doubleArray50, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight53 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray46);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray54 = new org.apache.commons.math3.optim.OptimizationData[] { objectiveFunction10, weight19, searchInterval24, weight34, weight44, weight53 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair55 = cMAESOptimizer8.optimize(optimizationDataArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 10.0d + "'", double25 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(optimizationDataArray54);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (int) (byte) 100, (int) (byte) 1, 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((double) (byte) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            array2DRowRealMatrix7.setEntry(10, (int) (byte) 1, 10.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "");
        java.lang.String str4 = realVectorFormat3.getPrefix();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector1 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 0L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6, 97);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection11 = null;
        try {
            boolean boolean14 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray6, orderDirection11, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(18918.0d, 3.8146972656435034E-6d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.012233790557032886d), (java.lang.Number) (-1L), (java.lang.Number) 1L);
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Number number6 = outOfRangeException4.getLo();
        java.lang.Number number7 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1L) + "'", number6.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1L + "'", number7.equals(1L));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        try {
            org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(0.0d, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(0, (double) 3.8146973E-6f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double[] doubleArray8 = null;
        try {
            double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray5, doubleArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.copy();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.blockInverse(realMatrix9, 247);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (247)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor16 = null;
        try {
            double double17 = arrayRealVector15.walkInOptimizedOrder(realVectorChangingVisitor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 0, (double) 1);
        double double3 = simpleUnivariateValueChecker2.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (short) -1, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 1.0f, (double) 10L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 1L, (java.lang.Number) 52.0d, (java.lang.Number) 0L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) 97);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        long long1 = org.apache.commons.math3.util.FastMath.abs(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double[] doubleArray6 = new double[] { 1L, 32.0d, 2.3978952727983707d, ' ', 252.05440211108893d, 'a' };
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex8 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        double[] doubleArray4 = new double[] { (byte) 10 };
        double[] doubleArray6 = new double[] { (byte) 10 };
        double[][] doubleArray7 = new double[][] { doubleArray4, doubleArray6 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7, false);
        try {
            openMapRealMatrix2.setSubMatrix(doubleArray7, (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        double[][] doubleArray46 = array2DRowRealMatrix7.getData();
        try {
            double[] doubleArray48 = array2DRowRealMatrix7.getColumn((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        try {
            double double9 = eigenDecomposition7.getImagEigenvalue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        double[][] doubleArray46 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = array2DRowRealMatrix7.createMatrix((int) ' ', 4);
        double[] doubleArray51 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray55 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition57 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray51, doubleArray55, (double) (byte) 10);
        double[] doubleArray58 = eigenDecomposition57.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix59 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray58);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix49, (org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 32x4 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double2 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.midpoint((double) (-1L), (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double15 = diagonalMatrix9.walkInColumnOrder(realMatrixChangingVisitor10, 52, (int) 'a', (int) (byte) 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException2 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, objArray1);
        try {
            java.lang.String str3 = mathArithmeticException2.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double[] doubleArray2 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray6 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray2, doubleArray6, (double) (byte) 10);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray6);
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, doubleArray16);
        double[] doubleArray24 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapDivideToSelf((double) (-1L));
        boolean boolean29 = arrayRealVector25.equals((java.lang.Object) 10);
        try {
            arrayRealVector17.setSubVector((int) '#', (org.apache.commons.math3.linear.RealVector) arrayRealVector25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double[] doubleArray2 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray6 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray2, doubleArray6, (double) (byte) 10);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray6);
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, doubleArray16);
        arrayRealVector17.addToEntry(1, 246.6779276708802d);
        try {
            arrayRealVector17.setEntry((int) (byte) 10, 1.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int int1 = org.apache.commons.math3.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (short) -1, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        double[][] doubleArray46 = array2DRowRealMatrix7.getData();
        int[] intArray52 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
        int[] intArray58 = new int[] { 97, 1, 100, (byte) 100, 52 };
        int int59 = org.apache.commons.math3.util.MathArrays.distance1(intArray52, intArray58);
        int[] intArray61 = new int[] { 100 };
        int[] intArray64 = new int[] { 100, 97 };
        int int65 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray61, intArray64);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, intArray58, intArray64);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 247 + "'", int59 == 247);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double double8 = arrayRealVector7.getMaxValue();
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.optim.PointValuePair pointValuePair18 = new org.apache.commons.math3.optim.PointValuePair(doubleArray15, (double) (byte) -1);
        boolean boolean20 = pointValuePair18.equals((java.lang.Object) 0);
        java.lang.Object obj21 = null;
        boolean boolean22 = pointValuePair18.equals(obj21);
        double[] doubleArray23 = pointValuePair18.getPoint();
        double[] doubleArray24 = pointValuePair18.getPoint();
        try {
            arrayRealVector7.setSubVector((int) (byte) 10, doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix11 = diagonalMatrix8.createMatrix(2147483647, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2,147,483,647 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathIllegalStateException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double3 = bracketFinder2.getHi();
        double double4 = bracketFinder2.getLo();
        org.apache.commons.math3.analysis.function.Sinc sinc6 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder2.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc6, goalType7, (double) '4', (double) 'a');
        try {
            double double14 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc6, (double) 97.0f, (double) 7.6293945E-6f, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [97, 48.5]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType7 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType7.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(0.0d, (-0.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex(anyMatrix0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double1 = org.apache.commons.math3.util.FastMath.atan(0.9075712110370514d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7369823785878259d + "'", double1 == 0.7369823785878259d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight32 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        double[] doubleArray33 = array2DRowRealMatrix7.operate(doubleArray25);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor34 = null;
        try {
            double double35 = array2DRowRealMatrix7.walkInOptimizedOrder(realMatrixChangingVisitor34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        double[][] doubleArray46 = array2DRowRealMatrix7.getData();
        int[] intArray47 = null;
        int[] intArray49 = new int[] { 100 };
        int[] intArray52 = new int[] { 100, 97 };
        int int53 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray49, intArray52);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix54 = array2DRowRealMatrix7.getSubMatrix(intArray47, intArray49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter(", ", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
        try {
            long long2 = mersenneTwister0.nextLong((long) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 0.9326714f);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (short) 0, (double) (short) 0, (double) 0.9326714f, 252.05440211108893d, 18918.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(2.6881171418161356E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double0 = org.apache.commons.math3.util.MathUtils.TWO_PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 6.283185307179586d + "'", double0 == 6.283185307179586d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair6 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double7 = univariatePointValuePair6.getValue();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair10 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double11 = univariatePointValuePair10.getValue();
        boolean boolean12 = simpleUnivariateValueChecker2.converged(1, univariatePointValuePair6, univariatePointValuePair10);
        double double13 = univariatePointValuePair6.getPoint();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 32.0d + "'", double7 == 32.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 32.0d + "'", double11 == 32.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double8 = openMapRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double[] doubleArray2 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray6 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray2, doubleArray6, (double) (byte) 10);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray6);
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, doubleArray16);
        arrayRealVector17.addToEntry(1, 246.6779276708802d);
        arrayRealVector17.unitize();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        float float3 = org.apache.commons.math3.util.Precision.round(0.15928364f, (int) (short) 100, 4);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        java.lang.String str2 = realVectorFormat0.getSeparator();
        java.lang.String str3 = realVectorFormat0.getSeparator();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = realVectorFormat0.parse("; ");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"; \" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "; " + "'", str3.equals("; "));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta((-1.0d), 1.4153232443518473d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4153232443518473d + "'", double2 == 1.4153232443518473d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (short) 10, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval((int) '#');
        int int2 = maxEval1.getMaxEval();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        double[] doubleArray6 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector7.isNaN();
        double[] doubleArray16 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) (-1L));
        boolean boolean20 = arrayRealVector17.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc22 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector17.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc22);
        double double24 = arrayRealVector7.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector17.mapDivideToSelf((double) 1);
        java.lang.StringBuffer stringBuffer27 = null;
        java.text.FieldPosition fieldPosition28 = null;
        try {
            java.lang.StringBuffer stringBuffer29 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector17, stringBuffer27, fieldPosition28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 2147483647, (float) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 10L, 3.141592653589793d, 35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(Double.NaN, (double) 1, 10671.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) (short) 10, doubleArray7);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray7, (double) (byte) 10, (double) 12, (double) (short) 0, 52.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (byte) 10, (-1));
        java.lang.Class<?> wildcardClass3 = nonSquareMatrixException2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) 32, 0, 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 2,147,483,647, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double[] doubleArray17 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray21 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition23 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray17, doubleArray21, (double) (byte) 10);
        double[] doubleArray24 = eigenDecomposition23.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray24);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor26 = null;
        try {
            double double29 = arrayRealVector6.walkInDefaultOrder(realVectorChangingVisitor26, 97, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (byte) 10, (-1));
        int int3 = nonSquareMatrixException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isSequence((double) 'a', (double) 10, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver5 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) '#', (-1.0d), (double) 97);
        int int6 = brentSolver5.getEvaluations();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver5);
        double double8 = brentSolver5.getMin();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (short) -1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 1, 0, 52, 10);
        int int5 = matrixDimensionMismatchException4.getExpectedRowDimension();
        int int6 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int8 = matrixDimensionMismatchException4.getWrongDimension((int) (short) 0);
        int int9 = matrixDimensionMismatchException4.getExpectedRowDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor16 = null;
        try {
            double double17 = array2DRowRealMatrix15.walkInColumnOrder(realMatrixChangingVisitor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double[] doubleArray13 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, false);
        double[] doubleArray21 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) (-1L));
        boolean boolean26 = arrayRealVector22.equals((java.lang.Object) 10);
        double double27 = arrayRealVector15.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        double[] doubleArray35 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector36.mapDivideToSelf((double) (-1L));
        boolean boolean40 = arrayRealVector36.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector36.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector36.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector22.combine((double) (byte) 0, (double) (-1L), realVector44);
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = arrayRealVector7.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        double[] doubleArray52 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray52);
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector53.mapDivideToSelf((double) (-1L));
        double[] doubleArray61 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray61);
        org.apache.commons.math3.linear.RealVector realVector64 = arrayRealVector62.mapDivideToSelf((double) (-1L));
        boolean boolean66 = arrayRealVector62.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector68 = arrayRealVector62.append((double) (short) 100);
        double double69 = arrayRealVector53.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector62);
        double[] doubleArray75 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray75);
        org.apache.commons.math3.linear.RealVector realVector78 = arrayRealVector76.mapDivideToSelf((double) (-1L));
        boolean boolean79 = arrayRealVector76.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc81 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = arrayRealVector76.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc81);
        org.apache.commons.math3.analysis.function.Sinc sinc84 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = arrayRealVector76.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc84);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = arrayRealVector62.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc84);
        org.apache.commons.math3.linear.RealVector realVector88 = arrayRealVector62.mapSubtractToSelf((double) '4');
        double double89 = arrayRealVector7.getDistance(realVector88);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 246.6779276708802d + "'", double27 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 18918.0d + "'", double69 == 18918.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(arrayRealVector82);
        org.junit.Assert.assertNotNull(arrayRealVector85);
        org.junit.Assert.assertNotNull(arrayRealVector86);
        org.junit.Assert.assertNotNull(realVector88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 348.9899712026121d + "'", double89 == 348.9899712026121d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double1 = org.apache.commons.math3.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(0, (double) 100, (double) 100.0f, 246.6779276708802d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((-7.175711493801343E-17d), (double) 3.8146973E-6f);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) '#', 6.283185307179586d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix((int) '#');
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 0.0f, 0.012233790557032886d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(3.141592653589793d, (double) (short) -1, 1.4153232443518473d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7262694092379458d + "'", double3 == 0.7262694092379458d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(0, 252.05440211108893d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double[] doubleArray1 = new double[] { (byte) 10 };
        double[] doubleArray3 = new double[] { (byte) 10 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double12 = array2DRowRealMatrix6.walkInOptimizedOrder(realMatrixPreservingVisitor7, 0, (int) (byte) 10, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat2 = realMatrixFormat1.getFormat();
        java.lang.StringBuffer stringBuffer3 = null;
        java.text.FieldPosition fieldPosition4 = null;
        try {
            java.lang.StringBuffer stringBuffer5 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) (byte) 10, numberFormat2, stringBuffer3, fieldPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        double[] doubleArray2 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray6 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray2, doubleArray6, (double) (byte) 10);
        double[] doubleArray9 = eigenDecomposition8.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray9);
        double[] doubleArray12 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray16 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition18 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray12, doubleArray16, (double) (byte) 10);
        double[] doubleArray19 = eigenDecomposition18.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray19);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix10, (org.apache.commons.math3.linear.AnyMatrix) realMatrix20);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition23 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix10, (double) 52.0f);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible(anyMatrix0, (org.apache.commons.math3.linear.AnyMatrix) realMatrix10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat2 = realMatrixFormat1.getFormat();
        java.lang.String str3 = realMatrixFormat1.getPrefix();
        java.text.NumberFormat numberFormat4 = realMatrixFormat1.getFormat();
        java.lang.StringBuffer stringBuffer5 = null;
        java.text.FieldPosition fieldPosition6 = null;
        try {
            java.lang.StringBuffer stringBuffer7 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) 32, numberFormat4, stringBuffer5, fieldPosition6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[" + "'", str3.equals("["));
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.748066027288565E7d + "'", double1 == 3.748066027288565E7d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        int int2 = org.apache.commons.math3.util.FastMath.min(0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 1L, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = array2DRowRealMatrix7.copy();
        double[] doubleArray48 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray52 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition54 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray48, doubleArray52, (double) (byte) 10);
        double[] doubleArray55 = eigenDecomposition54.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix56 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray55);
        double[] doubleArray58 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray62 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition64 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray58, doubleArray62, (double) (byte) 10);
        double[] doubleArray65 = eigenDecomposition64.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix66 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray65);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix56, (org.apache.commons.math3.linear.AnyMatrix) realMatrix66);
        boolean boolean69 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric(realMatrix66, (double) 100);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) realMatrix66);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x1 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int[] intArray5 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
        int[] intArray11 = new int[] { 97, 1, 100, (byte) 100, 52 };
        int int12 = org.apache.commons.math3.util.MathArrays.distance1(intArray5, intArray11);
        int[] intArray14 = new int[] { 100 };
        int[] intArray17 = new int[] { 100, 97 };
        int int18 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray14, intArray17);
        try {
            int int19 = org.apache.commons.math3.util.MathArrays.distance1(intArray5, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 247 + "'", int12 == 247);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 1, 0, 52, 10);
        int int5 = matrixDimensionMismatchException4.getExpectedRowDimension();
        int int6 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int8 = matrixDimensionMismatchException4.getWrongDimension((int) (short) 0);
        try {
            int int10 = matrixDimensionMismatchException4.getExpectedDimension((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray15 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition17 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray11, doubleArray15, (double) (byte) 10);
        double[] doubleArray18 = eigenDecomposition17.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix9, (org.apache.commons.math3.linear.AnyMatrix) realMatrix19);
        boolean boolean22 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric(realMatrix19, (double) 100);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition23 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix19);
        org.apache.commons.math3.linear.AnyMatrix anyMatrix24 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix19, anyMatrix24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector15.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.append((double) (short) 100);
        double double22 = arrayRealVector6.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector6.mapSubtractToSelf(3.982441812995697E30d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector6.copy();
        double[] doubleArray31 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31, false);
        double[] doubleArray39 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.mapDivideToSelf((double) (-1L));
        boolean boolean44 = arrayRealVector40.equals((java.lang.Object) 10);
        double double45 = arrayRealVector33.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        double[] doubleArray53 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53);
        org.apache.commons.math3.linear.RealVector realVector56 = arrayRealVector54.mapDivideToSelf((double) (-1L));
        boolean boolean58 = arrayRealVector54.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector54.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector62 = arrayRealVector54.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = arrayRealVector40.combine((double) (byte) 0, (double) (-1L), realVector62);
        double double64 = arrayRealVector25.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor65 = null;
        try {
            double double66 = arrayRealVector40.walkInDefaultOrder(realVectorPreservingVisitor65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 18918.0d + "'", double22 == 18918.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 246.6779276708802d + "'", double45 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertNotNull(arrayRealVector63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 3.982441812995697E30d + "'", double64 == 3.982441812995697E30d);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval((int) '#');
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister();
//        float float3 = mersenneTwister2.nextFloat();
//        boolean boolean4 = mersenneTwister2.nextBoolean();
//        org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator> maxEvalPair5 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator>(maxEval1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister2);
//        int int7 = mersenneTwister2.nextInt((int) (byte) 100);
//        int int8 = mersenneTwister2.nextInt();
//        try {
//            int int10 = mersenneTwister2.nextInt(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.37069952f + "'", float3 == 0.37069952f);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1524019143) + "'", int8 == (-1524019143));
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector16.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector16.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector6.append(realVector22);
        double[] doubleArray29 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.mapDivideToSelf((double) (-1L));
        boolean boolean33 = arrayRealVector30.isNaN();
        double[] doubleArray39 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.mapDivideToSelf((double) (-1L));
        boolean boolean43 = arrayRealVector40.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc45 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector40.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc45);
        double double47 = arrayRealVector30.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector40.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector6.append(arrayRealVector40);
        org.apache.commons.math3.linear.RealVector realVector53 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector40.combineToSelf((double) 32, 10671.0d, realVector53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double3 = sinc1.value((double) '#');
        java.io.ObjectInputStream objectInputStream5 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) sinc1, "hi!", objectInputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.012233790557032886d) + "'", double3 == (-0.012233790557032886d));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.0d + "'", double1 == 22026.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean23 = arrayRealVector19.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.append((double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double[] doubleArray32 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.mapDivideToSelf((double) (-1L));
        boolean boolean37 = arrayRealVector33.equals((java.lang.Object) 10);
        double double38 = arrayRealVector12.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        java.lang.String str39 = arrayRealVector12.toString();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-7.175711493801343E-17d) + "'", double38 == (-7.175711493801343E-17d));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{0; -0; 1; 1; 0}" + "'", str39.equals("{0; -0; 1; 1; 0}"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double[] doubleArray13 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector14.equals((java.lang.Object) 10);
        double double19 = arrayRealVector7.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double[] doubleArray27 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapDivideToSelf((double) (-1L));
        boolean boolean32 = arrayRealVector28.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector28.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector28.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector14.combine((double) (byte) 0, (double) (-1L), realVector36);
        double double38 = arrayRealVector14.getNorm();
        boolean boolean39 = arrayRealVector14.isInfinite();
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector14.mapDivide(3.831008000716577E22d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 246.6779276708802d + "'", double19 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 137.5427206361718d + "'", double38 == 137.5427206361718d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(realVector41);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = array2DRowRealMatrix7.copy();
        try {
            double double49 = array2DRowRealMatrix7.getEntry((int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(realMatrix46);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        arrayRealVector6.set((double) (byte) 0);
        boolean boolean11 = arrayRealVector6.isNaN();
        boolean boolean12 = arrayRealVector6.isNaN();
        double[] doubleArray19 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        org.apache.commons.math3.optim.PointValuePair pointValuePair30 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) (byte) -1);
        boolean boolean32 = pointValuePair30.equals((java.lang.Object) 0);
        java.lang.Object obj33 = null;
        boolean boolean34 = pointValuePair30.equals(obj33);
        double[] doubleArray35 = pointValuePair30.getPoint();
        double[] doubleArray36 = pointValuePair30.getKey();
        boolean boolean37 = array2DRowRealMatrix21.equals((java.lang.Object) doubleArray36);
        int int38 = org.apache.commons.math3.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math3.optim.PointValuePair pointValuePair40 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, (double) 2147483647);
        arrayRealVector6.setSubVector((int) (short) 0, doubleArray36);
        org.apache.commons.math3.linear.RealVector realVector43 = null;
        try {
            arrayRealVector6.setSubVector((int) (short) -1, realVector43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1809524577) + "'", int38 == (-1809524577));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (byte) 10, 0.5105547f, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (short) -1);
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 0);
        incrementor1.incrementCount(0);
        try {
            incrementor1.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        double[] doubleArray9 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray13 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition15 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray9, doubleArray13, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray9);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = weight16.getWeight();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix18 = openMapRealMatrix7.subtract(realMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 97x52 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.012233790557032886d), (java.lang.Number) (-1L), (java.lang.Number) 1L);
        java.lang.Throwable[] throwableArray5 = outOfRangeException4.getSuppressed();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1L + "'", number6.equals(1L));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double25 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector6.equals((java.lang.Object) 10);
        double[] doubleArray11 = arrayRealVector6.toArray();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException0 = new org.apache.commons.math3.exception.MathUnsupportedOperationException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathUnsupportedOperationException0.getContext();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix2 = null;
        org.apache.commons.math3.util.Pair<java.lang.UnsupportedOperationException, org.apache.commons.math3.linear.DiagonalMatrix> unsupportedOperationExceptionPair3 = new org.apache.commons.math3.util.Pair<java.lang.UnsupportedOperationException, org.apache.commons.math3.linear.DiagonalMatrix>((java.lang.UnsupportedOperationException) mathUnsupportedOperationException0, diagonalMatrix2);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = mathUnsupportedOperationException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.7894702148849957d + "'", double0 == 0.7894702148849957d);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc11, 137.5427206361718d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [137.543, -1]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) (-1L));
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        try {
            double double5 = brentSolver1.solve(0, univariateFunction3, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.4153232443518473d, (double) Float.NaN, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        int int6 = brentOptimizer5.getIterations();
        int int7 = brentOptimizer5.getMaxIterations();
        double double8 = brentOptimizer5.getMax();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(0.0d, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(0.0d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix15.copy();
        double[] doubleArray22 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) (-1L));
        boolean boolean26 = arrayRealVector23.isNaN();
        double[] doubleArray32 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector33.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector33.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector23.append(realVector39);
        double[] doubleArray46 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray46);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector47.mapDivideToSelf((double) (-1L));
        boolean boolean50 = arrayRealVector47.isNaN();
        double[] doubleArray56 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray56);
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector57.mapDivideToSelf((double) (-1L));
        boolean boolean60 = arrayRealVector57.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc62 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = arrayRealVector57.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc62);
        double double64 = arrayRealVector47.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector57.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = arrayRealVector23.append(arrayRealVector57);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem(realMatrix16, (org.apache.commons.math3.linear.RealVector) arrayRealVector57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(arrayRealVector63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(arrayRealVector67);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(10671.0d, (double) '#');
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector6.mapDivideToSelf((double) (byte) 1);
        int int15 = realVector14.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        double[] doubleArray6 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector7.isNaN();
        double[] doubleArray16 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) (-1L));
        boolean boolean20 = arrayRealVector17.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc22 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector17.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc22);
        double double24 = arrayRealVector7.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector7.mapSubtractToSelf((double) '4');
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, arrayRealVector7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double[] doubleArray3 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray3);
        double[] doubleArray7 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray11 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition13 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray7, doubleArray11, (double) (byte) 10);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray11);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition16 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray3, doubleArray14, (double) (byte) -1);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix17 = eigenDecomposition16.getSquareRoot();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathUnsupportedOperationException; message: unsupported operation");
        } catch (org.apache.commons.math3.exception.MathUnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 4, (float) 0, (-1809524577));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { (-1) };
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { 10, 52, 100 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException7 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray2, intArray6);
        try {
            int int9 = multiDimensionMismatchException7.getWrongDimension((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double3 = bracketFinder2.getFLo();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean23 = arrayRealVector19.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.append((double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat27 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        boolean boolean28 = arrayRealVector26.equals((java.lang.Object) realMatrixFormat27);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor29 = null;
        try {
            double double32 = arrayRealVector26.walkInOptimizedOrder(realVectorChangingVisitor29, (int) 'a', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(realMatrixFormat27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        double[][] doubleArray46 = array2DRowRealMatrix7.getData();
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition48 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix7, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (5x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double[] doubleArray29 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29);
        org.apache.commons.math3.optim.PointValuePair pointValuePair32 = new org.apache.commons.math3.optim.PointValuePair(doubleArray29, (double) (byte) -1);
        boolean boolean34 = pointValuePair32.equals((java.lang.Object) 0);
        java.lang.Object obj35 = null;
        boolean boolean36 = pointValuePair32.equals(obj35);
        double[] doubleArray37 = pointValuePair32.getPoint();
        double[] doubleArray38 = pointValuePair32.getKey();
        boolean boolean39 = array2DRowRealMatrix23.equals((java.lang.Object) doubleArray38);
        double[] doubleArray41 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray45 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition47 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray41, doubleArray45, (double) (byte) 10);
        double[] doubleArray48 = eigenDecomposition47.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray48);
        double[] doubleArray51 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray55 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition57 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray51, doubleArray55, (double) (byte) 10);
        double[] doubleArray58 = eigenDecomposition57.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix59 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray58);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix49, (org.apache.commons.math3.linear.AnyMatrix) realMatrix59);
        org.apache.commons.math3.linear.RealMatrix realMatrix61 = array2DRowRealMatrix23.multiply(realMatrix49);
        double[][] doubleArray62 = array2DRowRealMatrix23.getData();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = array2DRowRealMatrix15.add(array2DRowRealMatrix23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x5 but expected 5x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertNotNull(doubleArray62);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        double[] doubleArray10 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray14 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition16 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray10, doubleArray14, (double) (byte) 10);
        try {
            openMapRealMatrix7.setColumn((int) '#', doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 97x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition2 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix0, (double) 97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) '4');
        double[] doubleArray7 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = diagonalMatrix10.copy();
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight12 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix10);
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = diagonalMatrix1.multiply(diagonalMatrix10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 52 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, 12, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 12 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(0.7262694092379458d, 1.4153232443518473d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        boolean boolean9 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix7, (double) (byte) 0);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double15 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor10, 12, (int) (byte) -1, (int) (short) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (12)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 0L, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver8 = eigenDecomposition7.getSolver();
        double[] doubleArray9 = eigenDecomposition7.getImagEigenvalues();
        try {
            double double11 = eigenDecomposition7.getImagEigenvalue((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(decompositionSolver8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(252.05440211108893d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector6.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector6.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, true);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor15 = null;
        try {
            double double18 = arrayRealVector6.walkInOptimizedOrder(realVectorChangingVisitor15, 1, 247);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (247)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double[] doubleArray7 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) (short) 10, doubleArray8);
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray8, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.scale((double) 'a', doubleArray15);
        double[] doubleArray24 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition26 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray18, doubleArray25);
        double[] doubleArray32 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray40 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40);
        org.apache.commons.math3.optim.PointValuePair pointValuePair43 = new org.apache.commons.math3.optim.PointValuePair(doubleArray40, (double) (byte) -1);
        boolean boolean45 = pointValuePair43.equals((java.lang.Object) 0);
        java.lang.Object obj46 = null;
        boolean boolean47 = pointValuePair43.equals(obj46);
        double[] doubleArray48 = pointValuePair43.getPoint();
        double[] doubleArray49 = pointValuePair43.getKey();
        boolean boolean50 = array2DRowRealMatrix34.equals((java.lang.Object) doubleArray49);
        double[] doubleArray52 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray56 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition58 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray52, doubleArray56, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight59 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray52);
        double[] doubleArray60 = array2DRowRealMatrix34.operate(doubleArray52);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition62 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray18, doubleArray52, (-0.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(35.0d, 0.7369823785878259d, (double) 7.6293945E-6f, (double) (short) 1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double double3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve(univariateFunction0, (double) 247, (-7.175711493801343E-17d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 'a', (float) 100L, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((-0.8414709848078965d), pointVectorValuePairConvergenceChecker1, (double) 52, (double) 0.0f, 2.3978952727983707d, 2.3978952727983707d);
        int int7 = levenbergMarquardtOptimizer6.getEvaluations();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double[] doubleArray2 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray6 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray2, doubleArray6, (double) (byte) 10);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray6);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (-1 >= -1)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight32 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        double[] doubleArray33 = array2DRowRealMatrix7.operate(doubleArray25);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor34 = null;
        try {
            double double39 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor34, (int) (byte) 100, (-1), 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        double[][] doubleArray46 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = array2DRowRealMatrix7.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor50 = null;
        try {
            double double55 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor50, 100, 12, 32, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix49);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = array2DRowRealMatrix7.subtract(array2DRowRealMatrix46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (byte) 100, (double) (short) 10, (double) '4', (double) 97);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction5 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator6 = null;
        try {
            multiDirectionalSimplex4.iterate(multivariateFunction5, pointValuePairComparator6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] goalTypeArray0 = new org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] {};
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection1 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray0, orderDirection1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(goalTypeArray0);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval((int) '#');
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister();
//        float float3 = mersenneTwister2.nextFloat();
//        boolean boolean4 = mersenneTwister2.nextBoolean();
//        org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator> maxEvalPair5 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator>(maxEval1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister2);
//        int int7 = mersenneTwister2.nextInt((int) (byte) 100);
//        int int8 = mersenneTwister2.nextInt();
//        mersenneTwister2.clear();
//        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.3498621f + "'", float3 == 0.3498621f);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1555302186) + "'", int8 == (-1555302186));
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        boolean boolean10 = pointValuePair8.equals((java.lang.Object) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = pointValuePair8.equals(obj11);
        double[] doubleArray13 = pointValuePair8.getPoint();
        double[] doubleArray14 = pointValuePair8.getPoint();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection15 = null;
        try {
            boolean boolean17 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray14, orderDirection15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex(anyMatrix0, (-1809524577), 12, 35, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math3.util.FastMath.cos(0.7894702148849957d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7042215514498249d + "'", double1 == 0.7042215514498249d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math3.random.MersenneTwister();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker10 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(1378221360, 0.0d, true, 1378221360, 4, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister5, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker10);
        mersenneTwister5.setSeed((long) 247);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 10, 1.0d);
        double double3 = simpleVectorValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        int[] intArray0 = null;
        int[] intArray6 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
        int[] intArray12 = new int[] { 97, 1, 100, (byte) 100, 52 };
        int int13 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray12);
        try {
            double double14 = org.apache.commons.math3.util.MathArrays.distance(intArray0, intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 247 + "'", int13 == 247);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) (-1), (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int[] intArray1 = new int[] { 100 };
        int[] intArray4 = new int[] { 100, 97 };
        int int5 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray1, intArray4);
        int[] intArray6 = null;
        try {
            double double7 = org.apache.commons.math3.util.MathArrays.distance(intArray4, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) 0.04532051f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        float float2 = org.apache.commons.math3.util.Precision.round(3.8146973E-6f, (int) 'a');
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9836065573770492d + "'", double1 == 0.9836065573770492d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.copy();
        double[][] doubleArray10 = diagonalMatrix8.getData();
        double[] doubleArray16 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray22 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray23 = new double[][] { doubleArray16, doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix26.copy();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix8.multiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException0 = new org.apache.commons.math3.exception.MathUnsupportedOperationException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathUnsupportedOperationException0.getContext();
        java.lang.Throwable throwable2 = null;
        try {
            mathUnsupportedOperationException0.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        double double3 = brentSolver2.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.apache.commons.math3.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double13 = array2DRowRealMatrix7.walkInColumnOrder(realMatrixPreservingVisitor8, 0, (int) ' ', (int) (short) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 10, 1.0d);
        double double3 = simpleVectorValueChecker2.getAbsoluteThreshold();
        double double4 = simpleVectorValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double[] doubleArray1 = new double[] { (byte) 10 };
        double[] doubleArray3 = new double[] { (byte) 10 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14, 97);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair20 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray14, (java.lang.Double) 0.0d);
        try {
            array2DRowRealMatrix6.setRow(247, doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (247)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double[] doubleArray17 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray21 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition23 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray17, doubleArray21, (double) (byte) 10);
        double[] doubleArray24 = eigenDecomposition23.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex27 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray24);
        double[] doubleArray33 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray33);
        org.apache.commons.math3.optim.PointValuePair pointValuePair36 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) -1);
        boolean boolean38 = pointValuePair36.equals((java.lang.Object) 0);
        java.lang.Object obj39 = null;
        boolean boolean40 = pointValuePair36.equals(obj39);
        double[] doubleArray41 = pointValuePair36.getPoint();
        double[] doubleArray45 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray45);
        double[] doubleArray49 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray53 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition55 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray49, doubleArray53, (double) (byte) 10);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray53);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition58 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray45, doubleArray56, (double) (byte) -1);
        boolean boolean59 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray41, doubleArray45);
        try {
            nelderMeadSimplex27.build(doubleArray41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunctionJacobian modelFunctionJacobian1 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunctionJacobian(multivariateMatrixFunction0);
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction2 = modelFunctionJacobian1.getModelFunctionJacobian();
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction3 = modelFunctionJacobian1.getModelFunctionJacobian();
        org.junit.Assert.assertNull(multivariateMatrixFunction2);
        org.junit.Assert.assertNull(multivariateMatrixFunction3);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) 10.0f, 3.982441812995697E30d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.982441812995697E30d + "'", double2 == 3.982441812995697E30d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double9 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) (-3.982441812995697E30d));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        boolean boolean10 = pointValuePair8.equals((java.lang.Object) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = pointValuePair8.equals(obj11);
        double[] doubleArray13 = pointValuePair8.getPoint();
        java.lang.Number number15 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException17 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number15, 97);
        int int18 = nonMonotonicSequenceException17.getIndex();
        java.lang.Number number19 = nonMonotonicSequenceException17.getPrevious();
        int int20 = nonMonotonicSequenceException17.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection21 = nonMonotonicSequenceException17.getDirection();
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray13, orderDirection21, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not increasing (10 > 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 97 + "'", int18 == 97);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 97 + "'", int20 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.RealVector realVector9 = openMapRealMatrix7.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix12.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix12);
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix17.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix20 = openMapRealMatrix7.add(openMapRealMatrix17);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor21.start(0, 247, 1, (int) (short) -1, 0, 0);
        double double29 = openMapRealMatrix17.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        double[] doubleArray31 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray35 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition37 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray31, doubleArray35, (double) (byte) 10);
        double[] doubleArray38 = eigenDecomposition37.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray38);
        double[] doubleArray41 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray45 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition47 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray41, doubleArray45, (double) (byte) 10);
        double[] doubleArray48 = eigenDecomposition47.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray48);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix39, (org.apache.commons.math3.linear.AnyMatrix) realMatrix49);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition52 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix39, (double) 52.0f);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix17, (org.apache.commons.math3.linear.AnyMatrix) realMatrix39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 97x52 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealMatrix20);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix49);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) (short) 100, (double) 3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.814697265625E-6d + "'", double2 == 3.814697265625E-6d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math3.util.FastMath.signum(1.4153232443518473d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double1 = org.apache.commons.math3.util.FastMath.atan(0.7042215514498249d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6135536048441389d + "'", double1 == 0.6135536048441389d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        int[] intArray0 = new int[] {};
        try {
            org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        try {
            double double5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, 0.0d, (-3.141592653589793d), (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0, -1.571]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        java.lang.String str2 = realVectorFormat0.getSeparator();
        java.text.ParsePosition parsePosition4 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = realVectorFormat0.parse("{", parsePosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight32 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        double[] doubleArray33 = array2DRowRealMatrix7.operate(doubleArray25);
        double[] doubleArray34 = null;
        try {
            double[] doubleArray35 = array2DRowRealMatrix7.operate(doubleArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1023) + "'", int1 == (-1023));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14, 97);
        try {
            double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 97");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.copy();
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8);
        org.apache.commons.math3.exception.util.Localizable localizable15 = null;
        org.apache.commons.math3.exception.util.Localizable localizable16 = null;
        double[] doubleArray22 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray28 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray29 = new double[][] { doubleArray22, doubleArray28 };
        double[][] doubleArray30 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29, true);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable16, (java.lang.Object[]) doubleArray29);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException34 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable15, (java.lang.Object[]) doubleArray29);
        try {
            diagonalMatrix8.copySubMatrix(0, 52, 35, (-1), doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException(number0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) ' ', (-0.006179939774976235d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        try {
            double double11 = diagonalMatrix8.getEntry(97, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) (-1555302186));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.7894702148849957d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.2105297851150043d) + "'", double2 == (-0.2105297851150043d));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(97);
        double[] doubleArray7 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7);
        try {
            nelderMeadSimplex1.build(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(0.0d, 18918.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 4, (java.lang.Number) 0.957118376469154d, false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.RealVector realVector9 = openMapRealMatrix7.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix12.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix12);
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix17.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix20 = openMapRealMatrix7.add(openMapRealMatrix17);
        try {
            openMapRealMatrix20.addToEntry(0, (int) 'a', (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealMatrix20);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        double double9 = realVector8.getMaxValue();
        int int10 = realVector8.getMaxIndex();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.0d) + "'", double9 == (-0.0d));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        float float1 = mersenneTwister0.nextFloat();
//        byte[] byteArray7 = new byte[] { (byte) -1, (byte) 100, (byte) 0, (byte) 10, (byte) 100 };
//        mersenneTwister0.nextBytes(byteArray7);
//        float float9 = mersenneTwister0.nextFloat();
//        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.094331026f + "'", float1 == 0.094331026f);
//        org.junit.Assert.assertNotNull(byteArray7);
//        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.22463548f + "'", float9 == 0.22463548f);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector16.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        double double23 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector16.mapDivideToSelf((double) 1);
        double[] doubleArray26 = arrayRealVector16.getDataRef();
        double[] doubleArray32 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray33, 97);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds38 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray26, doubleArray33);
        double[] doubleArray39 = simpleBounds38.getLower();
        double[] doubleArray40 = simpleBounds38.getUpper();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector16.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        double double23 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector16.mapAdd((double) (short) 1);
        int int26 = arrayRealVector16.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(247, (int) (byte) 100);
        double[] doubleArray8 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray16 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray24 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24);
        org.apache.commons.math3.optim.PointValuePair pointValuePair27 = new org.apache.commons.math3.optim.PointValuePair(doubleArray24, (double) (byte) -1);
        boolean boolean29 = pointValuePair27.equals((java.lang.Object) 0);
        java.lang.Object obj30 = null;
        boolean boolean31 = pointValuePair27.equals(obj30);
        double[] doubleArray32 = pointValuePair27.getPoint();
        double[] doubleArray33 = pointValuePair27.getKey();
        boolean boolean34 = array2DRowRealMatrix18.equals((java.lang.Object) doubleArray33);
        double[] doubleArray36 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray40 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition42 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray36, doubleArray40, (double) (byte) 10);
        double[] doubleArray43 = eigenDecomposition42.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray43);
        double[] doubleArray46 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray50 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition52 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray46, doubleArray50, (double) (byte) 10);
        double[] doubleArray53 = eigenDecomposition52.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray53);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix44, (org.apache.commons.math3.linear.AnyMatrix) realMatrix54);
        org.apache.commons.math3.linear.RealMatrix realMatrix56 = array2DRowRealMatrix18.multiply(realMatrix44);
        double[][] doubleArray57 = array2DRowRealMatrix18.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = array2DRowRealMatrix18.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = array2DRowRealMatrix10.add(array2DRowRealMatrix18);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix2, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 247x100 but expected 5x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix61);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        boolean boolean9 = eigenDecomposition7.hasComplexEigenvalues();
        try {
            double double11 = eigenDecomposition7.getRealEigenvalue(247);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 247");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector23);
        int int25 = arrayRealVector24.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("{", 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat(", ", "{", "hi!", "[-0.0122337906]", "", "[");
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        double[] doubleArray12 = new double[] { (byte) 10 };
        double[] doubleArray14 = new double[] { (byte) 10 };
        double[][] doubleArray15 = new double[][] { doubleArray12, doubleArray14 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        try {
            openMapRealMatrix2.copySubMatrix(0, (-1023), 32, (-1023), doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor46 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double51 = array2DRowRealMatrix7.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor46, (-1809524577), (int) (byte) -1, 1, (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,809,524,577)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double[] doubleArray17 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray21 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition23 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray17, doubleArray21, (double) (byte) 10);
        double[] doubleArray24 = eigenDecomposition23.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray24);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, (-1), (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor(0, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        double double9 = realVector8.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector10 = null;
        try {
            double double11 = realVector8.cosine(realVector10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.0d) + "'", double9 == (-0.0d));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((-1.0d), 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) '4');
        try {
            diagonalMatrix1.addToEntry((int) (short) -1, 0, 348.9899712026121d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 348.99 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        diagonalMatrix9.multiplyEntry(0, (int) 'a', 7.211102550927978d);
        double[] doubleArray20 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapDivideToSelf((double) (-1L));
        boolean boolean24 = arrayRealVector21.isNaN();
        double[] doubleArray30 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) (-1L));
        boolean boolean34 = arrayRealVector31.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc36 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector31.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc36);
        double double38 = arrayRealVector21.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector31.copy();
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector31.getSubVector((int) (byte) 1, (int) (short) 1);
        try {
            diagonalMatrix9.setColumnVector((-1555302186), (org.apache.commons.math3.linear.RealVector) arrayRealVector31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,555,302,186)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertNotNull(realVector42);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(10671.0d, 0.0d, 1378221360);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (-1555302186), 100.0f, Float.NaN);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector15.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.append((double) (short) 100);
        double double22 = arrayRealVector6.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector6.mapSubtractToSelf(3.982441812995697E30d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector6.copy();
        double double26 = arrayRealVector6.getMaxValue();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor27 = null;
        try {
            double double30 = arrayRealVector6.walkInDefaultOrder(realVectorPreservingVisitor27, (int) (byte) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 18918.0d + "'", double22 == 18918.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-3.982441812995697E30d) + "'", double26 == (-3.982441812995697E30d));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor3.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double11 = openMapRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        try {
            openMapRealMatrix2.multiplyEntry((-1555302186), (-1023), 3.748066027288565E7d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,555,302,186)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            boolean boolean2 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric(realMatrix0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix7.createMatrix(35, (int) (byte) 100);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor27 = null;
        try {
            double double32 = array2DRowRealMatrix7.walkInColumnOrder(realMatrixChangingVisitor27, (-1809524577), 32, (int) (byte) 1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,809,524,577)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double2 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.midpoint((double) 100L, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 55.0d + "'", double2 == 55.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.analysis.function.Sinc sinc10 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc10);
        double[] doubleArray17 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17, false);
        double[] doubleArray25 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25, false);
        double[] doubleArray33 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector34.mapDivideToSelf((double) (-1L));
        boolean boolean38 = arrayRealVector34.equals((java.lang.Object) 10);
        double double39 = arrayRealVector27.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        double[] doubleArray47 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector48.mapDivideToSelf((double) (-1L));
        boolean boolean52 = arrayRealVector48.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector48.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector56 = arrayRealVector48.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = arrayRealVector34.combine((double) (byte) 0, (double) (-1L), realVector56);
        org.apache.commons.math3.linear.RealMatrix realMatrix58 = arrayRealVector19.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector11, arrayRealVector34);
        org.apache.commons.math3.linear.RealVector realVector62 = arrayRealVector34.getSubVector(0, 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 246.6779276708802d + "'", double39 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertNotNull(arrayRealVector57);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(realVector62);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math3.linear.SingularMatrixException singularMatrixException0 = new org.apache.commons.math3.linear.SingularMatrixException();
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix15.copy();
        double[] doubleArray18 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray22 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray18, doubleArray22, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver25 = eigenDecomposition24.getSolver();
        double[] doubleArray26 = eigenDecomposition24.getImagEigenvalues();
        boolean boolean27 = array2DRowRealMatrix15.equals((java.lang.Object) eigenDecomposition24);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = eigenDecomposition24.getD();
        boolean boolean29 = eigenDecomposition24.hasComplexEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(decompositionSolver25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(247, (int) (byte) 100);
        double[] doubleArray5 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray9 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition11 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray9, (double) (byte) 10);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray9);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray12);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix2, (org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) 'a', (int) (byte) 10);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 100L);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        boolean boolean13 = arrayRealVector6.isNaN();
        int int14 = arrayRealVector6.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 403.4287934927351d + "'", double1 == 403.4287934927351d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector6.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector6.unitVector();
        double[] doubleArray20 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) (short) 10, doubleArray21);
        double[] doubleArray28 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.scale((double) 'a', doubleArray28);
        try {
            arrayRealVector6.setSubVector(247, doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (247)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((-1.0d), (-3.141592653589793d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math3.random.MersenneTwister();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker10 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(1378221360, 0.0d, true, 1378221360, 4, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister5, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker10);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker10);
        org.apache.commons.math3.optim.PointValuePair pointValuePair14 = null;
        double[] doubleArray20 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        org.apache.commons.math3.optim.PointValuePair pointValuePair23 = new org.apache.commons.math3.optim.PointValuePair(doubleArray20, (double) (byte) -1);
        java.lang.Double double24 = pointValuePair23.getSecond();
        double[] doubleArray25 = pointValuePair23.getFirst();
        try {
            boolean boolean26 = simpleValueChecker10.converged((-1023), pointValuePair14, pointValuePair23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double[] doubleArray17 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray21 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition23 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray17, doubleArray21, (double) (byte) 10);
        double[] doubleArray24 = eigenDecomposition23.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray24);
        boolean boolean28 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric(realMatrix26, (double) 1L);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        java.lang.String str9 = arrayRealVector6.toString();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{-97; -10; -0; -0; -97}" + "'", str9.equals("{-97; -10; -0; -0; -97}"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor46 = null;
        try {
            double double51 = array2DRowRealMatrix7.walkInColumnOrder(realMatrixChangingVisitor46, (int) (short) 1, 32, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.copy();
        double[][] doubleArray10 = diagonalMatrix8.getData();
        try {
            double double13 = diagonalMatrix8.getEntry((int) '4', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double[] doubleArray6 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (-1L));
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean20 = arrayRealVector16.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector16.append((double) (short) 100);
        double double23 = arrayRealVector7.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        double[] doubleArray29 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.mapDivideToSelf((double) (-1L));
        boolean boolean33 = arrayRealVector30.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc35 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector30.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc35);
        org.apache.commons.math3.analysis.function.Sinc sinc38 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector30.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector16.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc38);
        org.apache.commons.math3.analysis.solvers.BracketedUnivariateSolver<org.apache.commons.math3.analysis.UnivariateFunction> univariateFunctionBracketedUnivariateSolver41 = null;
        org.apache.commons.math3.analysis.solvers.AllowedSolution allowedSolution45 = null;
        try {
            double double46 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.forceSide((-1809524577), (org.apache.commons.math3.analysis.UnivariateFunction) sinc38, univariateFunctionBracketedUnivariateSolver41, 0.0d, (double) 1378221360, (double) 2147483647, allowedSolution45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 18918.0d + "'", double23 == 18918.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertNotNull(arrayRealVector40);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 10, 1.0d);
        double double3 = simpleVectorValueChecker2.getAbsoluteThreshold();
        double double4 = simpleVectorValueChecker2.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (-1L), (double) 32);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 0.04532051f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.909921332671597E-4d + "'", double1 == 7.909921332671597E-4d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.RealVector realVector9 = openMapRealMatrix7.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix12.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix12);
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix17.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix20 = openMapRealMatrix7.add(openMapRealMatrix17);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor21.start(0, 247, 1, (int) (short) -1, 0, 0);
        double double29 = openMapRealMatrix17.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        try {
            openMapRealMatrix17.multiplyEntry((int) (short) -1, 12, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealMatrix20);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 10L, (double) (short) 1, 0.0d);
        int int4 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        int int5 = levenbergMarquardtOptimizer3.getMaxIterations();
        double double6 = levenbergMarquardtOptimizer3.getChiSquare();
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction7 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunctionJacobian modelFunctionJacobian8 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunctionJacobian(multivariateMatrixFunction7);
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction9 = modelFunctionJacobian8.getModelFunctionJacobian();
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction10 = modelFunctionJacobian8.getModelFunctionJacobian();
        double[] doubleArray16 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) (-1L));
        boolean boolean20 = arrayRealVector17.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc22 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector17.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc22);
        org.apache.commons.math3.analysis.function.Sinc sinc25 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector17.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc25);
        double[] doubleArray28 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray32 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition34 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray28, doubleArray32, (double) (byte) 10);
        double[] doubleArray35 = eigenDecomposition34.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray35);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray35);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex38 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray35);
        int int39 = nelderMeadSimplex38.getDimension();
        org.apache.commons.math3.optim.SimpleBounds simpleBounds41 = org.apache.commons.math3.optim.SimpleBounds.unbounded((int) (byte) 1);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray42 = new org.apache.commons.math3.optim.OptimizationData[] { modelFunctionJacobian8, nelderMeadSimplex38, simpleBounds41 };
        try {
            org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair43 = levenbergMarquardtOptimizer3.optimize(optimizationDataArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(multivariateMatrixFunction9);
        org.junit.Assert.assertNull(multivariateMatrixFunction10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(simpleBounds41);
        org.junit.Assert.assertNotNull(optimizationDataArray42);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.012233790557032886d), (java.lang.Number) (-1L), (java.lang.Number) 1L);
        try {
            java.lang.String str5 = outOfRangeException4.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        java.lang.String str2 = realMatrixFormat0.getRowSeparator();
        double[] doubleArray4 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray8 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray4, doubleArray8, (double) (byte) 10);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray11);
        java.lang.String str13 = realMatrixFormat0.format(realMatrix12);
        double[] doubleArray19 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.mapDivideToSelf((double) (-1L));
        boolean boolean23 = arrayRealVector20.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc25 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector20.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc25);
        org.apache.commons.math3.analysis.function.Sinc sinc28 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector20.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc28);
        double[] doubleArray31 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray35 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition37 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray31, doubleArray35, (double) (byte) 10);
        double[] doubleArray38 = eigenDecomposition37.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, doubleArray38);
        org.apache.commons.math3.linear.RealMatrix realMatrix40 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray38);
        boolean boolean42 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric(realMatrix40, (double) 10.0f);
        java.lang.StringBuffer stringBuffer43 = null;
        java.text.FieldPosition fieldPosition44 = null;
        try {
            java.lang.StringBuffer stringBuffer45 = realMatrixFormat0.format(realMatrix40, stringBuffer43, fieldPosition44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "[-0.0122337906]" + "'", str13.equals("[-0.0122337906]"));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition11 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix9, 7.211102550927978d);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = lUDecomposition11.getP();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNull(realMatrix12);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double[] doubleArray3 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray3);
        double[] doubleArray7 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray11 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition13 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray7, doubleArray11, (double) (byte) 10);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray11);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition16 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray3, doubleArray14, (double) (byte) -1);
        try {
            org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula2 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker3 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver6 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula2, pointValuePairConvergenceChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver6);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner8 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer9 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver6, preconditioner8);
        double[] doubleArray10 = nonLinearConjugateGradientOptimizer9.getLowerBound();
        org.junit.Assert.assertNull(doubleArray10);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) '4', (double) 10L, pointValuePairConvergenceChecker2);
        double[] doubleArray4 = powellOptimizer3.getLowerBound();
        org.junit.Assert.assertNull(doubleArray4);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray1, doubleArray30, true);
        double[] doubleArray34 = pointVectorValuePair33.getPoint();
        double[] doubleArray40 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40);
        org.apache.commons.math3.optim.PointValuePair pointValuePair43 = new org.apache.commons.math3.optim.PointValuePair(doubleArray40, (double) (byte) -1);
        java.lang.Double double44 = pointValuePair43.getSecond();
        java.lang.Double double45 = pointValuePair43.getValue();
        double[] doubleArray46 = pointValuePair43.getKey();
        double[] doubleArray52 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray52);
        double double54 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray46, doubleArray52);
        java.lang.Number number56 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException58 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number56, 97);
        int int59 = nonMonotonicSequenceException58.getIndex();
        java.lang.Number number60 = nonMonotonicSequenceException58.getPrevious();
        int int61 = nonMonotonicSequenceException58.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection62 = nonMonotonicSequenceException58.getDirection();
        boolean boolean64 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray46, orderDirection62, false);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray34, orderDirection62, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + (-1.0d) + "'", double44.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + (-1.0d) + "'", double45.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 97 + "'", int59 == 97);
        org.junit.Assert.assertNull(number60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 97 + "'", int61 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection62 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection62.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (byte) 100, (double) (short) 10, (double) '4', (double) 97);
        double[] doubleArray10 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[] doubleArray18 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18);
        org.apache.commons.math3.optim.PointValuePair pointValuePair21 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) -1);
        boolean boolean23 = pointValuePair21.equals((java.lang.Object) 0);
        java.lang.Object obj24 = null;
        boolean boolean25 = pointValuePair21.equals(obj24);
        double[] doubleArray26 = pointValuePair21.getPoint();
        double[] doubleArray27 = pointValuePair21.getKey();
        boolean boolean28 = array2DRowRealMatrix12.equals((java.lang.Object) doubleArray27);
        int int29 = org.apache.commons.math3.util.MathUtils.hash(doubleArray27);
        try {
            multiDirectionalSimplex4.build(doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1809524577) + "'", int29 == (-1809524577));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula2 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker3 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver6 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula2, pointValuePairConvergenceChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver6);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver6);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType9 = nonLinearConjugateGradientOptimizer8.getGoalType();
        org.junit.Assert.assertNull(goalType9);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        float float2 = org.apache.commons.math3.util.Precision.round(0.5105547f, (int) (byte) 100);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix15.copy();
        try {
            array2DRowRealMatrix15.addToEntry((-1023), 10, (double) 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.RealVector realVector9 = openMapRealMatrix7.getColumnVector((int) (short) 10);
        java.io.ObjectOutputStream objectOutputStream10 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector(realVector9, objectOutputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException0 = new org.apache.commons.math3.exception.MathUnsupportedOperationException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathUnsupportedOperationException0.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = mathUnsupportedOperationException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight32 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        double[] doubleArray33 = array2DRowRealMatrix7.operate(doubleArray25);
        double[] doubleArray40 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40);
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector41.mapDivideToSelf((double) (-1L));
        boolean boolean44 = arrayRealVector41.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc46 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector41.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc46);
        double[] doubleArray53 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53);
        org.apache.commons.math3.linear.RealVector realVector56 = arrayRealVector54.mapDivideToSelf((double) (-1L));
        boolean boolean58 = arrayRealVector54.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector54.append((double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = arrayRealVector47.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector54);
        try {
            array2DRowRealMatrix7.setRowVector(4, (org.apache.commons.math3.linear.RealVector) arrayRealVector47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x5 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(arrayRealVector61);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector23);
        double[] doubleArray30 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, false);
        double[] doubleArray38 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38, false);
        double double41 = arrayRealVector40.getMaxValue();
        double[] doubleArray47 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector48.mapDivideToSelf((double) (-1L));
        boolean boolean51 = arrayRealVector48.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc53 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector48.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc53);
        org.apache.commons.math3.analysis.function.Sinc sinc56 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = arrayRealVector48.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc56);
        double double58 = arrayRealVector40.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        double double60 = arrayRealVector40.getEntry(0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = arrayRealVector32.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        try {
            double double62 = arrayRealVector24.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.0d + "'", double41 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertNotNull(arrayRealVector57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 252.05440211108893d + "'", double58 == 252.05440211108893d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + (-1.0d) + "'", double60 == (-1.0d));
        org.junit.Assert.assertNotNull(arrayRealVector61);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        try {
            org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(0.0d, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(2.718281828459045d, 7.909921332671597E-4d, 2.3978952727983707d, (double) 0.013082147f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.033519757139437084d + "'", double4 == 0.033519757139437084d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 10L, (double) (short) 1, 0.0d);
        int int4 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        int int5 = levenbergMarquardtOptimizer3.getMaxIterations();
        double double6 = levenbergMarquardtOptimizer3.getChiSquare();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker7 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(pointVectorValuePairConvergenceChecker7);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.4153232443518473d, (double) Float.NaN, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        int int6 = brentOptimizer5.getIterations();
        double[] doubleArray12 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapDivideToSelf((double) (-1L));
        boolean boolean16 = arrayRealVector13.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc18 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector13.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc18);
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector13.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        double[] doubleArray24 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray28 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition30 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray24, doubleArray28, (double) (byte) 10);
        double[] doubleArray31 = eigenDecomposition30.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray31);
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray31);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex34 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray31);
        int int35 = nelderMeadSimplex34.getDimension();
        double[] doubleArray41 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix44 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray42);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, 97);
        org.apache.commons.math3.optim.nonlinear.vector.Target target47 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray46);
        double[] doubleArray53 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix56 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray54);
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = diagonalMatrix56.copy();
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight58 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix56);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray59 = new org.apache.commons.math3.optim.OptimizationData[] { nelderMeadSimplex34, target47, weight58 };
        try {
            org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair60 = brentOptimizer5.optimize(optimizationDataArray59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (0) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(optimizationDataArray59);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix2.add(openMapRealMatrix9);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double12 = openMapRealMatrix9.walkInOptimizedOrder(realMatrixChangingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        float float2 = org.apache.commons.math3.util.Precision.round(0.39037895f, 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.39f + "'", float2 == 0.39f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 18918.0d, (java.lang.Number) (-0.012233790557032886d), true);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 18918.0d + "'", number4.equals(18918.0d));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray6, 0.0d, (-0.006179939774976235d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) 3);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(247, (int) (byte) 100);
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix2, 10);
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double double17 = sinc14.value((double) 0.5105547f);
        try {
            double[] doubleArray22 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc14, (double) 6, (double) 0L, (double) 1L, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [6, 1]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.957118376469154d + "'", double17 == 0.957118376469154d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.0d, 246.6779276708802d, 3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight32 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        double[] doubleArray33 = array2DRowRealMatrix7.operate(doubleArray25);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor34 = null;
        try {
            double double39 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor34, 1378221360, 10, 247, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,378,221,360)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7, 97);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.scale(1.4153232443518473d, doubleArray11);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double1 = org.apache.commons.math3.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(97);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator3 = null;
        try {
            nelderMeadSimplex1.evaluate(multivariateFunction2, pointValuePairComparator3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver(7.211102550927978d, (double) 1L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        double double10 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray8);
        try {
            org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -0.012 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.012233790557032886d + "'", double10 == 0.012233790557032886d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.RealVector realVector9 = openMapRealMatrix7.getColumnVector((int) (short) 10);
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = openMapRealMatrix7.createMatrix((-1023), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1,023 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        double[][] doubleArray10 = diagonalMatrix9.getData();
        try {
            diagonalMatrix9.addToEntry((int) 'a', (int) (byte) 0, (double) 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 32 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.NoDataException noDataException2 = new org.apache.commons.math3.exception.NoDataException(localizable1);
        java.lang.Throwable[] throwableArray3 = noDataException2.getSuppressed();
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException4 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.9836065573770492d, 10.0d, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) (short) 10, doubleArray7);
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray7, doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray14);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) (short) 10, (double) 'a', (double) (short) 10);
        double double4 = searchInterval3.getMin();
        double double5 = searchInterval3.getStartValue();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix15.copy();
        try {
            array2DRowRealMatrix15.addToEntry((-1), 97, (-99.85121904920359d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double1 = org.apache.commons.math3.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double[] doubleArray21 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) (-1L));
        double[] doubleArray30 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) (-1L));
        boolean boolean35 = arrayRealVector31.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector31.append((double) (short) 100);
        double double38 = arrayRealVector22.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double[] doubleArray44 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray44);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector45.mapDivideToSelf((double) (-1L));
        boolean boolean48 = arrayRealVector45.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc50 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector45.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc50);
        org.apache.commons.math3.analysis.function.Sinc sinc53 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector45.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector31.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc53);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor57 = null;
        try {
            double double60 = arrayRealVector56.walkInOptimizedOrder(realVectorPreservingVisitor57, (int) (short) 100, 4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 18918.0d + "'", double38 == 18918.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(arrayRealVector56);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double1 = org.apache.commons.math3.util.FastMath.atan((-7.175711493801343E-17d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.175711493801343E-17d) + "'", double1 == (-7.175711493801343E-17d));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = weight8.getWeight();
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = weight8.getWeight();
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = weight8.getWeight();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 0.0f, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) 0.39037895f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.38108765337432393d + "'", double1 == 0.38108765337432393d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        double[] doubleArray8 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray16 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        org.apache.commons.math3.optim.PointValuePair pointValuePair19 = new org.apache.commons.math3.optim.PointValuePair(doubleArray16, (double) (byte) -1);
        boolean boolean21 = pointValuePair19.equals((java.lang.Object) 0);
        java.lang.Object obj22 = null;
        boolean boolean23 = pointValuePair19.equals(obj22);
        double[] doubleArray24 = pointValuePair19.getPoint();
        double[] doubleArray25 = pointValuePair19.getKey();
        boolean boolean26 = array2DRowRealMatrix10.equals((java.lang.Object) doubleArray25);
        double[] doubleArray28 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray32 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition34 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray28, doubleArray32, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight35 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray28);
        double[] doubleArray36 = array2DRowRealMatrix10.operate(doubleArray28);
        try {
            double[] doubleArray37 = openMapRealMatrix2.operate(doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        float float2 = org.apache.commons.math3.util.FastMath.min(10.0f, (float) (-1555302186));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.55530214E9f) + "'", float2 == (-1.55530214E9f));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 0.013082147f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.734723475976807E-18d + "'", double1 == 1.734723475976807E-18d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round(0.957118376469154d, (int) (short) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, 100.0d, 2147483647);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        boolean boolean10 = pointValuePair8.equals((java.lang.Object) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = pointValuePair8.equals(obj11);
        double[] doubleArray13 = pointValuePair8.getPoint();
        double[] doubleArray14 = pointValuePair8.getKey();
        double[] doubleArray15 = pointValuePair8.getPoint();
        java.lang.Double double16 = pointValuePair8.getValue();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16.equals((-1.0d)));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6, 97);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.177446878757825d + "'", double12 == 14.177446878757825d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight32 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        double[] doubleArray33 = array2DRowRealMatrix7.operate(doubleArray25);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor34 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor34.start(0, 247, 1, (int) (short) -1, 0, 0);
        defaultRealMatrixPreservingVisitor34.visit((int) (byte) 0, (int) (short) 0, 246.6779276708802d);
        try {
            double double50 = array2DRowRealMatrix7.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor34, 100, (-1023), (int) (short) -1, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        float float1 = org.apache.commons.math3.util.FastMath.signum(0.013082147f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double[] doubleArray17 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray21 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition23 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray17, doubleArray21, (double) (byte) 10);
        double[] doubleArray24 = eigenDecomposition23.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray24);
        double double26 = arrayRealVector25.getNorm();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor27 = null;
        try {
            double double28 = arrayRealVector25.walkInDefaultOrder(realVectorPreservingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.4153232443518473d + "'", double26 == 1.4153232443518473d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 97, (float) 6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            double double10 = array2DRowRealMatrix7.getEntry(97, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor3.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double11 = openMapRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double17 = openMapRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor12, (int) (byte) 1, (int) (short) 0, (int) (short) -1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) '4');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix4 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix4.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix4);
        org.apache.commons.math3.linear.RealVector realVector11 = openMapRealMatrix9.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix14.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix19 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix14);
        org.apache.commons.math3.linear.RealVector realVector21 = openMapRealMatrix19.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix9.add(openMapRealMatrix19);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor23 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor23.start(0, 247, 1, (int) (short) -1, 0, 0);
        double double31 = openMapRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor23);
        try {
            double double36 = diagonalMatrix1.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor23, 1, (int) '#', 1378221360, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,378,221,360)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }
}

