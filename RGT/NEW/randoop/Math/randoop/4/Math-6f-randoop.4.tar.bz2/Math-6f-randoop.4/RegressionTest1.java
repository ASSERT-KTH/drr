import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(0.9836065573770492d, (double) 100L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        try {
            org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double[] doubleArray1 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math3.util.MathArrays.scale(0.0d, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.RealVector realVector9 = openMapRealMatrix7.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double15 = openMapRealMatrix7.walkInOptimizedOrder(realMatrixChangingVisitor10, 1, 0, 3, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.4153232443518473d, (double) Float.NaN, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        int int6 = brentOptimizer5.getIterations();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = brentOptimizer5.getGoalType();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(goalType7);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix11.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix16 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix11);
        org.apache.commons.math3.linear.RealVector realVector18 = openMapRealMatrix16.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix21.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix26 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix21);
        org.apache.commons.math3.linear.RealVector realVector28 = openMapRealMatrix26.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix29 = openMapRealMatrix16.add(openMapRealMatrix26);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix30 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x1 but expected 97x52");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(openMapRealMatrix29);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 7.6293945E-6f, (java.lang.Number) 0.15928364f, (int) (short) 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(348.9899712026121d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.5481924191803085d + "'", double1 == 6.5481924191803085d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("[", "; ", "; ");
        java.text.ParsePosition parsePosition5 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = realVectorFormat3.parse("{{1}}", parsePosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean22 = arrayRealVector19.isNaN();
        double[] doubleArray28 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapDivideToSelf((double) (-1L));
        boolean boolean32 = arrayRealVector29.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc34 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector29.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc34);
        double double36 = arrayRealVector19.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector29.copy();
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector29.getSubVector((int) (byte) 1, (int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector29);
        try {
            org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector29.getSubVector((int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertNotNull(realVector40);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (-1L), (-1.55530214E9f), (float) (-1L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.7042215514498249d, number1, false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.4153232443518473d, (double) Float.NaN, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker6 = brentOptimizer5.getConvergenceChecker();
        double double7 = brentOptimizer5.getMin();
        org.junit.Assert.assertNotNull(univariatePointValuePairConvergenceChecker6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        boolean boolean10 = pointValuePair8.equals((java.lang.Object) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = pointValuePair8.equals(obj11);
        double[] doubleArray13 = pointValuePair8.getPoint();
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray13);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, 1378221360, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1,378,221,360 is larger than the maximum (5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double[] doubleArray13 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, false);
        double[] doubleArray21 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) (-1L));
        boolean boolean26 = arrayRealVector22.equals((java.lang.Object) 10);
        double double27 = arrayRealVector15.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        double[] doubleArray35 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector36.mapDivideToSelf((double) (-1L));
        boolean boolean40 = arrayRealVector36.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector36.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector36.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector22.combine((double) (byte) 0, (double) (-1L), realVector44);
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = arrayRealVector7.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.RealVector realVector48 = arrayRealVector22.append((double) (short) 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 246.6779276708802d + "'", double27 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(realVector48);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 0, (double) 1);
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker6 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair10 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double11 = univariatePointValuePair10.getValue();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair14 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double15 = univariatePointValuePair14.getValue();
        boolean boolean16 = simpleUnivariateValueChecker6.converged(1, univariatePointValuePair10, univariatePointValuePair14);
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker19 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair23 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double24 = univariatePointValuePair23.getValue();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair27 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double28 = univariatePointValuePair27.getValue();
        boolean boolean29 = simpleUnivariateValueChecker19.converged(1, univariatePointValuePair23, univariatePointValuePair27);
        boolean boolean30 = simpleUnivariateValueChecker2.converged(0, univariatePointValuePair14, univariatePointValuePair27);
        double double31 = univariatePointValuePair14.getValue();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 32.0d + "'", double11 == 32.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 32.0d + "'", double15 == 32.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 32.0d + "'", double24 == 32.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 32.0d + "'", double28 == 32.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 32.0d + "'", double31 == 32.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double14 = array2DRowRealMatrix7.walkInColumnOrder(realMatrixChangingVisitor9, 35, 12, 2147483647, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) (short) 1, (double) (byte) 0, 100);
        double double4 = simpleVectorValueChecker3.getAbsoluteThreshold();
        double double5 = simpleVectorValueChecker3.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector23);
        try {
            arrayRealVector23.setEntry((int) (byte) -1, Double.NaN);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double double4 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve(univariateFunction0, 403.4287934927351d, 7.211102550927978d, (double) 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException(number0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        double double8 = openMapRealMatrix7.getNorm();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 4, 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.5108406941546723E58d + "'", double2 == 2.5108406941546723E58d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        try {
            org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker3 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(0.9877662094429671d, (double) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (byte) 10, (double) 32, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(0.6135536048441389d, 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.108154133718787E10d + "'", double2 == 2.108154133718787E10d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        long[] longArray6 = new long[] { '4', 97, 2147483647, 4, 10L, ' ' };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray6);
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) '#', (double) 1.1920929E-7f, (double) 0.18379879f, 7.909921332671597E-4d, (double) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.4955572211091983E-4d + "'", double6 == 1.4955572211091983E-4d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean23 = arrayRealVector19.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.append((double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double[] doubleArray32 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.mapDivideToSelf((double) (-1L));
        boolean boolean37 = arrayRealVector33.equals((java.lang.Object) 10);
        double double38 = arrayRealVector12.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector12.mapMultiplyToSelf((double) ' ');
        double[] doubleArray48 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray48);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector49.mapDivideToSelf((double) (-1L));
        boolean boolean52 = arrayRealVector49.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc54 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector49.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc54);
        org.apache.commons.math3.analysis.function.Sinc sinc57 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector49.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc57);
        double[] doubleArray64 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray64);
        org.apache.commons.math3.linear.RealVector realVector67 = arrayRealVector65.mapDivideToSelf((double) (-1L));
        boolean boolean69 = arrayRealVector65.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector70 = arrayRealVector65.unitVector();
        org.apache.commons.math3.linear.RealVector realVector71 = realVector70.unitVector();
        double double72 = arrayRealVector58.getDistance(realVector71);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = arrayRealVector12.combine(55.0d, 2.3978952727983707d, realVector71);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-7.175711493801343E-17d) + "'", double38 == (-7.175711493801343E-17d));
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.733816411287911d + "'", double72 == 1.733816411287911d);
        org.junit.Assert.assertNotNull(arrayRealVector73);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        double[] doubleArray33 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray37 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition39 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray33, doubleArray37, (double) (byte) 10);
        double[] doubleArray40 = eigenDecomposition39.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray40);
        double[] doubleArray43 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray47 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray43, doubleArray47, (double) (byte) 10);
        double[] doubleArray50 = eigenDecomposition49.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray50);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix41, (org.apache.commons.math3.linear.AnyMatrix) realMatrix51);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = array2DRowRealMatrix15.multiply(realMatrix41);
        double[][] doubleArray54 = array2DRowRealMatrix15.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = array2DRowRealMatrix15.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = array2DRowRealMatrix7.add(array2DRowRealMatrix15);
        double[] doubleArray64 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray65 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray64);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        double[] doubleArray72 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray72);
        org.apache.commons.math3.optim.PointValuePair pointValuePair75 = new org.apache.commons.math3.optim.PointValuePair(doubleArray72, (double) (byte) -1);
        boolean boolean77 = pointValuePair75.equals((java.lang.Object) 0);
        java.lang.Object obj78 = null;
        boolean boolean79 = pointValuePair75.equals(obj78);
        double[] doubleArray80 = pointValuePair75.getPoint();
        double[] doubleArray81 = pointValuePair75.getKey();
        boolean boolean82 = array2DRowRealMatrix66.equals((java.lang.Object) doubleArray81);
        org.apache.commons.math3.linear.RealMatrix realMatrix85 = array2DRowRealMatrix66.createMatrix(35, (int) (byte) 100);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = array2DRowRealMatrix7.add(array2DRowRealMatrix66);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(realMatrix85);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix86);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int int2 = org.apache.commons.math3.util.FastMath.max((-1), (-1023));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math3.random.RandomGenerator randomGenerator5 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker7 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(247, 0.0d, true, (int) (byte) -1, (int) '#', randomGenerator5, true, pointValuePairConvergenceChecker7);
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList9 = cMAESOptimizer8.getStatisticsMeanHistory();
        java.util.List<java.lang.Double> doubleList10 = cMAESOptimizer8.getStatisticsFitnessHistory();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType11 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType12 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean22 = arrayRealVector19.isNaN();
        double[] doubleArray28 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapDivideToSelf((double) (-1L));
        boolean boolean32 = arrayRealVector29.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc34 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector29.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc34);
        double double36 = arrayRealVector19.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector29.mapDivideToSelf((double) 1);
        double[] doubleArray39 = arrayRealVector29.getDataRef();
        double[] doubleArray45 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray45);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray46);
        double[] doubleArray50 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray46, 97);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds51 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray39, doubleArray46);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray52 = new org.apache.commons.math3.optim.OptimizationData[] { goalType11, goalType12, simpleBounds51 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair53 = cMAESOptimizer8.optimize(optimizationDataArray52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixList9);
        org.junit.Assert.assertNotNull(doubleList10);
        org.junit.Assert.assertTrue("'" + goalType11 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType11.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + goalType12 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType12.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(optimizationDataArray52);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver3 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) '#', (-1.0d), (double) 97);
        int int4 = brentSolver3.getEvaluations();
        double double5 = brentSolver3.getStartValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector6.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor12 = null;
        try {
            double double15 = arrayRealVector11.walkInOptimizedOrder(realVectorPreservingVisitor12, (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray1, doubleArray30, true);
        double[] doubleArray39 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.mapDivideToSelf((double) (-1L));
        arrayRealVector40.set((double) (byte) 0);
        boolean boolean45 = arrayRealVector40.isNaN();
        boolean boolean46 = arrayRealVector40.isNaN();
        double[] doubleArray53 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        double[] doubleArray61 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray61);
        org.apache.commons.math3.optim.PointValuePair pointValuePair64 = new org.apache.commons.math3.optim.PointValuePair(doubleArray61, (double) (byte) -1);
        boolean boolean66 = pointValuePair64.equals((java.lang.Object) 0);
        java.lang.Object obj67 = null;
        boolean boolean68 = pointValuePair64.equals(obj67);
        double[] doubleArray69 = pointValuePair64.getPoint();
        double[] doubleArray70 = pointValuePair64.getKey();
        boolean boolean71 = array2DRowRealMatrix55.equals((java.lang.Object) doubleArray70);
        int int72 = org.apache.commons.math3.util.MathUtils.hash(doubleArray70);
        org.apache.commons.math3.optim.PointValuePair pointValuePair74 = new org.apache.commons.math3.optim.PointValuePair(doubleArray70, (double) 2147483647);
        arrayRealVector40.setSubVector((int) (short) 0, doubleArray70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1809524577) + "'", int72 == (-1809524577));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) (short) 10, doubleArray7);
        double[] doubleArray10 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray14 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition16 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray10, doubleArray14, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver17 = eigenDecomposition16.getSolver();
        double[] doubleArray18 = eigenDecomposition16.getImagEigenvalues();
        double[] doubleArray24 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24);
        org.apache.commons.math3.optim.PointValuePair pointValuePair27 = new org.apache.commons.math3.optim.PointValuePair(doubleArray24, (double) (byte) -1);
        boolean boolean29 = pointValuePair27.equals((java.lang.Object) 0);
        java.lang.Object obj30 = null;
        boolean boolean31 = pointValuePair27.equals(obj30);
        double[] doubleArray32 = pointValuePair27.getPoint();
        boolean boolean33 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray32);
        try {
            double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray7, doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(decompositionSolver17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker4 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
        org.apache.commons.math3.analysis.solvers.UnivariateSolver univariateSolver5 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker4, univariateSolver5);
        double[] doubleArray7 = nonLinearConjugateGradientOptimizer6.getUpperBound();
        org.junit.Assert.assertNull(doubleArray7);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (short) 0, 97.0d, (double) 4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded((int) (byte) 1);
        double[] doubleArray2 = simpleBounds1.getLower();
        org.junit.Assert.assertNotNull(simpleBounds1);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.optim.MaxEval maxEval0 = org.apache.commons.math3.optim.MaxEval.unlimited();
        int int1 = maxEval0.getMaxEval();
        org.junit.Assert.assertNotNull(maxEval0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        java.lang.String str8 = realMatrixFormat6.getRowSeparator();
        double[] doubleArray10 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray14 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition16 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray10, doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = eigenDecomposition16.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray17);
        double[] doubleArray20 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray24 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition26 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray20, doubleArray24, (double) (byte) 10);
        double[] doubleArray27 = eigenDecomposition26.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray27);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix18, (org.apache.commons.math3.linear.AnyMatrix) realMatrix28);
        java.lang.String str30 = realMatrixFormat6.format(realMatrix28);
        java.text.NumberFormat numberFormat31 = realMatrixFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat32 = new org.apache.commons.math3.linear.RealMatrixFormat("; ", ",", "{0; -0; 1; 1; 0}", "{-97; -10; -0; -0; -97}", "{-97; -10; -0; -0; -97}", "[", numberFormat31);
        double[] doubleArray38 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray38);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray46 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray46);
        org.apache.commons.math3.optim.PointValuePair pointValuePair49 = new org.apache.commons.math3.optim.PointValuePair(doubleArray46, (double) (byte) -1);
        boolean boolean51 = pointValuePair49.equals((java.lang.Object) 0);
        java.lang.Object obj52 = null;
        boolean boolean53 = pointValuePair49.equals(obj52);
        double[] doubleArray54 = pointValuePair49.getPoint();
        double[] doubleArray55 = pointValuePair49.getKey();
        boolean boolean56 = array2DRowRealMatrix40.equals((java.lang.Object) doubleArray55);
        double[] doubleArray58 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray62 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition64 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray58, doubleArray62, (double) (byte) 10);
        double[] doubleArray65 = eigenDecomposition64.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix66 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray65);
        double[] doubleArray68 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray72 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition74 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray68, doubleArray72, (double) (byte) 10);
        double[] doubleArray75 = eigenDecomposition74.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix76 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray75);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix66, (org.apache.commons.math3.linear.AnyMatrix) realMatrix76);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = array2DRowRealMatrix40.multiply(realMatrix66);
        java.lang.StringBuffer stringBuffer79 = null;
        java.text.FieldPosition fieldPosition80 = null;
        try {
            java.lang.StringBuffer stringBuffer81 = realMatrixFormat32.format((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix40, stringBuffer79, fieldPosition80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "; " + "'", str8.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "[-0.0122337906]" + "'", str30.equals("[-0.0122337906]"));
        org.junit.Assert.assertNotNull(numberFormat31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(realMatrix76);
        org.junit.Assert.assertNotNull(realMatrix78);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = eigenDecomposition7.getVT();
        double[] doubleArray10 = eigenDecomposition7.getImagEigenvalues();
        double[] doubleArray16 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        double[][] doubleArray19 = array2DRowRealMatrix18.getData();
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray10, doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray13 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray19 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray20 = new double[][] { doubleArray13, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20, true);
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "");
        java.lang.String str4 = realVectorFormat3.getSuffix();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) (short) -1, 22026.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) (-1023), (-0.2105297851150043d), 137.5427206361718d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 137.543 out of [-1,023, -0.211] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 3.814697265625E-6d, (java.lang.Number) 6205813978047108984L, (java.lang.Number) 10L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat0);
        java.lang.String str2 = realMatrixFormat1.getColumnSeparator();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "," + "'", str2.equals(","));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(3.8146972656435034E-6d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.8146972656435034E-6d + "'", double2 == 3.8146972656435034E-6d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        float float2 = org.apache.commons.math3.util.FastMath.max(10.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        float float1 = org.apache.commons.math3.util.FastMath.abs(0.15928364f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.15928364f + "'", float1 == 0.15928364f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double9 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6, 97);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair12 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray6, (java.lang.Double) 0.0d);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix14 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        double[][] doubleArray46 = array2DRowRealMatrix7.getData();
        double[] doubleArray52 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray52);
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector53.mapDivideToSelf((double) (-1L));
        boolean boolean57 = arrayRealVector53.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector53.unitVector();
        org.apache.commons.math3.linear.RealVector realVector59 = realVector58.unitVector();
        try {
            org.apache.commons.math3.linear.RealVector realVector60 = array2DRowRealMatrix7.operate(realVector59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(realVector59);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double[] doubleArray0 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection1 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray0, orderDirection1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection1 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection1.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        float float1 = mersenneTwister0.nextFloat();
//        boolean boolean2 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt((int) (short) 1);
//        int[] intArray6 = new int[] { 100 };
//        int[] intArray9 = new int[] { 100, 97 };
//        int int10 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray6, intArray9);
//        mersenneTwister0.setSeed(intArray6);
//        mersenneTwister0.clear();
//        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.22720921f + "'", float1 == 0.22720921f);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) 99);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix7, 0, (int) (byte) 1);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition11 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (97x52) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double2 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.midpoint((double) (short) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.Fraction> fractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.fractionMatrixToRealMatrix(fractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.4153232443518473d, (double) Float.NaN, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        double double6 = simpleUnivariateValueChecker4.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, (-1809524577), 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.lang.String str1 = realVectorFormat0.getPrefix();
        java.lang.String str2 = realVectorFormat0.getPrefix();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = realVectorFormat0.parse(",");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \",\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(252.05440211108893d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) (-1), (-1.55530214E9f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        double[] doubleArray33 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray37 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition39 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray33, doubleArray37, (double) (byte) 10);
        double[] doubleArray40 = eigenDecomposition39.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray40);
        double[] doubleArray43 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray47 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray43, doubleArray47, (double) (byte) 10);
        double[] doubleArray50 = eigenDecomposition49.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray50);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix41, (org.apache.commons.math3.linear.AnyMatrix) realMatrix51);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = array2DRowRealMatrix15.multiply(realMatrix41);
        double[][] doubleArray54 = array2DRowRealMatrix15.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = array2DRowRealMatrix15.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = array2DRowRealMatrix7.add(array2DRowRealMatrix15);
        try {
            double[] doubleArray60 = array2DRowRealMatrix15.getColumn((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix58);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 4, 97.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0000005f + "'", float2 == 4.0000005f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 1, 0, 52, 10);
        int int5 = matrixDimensionMismatchException4.getExpectedRowDimension();
        int int6 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int7 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        int int8 = matrixDimensionMismatchException4.getWrongColumnDimension();
        try {
            int int10 = matrixDimensionMismatchException4.getWrongDimension(35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math3.optim.MaxIter maxIter0 = org.apache.commons.math3.optim.MaxIter.unlimited();
        int int1 = maxIter0.getMaxIter();
        org.junit.Assert.assertNotNull(maxIter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker6 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 0L, 0.8414709848078965d);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(99.0d, 0.0d, 1.2554203470773362E58d, 0.0d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        double[] doubleArray33 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray37 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition39 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray33, doubleArray37, (double) (byte) 10);
        double[] doubleArray40 = eigenDecomposition39.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray40);
        double[] doubleArray43 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray47 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray43, doubleArray47, (double) (byte) 10);
        double[] doubleArray50 = eigenDecomposition49.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray50);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix41, (org.apache.commons.math3.linear.AnyMatrix) realMatrix51);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = array2DRowRealMatrix15.multiply(realMatrix41);
        double[][] doubleArray54 = array2DRowRealMatrix15.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = array2DRowRealMatrix15.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = array2DRowRealMatrix7.add(array2DRowRealMatrix15);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor59 = null;
        try {
            double double64 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor59, (int) (byte) 0, 0, 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix58);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) ' ');
        double[] doubleArray7 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.mapDivideToSelf((double) (-1L));
        arrayRealVector8.set((double) (byte) 0);
        boolean boolean13 = arrayRealVector8.isNaN();
        double[] doubleArray20 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, false);
        double[] doubleArray28 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapDivideToSelf((double) (-1L));
        double[] doubleArray37 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37);
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector38.mapDivideToSelf((double) (-1L));
        boolean boolean42 = arrayRealVector38.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector38.append((double) (short) 100);
        double double45 = arrayRealVector29.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        double[] doubleArray51 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51);
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector52.mapDivideToSelf((double) (-1L));
        boolean boolean55 = arrayRealVector52.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc57 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector52.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc57);
        org.apache.commons.math3.analysis.function.Sinc sinc60 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = arrayRealVector52.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector38.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = arrayRealVector22.add((org.apache.commons.math3.linear.RealVector) arrayRealVector62);
        arrayRealVector8.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        try {
            double double65 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 32 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 18918.0d + "'", double45 == 18918.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertNotNull(arrayRealVector61);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(arrayRealVector63);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 0);
        incrementor1.setMaximalCount((int) ' ');
        incrementor1.resetCount();
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) '4');
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix((int) (short) 1);
        double[][] doubleArray4 = diagonalMatrix3.getData();
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = diagonalMatrix1.multiply(diagonalMatrix3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 52 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(1.4153232443518473d, 2.718281828459045d);
        double[] doubleArray4 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray8 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray4, doubleArray8, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = weight11.getWeight();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = weight11.getWeight();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = weight11.getWeight();
        double[] doubleArray20 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapDivideToSelf((double) (-1L));
        boolean boolean24 = arrayRealVector21.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc26 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector21.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc26);
        org.apache.commons.math3.analysis.function.Sinc sinc29 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector21.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc29);
        double[] doubleArray32 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray36 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray32, doubleArray36, (double) (byte) 10);
        double[] doubleArray39 = eigenDecomposition38.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, doubleArray39);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray39);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex42 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray39);
        int int43 = nelderMeadSimplex42.getDimension();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction44 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction objectiveFunction45 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction(multivariateFunction44);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray46 = new org.apache.commons.math3.optim.OptimizationData[] { weight11, nelderMeadSimplex42, objectiveFunction45 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair47 = simplexOptimizer2.optimize(optimizationDataArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(optimizationDataArray46);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.copy();
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16);
        java.lang.Number number20 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException22 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number20, 97);
        int int23 = nonMonotonicSequenceException22.getIndex();
        java.lang.Number number24 = nonMonotonicSequenceException22.getPrevious();
        int int25 = nonMonotonicSequenceException22.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection26 = nonMonotonicSequenceException22.getDirection();
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray16, orderDirection26, false, false);
        double[] doubleArray30 = diagonalMatrix8.operate(doubleArray16);
        double[] doubleArray32 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray36 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition38 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray32, doubleArray36, (double) (byte) 10);
        double[] doubleArray39 = eigenDecomposition38.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix40 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray39);
        double[][] doubleArray41 = diagonalMatrix40.getData();
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = diagonalMatrix8.add(diagonalMatrix40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x5 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 97 + "'", int23 == 97);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 97 + "'", int25 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        diagonalMatrix9.multiplyEntry(0, (int) 'a', 7.211102550927978d);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix16 = diagonalMatrix9.createMatrix((-1023), (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: -1,023 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor0 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor0.visit((int) (byte) 100, (int) 'a', 3.8146972656435034E-6d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.7894702148849957d, (double) (-1L), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.analysis.function.Sinc sinc10 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc10);
        org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure12 = null;
        try {
            org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure13 = sinc10.value(derivativeStructure12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(arrayRealVector11);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(3.8146972656435034E-6d, 3.141592653589793d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double2 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.midpoint(0.033519757139437084d, (-99.85121904920359d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-49.90884964603208d) + "'", double2 == (-49.90884964603208d));
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
//        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
//        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
//        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
//        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
//        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
//        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
//        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = pointValuePair24.equals(obj27);
//        double[] doubleArray29 = pointValuePair24.getPoint();
//        double[] doubleArray30 = pointValuePair24.getKey();
//        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
//        double[] doubleArray33 = new double[] { (-0.012233790557032886d) };
//        double[] doubleArray37 = new double[] { (-1L), (-1.0f), 0.0d };
//        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition39 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray33, doubleArray37, (double) (byte) 10);
//        double[] doubleArray40 = eigenDecomposition39.getRealEigenvalues();
//        org.apache.commons.math3.linear.RealMatrix realMatrix41 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray40);
//        double[] doubleArray43 = new double[] { (-0.012233790557032886d) };
//        double[] doubleArray47 = new double[] { (-1L), (-1.0f), 0.0d };
//        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray43, doubleArray47, (double) (byte) 10);
//        double[] doubleArray50 = eigenDecomposition49.getRealEigenvalues();
//        org.apache.commons.math3.linear.RealMatrix realMatrix51 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray50);
//        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix41, (org.apache.commons.math3.linear.AnyMatrix) realMatrix51);
//        org.apache.commons.math3.linear.RealMatrix realMatrix53 = array2DRowRealMatrix15.multiply(realMatrix41);
//        double[][] doubleArray54 = array2DRowRealMatrix15.getData();
//        org.apache.commons.math3.linear.RealMatrix realMatrix57 = array2DRowRealMatrix15.createMatrix((int) ' ', 4);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = array2DRowRealMatrix7.add(array2DRowRealMatrix15);
//        int[] intArray64 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
//        int[] intArray70 = new int[] { 97, 1, 100, (byte) 100, 52 };
//        int int71 = org.apache.commons.math3.util.MathArrays.distance1(intArray64, intArray70);
//        int[] intArray72 = org.apache.commons.math3.util.MathArrays.copyOf(intArray64);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister73 = new org.apache.commons.math3.random.MersenneTwister();
//        float float74 = mersenneTwister73.nextFloat();
//        int[] intArray80 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
//        int[] intArray86 = new int[] { 97, 1, 100, (byte) 100, 52 };
//        int int87 = org.apache.commons.math3.util.MathArrays.distance1(intArray80, intArray86);
//        mersenneTwister73.setSeed(intArray80);
//        try {
//            org.apache.commons.math3.linear.RealMatrix realMatrix89 = array2DRowRealMatrix15.getSubMatrix(intArray72, intArray80);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray5);
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertNotNull(doubleArray21);
//        org.junit.Assert.assertNotNull(doubleArray22);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(doubleArray29);
//        org.junit.Assert.assertNotNull(doubleArray30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(doubleArray33);
//        org.junit.Assert.assertNotNull(doubleArray37);
//        org.junit.Assert.assertNotNull(doubleArray40);
//        org.junit.Assert.assertNotNull(realMatrix41);
//        org.junit.Assert.assertNotNull(doubleArray43);
//        org.junit.Assert.assertNotNull(doubleArray47);
//        org.junit.Assert.assertNotNull(doubleArray50);
//        org.junit.Assert.assertNotNull(realMatrix51);
//        org.junit.Assert.assertNotNull(realMatrix53);
//        org.junit.Assert.assertNotNull(doubleArray54);
//        org.junit.Assert.assertNotNull(realMatrix57);
//        org.junit.Assert.assertNotNull(array2DRowRealMatrix58);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertNotNull(intArray70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 247 + "'", int71 == 247);
//        org.junit.Assert.assertNotNull(intArray72);
//        org.junit.Assert.assertTrue("'" + float74 + "' != '" + 0.024650097f + "'", float74 == 0.024650097f);
//        org.junit.Assert.assertNotNull(intArray80);
//        org.junit.Assert.assertNotNull(intArray86);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 247 + "'", int87 == 247);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        org.apache.commons.math3.linear.RealVector realVector16 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector6.ebeMultiply(realVector16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray22);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = diagonalMatrix24.copy();
        double[][] doubleArray26 = diagonalMatrix24.getData();
        try {
            array2DRowRealMatrix15.setSubMatrix(doubleArray26, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector6.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector6.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector6.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(12, 0.7262694092379458d);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapSubtract((double) (byte) 10);
        try {
            double double20 = arrayRealVector6.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 12");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray7 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray13 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        double[][] doubleArray15 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray14);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14, true);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException19 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, (java.lang.Object[]) doubleArray14);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex24 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray14, (double) 7.6293945E-6f, 0.9075712110370514d, (double) 0.0f, 3.831008000716577E22d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, 0.7262694092379458d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        boolean boolean9 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix7, (double) (byte) 0);
        double[] doubleArray16 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) (-1L));
        double[] doubleArray25 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) (-1L));
        boolean boolean30 = arrayRealVector26.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector26.append((double) (short) 100);
        double double33 = arrayRealVector17.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        double[] doubleArray39 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.mapDivideToSelf((double) (-1L));
        boolean boolean43 = arrayRealVector40.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc45 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector40.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc45);
        org.apache.commons.math3.analysis.function.Sinc sinc48 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector40.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector26.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc48);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector26.mapSubtractToSelf((double) '4');
        try {
            array2DRowRealMatrix7.setRowVector((int) (byte) 1, realVector52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x5 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 18918.0d + "'", double33 == 18918.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertNotNull(realVector52);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double[] doubleArray2 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray6 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray2, doubleArray6, (double) (byte) 10);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray6);
        double double10 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray6);
        java.io.ObjectInputStream objectInputStream12 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) double10, "[-0.0122337906]", objectInputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.4142135623730951d + "'", double10 == 1.4142135623730951d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(252.05440211108893d, (double) 9, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight32 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        double[] doubleArray33 = array2DRowRealMatrix7.operate(doubleArray25);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 0);
        incrementor1.setMaximalCount((int) ' ');
        incrementor1.setMaximalCount((-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double[] doubleArray3 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray3);
        double[] doubleArray7 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray11 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition13 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray7, doubleArray11, (double) (byte) 10);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray11);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition16 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray3, doubleArray14, (double) (byte) -1);
        double[] doubleArray17 = eigenDecomposition16.getRealEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.RealVector realVector9 = openMapRealMatrix7.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix12.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix12);
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix17.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix20 = openMapRealMatrix7.add(openMapRealMatrix17);
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix20.createMatrix((int) (byte) -1, 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealMatrix20);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double[] doubleArray13 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector14.equals((java.lang.Object) 10);
        double double19 = arrayRealVector7.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double[] doubleArray27 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapDivideToSelf((double) (-1L));
        boolean boolean32 = arrayRealVector28.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector28.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector28.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector14.combine((double) (byte) 0, (double) (-1L), realVector36);
        double double38 = arrayRealVector37.getMinValue();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 246.6779276708802d + "'", double19 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        int int2 = org.apache.commons.math3.util.FastMath.max(32, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) (-1809524577), (double) 9, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer5 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray6 = new org.apache.commons.math3.optim.OptimizationData[] {};
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair7 = nonLinearConjugateGradientOptimizer5.optimize(optimizationDataArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(optimizationDataArray6);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[][] doubleArray24 = array2DRowRealMatrix7.getData();
        try {
            array2DRowRealMatrix7.addToEntry(4, (int) 'a', 3.141592653589793d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) '4');
        double[] doubleArray7 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.mapDivideToSelf((double) (-1L));
        boolean boolean11 = arrayRealVector8.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc13 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector8.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc13);
        org.apache.commons.math3.analysis.function.Sinc sinc16 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector8.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc16);
        double[] doubleArray19 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray23 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray19, doubleArray23, (double) (byte) 10);
        double[] doubleArray26 = eigenDecomposition25.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray26);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray26);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex29 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray26);
        double double30 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray26);
        try {
            double[] doubleArray31 = diagonalMatrix1.preMultiply(doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 52 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.012233790557032886d + "'", double30 == 0.012233790557032886d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, 0, 100);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat2 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat1);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat1);
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double2 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.midpoint((double) 0.3820138f, (double) 0.19685411f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.28943395614624023d + "'", double2 == 0.28943395614624023d);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        float float1 = mersenneTwister0.nextFloat();
//        int[] intArray7 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
//        int[] intArray13 = new int[] { 97, 1, 100, (byte) 100, 52 };
//        int int14 = org.apache.commons.math3.util.MathArrays.distance1(intArray7, intArray13);
//        mersenneTwister0.setSeed(intArray7);
//        boolean boolean16 = mersenneTwister0.nextBoolean();
//        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.29159784f + "'", float1 == 0.29159784f);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 247 + "'", int14 == 247);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-0.006179939774976235d), (java.lang.Number) (byte) 1, (int) (short) 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray12 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray13 = new double[][] { doubleArray6, doubleArray12 };
        double[][] doubleArray14 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, true);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray13);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 0.0f, 0.0d, 0.0d, (double) 100, (double) 10.0f);
        double[] doubleArray6 = levenbergMarquardtOptimizer5.getUpperBound();
        int int7 = levenbergMarquardtOptimizer5.getEvaluations();
        org.junit.Assert.assertNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double[] doubleArray13 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector14.equals((java.lang.Object) 10);
        double double19 = arrayRealVector7.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        boolean boolean20 = arrayRealVector7.isNaN();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 246.6779276708802d + "'", double19 == 246.6779276708802d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat0);
        java.lang.String str2 = realMatrixFormat1.getSuffix();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "}" + "'", str2.equals("}"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double[] doubleArray3 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray3);
        double[] doubleArray7 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray11 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition13 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray7, doubleArray11, (double) (byte) 10);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray11);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition16 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray3, doubleArray14, (double) (byte) -1);
        double[] doubleArray17 = eigenDecomposition16.getImagEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = eigenDecomposition16.getV();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double[] doubleArray2 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray6 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray2, doubleArray6, (double) (byte) 10);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (short) 10, (int) ' ', 0.0d);
        int int4 = nonSymmetricMatrixException3.getColumn();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) (byte) 0, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 1, 0, 52, 10);
        int int5 = matrixDimensionMismatchException4.getExpectedRowDimension();
        int int6 = matrixDimensionMismatchException4.getWrongColumnDimension();
        try {
            int int8 = matrixDimensionMismatchException4.getWrongDimension((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int[] intArray0 = null;
        int[] intArray2 = new int[] { 100 };
        int[] intArray5 = new int[] { 100, 97 };
        int int6 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray2, intArray5);
        int[] intArray12 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
        int[] intArray18 = new int[] { 97, 1, 100, (byte) 100, 52 };
        int int19 = org.apache.commons.math3.util.MathArrays.distance1(intArray12, intArray18);
        double double20 = org.apache.commons.math3.util.MathArrays.distance(intArray2, intArray12);
        int[] intArray26 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
        int[] intArray32 = new int[] { 97, 1, 100, (byte) 100, 52 };
        int int33 = org.apache.commons.math3.util.MathArrays.distance1(intArray26, intArray32);
        int[] intArray34 = org.apache.commons.math3.util.MathArrays.copyOf(intArray26);
        int int35 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray2, intArray26);
        try {
            double double36 = org.apache.commons.math3.util.MathArrays.distance(intArray0, intArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 247 + "'", int19 == 247);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 99.0d + "'", double20 == 99.0d);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 247 + "'", int33 == 247);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        float float1 = org.apache.commons.math3.util.FastMath.abs(0.3498621f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.3498621f + "'", float1 == 0.3498621f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((long) '#');
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { (-1) };
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { 10, 52, 100 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException9 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable2, intArray4, intArray8);
        try {
            org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException10 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray1, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix15.copy();
        double[] doubleArray18 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray22 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray18, doubleArray22, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver25 = eigenDecomposition24.getSolver();
        double[] doubleArray26 = eigenDecomposition24.getImagEigenvalues();
        boolean boolean27 = array2DRowRealMatrix15.equals((java.lang.Object) eigenDecomposition24);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = eigenDecomposition24.getD();
        double double29 = eigenDecomposition24.getDeterminant();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(decompositionSolver25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-0.012233790557032886d) + "'", double29 == (-0.012233790557032886d));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((-1809524577), 1.4955572211091983E-4d, 3.8146972656435034E-6d, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("{", "hi!", "; ", "}", "hi!", "[-0.0122337906]");
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector16.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        double double23 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector16.mapDivideToSelf((double) 1);
        double[] doubleArray26 = arrayRealVector16.getDataRef();
        double[] doubleArray32 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray33, 97);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds38 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray26, doubleArray33);
        java.lang.Number number40 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException42 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number40, 97);
        int int43 = nonMonotonicSequenceException42.getIndex();
        java.lang.Number number44 = nonMonotonicSequenceException42.getPrevious();
        int int45 = nonMonotonicSequenceException42.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection46 = nonMonotonicSequenceException42.getDirection();
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray26, orderDirection46, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 3 and 4 are not increasing (-0 > -97)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 97 + "'", int43 == 97);
        org.junit.Assert.assertNull(number44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 97 + "'", int45 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection46 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection46.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        float float3 = org.apache.commons.math3.util.Precision.round((float) 0, (int) (byte) -1, 5);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-0.0f) + "'", float3 == (-0.0f));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker((-1.0d), 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(10);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 0.19685411f, 252.05440211108893d, (double) 1L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((-0.006179939774976235d), (-3.141592653589793d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-99.85121904920359d), 3.748066027288565E7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-99.85121904920359d) + "'", double2 == (-99.85121904920359d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 0L, 2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray1, doubleArray30, true);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection37 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException39 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 0.15928364f, (java.lang.Number) 0.9326714f, 32, orderDirection37, true);
        try {
            boolean boolean42 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray30, orderDirection37, true, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + orderDirection37 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection37.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction objectiveFunction1 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction(multivariateFunction0);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = objectiveFunction1.getObjectiveFunction();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = objectiveFunction1.getObjectiveFunction();
        org.junit.Assert.assertNull(multivariateFunction2);
        org.junit.Assert.assertNull(multivariateFunction3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double[] doubleArray13 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (-1L));
        double[] doubleArray22 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) (-1L));
        boolean boolean27 = arrayRealVector23.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector23.append((double) (short) 100);
        double double30 = arrayRealVector14.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        double[] doubleArray36 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray36);
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector37.mapDivideToSelf((double) (-1L));
        boolean boolean40 = arrayRealVector37.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc42 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector37.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc42);
        org.apache.commons.math3.analysis.function.Sinc sinc45 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector37.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector23.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector7.add((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor49 = null;
        try {
            double double50 = arrayRealVector48.walkInDefaultOrder(realVectorPreservingVisitor49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 18918.0d + "'", double30 == 18918.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertNotNull(arrayRealVector48);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 0.0d, (java.lang.Number) 10);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector15.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.append((double) (short) 100);
        double double22 = arrayRealVector6.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        double[] doubleArray28 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapDivideToSelf((double) (-1L));
        boolean boolean32 = arrayRealVector29.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc34 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector29.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc34);
        org.apache.commons.math3.analysis.function.Sinc sinc37 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector29.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc37);
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector15.mapSubtractToSelf((double) '4');
        org.apache.commons.math3.linear.RealVector realVector42 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector15.append(realVector42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 18918.0d + "'", double22 == 18918.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertNotNull(realVector41);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(1.0d, (double) 6205813978047108984L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) (short) 10, doubleArray7);
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray7, doubleArray14);
        double[] doubleArray22 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix25 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray23);
        java.lang.Number number27 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException29 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number27, 97);
        int int30 = nonMonotonicSequenceException29.getIndex();
        java.lang.Number number31 = nonMonotonicSequenceException29.getPrevious();
        int int32 = nonMonotonicSequenceException29.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection33 = nonMonotonicSequenceException29.getDirection();
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray23, orderDirection33, false, false);
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray14, orderDirection33, false, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 97 + "'", int30 == 97);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 97 + "'", int32 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection33.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor46 = null;
        try {
            double double47 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor3.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double11 = openMapRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        int int12 = openMapRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 0);
        double[] doubleArray20 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        org.apache.commons.math3.optim.PointValuePair pointValuePair23 = new org.apache.commons.math3.optim.PointValuePair(doubleArray20, (double) (byte) -1);
        java.lang.Double double24 = pointValuePair23.getSecond();
        java.lang.Double double25 = pointValuePair23.getValue();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32);
        double double34 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray26, doubleArray32);
        try {
            double[] doubleArray35 = openMapRealMatrix2.preMultiply(doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 97");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-1.0d) + "'", double25.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver8 = eigenDecomposition7.getSolver();
        double[] doubleArray9 = eigenDecomposition7.getImagEigenvalues();
        try {
            double double11 = eigenDecomposition7.getRealEigenvalue(6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(decompositionSolver8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        float float2 = org.apache.commons.math3.util.FastMath.min(0.0f, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double[] doubleArray7 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) (short) 10, doubleArray8);
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray8, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.scale((double) 'a', doubleArray15);
        double[] doubleArray24 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition26 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray18, doubleArray25);
        double[] doubleArray32 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        double[] doubleArray41 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector42.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector48 = arrayRealVector42.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector42, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33, arrayRealVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector52, true);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(realVector48);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        float float2 = org.apache.commons.math3.util.Precision.round(0.0f, (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double[] doubleArray1 = new double[] { (byte) 10 };
        double[] doubleArray3 = new double[] { (byte) 10 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double double2 = org.apache.commons.math3.util.FastMath.max(0.9836065573770492d, 18918.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18918.0d + "'", double2 == 18918.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7, 97);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.scale(1.4153232443518473d, doubleArray11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean22 = arrayRealVector19.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc24 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector19.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc24);
        org.apache.commons.math3.analysis.function.Sinc sinc27 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector19.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc27);
        double[] doubleArray30 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray34 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition36 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray30, doubleArray34, (double) (byte) 10);
        double[] doubleArray37 = eigenDecomposition36.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, doubleArray37);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, doubleArray37);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37);
        double[] doubleArray44 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray48 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition50 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray44, doubleArray48, (double) (byte) 10);
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray48);
        double[] doubleArray57 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray48, doubleArray58);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma60 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray58);
        try {
            double[] doubleArray61 = diagonalMatrix41.preMultiply(doubleArray58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 2.5108406941546723E58d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 10L, (double) (short) 1, 0.0d);
        int int4 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        int int5 = levenbergMarquardtOptimizer3.getMaxIterations();
        double[] doubleArray6 = levenbergMarquardtOptimizer3.getStartPoint();
        int int7 = levenbergMarquardtOptimizer3.getEvaluations();
        int int8 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray15 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition17 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray11, doubleArray15, (double) (byte) 10);
        double[] doubleArray18 = eigenDecomposition17.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix9, (org.apache.commons.math3.linear.AnyMatrix) realMatrix19);
        boolean boolean22 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric(realMatrix19, (double) 100);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition23 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix19);
        double[] doubleArray29 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        double[] doubleArray37 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        double[] doubleArray45 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray45);
        org.apache.commons.math3.optim.PointValuePair pointValuePair48 = new org.apache.commons.math3.optim.PointValuePair(doubleArray45, (double) (byte) -1);
        boolean boolean50 = pointValuePair48.equals((java.lang.Object) 0);
        java.lang.Object obj51 = null;
        boolean boolean52 = pointValuePair48.equals(obj51);
        double[] doubleArray53 = pointValuePair48.getPoint();
        double[] doubleArray54 = pointValuePair48.getKey();
        boolean boolean55 = array2DRowRealMatrix39.equals((java.lang.Object) doubleArray54);
        double[] doubleArray57 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray61 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition63 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray57, doubleArray61, (double) (byte) 10);
        double[] doubleArray64 = eigenDecomposition63.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix65 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray64);
        double[] doubleArray67 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray71 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition73 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray67, doubleArray71, (double) (byte) 10);
        double[] doubleArray74 = eigenDecomposition73.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix75 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray74);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix65, (org.apache.commons.math3.linear.AnyMatrix) realMatrix75);
        org.apache.commons.math3.linear.RealMatrix realMatrix77 = array2DRowRealMatrix39.multiply(realMatrix65);
        double[][] doubleArray78 = array2DRowRealMatrix39.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix81 = array2DRowRealMatrix39.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix82 = array2DRowRealMatrix31.add(array2DRowRealMatrix39);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix19, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix82);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 5x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertNotNull(realMatrix77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realMatrix81);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix82);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        boolean boolean9 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix7, (double) (byte) 0);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double11 = array2DRowRealMatrix7.walkInOptimizedOrder(realMatrixChangingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.19685411f, (float) 100, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.4153232443518473d, (double) Float.NaN, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        int int6 = brentOptimizer5.getIterations();
        int int7 = brentOptimizer5.getEvaluations();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix12.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix12);
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix17.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix22 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix22.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix22);
        org.apache.commons.math3.linear.RealVector realVector29 = openMapRealMatrix27.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix30 = openMapRealMatrix17.add(openMapRealMatrix27);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor31 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor31.start(0, 247, 1, (int) (short) -1, 0, 0);
        double double39 = openMapRealMatrix27.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor31);
        try {
            double double44 = diagonalMatrix9.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor31, (int) (byte) 0, (-1), 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealMatrix30);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapMultiplyToSelf((double) 97);
        try {
            org.apache.commons.math3.linear.RealVector realVector3 = realVector2.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double[] doubleArray2 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray6 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray2, doubleArray6, (double) (byte) 10);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix12 = diagonalMatrix10.getColumnMatrix(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) 99, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 101376.0f + "'", float2 == 101376.0f);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector6.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector6.unitVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.copy();
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean23 = arrayRealVector19.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.append((double) (short) 100);
        double double26 = arrayRealVector12.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double double28 = arrayRealVector19.getEntry(0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-97.0d) + "'", double28 == (-97.0d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        java.lang.String str2 = realMatrixFormat0.getRowSeparator();
        java.lang.String str3 = realMatrixFormat0.getColumnSeparator();
        java.text.ParsePosition parsePosition5 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix6 = realMatrixFormat0.parse("", parsePosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ", " + "'", str3.equals(", "));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(0.6135536048441389d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 628.2788913603982d + "'", double2 == 628.2788913603982d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        double[] doubleArray33 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray37 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition39 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray33, doubleArray37, (double) (byte) 10);
        double[] doubleArray40 = eigenDecomposition39.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray40);
        double[] doubleArray43 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray47 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray43, doubleArray47, (double) (byte) 10);
        double[] doubleArray50 = eigenDecomposition49.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray50);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix41, (org.apache.commons.math3.linear.AnyMatrix) realMatrix51);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = array2DRowRealMatrix15.multiply(realMatrix41);
        double[][] doubleArray54 = array2DRowRealMatrix15.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = array2DRowRealMatrix15.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = array2DRowRealMatrix7.add(array2DRowRealMatrix15);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix58, 0, (int) (short) 1, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix58);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double[] doubleArray17 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray21 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition23 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray17, doubleArray21, (double) (byte) 10);
        double[] doubleArray24 = eigenDecomposition23.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex27 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray24);
        int int28 = nelderMeadSimplex27.getDimension();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction29 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator30 = null;
        try {
            nelderMeadSimplex27.iterate(multivariateFunction29, pointValuePairComparator30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray6 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray2, doubleArray6, (double) (byte) 10);
        double[] doubleArray9 = eigenDecomposition8.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray9);
        double double11 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray9);
        try {
            double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray0, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.012233790557032886d + "'", double11 == 0.012233790557032886d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) 101376.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 318.3959798741184d + "'", double1 == 318.3959798741184d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        try {
            double double7 = openMapRealMatrix2.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (97x52) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        try {
            org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -0.012 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray15 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition17 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray11, doubleArray15, (double) (byte) 10);
        double[] doubleArray18 = eigenDecomposition17.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix9, (org.apache.commons.math3.linear.AnyMatrix) realMatrix19);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition22 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix9, (double) 52.0f);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix23 = eigenDecomposition22.getSquareRoot();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathUnsupportedOperationException; message: unsupported operation");
        } catch (org.apache.commons.math3.exception.MathUnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        double[] doubleArray33 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray37 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition39 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray33, doubleArray37, (double) (byte) 10);
        double[] doubleArray40 = eigenDecomposition39.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray40);
        double[] doubleArray43 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray47 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray43, doubleArray47, (double) (byte) 10);
        double[] doubleArray50 = eigenDecomposition49.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray50);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix41, (org.apache.commons.math3.linear.AnyMatrix) realMatrix51);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = array2DRowRealMatrix15.multiply(realMatrix41);
        double[][] doubleArray54 = array2DRowRealMatrix15.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = array2DRowRealMatrix15.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = array2DRowRealMatrix7.add(array2DRowRealMatrix15);
        try {
            array2DRowRealMatrix7.multiplyEntry(99, (int) (byte) 100, 3.982441812995697E30d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (99)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix58);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double1 = org.apache.commons.math3.util.FastMath.tan(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1189396031849523d + "'", double1 == 1.1189396031849523d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance((double) 9, (double) 1.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 1, 0, 52, 10);
        int int5 = matrixDimensionMismatchException4.getWrongRowDimension();
        java.lang.String str6 = matrixDimensionMismatchException4.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.linear.MatrixDimensionMismatchException: got 1x0 but expected 52x10" + "'", str6.equals("org.apache.commons.math3.linear.MatrixDimensionMismatchException: got 1x0 but expected 52x10"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray12 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray13 = new double[][] { doubleArray6, doubleArray12 };
        double[][] doubleArray14 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, true);
        org.apache.commons.math3.exception.ConvergenceException convergenceException17 = new org.apache.commons.math3.exception.ConvergenceException(localizable0, (java.lang.Object[]) doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix15.copy();
        double[] doubleArray18 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray22 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray18, doubleArray22, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver25 = eigenDecomposition24.getSolver();
        double[] doubleArray26 = eigenDecomposition24.getImagEigenvalues();
        boolean boolean27 = array2DRowRealMatrix15.equals((java.lang.Object) eigenDecomposition24);
        double double28 = eigenDecomposition24.getDeterminant();
        try {
            double double30 = eigenDecomposition24.getImagEigenvalue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(decompositionSolver25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-0.012233790557032886d) + "'", double28 == (-0.012233790557032886d));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (byte) 1);
        double[] doubleArray7 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7);
        try {
            multiDirectionalSimplex1.build(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7, 97);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.scale(1.4153232443518473d, doubleArray11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean22 = arrayRealVector19.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc24 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector19.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc24);
        org.apache.commons.math3.analysis.function.Sinc sinc27 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector19.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc27);
        double[] doubleArray30 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray34 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition36 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray30, doubleArray34, (double) (byte) 10);
        double[] doubleArray37 = eigenDecomposition36.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, doubleArray37);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, doubleArray37);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37);
        double[] doubleArray47 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47, false);
        double[] doubleArray55 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray55, false);
        double[] doubleArray63 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray63);
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector64.mapDivideToSelf((double) (-1L));
        boolean boolean68 = arrayRealVector64.equals((java.lang.Object) 10);
        double double69 = arrayRealVector57.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector64);
        double[] doubleArray77 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray77);
        org.apache.commons.math3.linear.RealVector realVector80 = arrayRealVector78.mapDivideToSelf((double) (-1L));
        boolean boolean82 = arrayRealVector78.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector84 = arrayRealVector78.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector86 = arrayRealVector78.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = arrayRealVector64.combine((double) (byte) 0, (double) (-1L), realVector86);
        org.apache.commons.math3.linear.RealMatrix realMatrix88 = arrayRealVector49.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector64);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix41, (org.apache.commons.math3.linear.AnyMatrix) realMatrix88);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 5x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 246.6779276708802d + "'", double69 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(realVector84);
        org.junit.Assert.assertNotNull(realVector86);
        org.junit.Assert.assertNotNull(arrayRealVector87);
        org.junit.Assert.assertNotNull(realMatrix88);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.text.NumberFormat numberFormat6 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat6);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat("", "[-0.0122337906]", "hi!", "[-0.0122337906]", "; ", "org.apache.commons.math3.linear.MatrixDimensionMismatchException: got 1x0 but expected 52x10", numberFormat6);
        org.junit.Assert.assertNotNull(numberFormat6);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        java.lang.String str2 = realMatrixFormat0.getRowSeparator();
        double[] doubleArray4 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray8 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray4, doubleArray8, (double) (byte) 10);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray11);
        java.lang.String str13 = realMatrixFormat0.format(realMatrix12);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) realMatrix12);
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "[-0.0122337906]" + "'", str13.equals("[-0.0122337906]"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(7.909921332671597E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2147483647, (java.lang.Number) 10L, true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = eigenDecomposition7.getVT();
        double[] doubleArray10 = eigenDecomposition7.getImagEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = eigenDecomposition7.getV();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(0, (double) 0.04532051f, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer5 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType6 = nonLinearConjugateGradientOptimizer5.getGoalType();
        int int7 = nonLinearConjugateGradientOptimizer5.getIterations();
        int int8 = nonLinearConjugateGradientOptimizer5.getIterations();
        org.junit.Assert.assertNull(goalType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(2.108154133718787E10d, 9);
        double double3 = bracketFinder2.getFLo();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        int int1 = incrementor0.getCount();
        boolean boolean2 = incrementor0.canIncrement();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (byte) 10, 0.38108765337432393d, (double) (short) -1, (double) 0.5105547f, 0.0d, (double) (-1.55530214E9f));
        int int7 = nelderMeadSimplex6.getDimension();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.lang.Object obj0 = null;
        try {
            org.apache.commons.math3.util.MathUtils.checkNotNull(obj0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.RealVector realVector9 = openMapRealMatrix7.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix12.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix12);
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix17.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix20 = openMapRealMatrix7.add(openMapRealMatrix17);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor21.start(0, 247, 1, (int) (short) -1, 0, 0);
        double double29 = openMapRealMatrix17.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        int int30 = openMapRealMatrix17.getColumnDimension();
        try {
            double double31 = openMapRealMatrix17.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (97x52) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealMatrix20);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 52 + "'", int30 == 52);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 0.0f, 0.0d, 0.0d, (double) 100, (double) 10.0f);
        int int6 = levenbergMarquardtOptimizer5.getIterations();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector16.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        double double23 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector16.mapDivideToSelf((double) 1);
        double[] doubleArray31 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector32.mapDivideToSelf((double) (-1L));
        double[] doubleArray40 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40);
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector41.mapDivideToSelf((double) (-1L));
        boolean boolean45 = arrayRealVector41.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector41.append((double) (short) 100);
        double double48 = arrayRealVector32.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, arrayRealVector32);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 18918.0d + "'", double48 == 18918.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double[] doubleArray17 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray21 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition23 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray17, doubleArray21, (double) (byte) 10);
        double[] doubleArray24 = eigenDecomposition23.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray24);
        double[] doubleArray26 = arrayRealVector25.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.012233790557032886d), (java.lang.Number) (-1L), (java.lang.Number) 1L);
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Number number6 = outOfRangeException4.getLo();
        java.lang.Number number7 = outOfRangeException4.getLo();
        java.lang.Number number8 = outOfRangeException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1L) + "'", number6.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1L) + "'", number7.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-0.012233790557032886d) + "'", number8.equals((-0.012233790557032886d)));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(101376.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(6, 10);
        try {
            openMapRealMatrix2.addToEntry(99, (int) (byte) -1, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (99)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor46 = null;
        try {
            double double51 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor46, 35, (int) (byte) 10, 5, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double double8 = arrayRealVector7.getMaxValue();
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector15.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc20 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc20);
        org.apache.commons.math3.analysis.function.Sinc sinc23 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector15.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc23);
        double double25 = arrayRealVector7.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector24.copy();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector24.append(0.0d);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector24.mapAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector32 = realVector30.mapMultiply(1.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 252.05440211108893d + "'", double25 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(realVector32);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (short) 100, 0, (-3.982441812995697E30d));
        double double4 = nonSymmetricMatrixException3.getThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3.982441812995697E30d) + "'", double4 == (-3.982441812995697E30d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 12);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray1, doubleArray30, true);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix43 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.4153232443518473d, (double) Float.NaN, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        int int6 = brentOptimizer5.getIterations();
        int int7 = brentOptimizer5.getMaxIterations();
        double double8 = brentOptimizer5.getStartValue();
        int int9 = brentOptimizer5.getEvaluations();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker10 = brentOptimizer5.getConvergenceChecker();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(univariatePointValuePairConvergenceChecker10);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix2.add(openMapRealMatrix9);
        try {
            org.apache.commons.math3.linear.RealVector realVector12 = openMapRealMatrix9.getColumnVector((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor3.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double11 = openMapRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        int int12 = openMapRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix2.multiply(openMapRealMatrix14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) (short) 10, (double) 'a', (double) (short) 10);
        double double4 = searchInterval3.getMin();
        double double5 = searchInterval3.getMin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(0.0d, (double) 4.0000005f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        try {
            org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(318.3959798741184d, 3.814697265625E-6d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        java.lang.String str8 = realMatrixFormat6.getRowSeparator();
        double[] doubleArray10 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray14 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition16 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray10, doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = eigenDecomposition16.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray17);
        double[] doubleArray20 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray24 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition26 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray20, doubleArray24, (double) (byte) 10);
        double[] doubleArray27 = eigenDecomposition26.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray27);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix18, (org.apache.commons.math3.linear.AnyMatrix) realMatrix28);
        java.lang.String str30 = realMatrixFormat6.format(realMatrix28);
        java.text.NumberFormat numberFormat31 = realMatrixFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat32 = new org.apache.commons.math3.linear.RealMatrixFormat("; ", ",", "{0; -0; 1; 1; 0}", "{-97; -10; -0; -0; -97}", "{-97; -10; -0; -0; -97}", "[", numberFormat31);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat33 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat31);
        java.text.NumberFormat numberFormat34 = realVectorFormat33.getFormat();
        org.junit.Assert.assertNotNull(realMatrixFormat6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "; " + "'", str8.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "[-0.0122337906]" + "'", str30.equals("[-0.0122337906]"));
        org.junit.Assert.assertNotNull(numberFormat31);
        org.junit.Assert.assertNotNull(numberFormat34);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.RealVector realVector9 = openMapRealMatrix7.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix12.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix12);
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix17.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix20 = openMapRealMatrix7.add(openMapRealMatrix17);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix23 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix23.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix28 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix23);
        org.apache.commons.math3.linear.RealVector realVector30 = openMapRealMatrix28.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix33 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix33.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix38 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix33);
        org.apache.commons.math3.linear.RealVector realVector40 = openMapRealMatrix38.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix41 = openMapRealMatrix28.add(openMapRealMatrix38);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor42 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor42.start(0, 247, 1, (int) (short) -1, 0, 0);
        double double50 = openMapRealMatrix38.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor42);
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix51 = openMapRealMatrix17.multiply(openMapRealMatrix38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 52 != 97");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealMatrix20);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(openMapRealMatrix41);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 0);
        incrementor1.incrementCount((int) (byte) 0);
        incrementor1.setMaximalCount(0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        int int2 = org.apache.commons.math3.util.FastMath.min(32, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula2 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker3 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver6 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula2, pointValuePairConvergenceChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver6);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner8 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer9 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver6, preconditioner8);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction11 = null;
        try {
            double double13 = brentSolver6.solve(6, univariateFunction11, (double) 0.19685411f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector6.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector6.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector6.mapDivide((double) '4');
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor15 = null;
        try {
            double double16 = arrayRealVector6.walkInOptimizedOrder(realVectorPreservingVisitor15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((-0.8414709848078965d), 22026.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("[-0.0122337906]", 2147483647);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = mathParseException2.getContext();
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor11.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double19 = openMapRealMatrix10.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        int int20 = openMapRealMatrix10.getRowDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix21 = openMapRealMatrix7.subtract(openMapRealMatrix10);
        double[] doubleArray28 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray34 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray35 = new double[][] { doubleArray28, doubleArray34 };
        double[][] doubleArray36 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray35);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = array2DRowRealMatrix38.copy();
        try {
            openMapRealMatrix7.setColumnMatrix(10, realMatrix39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x5 but expected 97x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 97 + "'", int20 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realMatrix39);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector16.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector16.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector6.append(realVector22);
        double[] doubleArray29 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.mapDivideToSelf((double) (-1L));
        boolean boolean33 = arrayRealVector30.isNaN();
        double[] doubleArray39 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.mapDivideToSelf((double) (-1L));
        boolean boolean43 = arrayRealVector40.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc45 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector40.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc45);
        double double47 = arrayRealVector30.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector40.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector6.append(arrayRealVector40);
        double double51 = arrayRealVector6.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector6.mapSubtractToSelf(2.718281828459045d);
        try {
            org.apache.commons.math3.linear.RealVector realVector56 = arrayRealVector6.getSubVector(0, 16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (15)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + (-97.0d) + "'", double51 == (-97.0d));
        org.junit.Assert.assertNotNull(realVector53);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        java.lang.String str2 = realMatrixFormat0.getPrefix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = realMatrixFormat0.parse(",");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \",\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.Array2DRowRealMatrix");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[" + "'", str2.equals("["));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection8 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5, orderDirection8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.7042215514498249d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7042215514498249d + "'", double2 == 0.7042215514498249d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("[-0.0122337906]", "org.apache.commons.math3.linear.MatrixDimensionMismatchException: got 1x0 but expected 52x10", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight32 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        double[] doubleArray33 = array2DRowRealMatrix7.operate(doubleArray25);
        double[] doubleArray39 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39);
        try {
            double[] doubleArray41 = array2DRowRealMatrix7.operate(doubleArray39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double double8 = arrayRealVector7.getMaxValue();
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector15.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc20 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc20);
        org.apache.commons.math3.analysis.function.Sinc sinc23 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector15.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc23);
        double double25 = arrayRealVector7.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector24.copy();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector24.append(0.0d);
        int int29 = realVector28.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 252.05440211108893d + "'", double25 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector23);
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.mapMultiply(0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) '4');
        double[][] doubleArray2 = diagonalMatrix1.getData();
        double[][] doubleArray3 = diagonalMatrix1.getData();
        double[] doubleArray9 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix12.copy();
        double[][] doubleArray14 = diagonalMatrix12.getData();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor15 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor15.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double23 = defaultRealMatrixPreservingVisitor15.end();
        double double24 = diagonalMatrix12.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor15);
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix25 = diagonalMatrix1.subtract(diagonalMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 52x52 but expected 5x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition11 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix9, (double) 0);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver12 = lUDecomposition11.getSolver();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(decompositionSolver12);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.copy();
        double[][] doubleArray10 = diagonalMatrix8.getData();
        double[] doubleArray11 = diagonalMatrix8.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep1 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep((-1.0d));
        double double2 = bracketingStep1.getBracketingStep();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        boolean boolean10 = pointValuePair8.equals((java.lang.Object) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = pointValuePair8.equals(obj11);
        double[] doubleArray13 = pointValuePair8.getFirst();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, (double) 10L, 2.99822295029797d, 5.0d, 32.0d, 2.3978952727983707d, 55.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 91.72376348103771d + "'", double8 == 91.72376348103771d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(1.1189396031849523d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.019529180206536247d + "'", double1 == 0.019529180206536247d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math3.random.MersenneTwister();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker10 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(1378221360, 0.0d, true, 1378221360, 4, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister5, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker10);
        int[] intArray17 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
        int[] intArray23 = new int[] { 97, 1, 100, (byte) 100, 52 };
        int int24 = org.apache.commons.math3.util.MathArrays.distance1(intArray17, intArray23);
        mersenneTwister5.setSeed(intArray17);
        int int27 = mersenneTwister5.nextInt(12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 247 + "'", int24 == 247);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 9 + "'", int27 == 9);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(14.177446878757825d, (double) 16, 137.5427206361718d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double3 = bracketFinder2.getHi();
        double double4 = bracketFinder2.getLo();
        double double5 = bracketFinder2.getLo();
        int int6 = bracketFinder2.getEvaluations();
        double double7 = bracketFinder2.getFHi();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double3 = bracketFinder2.getHi();
        double double4 = bracketFinder2.getLo();
        org.apache.commons.math3.analysis.function.Sinc sinc6 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder2.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc6, goalType7, (double) '4', (double) 'a');
        double double11 = bracketFinder2.getFHi();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType7 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType7.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.001046155115639312d) + "'", double11 == (-0.001046155115639312d));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((-3.141592653589793d), 6.283185307179586d, (double) (-1555302186), (double) 3, (-97.0d), 0.9836065573770492d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-4.665906673149045E9d) + "'", double6 == (-4.665906673149045E9d));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        int[] intArray1 = new int[] { 100 };
        int[] intArray4 = new int[] { 100, 97 };
        int int5 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray1, intArray4);
        try {
            int[] intArray7 = org.apache.commons.math3.util.MathArrays.copyOf(intArray4, (-1023));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double double8 = arrayRealVector7.getMaxValue();
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector15.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc20 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc20);
        org.apache.commons.math3.analysis.function.Sinc sinc23 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector15.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc23);
        double double25 = arrayRealVector7.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector24.copy();
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector26.getSubVector(0, 0);
        double[] doubleArray30 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, doubleArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 252.05440211108893d + "'", double25 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(realVector29);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(100, 5);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(6, 10);
        int int3 = openMapRealMatrix2.getColumnDimension();
        double[] doubleArray5 = new double[] { (byte) 10 };
        double[] doubleArray7 = new double[] { (byte) 10 };
        double[][] doubleArray8 = new double[][] { doubleArray5, doubleArray7 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray8);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix12 = openMapRealMatrix2.multiply(realMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 0, (double) 1);
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker6 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair10 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double11 = univariatePointValuePair10.getValue();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair14 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double15 = univariatePointValuePair14.getValue();
        boolean boolean16 = simpleUnivariateValueChecker6.converged(1, univariatePointValuePair10, univariatePointValuePair14);
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker19 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair23 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double24 = univariatePointValuePair23.getValue();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair27 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double28 = univariatePointValuePair27.getValue();
        boolean boolean29 = simpleUnivariateValueChecker19.converged(1, univariatePointValuePair23, univariatePointValuePair27);
        boolean boolean30 = simpleUnivariateValueChecker2.converged(0, univariatePointValuePair14, univariatePointValuePair27);
        double double31 = simpleUnivariateValueChecker2.getRelativeThreshold();
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker35 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 0, (double) 1);
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker39 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair43 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double44 = univariatePointValuePair43.getValue();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair47 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double48 = univariatePointValuePair47.getValue();
        boolean boolean49 = simpleUnivariateValueChecker39.converged(1, univariatePointValuePair43, univariatePointValuePair47);
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker52 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair56 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double57 = univariatePointValuePair56.getValue();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair60 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double61 = univariatePointValuePair60.getValue();
        boolean boolean62 = simpleUnivariateValueChecker52.converged(1, univariatePointValuePair56, univariatePointValuePair60);
        boolean boolean63 = simpleUnivariateValueChecker35.converged(0, univariatePointValuePair47, univariatePointValuePair60);
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker66 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker70 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair74 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double75 = univariatePointValuePair74.getValue();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair78 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double79 = univariatePointValuePair78.getValue();
        boolean boolean80 = simpleUnivariateValueChecker70.converged(1, univariatePointValuePair74, univariatePointValuePair78);
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker83 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair87 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double88 = univariatePointValuePair87.getValue();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair91 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double92 = univariatePointValuePair91.getValue();
        boolean boolean93 = simpleUnivariateValueChecker83.converged(1, univariatePointValuePair87, univariatePointValuePair91);
        boolean boolean94 = simpleUnivariateValueChecker66.converged(2147483647, univariatePointValuePair78, univariatePointValuePair87);
        boolean boolean95 = simpleUnivariateValueChecker2.converged(0, univariatePointValuePair47, univariatePointValuePair87);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 32.0d + "'", double11 == 32.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 32.0d + "'", double15 == 32.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 32.0d + "'", double24 == 32.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 32.0d + "'", double28 == 32.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 32.0d + "'", double44 == 32.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 32.0d + "'", double48 == 32.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 32.0d + "'", double57 == 32.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 32.0d + "'", double61 == 32.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 32.0d + "'", double75 == 32.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 32.0d + "'", double79 == 32.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 32.0d + "'", double88 == 32.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 32.0d + "'", double92 == 32.0d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException1 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { 4, 52, 2147483647, 97, 97 };
        java.lang.Integer[] intArray16 = new java.lang.Integer[] { 52, 100, 2147483647, 4, 100, 2147483647 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException17 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable3, intArray9, intArray16);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathArithmeticException1, localizable2, (java.lang.Object[]) intArray16);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException19 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 99.0d, (java.lang.Object[]) intArray16);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double[] doubleArray17 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray21 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition23 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray17, doubleArray21, (double) (byte) 10);
        double[] doubleArray24 = eigenDecomposition23.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex27 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray24);
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight29 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.012233790557032886d + "'", double28 == 0.012233790557032886d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double3 = bracketFinder2.getHi();
        double double4 = bracketFinder2.getLo();
        double double5 = bracketFinder2.getLo();
        double double6 = bracketFinder2.getFHi();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[][] doubleArray24 = array2DRowRealMatrix7.getData();
        try {
            array2DRowRealMatrix7.setEntry(1, (int) (byte) 10, 628.2788913603982d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        double[][] doubleArray46 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = array2DRowRealMatrix7.createMatrix((int) ' ', 4);
        double[] doubleArray56 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray56);
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector57.mapDivideToSelf((double) (-1L));
        boolean boolean60 = arrayRealVector57.isNaN();
        double[] doubleArray66 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray66);
        org.apache.commons.math3.linear.RealVector realVector69 = arrayRealVector67.mapDivideToSelf((double) (-1L));
        boolean boolean70 = arrayRealVector67.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc72 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = arrayRealVector67.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc72);
        double double74 = arrayRealVector57.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector67);
        org.apache.commons.math3.linear.RealVector realVector76 = arrayRealVector67.mapDivideToSelf((double) 1);
        double[] doubleArray77 = arrayRealVector67.getDataRef();
        double[] doubleArray83 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray84 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray83);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix85 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray84);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix86 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray84);
        double[] doubleArray88 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray84, 97);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds89 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray77, doubleArray84);
        double[] doubleArray90 = simpleBounds89.getUpper();
        double[] doubleArray91 = null;
        boolean boolean92 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray90, doubleArray91);
        try {
            array2DRowRealMatrix7.setRow(12, doubleArray90);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (12)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(arrayRealVector73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(realVector76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor11.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double19 = openMapRealMatrix10.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        int int20 = openMapRealMatrix10.getRowDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix21 = openMapRealMatrix7.subtract(openMapRealMatrix10);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor22 = null;
        try {
            double double27 = openMapRealMatrix21.walkInOptimizedOrder(realMatrixChangingVisitor22, (int) (byte) -1, 6, 247, 9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 97 + "'", int20 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix21);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        double[][] doubleArray46 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = array2DRowRealMatrix7.createMatrix((int) ' ', 4);
        try {
            double[] doubleArray51 = array2DRowRealMatrix7.getColumn((-1809524577));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,809,524,577)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix49);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        boolean boolean9 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix7, (double) (byte) 0);
        double[] doubleArray15 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray21 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray22 = new double[][] { doubleArray15, doubleArray21 };
        double[][] doubleArray23 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix25.copy();
        double[] doubleArray28 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray32 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition34 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray28, doubleArray32, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver35 = eigenDecomposition34.getSolver();
        double[] doubleArray36 = eigenDecomposition34.getImagEigenvalues();
        boolean boolean37 = array2DRowRealMatrix25.equals((java.lang.Object) eigenDecomposition34);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = array2DRowRealMatrix7.add(array2DRowRealMatrix25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x1 but expected 2x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(decompositionSolver35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(2.108154133718787E10d, 9);
        double double3 = bracketFinder2.getFMid();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        float float1 = mersenneTwister0.nextFloat();
//        boolean boolean2 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt((int) (short) 1);
//        int[] intArray6 = new int[] { 100 };
//        int[] intArray9 = new int[] { 100, 97 };
//        int int10 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray6, intArray9);
//        mersenneTwister0.setSeed(intArray6);
//        try {
//            int int13 = mersenneTwister0.nextInt((-381728948));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -381,728,948 is smaller than, or equal to, the minimum (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.11359978f + "'", float1 == 0.11359978f);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (-1555302186), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1555302186L) + "'", long2 == (-1555302186L));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        java.lang.String str2 = realMatrixFormat0.getPrefix();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix((int) '4');
        java.lang.StringBuffer stringBuffer5 = null;
        java.text.FieldPosition fieldPosition6 = null;
        try {
            java.lang.StringBuffer stringBuffer7 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, stringBuffer5, fieldPosition6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[" + "'", str2.equals("["));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor3.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double11 = openMapRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        double[] doubleArray14 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray18 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition20 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray14, doubleArray18, (double) (byte) 10);
        double[] doubleArray21 = eigenDecomposition20.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray21);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray29);
        double double33 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray29);
        double double34 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray21, doubleArray29);
        try {
            openMapRealMatrix2.setRow((int) (short) 100, doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.4142135623730951d + "'", double33 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.9877662094429671d + "'", double34 == 0.9877662094429671d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isSequence((double) (short) 0, 0.0d, 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        float[] floatArray0 = new float[] {};
        float[] floatArray1 = new float[] {};
        float[] floatArray2 = null;
        float[] floatArray3 = new float[] {};
        boolean boolean4 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray2, floatArray3);
        float[] floatArray5 = null;
        float[] floatArray6 = new float[] {};
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray5, floatArray6);
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray2, floatArray6);
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray1, floatArray2);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray0, floatArray2);
        float[] floatArray11 = null;
        float[] floatArray12 = new float[] {};
        boolean boolean13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray11, floatArray12);
        float[] floatArray14 = null;
        float[] floatArray15 = new float[] {};
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray14, floatArray15);
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray11, floatArray15);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray0, floatArray15);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        arrayRealVector6.set((double) (byte) 0);
        boolean boolean11 = arrayRealVector6.isNaN();
        boolean boolean12 = arrayRealVector6.isNaN();
        double[] doubleArray19 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        org.apache.commons.math3.optim.PointValuePair pointValuePair30 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) (byte) -1);
        boolean boolean32 = pointValuePair30.equals((java.lang.Object) 0);
        java.lang.Object obj33 = null;
        boolean boolean34 = pointValuePair30.equals(obj33);
        double[] doubleArray35 = pointValuePair30.getPoint();
        double[] doubleArray36 = pointValuePair30.getKey();
        boolean boolean37 = array2DRowRealMatrix21.equals((java.lang.Object) doubleArray36);
        int int38 = org.apache.commons.math3.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math3.optim.PointValuePair pointValuePair40 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, (double) 2147483647);
        arrayRealVector6.setSubVector((int) (short) 0, doubleArray36);
        double[] doubleArray45 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray45);
        double[] doubleArray49 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray53 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition55 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray49, doubleArray53, (double) (byte) 10);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray53);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition58 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray45, doubleArray56, (double) (byte) -1);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray36, doubleArray56);
        double[] doubleArray60 = pointVectorValuePair59.getPointRef();
        double[] doubleArray61 = pointVectorValuePair59.getFirst();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1809524577) + "'", int38 == (-1809524577));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double double2 = org.apache.commons.math3.util.FastMath.max(2.5108406941546723E58d, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.5108406941546723E58d + "'", double2 == 2.5108406941546723E58d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.NoDataException noDataException3 = new org.apache.commons.math3.exception.NoDataException(localizable2);
        java.lang.Throwable[] throwableArray4 = noDataException3.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, (java.lang.Object[]) throwableArray4);
        org.apache.commons.math3.exception.MathInternalError mathInternalError6 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded(0);
        org.junit.Assert.assertNotNull(simpleBounds1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 1, 0, 52, 10);
        int int5 = matrixDimensionMismatchException4.getExpectedRowDimension();
        int int6 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int7 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        int int8 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int10 = matrixDimensionMismatchException4.getExpectedDimension(1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) 0.39037895f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.62480313061505d + "'", double1 == 0.62480313061505d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector16.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector16.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector6.append(realVector22);
        double[] doubleArray29 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, false);
        double[] doubleArray37 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37);
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector38.mapDivideToSelf((double) (-1L));
        boolean boolean42 = arrayRealVector38.equals((java.lang.Object) 10);
        double double43 = arrayRealVector31.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        double[] doubleArray51 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51);
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector52.mapDivideToSelf((double) (-1L));
        boolean boolean56 = arrayRealVector52.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector52.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector52.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = arrayRealVector38.combine((double) (byte) 0, (double) (-1L), realVector60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector6.add(realVector60);
        try {
            arrayRealVector62.addToEntry(5, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 246.6779276708802d + "'", double43 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(arrayRealVector61);
        org.junit.Assert.assertNotNull(arrayRealVector62);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double double8 = arrayRealVector7.getMaxValue();
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector15.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc20 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc20);
        org.apache.commons.math3.analysis.function.Sinc sinc23 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector15.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc23);
        double double25 = arrayRealVector7.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector24.copy();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat27 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat28 = realVectorFormat27.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = realVectorFormat27.parse("{0; -0; 1; 1; 0}");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector24.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        int int32 = arrayRealVector30.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 252.05440211108893d + "'", double25 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(realVectorFormat27);
        org.junit.Assert.assertNotNull(numberFormat28);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 1, 0, 52, 10);
        int int5 = matrixDimensionMismatchException4.getExpectedRowDimension();
        int int6 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int8 = matrixDimensionMismatchException4.getWrongDimension((int) (short) 0);
        try {
            int int10 = matrixDimensionMismatchException4.getWrongDimension((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.copy();
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16);
        java.lang.Number number20 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException22 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number20, 97);
        int int23 = nonMonotonicSequenceException22.getIndex();
        java.lang.Number number24 = nonMonotonicSequenceException22.getPrevious();
        int int25 = nonMonotonicSequenceException22.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection26 = nonMonotonicSequenceException22.getDirection();
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray16, orderDirection26, false, false);
        double[] doubleArray30 = diagonalMatrix8.operate(doubleArray16);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix33 = diagonalMatrix8.createMatrix(0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 97 + "'", int23 == 97);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 97 + "'", int25 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 97, 0.22463548f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        float float1 = mersenneTwister0.nextFloat();
//        boolean boolean2 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt((int) (short) 1);
//        int[] intArray6 = new int[] { 100 };
//        int[] intArray9 = new int[] { 100, 97 };
//        int int10 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray6, intArray9);
//        mersenneTwister0.setSeed(intArray6);
//        double double12 = mersenneTwister0.nextGaussian();
//        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0069203377f + "'", float1 == 0.0069203377f);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.7650730050315234d + "'", double12 == 0.7650730050315234d);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7, 97);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.scale(1.4153232443518473d, doubleArray11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean22 = arrayRealVector19.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc24 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector19.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc24);
        org.apache.commons.math3.analysis.function.Sinc sinc27 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector19.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc27);
        double[] doubleArray30 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray34 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition36 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray30, doubleArray34, (double) (byte) 10);
        double[] doubleArray37 = eigenDecomposition36.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, doubleArray37);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, doubleArray37);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37);
        double[] doubleArray47 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray48 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray47);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray48);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = diagonalMatrix50.copy();
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = diagonalMatrix41.subtract(diagonalMatrix50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 5x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.28943395614624023d, 99.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.28943395614624023d + "'", double2 == 0.28943395614624023d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 10L, (double) (short) 1, 0.0d);
        int int4 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        int int5 = levenbergMarquardtOptimizer3.getMaxIterations();
        double[] doubleArray6 = levenbergMarquardtOptimizer3.getStartPoint();
        int int7 = levenbergMarquardtOptimizer3.getEvaluations();
        double[] doubleArray8 = levenbergMarquardtOptimizer3.getLowerBound();
        double[] doubleArray9 = levenbergMarquardtOptimizer3.getStartPoint();
        double[] doubleArray10 = levenbergMarquardtOptimizer3.getUpperBound();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(doubleArray8);
        org.junit.Assert.assertNull(doubleArray9);
        org.junit.Assert.assertNull(doubleArray10);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double3 = bracketFinder2.getHi();
        double double4 = bracketFinder2.getLo();
        double double5 = bracketFinder2.getLo();
        int int6 = bracketFinder2.getEvaluations();
        int int7 = bracketFinder2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        arrayRealVector6.set((double) (byte) 0);
        boolean boolean11 = arrayRealVector6.isNaN();
        boolean boolean12 = arrayRealVector6.isNaN();
        double[] doubleArray19 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        org.apache.commons.math3.optim.PointValuePair pointValuePair30 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) (byte) -1);
        boolean boolean32 = pointValuePair30.equals((java.lang.Object) 0);
        java.lang.Object obj33 = null;
        boolean boolean34 = pointValuePair30.equals(obj33);
        double[] doubleArray35 = pointValuePair30.getPoint();
        double[] doubleArray36 = pointValuePair30.getKey();
        boolean boolean37 = array2DRowRealMatrix21.equals((java.lang.Object) doubleArray36);
        int int38 = org.apache.commons.math3.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math3.optim.PointValuePair pointValuePair40 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, (double) 2147483647);
        arrayRealVector6.setSubVector((int) (short) 0, doubleArray36);
        double[] doubleArray45 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray45);
        double[] doubleArray49 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray53 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition55 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray49, doubleArray53, (double) (byte) 10);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray53);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition58 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray45, doubleArray56, (double) (byte) -1);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray36, doubleArray56);
        double[] doubleArray60 = pointVectorValuePair59.getPointRef();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix62 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray60, false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1809524577) + "'", int38 == (-1809524577));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        arrayRealVector6.set((double) (byte) 0);
        boolean boolean11 = arrayRealVector6.isNaN();
        boolean boolean12 = arrayRealVector6.isNaN();
        double[] doubleArray19 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        org.apache.commons.math3.optim.PointValuePair pointValuePair30 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) (byte) -1);
        boolean boolean32 = pointValuePair30.equals((java.lang.Object) 0);
        java.lang.Object obj33 = null;
        boolean boolean34 = pointValuePair30.equals(obj33);
        double[] doubleArray35 = pointValuePair30.getPoint();
        double[] doubleArray36 = pointValuePair30.getKey();
        boolean boolean37 = array2DRowRealMatrix21.equals((java.lang.Object) doubleArray36);
        int int38 = org.apache.commons.math3.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math3.optim.PointValuePair pointValuePair40 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, (double) 2147483647);
        arrayRealVector6.setSubVector((int) (short) 0, doubleArray36);
        double[] doubleArray45 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray45);
        double[] doubleArray49 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray53 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition55 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray49, doubleArray53, (double) (byte) 10);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray53);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition58 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray45, doubleArray56, (double) (byte) -1);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray36, doubleArray56);
        double[] doubleArray65 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray66 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray65);
        org.apache.commons.math3.optim.PointValuePair pointValuePair68 = new org.apache.commons.math3.optim.PointValuePair(doubleArray65, (double) (byte) -1);
        java.lang.Double double69 = pointValuePair68.getSecond();
        double[] doubleArray70 = pointValuePair68.getFirst();
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair71 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray56, doubleArray70);
        double[] doubleArray72 = pointVectorValuePair71.getKey();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma73 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: -10 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1809524577) + "'", int38 == (-1809524577));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + (-1.0d) + "'", double69.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance(18918.0d, (-0.0d), (double) 32.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        boolean boolean9 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix7, (double) (byte) 0);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double15 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor10, 16, (int) ' ', (-1023), (-1555302186));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (16)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) (byte) 1, 0.7262694092379458d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector16.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector16.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector6.append(realVector22);
        double[] doubleArray29 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.mapDivideToSelf((double) (-1L));
        boolean boolean33 = arrayRealVector30.isNaN();
        double[] doubleArray39 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.mapDivideToSelf((double) (-1L));
        boolean boolean43 = arrayRealVector40.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc45 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector40.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc45);
        double double47 = arrayRealVector30.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector40.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector6.append(arrayRealVector40);
        double double51 = arrayRealVector6.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector6.mapSubtractToSelf(2.718281828459045d);
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector6.append((double) 0.19685411f);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + (-97.0d) + "'", double51 == (-97.0d));
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(realVector55);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray1, doubleArray30, true);
        double[] doubleArray41 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) (short) 10, doubleArray42);
        double[] doubleArray49 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray49);
        boolean boolean51 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray42, doubleArray49);
        double[] doubleArray52 = org.apache.commons.math3.util.MathArrays.scale((double) 'a', doubleArray49);
        double[] doubleArray58 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray59 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray58);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition60 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray52, doubleArray59);
        double[] doubleArray66 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray67 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray66);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray67);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix69 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray67);
        double[] doubleArray75 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray75);
        org.apache.commons.math3.linear.RealVector realVector78 = arrayRealVector76.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector80 = arrayRealVector76.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector82 = arrayRealVector76.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector76, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray67, arrayRealVector84);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray59, doubleArray67);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition88 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray30, doubleArray59, (double) (-1.0f));
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertNotNull(realVector82);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 6);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.7683716E-7f + "'", float1 == 4.7683716E-7f);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double[] doubleArray0 = null;
        org.apache.commons.math3.optim.PointValuePair pointValuePair3 = new org.apache.commons.math3.optim.PointValuePair(doubleArray0, (double) 1, true);
        double[] doubleArray4 = pointValuePair3.getPointRef();
        java.lang.Double double5 = pointValuePair3.getValue();
        double[] doubleArray6 = pointValuePair3.getKey();
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5.equals(1.0d));
        org.junit.Assert.assertNull(doubleArray6);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(0, 9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        try {
            array2DRowRealMatrix7.multiplyEntry(10, 0, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 'a', (float) 6205813978047108984L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.2058141E18f + "'", float2 == 6.2058141E18f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(247, (int) (byte) 100);
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix(realMatrix2, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 52.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, (-1555302186), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1555302186");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        double[][] doubleArray46 = array2DRowRealMatrix7.getData();
        int int47 = array2DRowRealMatrix7.getRowDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor48 = null;
        try {
            double double53 = array2DRowRealMatrix7.walkInColumnOrder(realMatrixChangingVisitor48, (int) (byte) 10, 1678488564, 97, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 5 + "'", int47 == 5);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            boolean boolean2 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric(realMatrix0, (double) (-1809524577));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        arrayRealVector12.unitize();
        int int14 = arrayRealVector12.getMaxIndex();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1833.4649444186343d + "'", double1 == 1833.4649444186343d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) 0.0f);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("{{1}}", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        long long2 = org.apache.commons.math3.util.FastMath.min(0L, (long) 93);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        double[][] doubleArray46 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.RealVector realVector48 = null;
        try {
            array2DRowRealMatrix7.setColumnVector((int) (byte) 10, realVector48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double[] doubleArray6 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector7.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc12 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector7.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc12);
        org.apache.commons.math3.analysis.function.Sinc sinc15 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc15);
        double double18 = sinc15.value((double) 0.5105547f);
        double double21 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc15, 97.0d, 2.5108406941546723E58d);
        org.apache.commons.math3.analysis.solvers.BracketedUnivariateSolver<org.apache.commons.math3.analysis.UnivariateFunction> univariateFunctionBracketedUnivariateSolver22 = null;
        org.apache.commons.math3.analysis.solvers.AllowedSolution allowedSolution26 = null;
        try {
            double double27 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.forceSide(9, (org.apache.commons.math3.analysis.UnivariateFunction) sinc15, univariateFunctionBracketedUnivariateSolver22, 99.0d, 1.4142135623730951d, 22025.465794806718d, allowedSolution26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.957118376469154d + "'", double18 == 0.957118376469154d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.2554203470773362E58d + "'", double21 == 1.2554203470773362E58d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 2.3978952727983707d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        long[] longArray0 = new long[] {};
        long[][] longArray1 = new long[][] { longArray0 };
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray1);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertNotNull(longArray1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector16.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector16.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector6.append(realVector22);
        double[] doubleArray29 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.mapDivideToSelf((double) (-1L));
        boolean boolean33 = arrayRealVector30.isNaN();
        double[] doubleArray39 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.mapDivideToSelf((double) (-1L));
        boolean boolean43 = arrayRealVector40.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc45 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector40.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc45);
        double double47 = arrayRealVector30.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector40.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector6.append(arrayRealVector40);
        double double51 = arrayRealVector6.getMinValue();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor52 = null;
        try {
            double double53 = arrayRealVector6.walkInDefaultOrder(realVectorChangingVisitor52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + (-97.0d) + "'", double51 == (-97.0d));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) '4', 0.39037895f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double3 = bracketFinder2.getHi();
        double double4 = bracketFinder2.getLo();
        org.apache.commons.math3.analysis.function.Sinc sinc6 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder2.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc6, goalType7, (double) '4', (double) 'a');
        double[] doubleArray16 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) (-1L));
        double[] doubleArray25 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) (-1L));
        boolean boolean30 = arrayRealVector26.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector26.append((double) (short) 100);
        double double33 = arrayRealVector17.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        double[] doubleArray39 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.mapDivideToSelf((double) (-1L));
        boolean boolean43 = arrayRealVector40.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc45 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector40.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc45);
        org.apache.commons.math3.analysis.function.Sinc sinc48 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector40.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector26.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc48);
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder53 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double54 = bracketFinder53.getHi();
        double double55 = bracketFinder53.getLo();
        org.apache.commons.math3.analysis.function.Sinc sinc57 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType58 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder53.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc57, goalType58, (double) '4', (double) 'a');
        bracketFinder2.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc48, goalType58, (double) 100, 0.0d);
        boolean boolean67 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc48, (double) 0.3820138f, 0.0d);
        org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure68 = null;
        try {
            org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure69 = sinc48.value(derivativeStructure68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType7 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType7.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 18918.0d + "'", double33 == 18918.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType58 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType58.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double2 = org.apache.commons.math3.util.FastMath.pow(100.0d, 1.4955572211091983E-4d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0006889667812664d + "'", double2 == 1.0006889667812664d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) '4', (double) 10L, pointValuePairConvergenceChecker2);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType4 = powellOptimizer3.getGoalType();
        org.junit.Assert.assertNull(goalType4);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector6.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector6.unitVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.copy();
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean23 = arrayRealVector19.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.append((double) (short) 100);
        double double26 = arrayRealVector12.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double[] doubleArray32 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, false);
        double double35 = arrayRealVector34.getMaxValue();
        double[] doubleArray41 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.mapDivideToSelf((double) (-1L));
        boolean boolean45 = arrayRealVector42.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc47 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector42.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc47);
        org.apache.commons.math3.analysis.function.Sinc sinc50 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector42.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc50);
        double double52 = arrayRealVector34.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector12.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector34.mapMultiplyToSelf(91.72376348103771d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.0d + "'", double35 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 252.05440211108893d + "'", double52 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector53);
        org.junit.Assert.assertNotNull(realVector55);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection0 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.junit.Assert.assertTrue("'" + orderDirection0 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection0.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp(0.5105547f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.51055473f + "'", float1 == 0.51055473f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { (byte) 10 };
        double[] doubleArray8 = new double[] { (byte) 10 };
        double[][] doubleArray9 = new double[][] { doubleArray6, doubleArray8 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9, false);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, 0.0d, 3.141592653589793d, (double) 97, (double) 247, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = noBracketingException12.getContext();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(exceptionContext13);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((long) (byte) 1);
        mersenneTwister1.setSeed((long) 'a');
        double double4 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5288560945221015d + "'", double4 == 0.5288560945221015d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 32, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix7);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor13 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor13.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double21 = openMapRealMatrix12.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor13);
        int int22 = openMapRealMatrix12.getRowDimension();
        try {
            openMapRealMatrix7.setRowMatrix(1678488564, (org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,678,488,564)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 97 + "'", int22 == 97);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix15.copy();
        double[] doubleArray18 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray22 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray18, doubleArray22, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver25 = eigenDecomposition24.getSolver();
        double[] doubleArray26 = eigenDecomposition24.getImagEigenvalues();
        boolean boolean27 = array2DRowRealMatrix15.equals((java.lang.Object) eigenDecomposition24);
        double double28 = eigenDecomposition24.getDeterminant();
        try {
            double double30 = eigenDecomposition24.getRealEigenvalue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(decompositionSolver25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-0.012233790557032886d) + "'", double28 == (-0.012233790557032886d));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(1.2554203470773362E58d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.787593149816328E42d + "'", double1 == 2.787593149816328E42d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double3 = bracketFinder2.getHi();
        double double4 = bracketFinder2.getLo();
        int int5 = bracketFinder2.getEvaluations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 1678488564);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.678488564E9d + "'", double1 == 1.678488564E9d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        boolean boolean10 = pointValuePair8.equals((java.lang.Object) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = pointValuePair8.equals(obj11);
        double[] doubleArray13 = pointValuePair8.getPoint();
        double[] doubleArray14 = pointValuePair8.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(6.5481924191803085d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.548192419180309d + "'", double1 == 6.548192419180309d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        boolean boolean9 = eigenDecomposition7.hasComplexEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = eigenDecomposition7.getVT();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.blockInverse(realMatrix10, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix15.copy();
        double double17 = array2DRowRealMatrix15.getNorm();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 200.0d + "'", double17 == 200.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isSequence(18918.0d, (double) 6205813978047108984L, (double) 0.013082147f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 97, (java.lang.Number) 3.748066027288565E7d, (java.lang.Number) 0.957118376469154d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(93, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double[] doubleArray13 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector14.equals((java.lang.Object) 10);
        double double19 = arrayRealVector7.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double[] doubleArray27 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapDivideToSelf((double) (-1L));
        boolean boolean32 = arrayRealVector28.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector28.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector28.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector14.combine((double) (byte) 0, (double) (-1L), realVector36);
        double double38 = arrayRealVector14.getNorm();
        boolean boolean39 = arrayRealVector14.isInfinite();
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector14.mapSubtractToSelf((-0.012233790557032886d));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 246.6779276708802d + "'", double19 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 137.5427206361718d + "'", double38 == 137.5427206361718d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(realVector41);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector15.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.append((double) (short) 100);
        double double22 = arrayRealVector6.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        double[] doubleArray28 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapDivideToSelf((double) (-1L));
        boolean boolean32 = arrayRealVector29.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc34 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector29.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc34);
        org.apache.commons.math3.analysis.function.Sinc sinc37 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector29.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc37);
        double double40 = arrayRealVector39.getMaxValue();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 18918.0d + "'", double22 == 18918.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double double8 = arrayRealVector7.getMaxValue();
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector15.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc20 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc20);
        org.apache.commons.math3.analysis.function.Sinc sinc23 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector15.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc23);
        double double25 = arrayRealVector7.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        double double27 = arrayRealVector7.getEntry(0);
        double double28 = arrayRealVector7.getL1Norm();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 252.05440211108893d + "'", double25 == 252.05440211108893d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 254.0d + "'", double28 == 254.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((-1809524577), (int) '#', (double) 52.0f);
        double double4 = nonSymmetricMatrixException3.getThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = realVectorFormat3.parse("[-0.0122337906]");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"[-0.0122337906]\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 0.0f, 2.5108406941546723E58d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        double[][] doubleArray46 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = array2DRowRealMatrix7.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = array2DRowRealMatrix7.getColumnMatrix((int) (short) 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        double[] doubleArray3 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray7 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray3, doubleArray7, (double) (byte) 10);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = eigenDecomposition9.getVT();
        java.lang.String str12 = realMatrixFormat0.format(realMatrix11);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix14 = realMatrixFormat0.parse("; ");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"; \" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.Array2DRowRealMatrix");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "{{1}}" + "'", str12.equals("{{1}}"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex8 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(0, (double) 99);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.536743E-7f + "'", float1 == 9.536743E-7f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double[] doubleArray13 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector14.equals((java.lang.Object) 10);
        double double19 = arrayRealVector7.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double[] doubleArray27 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapDivideToSelf((double) (-1L));
        boolean boolean32 = arrayRealVector28.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector28.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector28.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector14.combine((double) (byte) 0, (double) (-1L), realVector36);
        double[] doubleArray39 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray43 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition45 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray39, doubleArray43, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight46 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray39);
        org.apache.commons.math3.optim.PointValuePair pointValuePair49 = new org.apache.commons.math3.optim.PointValuePair(doubleArray39, 3.831008000716577E22d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 246.6779276708802d + "'", double19 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor10.start(0, 247, 1, (int) (short) -1, 0, 0);
        double double18 = defaultRealMatrixPreservingVisitor10.end();
        try {
            double double23 = diagonalMatrix8.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10, 6, 1, (-381728948), 9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, 0, (-1), 16, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0f, (float) 3, (float) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (byte) 10, 0.38108765337432393d, (double) (short) -1, (double) 0.5105547f, 0.0d, (double) (-1.55530214E9f));
        double[] doubleArray12 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapDivideToSelf((double) (-1L));
        boolean boolean16 = arrayRealVector13.isNaN();
        double[] doubleArray22 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) (-1L));
        boolean boolean26 = arrayRealVector23.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc28 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector23.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc28);
        double double30 = arrayRealVector13.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector23.mapDivideToSelf((double) 1);
        double[] doubleArray33 = arrayRealVector23.getDataRef();
        double[] doubleArray39 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray40);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40, 97);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds45 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray33, doubleArray40);
        double[] doubleArray46 = simpleBounds45.getLower();
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray46);
        try {
            nelderMeadSimplex6.build(doubleArray46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix47);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) 0.22463548f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 0, (double) 1);
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker6 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair10 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double11 = univariatePointValuePair10.getValue();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair14 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double15 = univariatePointValuePair14.getValue();
        boolean boolean16 = simpleUnivariateValueChecker6.converged(1, univariatePointValuePair10, univariatePointValuePair14);
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker19 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair23 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double24 = univariatePointValuePair23.getValue();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair27 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double28 = univariatePointValuePair27.getValue();
        boolean boolean29 = simpleUnivariateValueChecker19.converged(1, univariatePointValuePair23, univariatePointValuePair27);
        boolean boolean30 = simpleUnivariateValueChecker2.converged(0, univariatePointValuePair14, univariatePointValuePair27);
        double double31 = simpleUnivariateValueChecker2.getAbsoluteThreshold();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair35 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker38 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker42 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair46 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double47 = univariatePointValuePair46.getValue();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair50 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double51 = univariatePointValuePair50.getValue();
        boolean boolean52 = simpleUnivariateValueChecker42.converged(1, univariatePointValuePair46, univariatePointValuePair50);
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker55 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair59 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double60 = univariatePointValuePair59.getValue();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair63 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 1.0f, (double) ' ');
        double double64 = univariatePointValuePair63.getValue();
        boolean boolean65 = simpleUnivariateValueChecker55.converged(1, univariatePointValuePair59, univariatePointValuePair63);
        boolean boolean66 = simpleUnivariateValueChecker38.converged(2147483647, univariatePointValuePair50, univariatePointValuePair59);
        boolean boolean67 = simpleUnivariateValueChecker2.converged(0, univariatePointValuePair35, univariatePointValuePair50);
        double double68 = univariatePointValuePair50.getValue();
        double double69 = univariatePointValuePair50.getPoint();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 32.0d + "'", double11 == 32.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 32.0d + "'", double15 == 32.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 32.0d + "'", double24 == 32.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 32.0d + "'", double28 == 32.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 32.0d + "'", double47 == 32.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 32.0d + "'", double51 == 32.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 32.0d + "'", double60 == 32.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 32.0d + "'", double64 == 32.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 32.0d + "'", double68 == 32.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.lang.String str1 = realVectorFormat0.getPrefix();
        java.text.NumberFormat numberFormat2 = realVectorFormat0.getFormat();
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver8 = eigenDecomposition7.getSolver();
        try {
            double double10 = eigenDecomposition7.getRealEigenvalue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(decompositionSolver8);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.4153232443518473d, (double) Float.NaN, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        int int6 = brentOptimizer5.getIterations();
        int int7 = brentOptimizer5.getMaxIterations();
        int int8 = brentOptimizer5.getEvaluations();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix7.createMatrix(35, (int) (byte) 100);
        int int27 = array2DRowRealMatrix7.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        int int0 = org.apache.commons.math3.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean23 = arrayRealVector19.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.append((double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double[] doubleArray32 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.mapDivideToSelf((double) (-1L));
        boolean boolean37 = arrayRealVector33.equals((java.lang.Object) 10);
        double double38 = arrayRealVector12.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        double double39 = arrayRealVector12.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector12.mapMultiply(0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-7.175711493801343E-17d) + "'", double38 == (-7.175711493801343E-17d));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(realVector41);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        float[] floatArray0 = null;
        float[] floatArray1 = new float[] {};
        float[] floatArray2 = new float[] {};
        float[] floatArray3 = null;
        float[] floatArray4 = new float[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray3, floatArray4);
        float[] floatArray6 = null;
        float[] floatArray7 = new float[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray6, floatArray7);
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray3, floatArray7);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray2, floatArray3);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray1, floatArray3);
        boolean boolean12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray0, floatArray3);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math3.util.FastMath.atan(3.8146972656435034E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8146972656249996E-6d + "'", double1 == 3.8146972656249996E-6d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double[] doubleArray17 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray21 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition23 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray17, doubleArray21, (double) (byte) 10);
        double[] doubleArray24 = eigenDecomposition23.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray24);
        boolean boolean28 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric(realMatrix26, (double) 10.0f);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition29 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix26);
        double double30 = lUDecomposition29.getDeterminant();
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = lUDecomposition29.getP();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-0.012233790557032886d) + "'", double30 == (-0.012233790557032886d));
        org.junit.Assert.assertNotNull(realMatrix31);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException(localizable6, (java.lang.Number) (-0.012233790557032886d), (java.lang.Number) (-1L), (java.lang.Number) 1L);
        java.lang.Throwable[] throwableArray11 = outOfRangeException10.getSuppressed();
        org.apache.commons.math3.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math3.exception.NoBracketingException(localizable1, (double) 9, (double) 0.3820138f, 0.0d, 0.0d, (java.lang.Object[]) throwableArray11);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException13 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        boolean boolean10 = pointValuePair8.equals((java.lang.Object) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = pointValuePair8.equals(obj11);
        double[] doubleArray13 = pointValuePair8.getPoint();
        double[] doubleArray14 = pointValuePair8.getKey();
        double[] doubleArray15 = pointValuePair8.getPoint();
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = eigenDecomposition7.getVT();
        double[] doubleArray10 = eigenDecomposition7.getImagEigenvalues();
        try {
            double double12 = eigenDecomposition7.getRealEigenvalue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double1 = org.apache.commons.math3.util.FastMath.log10(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.342925101645957d + "'", double1 == 4.342925101645957d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((double) 0.094331026f, (double) 1.0f);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor11.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double19 = openMapRealMatrix10.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        int int20 = openMapRealMatrix10.getRowDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix21 = openMapRealMatrix7.subtract(openMapRealMatrix10);
        double[] doubleArray23 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray27 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition29 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray23, doubleArray27, (double) (byte) 10);
        double[] doubleArray30 = eigenDecomposition29.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray30);
        double[] doubleArray33 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray37 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition39 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray33, doubleArray37, (double) (byte) 10);
        double[] doubleArray40 = eigenDecomposition39.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray40);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix31, (org.apache.commons.math3.linear.AnyMatrix) realMatrix41);
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix43 = openMapRealMatrix21.subtract(realMatrix31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 97x52 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 97 + "'", int20 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix41);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector16.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        double double23 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector16.copy();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector16.getSubVector((int) (byte) 1, (int) (short) 1);
        double[] doubleArray33 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector34.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector34.mapAdd((double) 0.0f);
        double[] doubleArray44 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray44);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector45.mapDivideToSelf((double) (-1L));
        boolean boolean48 = arrayRealVector45.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc50 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector45.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc50);
        double[] doubleArray57 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray57);
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector58.mapDivideToSelf((double) (-1L));
        boolean boolean62 = arrayRealVector58.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector64 = arrayRealVector58.append((double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = arrayRealVector51.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = arrayRealVector34.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = arrayRealVector16.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix70 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix70.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix75 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix70);
        org.apache.commons.math3.linear.RealVector realVector77 = openMapRealMatrix75.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.RealVector realVector78 = arrayRealVector16.append(realVector77);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertNotNull(arrayRealVector65);
        org.junit.Assert.assertNotNull(arrayRealVector66);
        org.junit.Assert.assertNotNull(arrayRealVector67);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertNotNull(realVector78);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray21 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) -1);
        boolean boolean26 = pointValuePair24.equals((java.lang.Object) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = pointValuePair24.equals(obj27);
        double[] doubleArray29 = pointValuePair24.getPoint();
        double[] doubleArray30 = pointValuePair24.getKey();
        boolean boolean31 = array2DRowRealMatrix15.equals((java.lang.Object) doubleArray30);
        double[] doubleArray33 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray37 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition39 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray33, doubleArray37, (double) (byte) 10);
        double[] doubleArray40 = eigenDecomposition39.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray40);
        double[] doubleArray43 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray47 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray43, doubleArray47, (double) (byte) 10);
        double[] doubleArray50 = eigenDecomposition49.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray50);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix41, (org.apache.commons.math3.linear.AnyMatrix) realMatrix51);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = array2DRowRealMatrix15.multiply(realMatrix41);
        double[][] doubleArray54 = array2DRowRealMatrix15.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = array2DRowRealMatrix15.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = array2DRowRealMatrix7.add(array2DRowRealMatrix15);
        org.apache.commons.math3.exception.util.Localizable localizable59 = null;
        double[] doubleArray65 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray66 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix68 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray66);
        org.apache.commons.math3.linear.RealMatrix realMatrix69 = diagonalMatrix68.copy();
        double[][] doubleArray70 = diagonalMatrix68.getData();
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException71 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable59, (java.lang.Object[]) doubleArray70);
        try {
            array2DRowRealMatrix7.setSubMatrix(doubleArray70, 4, 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (3)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertNotNull(doubleArray70);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight32 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        double[] doubleArray33 = array2DRowRealMatrix7.operate(doubleArray25);
        double[] doubleArray39 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray40);
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = diagonalMatrix42.copy();
        double[][] doubleArray44 = diagonalMatrix42.getData();
        double[] doubleArray45 = diagonalMatrix42.getDataRef();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix48 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor49 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor49.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double57 = openMapRealMatrix48.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor49);
        double double58 = diagonalMatrix42.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor49);
        try {
            double double63 = array2DRowRealMatrix7.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor49, (int) ' ', 35, (-1023), 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((-0.8414709848078965d), pointVectorValuePairConvergenceChecker1, (double) 52, (double) 0.0f, 2.3978952727983707d, 2.3978952727983707d);
        int int7 = levenbergMarquardtOptimizer6.getMaxEvaluations();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = levenbergMarquardtOptimizer6.getWeightSquareRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double double8 = arrayRealVector7.getMaxValue();
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector15.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc20 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc20);
        org.apache.commons.math3.analysis.function.Sinc sinc23 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector15.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc23);
        double double25 = arrayRealVector7.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector24.copy();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat27 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat28 = realVectorFormat27.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = realVectorFormat27.parse("{0; -0; 1; 1; 0}");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector24.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 0.57984495f);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 252.05440211108893d + "'", double25 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(realVectorFormat27);
        org.junit.Assert.assertNotNull(numberFormat28);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(realVector33);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 0);
        boolean boolean2 = incrementor1.canIncrement();
        int int3 = incrementor1.getMaximalCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        double[][] doubleArray10 = diagonalMatrix9.getData();
        double[][] doubleArray11 = diagonalMatrix9.getData();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix14 = diagonalMatrix9.createMatrix((int) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: -1 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor16 = null;
        try {
            double double21 = array2DRowRealMatrix15.walkInRowOrder(realMatrixChangingVisitor16, 1378221360, (int) (short) 10, 1678488564, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,378,221,360)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix7.createMatrix(35, (int) (byte) 100);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (int) (byte) 100, (int) 'a', 3, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula2 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker3 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver6 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula2, pointValuePairConvergenceChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver6);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver6);
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        double double13 = brentSolver6.solve(52, (org.apache.commons.math3.analysis.UnivariateFunction) sinc11, 6.691673596021348E41d);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction15 = null;
        try {
            double double19 = brentSolver6.solve(0, univariateFunction15, (double) (byte) 0, (double) (-1555302186L), (double) 0.013082147f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 6.691673596021348E41d + "'", double13 == 6.691673596021348E41d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 6, (-7.175711493801343E-17d), 1378221360);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(22026.0d, (double) (-1555302186L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22025.999999999996d + "'", double2 == 22025.999999999996d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix2.add(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix13.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix13);
        org.apache.commons.math3.linear.RealVector realVector20 = openMapRealMatrix18.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix21 = openMapRealMatrix2.subtract(openMapRealMatrix18);
        double[] doubleArray29 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30);
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, 97);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.scale(1.4153232443518473d, doubleArray34);
        try {
            openMapRealMatrix21.setColumn((-1809524577), doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,809,524,577)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(openMapRealMatrix21);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(93);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker(2.108154133718787E10d, 0.9075712110370514d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector16.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        double double23 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector16.mapAdd((double) (short) 1);
        double[] doubleArray31 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector32.mapDivideToSelf((double) (-1L));
        boolean boolean35 = arrayRealVector32.isNaN();
        double[] doubleArray41 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector42.mapAdd((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector48 = arrayRealVector42.mapMultiplyToSelf(0.0d);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector32.append(realVector48);
        double[] doubleArray55 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray55);
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector56.mapDivideToSelf((double) (-1L));
        boolean boolean59 = arrayRealVector56.isNaN();
        double[] doubleArray65 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray65);
        org.apache.commons.math3.linear.RealVector realVector68 = arrayRealVector66.mapDivideToSelf((double) (-1L));
        boolean boolean69 = arrayRealVector66.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc71 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = arrayRealVector66.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc71);
        double double73 = arrayRealVector56.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector66);
        org.apache.commons.math3.linear.RealVector realVector75 = arrayRealVector66.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = arrayRealVector32.append(arrayRealVector66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = arrayRealVector16.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector66);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor78 = null;
        try {
            double double81 = arrayRealVector77.walkInDefaultOrder(realVectorPreservingVisitor78, (int) (byte) 100, 4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(arrayRealVector72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(realVector75);
        org.junit.Assert.assertNotNull(arrayRealVector76);
        org.junit.Assert.assertNotNull(arrayRealVector77);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.copy();
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16);
        java.lang.Number number20 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException22 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number20, 97);
        int int23 = nonMonotonicSequenceException22.getIndex();
        java.lang.Number number24 = nonMonotonicSequenceException22.getPrevious();
        int int25 = nonMonotonicSequenceException22.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection26 = nonMonotonicSequenceException22.getDirection();
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray16, orderDirection26, false, false);
        double[] doubleArray30 = diagonalMatrix8.operate(doubleArray16);
        double[] doubleArray36 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36);
        org.apache.commons.math3.optim.PointValuePair pointValuePair39 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, (double) (byte) -1);
        java.lang.Double double40 = pointValuePair39.getSecond();
        java.lang.Double double41 = pointValuePair39.getValue();
        double[] doubleArray42 = pointValuePair39.getKey();
        double[] doubleArray48 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray49 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray48);
        double double50 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray42, doubleArray48);
        java.lang.Number number52 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException54 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number52, 97);
        int int55 = nonMonotonicSequenceException54.getIndex();
        java.lang.Number number56 = nonMonotonicSequenceException54.getPrevious();
        int int57 = nonMonotonicSequenceException54.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection58 = nonMonotonicSequenceException54.getDirection();
        boolean boolean60 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray42, orderDirection58, false);
        double double61 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray30, doubleArray42);
        double[] doubleArray63 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray67 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition69 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray63, doubleArray67, (double) (byte) 10);
        double[] doubleArray75 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray75);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix77 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray76);
        double[] doubleArray83 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray84 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray83);
        org.apache.commons.math3.optim.PointValuePair pointValuePair86 = new org.apache.commons.math3.optim.PointValuePair(doubleArray83, (double) (byte) -1);
        boolean boolean88 = pointValuePair86.equals((java.lang.Object) 0);
        java.lang.Object obj89 = null;
        boolean boolean90 = pointValuePair86.equals(obj89);
        double[] doubleArray91 = pointValuePair86.getPoint();
        double[] doubleArray92 = pointValuePair86.getKey();
        boolean boolean93 = array2DRowRealMatrix77.equals((java.lang.Object) doubleArray92);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair95 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray63, doubleArray92, true);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition96 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray42, doubleArray63);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 97 + "'", int23 == 97);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 97 + "'", int25 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + (-1.0d) + "'", double40.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-1.0d) + "'", double41.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 97 + "'", int55 == 97);
        org.junit.Assert.assertNull(number56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 97 + "'", int57 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection58.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 90.0d + "'", double61 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { (byte) 10 };
        double[] doubleArray8 = new double[] { (byte) 10 };
        double[][] doubleArray9 = new double[][] { doubleArray6, doubleArray8 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9, false);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, 0.0d, 3.141592653589793d, (double) 97, (double) 247, (java.lang.Object[]) doubleArray9);
        double double13 = noBracketingException12.getLo();
        double double14 = noBracketingException12.getFHi();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 247.0d + "'", double14 == 247.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor11.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double19 = openMapRealMatrix10.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        int int20 = openMapRealMatrix10.getRowDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix21 = openMapRealMatrix7.subtract(openMapRealMatrix10);
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix7.createMatrix(97, 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 208,305,913,759 is larger than, or equal to, the maximum (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 97 + "'", int20 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix21);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.copy();
        double[][] doubleArray10 = diagonalMatrix8.getData();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor11.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double19 = defaultRealMatrixPreservingVisitor11.end();
        double double20 = diagonalMatrix8.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        defaultRealMatrixPreservingVisitor11.visit(0, 1378221360, 1.7763568394002505E-15d);
        defaultRealMatrixPreservingVisitor11.start(0, 97, (int) (byte) 100, (-1809524577), (int) '4', 12);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double[] doubleArray17 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray21 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition23 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray17, doubleArray21, (double) (byte) 10);
        double[] doubleArray24 = eigenDecomposition23.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray24);
        double double26 = arrayRealVector25.getNorm();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor27 = null;
        try {
            double double30 = arrayRealVector25.walkInDefaultOrder(realVectorChangingVisitor27, (int) (byte) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.4153232443518473d + "'", double26 == 1.4153232443518473d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.copy();
        double[][] doubleArray10 = diagonalMatrix8.getData();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor11.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double19 = defaultRealMatrixPreservingVisitor11.end();
        double double20 = diagonalMatrix8.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix23 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor24 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor24.start((int) (byte) 0, 10, 1, 2147483647, 1, (int) (byte) 1);
        double double32 = openMapRealMatrix23.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        int int33 = openMapRealMatrix23.getRowDimension();
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix23, 0);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = openMapRealMatrix23.transpose();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix37 = diagonalMatrix8.multiply((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 97");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 97 + "'", int33 == 97);
        org.junit.Assert.assertNotNull(realMatrix36);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        double[] doubleArray16 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) (short) 10, doubleArray17);
        double[] doubleArray24 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray17, doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        org.apache.commons.math3.util.MathArrays.scaleInPlace(0.9836065573770492d, doubleArray24);
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray8, doubleArray24);
        double[][] doubleArray30 = null;
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray8, doubleArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double[] doubleArray2 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray6 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray2, doubleArray6, (double) (byte) 10);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray6);
        double[] doubleArray15 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray21 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray22 = new double[][] { doubleArray15, doubleArray21 };
        double[][] doubleArray23 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix25.copy();
        double[] doubleArray28 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray32 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition34 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray28, doubleArray32, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver35 = eigenDecomposition34.getSolver();
        double[] doubleArray36 = eigenDecomposition34.getImagEigenvalues();
        boolean boolean37 = array2DRowRealMatrix25.equals((java.lang.Object) eigenDecomposition34);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = eigenDecomposition34.getD();
        double[] doubleArray39 = eigenDecomposition34.getImagEigenvalues();
        org.apache.commons.math3.optim.SimpleBounds simpleBounds40 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray9, doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(decompositionSolver35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test396");
//        org.apache.commons.math3.optim.MaxEval maxEval6 = new org.apache.commons.math3.optim.MaxEval((int) '#');
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister();
//        float float8 = mersenneTwister7.nextFloat();
//        boolean boolean9 = mersenneTwister7.nextBoolean();
//        org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator> maxEvalPair10 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator>(maxEval6, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7);
//        int int12 = mersenneTwister7.nextInt((int) (byte) 100);
//        int int13 = mersenneTwister7.nextInt();
//        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker17 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 0L, 0.8414709848078965d);
//        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (-0.0d), true, (-1555302186), 100, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker17);
//        double[] doubleArray20 = null;
//        org.apache.commons.math3.optim.PointValuePair pointValuePair23 = new org.apache.commons.math3.optim.PointValuePair(doubleArray20, (double) 1, true);
//        double[] doubleArray24 = pointValuePair23.getPointRef();
//        java.lang.Double double25 = pointValuePair23.getValue();
//        double[] doubleArray31 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
//        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray31);
//        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray31, (double) (byte) -1);
//        java.lang.Double double35 = pointValuePair34.getSecond();
//        java.lang.Double double36 = pointValuePair34.getValue();
//        double[] doubleArray37 = pointValuePair34.getKey();
//        boolean boolean38 = simpleValueChecker17.converged(247, pointValuePair23, pointValuePair34);
//        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.34361863f + "'", float8 == 0.34361863f);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 74 + "'", int12 == 74);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1773261632) + "'", int13 == (-1773261632));
//        org.junit.Assert.assertNull(doubleArray24);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25.equals(1.0d));
//        org.junit.Assert.assertNotNull(doubleArray31);
//        org.junit.Assert.assertNotNull(doubleArray32);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-1.0d) + "'", double35.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-1.0d) + "'", double36.equals((-1.0d)));
//        org.junit.Assert.assertNotNull(doubleArray37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector16.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        double double23 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector16.mapDivideToSelf((double) 1);
        double[] doubleArray26 = arrayRealVector16.getDataRef();
        double[] doubleArray32 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray33, 97);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds38 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray26, doubleArray33);
        double[] doubleArray39 = simpleBounds38.getUpper();
        double[] doubleArray40 = simpleBounds38.getLower();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        boolean boolean16 = array2DRowRealMatrix15.isSquare();
        double double17 = array2DRowRealMatrix15.getFrobeniusNorm();
        try {
            array2DRowRealMatrix15.addToEntry(0, (int) (short) 100, (-0.8414709848078965d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 200.50935140287098d + "'", double17 == 200.50935140287098d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix2.add(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix13.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix13);
        org.apache.commons.math3.linear.RealVector realVector20 = openMapRealMatrix18.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix21 = openMapRealMatrix2.subtract(openMapRealMatrix18);
        double[] doubleArray27 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28);
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = diagonalMatrix30.copy();
        double[][] doubleArray32 = diagonalMatrix30.getData();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix18, (org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 52 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(openMapRealMatrix21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double double2 = org.apache.commons.math3.util.Precision.round((double) '#', 74);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double[] doubleArray1 = new double[] { (byte) 10 };
        double[] doubleArray3 = new double[] { (byte) 10 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4, true);
        int int10 = array2DRowRealMatrix9.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math3.random.MersenneTwister();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker10 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(1378221360, 0.0d, true, 1378221360, 4, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister5, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker10);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker10);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray13 = new org.apache.commons.math3.optim.OptimizationData[] {};
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair14 = simplexOptimizer12.optimize(optimizationDataArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(optimizationDataArray13);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray15 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition17 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray11, doubleArray15, (double) (byte) 10);
        double[] doubleArray18 = eigenDecomposition17.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix9, (org.apache.commons.math3.linear.AnyMatrix) realMatrix19);
        boolean boolean22 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric(realMatrix19, (double) 100);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition23 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix19);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix19, (double) 0.39037895f);
        int[] intArray26 = null;
        int[] intArray28 = new int[] { 100 };
        int[] intArray31 = new int[] { 100, 97 };
        int int32 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray28, intArray31);
        int[] intArray38 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
        int[] intArray44 = new int[] { 97, 1, 100, (byte) 100, 52 };
        int int45 = org.apache.commons.math3.util.MathArrays.distance1(intArray38, intArray44);
        double double46 = org.apache.commons.math3.util.MathArrays.distance(intArray28, intArray38);
        int[] intArray48 = new int[] { 100 };
        int[] intArray51 = new int[] { 100, 97 };
        int int52 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray48, intArray51);
        int[] intArray58 = new int[] { (short) 1, (short) -1, (-1), 52, 52 };
        int[] intArray64 = new int[] { 97, 1, 100, (byte) 100, 52 };
        int int65 = org.apache.commons.math3.util.MathArrays.distance1(intArray58, intArray64);
        double double66 = org.apache.commons.math3.util.MathArrays.distance(intArray48, intArray58);
        double double67 = org.apache.commons.math3.util.MathArrays.distance(intArray28, intArray48);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix19, intArray26, intArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 247 + "'", int45 == 247);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 99.0d + "'", double46 == 99.0d);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 247 + "'", int65 == 247);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 99.0d + "'", double66 == 99.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula4 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker8 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer9 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula4, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker8);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (short) 1, 246.6779276708802d, 0.0d, (double) (-0.0f), (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker8);
        double double11 = simpleValueChecker8.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double[] doubleArray17 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray21 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition23 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray17, doubleArray21, (double) (byte) 10);
        double[] doubleArray24 = eigenDecomposition23.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex27 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray24);
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray24);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.012233790557032886d + "'", double28 == 0.012233790557032886d);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7, 97);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.scale(1.4153232443518473d, doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) (byte) 10);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowPrefix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double[] doubleArray6 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        double[] doubleArray14 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14);
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, (double) (byte) -1);
        boolean boolean19 = pointValuePair17.equals((java.lang.Object) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = pointValuePair17.equals(obj20);
        double[] doubleArray22 = pointValuePair17.getPoint();
        double[] doubleArray23 = pointValuePair17.getKey();
        boolean boolean24 = array2DRowRealMatrix8.equals((java.lang.Object) doubleArray23);
        org.apache.commons.math3.util.MathArrays.scaleInPlace(2.108154133718787E10d, doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.apache.commons.math3.optim.MaxIter maxIter1 = new org.apache.commons.math3.optim.MaxIter(3);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat8 = realMatrixFormat7.getFormat();
        java.lang.String str9 = realMatrixFormat7.getRowSeparator();
        double[] doubleArray11 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray15 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition17 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray11, doubleArray15, (double) (byte) 10);
        double[] doubleArray18 = eigenDecomposition17.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray25 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition27 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray21, doubleArray25, (double) (byte) 10);
        double[] doubleArray28 = eigenDecomposition27.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray28);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix19, (org.apache.commons.math3.linear.AnyMatrix) realMatrix29);
        java.lang.String str31 = realMatrixFormat7.format(realMatrix29);
        java.text.NumberFormat numberFormat32 = realMatrixFormat7.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat33 = new org.apache.commons.math3.linear.RealMatrixFormat("; ", ",", "{0; -0; 1; 1; 0}", "{-97; -10; -0; -0; -97}", "{-97; -10; -0; -0; -97}", "[", numberFormat32);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat34 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat32);
        java.text.ParsePosition parsePosition35 = null;
        try {
            java.lang.Number number36 = org.apache.commons.math3.util.CompositeFormat.parseNumber("org.apache.commons.math3.linear.MatrixDimensionMismatchException: got 1x0 but expected 52x10", numberFormat32, parsePosition35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat7);
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "; " + "'", str9.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "[-0.0122337906]" + "'", str31.equals("[-0.0122337906]"));
        org.junit.Assert.assertNotNull(numberFormat32);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean23 = arrayRealVector19.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.append((double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, true);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        arrayRealVector6.set((double) (byte) 0);
        double double11 = arrayRealVector6.getLInfNorm();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) 74);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.0d + "'", double1 == 74.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 515.6620156177408d + "'", double1 == 515.6620156177408d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        float float2 = org.apache.commons.math3.util.Precision.round((float) 9, (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        double[] doubleArray3 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray7 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray3, doubleArray7, (double) (byte) 10);
        double[] doubleArray10 = eigenDecomposition9.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = eigenDecomposition9.getVT();
        java.lang.String str12 = realMatrixFormat0.format(realMatrix11);
        boolean boolean14 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric(realMatrix11, (double) 0.3820138f);
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "{{1}}" + "'", str12.equals("{{1}}"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        float[] floatArray0 = null;
        float[] floatArray1 = new float[] {};
        boolean boolean2 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray0, floatArray1);
        float[] floatArray3 = null;
        float[] floatArray4 = new float[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray3, floatArray4);
        boolean boolean6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray0, floatArray4);
        float[] floatArray7 = null;
        float[] floatArray8 = new float[] {};
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray7, floatArray8);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray0, floatArray7);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double[] doubleArray3 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray3);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray3, orderDirection5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.copy();
        double[][] doubleArray10 = diagonalMatrix8.getData();
        double[] doubleArray11 = diagonalMatrix8.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix8.power((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix16 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix16.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix23 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix16.add(openMapRealMatrix23);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix27.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix32 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix27);
        org.apache.commons.math3.linear.RealVector realVector34 = openMapRealMatrix32.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix16.subtract(openMapRealMatrix32);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix8, (org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 97");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math3.random.MersenneTwister();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker15 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (byte) 10, (int) '#');
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer16 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(1378221360, 0.0d, true, 1378221360, 4, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister10, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker15);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker18 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', 1.4153232443518473d, false, 6, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister10, true, pointValuePairConvergenceChecker18);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math3.exception.OutOfRangeException(localizable5, (java.lang.Number) (-0.012233790557032886d), (java.lang.Number) (-1L), (java.lang.Number) 1L);
        java.lang.Throwable[] throwableArray10 = outOfRangeException9.getSuppressed();
        org.apache.commons.math3.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, (double) 9, (double) 0.3820138f, 0.0d, 0.0d, (java.lang.Object[]) throwableArray10);
        double double12 = noBracketingException11.getFHi();
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        double[] doubleArray2 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray6 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray2, doubleArray6, (double) (byte) 10);
        double[] doubleArray9 = eigenDecomposition8.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        double[][] doubleArray11 = diagonalMatrix10.getData();
        double[][] doubleArray12 = diagonalMatrix10.getData();
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 3, (java.lang.Object[]) doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) 50);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double double8 = arrayRealVector7.getMaxValue();
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector15.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc20 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc20);
        org.apache.commons.math3.analysis.function.Sinc sinc23 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector15.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc23);
        double double25 = arrayRealVector7.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector24.copy();
        java.lang.Class<?> wildcardClass27 = arrayRealVector24.getClass();
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector24.mapAdd((double) 0.9326714f);
        double[] doubleArray35 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector36.mapDivideToSelf((double) (-1L));
        org.apache.commons.math3.analysis.function.Sinc sinc40 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector36.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc40);
        double[] doubleArray47 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47, false);
        double[] doubleArray55 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray55, false);
        double[] doubleArray63 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray63);
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector64.mapDivideToSelf((double) (-1L));
        boolean boolean68 = arrayRealVector64.equals((java.lang.Object) 10);
        double double69 = arrayRealVector57.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector64);
        double[] doubleArray77 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray77);
        org.apache.commons.math3.linear.RealVector realVector80 = arrayRealVector78.mapDivideToSelf((double) (-1L));
        boolean boolean82 = arrayRealVector78.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector84 = arrayRealVector78.append((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector86 = arrayRealVector78.mapDivide((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = arrayRealVector64.combine((double) (byte) 0, (double) (-1L), realVector86);
        org.apache.commons.math3.linear.RealMatrix realMatrix88 = arrayRealVector49.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector41, arrayRealVector64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = new org.apache.commons.math3.linear.ArrayRealVector(realVector29, arrayRealVector89);
        org.apache.commons.math3.linear.RealVector realVector91 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector92 = arrayRealVector89.ebeDivide(realVector91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 252.05440211108893d + "'", double25 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(arrayRealVector41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 246.6779276708802d + "'", double69 == 246.6779276708802d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(realVector84);
        org.junit.Assert.assertNotNull(realVector86);
        org.junit.Assert.assertNotNull(arrayRealVector87);
        org.junit.Assert.assertNotNull(realMatrix88);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner5 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4, preconditioner5);
        int int7 = nonLinearConjugateGradientOptimizer6.getEvaluations();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker8 = nonLinearConjugateGradientOptimizer6.getConvergenceChecker();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(pointValuePairConvergenceChecker8);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isSequence((double) 0.9145533f, 0.012233790557032886d, (double) 99);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(1, 9);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        double[] doubleArray8 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8);
        org.apache.commons.math3.optim.PointValuePair pointValuePair11 = new org.apache.commons.math3.optim.PointValuePair(doubleArray8, (double) (byte) -1);
        java.lang.Double double12 = pointValuePair11.getSecond();
        double[] doubleArray13 = pointValuePair11.getKey();
        double[] doubleArray19 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray13, doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        org.apache.commons.math3.optim.PointValuePair pointValuePair30 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) (byte) -1);
        java.lang.Double double31 = pointValuePair30.getSecond();
        java.lang.Double double32 = pointValuePair30.getValue();
        double[] doubleArray33 = pointValuePair30.getKey();
        double[] doubleArray39 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39);
        double double41 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray33, doubleArray39);
        java.lang.Number number43 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException45 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number43, 97);
        int int46 = nonMonotonicSequenceException45.getIndex();
        java.lang.Number number47 = nonMonotonicSequenceException45.getPrevious();
        int int48 = nonMonotonicSequenceException45.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection49 = nonMonotonicSequenceException45.getDirection();
        boolean boolean51 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray33, orderDirection49, false);
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray13, orderDirection49, true, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException56 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 2.99822295029797d, (java.lang.Number) 1, 12, orderDirection49, true);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-1.0d) + "'", double31.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.0d) + "'", double32.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertNull(number47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 97 + "'", int48 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector6.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        double[] doubleArray21 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) (-1L));
        boolean boolean25 = arrayRealVector22.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc27 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector22.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc27);
        org.apache.commons.math3.analysis.function.Sinc sinc30 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector22.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc30);
        double double33 = sinc30.value((double) 0.5105547f);
        double double36 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc30, 97.0d, 2.5108406941546723E58d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc30);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor38 = null;
        try {
            double double41 = arrayRealVector37.walkInOptimizedOrder(realVectorPreservingVisitor38, 1678488564, 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1,678,488,564)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.957118376469154d + "'", double33 == 0.957118376469154d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.2554203470773362E58d + "'", double36 == 1.2554203470773362E58d);
        org.junit.Assert.assertNotNull(arrayRealVector37);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d);
        double double2 = brentSolver1.getMin();
        double[] doubleArray9 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.mapDivideToSelf((double) (-1L));
        boolean boolean13 = arrayRealVector10.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc15 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector10.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc15);
        try {
            double double20 = brentSolver1.solve(2147483647, (org.apache.commons.math3.analysis.UnivariateFunction) sinc15, 0.033519757139437084d, 1.4142135623730951d, (double) 3.8146973E-6f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0.034, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(arrayRealVector16);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver8 = eigenDecomposition7.getSolver();
        double[] doubleArray9 = eigenDecomposition7.getImagEigenvalues();
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.optim.PointValuePair pointValuePair18 = new org.apache.commons.math3.optim.PointValuePair(doubleArray15, (double) (byte) -1);
        boolean boolean20 = pointValuePair18.equals((java.lang.Object) 0);
        java.lang.Object obj21 = null;
        boolean boolean22 = pointValuePair18.equals(obj21);
        double[] doubleArray23 = pointValuePair18.getPoint();
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray32 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray40 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40);
        org.apache.commons.math3.optim.PointValuePair pointValuePair43 = new org.apache.commons.math3.optim.PointValuePair(doubleArray40, (double) (byte) -1);
        boolean boolean45 = pointValuePair43.equals((java.lang.Object) 0);
        java.lang.Object obj46 = null;
        boolean boolean47 = pointValuePair43.equals(obj46);
        double[] doubleArray48 = pointValuePair43.getPoint();
        double[] doubleArray49 = pointValuePair43.getKey();
        boolean boolean50 = array2DRowRealMatrix34.equals((java.lang.Object) doubleArray49);
        double[] doubleArray52 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray56 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition58 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray52, doubleArray56, (double) (byte) 10);
        double[] doubleArray59 = eigenDecomposition58.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray59);
        double[] doubleArray62 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray66 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition68 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray62, doubleArray66, (double) (byte) 10);
        double[] doubleArray69 = eigenDecomposition68.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray69);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix60, (org.apache.commons.math3.linear.AnyMatrix) realMatrix70);
        org.apache.commons.math3.linear.RealMatrix realMatrix72 = array2DRowRealMatrix34.multiply(realMatrix60);
        try {
            array2DRowRealMatrix25.setRowMatrix((int) (byte) 10, realMatrix72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(decompositionSolver8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(realMatrix72);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (-0.012233790557032886d), (java.lang.Number) 247, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc11);
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean23 = arrayRealVector19.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.append((double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double[] doubleArray32 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.mapDivideToSelf((double) (-1L));
        boolean boolean37 = arrayRealVector33.equals((java.lang.Object) 10);
        double double38 = arrayRealVector12.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        float[] floatArray39 = new float[] {};
        float[] floatArray40 = null;
        float[] floatArray41 = new float[] {};
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray40, floatArray41);
        float[] floatArray43 = null;
        float[] floatArray44 = new float[] {};
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray43, floatArray44);
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray40, floatArray44);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray39, floatArray40);
        boolean boolean48 = arrayRealVector33.equals((java.lang.Object) floatArray39);
        double[] doubleArray55 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray55, false);
        double double58 = arrayRealVector57.getMaxValue();
        double[] doubleArray64 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray64);
        org.apache.commons.math3.linear.RealVector realVector67 = arrayRealVector65.mapDivideToSelf((double) (-1L));
        boolean boolean68 = arrayRealVector65.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc70 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector65.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc70);
        org.apache.commons.math3.analysis.function.Sinc sinc73 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = arrayRealVector65.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc73);
        double double75 = arrayRealVector57.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector74);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = arrayRealVector74.copy();
        org.apache.commons.math3.linear.RealVector realVector78 = arrayRealVector74.append(0.0d);
        try {
            arrayRealVector33.setSubVector(97, (org.apache.commons.math3.linear.RealVector) arrayRealVector74);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-7.175711493801343E-17d) + "'", double38 == (-7.175711493801343E-17d));
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 100.0d + "'", double58 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(arrayRealVector71);
        org.junit.Assert.assertNotNull(arrayRealVector74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 252.05440211108893d + "'", double75 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector76);
        org.junit.Assert.assertNotNull(realVector78);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        java.lang.String str8 = realMatrixFormat6.getRowSeparator();
        double[] doubleArray10 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray14 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition16 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray10, doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = eigenDecomposition16.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray17);
        double[] doubleArray20 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray24 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition26 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray20, doubleArray24, (double) (byte) 10);
        double[] doubleArray27 = eigenDecomposition26.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray27);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix18, (org.apache.commons.math3.linear.AnyMatrix) realMatrix28);
        java.lang.String str30 = realMatrixFormat6.format(realMatrix28);
        java.text.NumberFormat numberFormat31 = realMatrixFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat32 = new org.apache.commons.math3.linear.RealMatrixFormat("; ", ",", "{0; -0; 1; 1; 0}", "{-97; -10; -0; -0; -97}", "{-97; -10; -0; -0; -97}", "[", numberFormat31);
        java.lang.String str33 = realMatrixFormat32.getRowPrefix();
        org.junit.Assert.assertNotNull(realMatrixFormat6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "; " + "'", str8.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "[-0.0122337906]" + "'", str30.equals("[-0.0122337906]"));
        org.junit.Assert.assertNotNull(numberFormat31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "{0; -0; 1; 1; 0}" + "'", str33.equals("{0; -0; 1; 1; 0}"));
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test438");
//        org.apache.commons.math3.optim.MaxEval maxEval14 = new org.apache.commons.math3.optim.MaxEval((int) '#');
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math3.random.MersenneTwister();
//        float float16 = mersenneTwister15.nextFloat();
//        boolean boolean17 = mersenneTwister15.nextBoolean();
//        org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator> maxEvalPair18 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator>(maxEval14, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister15);
//        int int20 = mersenneTwister15.nextInt((int) (byte) 100);
//        int int21 = mersenneTwister15.nextInt();
//        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker25 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 0L, 0.8414709848078965d);
//        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer26 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (-0.0d), true, (-1555302186), 100, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister15, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker25);
//        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer27 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(6.5481924191803085d, 52.0d, 0.7042215514498249d, 1.1920928955078125E-7d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker25);
//        try {
//            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer28 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 0.0f, (double) 0.3498621f, (double) 9, 3.296908309475615d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker25);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
//        }
//        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.18395841f + "'", float16 == 0.18395841f);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 45 + "'", int20 == 45);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1819057182 + "'", int21 == 1819057182);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver8 = eigenDecomposition7.getSolver();
        double[] doubleArray9 = eigenDecomposition7.getImagEigenvalues();
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.optim.PointValuePair pointValuePair18 = new org.apache.commons.math3.optim.PointValuePair(doubleArray15, (double) (byte) -1);
        boolean boolean20 = pointValuePair18.equals((java.lang.Object) 0);
        java.lang.Object obj21 = null;
        boolean boolean22 = pointValuePair18.equals(obj21);
        double[] doubleArray23 = pointValuePair18.getPoint();
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray32 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray33, 97);
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.scale(1.4153232443518473d, doubleArray37);
        double[] doubleArray44 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray44);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector45.mapDivideToSelf((double) (-1L));
        boolean boolean48 = arrayRealVector45.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc50 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector45.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc50);
        org.apache.commons.math3.analysis.function.Sinc sinc53 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector45.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc53);
        double[] doubleArray56 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray60 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition62 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray56, doubleArray60, (double) (byte) 10);
        double[] doubleArray63 = eigenDecomposition62.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector45, doubleArray63);
        org.apache.commons.math3.linear.RealMatrix realMatrix65 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, doubleArray63);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix67 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray63);
        try {
            double[] doubleArray68 = array2DRowRealMatrix25.preMultiply(doubleArray63);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(decompositionSolver8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(realMatrix65);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(0, (-4.665906673149045E9d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (short) 1, (double) 0.22463548f, 0.0d);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction4 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator5 = null;
        try {
            multiDirectionalSimplex3.iterate(multivariateFunction4, pointValuePairComparator5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, 3.141592653589793d, 97);
        double double4 = simpleVectorValueChecker3.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.141592653589793d + "'", double4 == 3.141592653589793d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(0.5288560945221015d, 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) '4');
        double[][] doubleArray2 = diagonalMatrix1.getData();
        double[] doubleArray4 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray8 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray4, doubleArray8, (double) (byte) 10);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11);
        diagonalMatrix12.multiplyEntry(0, (int) 'a', 7.211102550927978d);
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = diagonalMatrix1.add(diagonalMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 52x52 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test445");
//        org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval((int) '#');
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister();
//        float float3 = mersenneTwister2.nextFloat();
//        boolean boolean4 = mersenneTwister2.nextBoolean();
//        org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator> maxEvalPair5 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.optim.MaxEval, org.apache.commons.math3.random.RandomGenerator>(maxEval1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister2);
//        int int6 = maxEval1.getMaxEval();
//        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.053712964f + "'", float3 == 0.053712964f);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.4153232443518473d, (double) Float.NaN, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType6 = brentOptimizer5.getGoalType();
        int int7 = brentOptimizer5.getMaxEvaluations();
        org.junit.Assert.assertNull(goalType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = eigenDecomposition7.getRealEigenvalues();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        double[][] doubleArray10 = diagonalMatrix9.getData();
        java.io.ObjectInputStream objectInputStream12 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) doubleArray10, "}", objectInputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.4153232443518473d, (double) Float.NaN, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        int int6 = brentOptimizer5.getIterations();
        int int7 = brentOptimizer5.getMaxIterations();
        double double8 = brentOptimizer5.getStartValue();
        int int9 = brentOptimizer5.getEvaluations();
        int int10 = brentOptimizer5.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction1 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) 0.9326714f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9657491536246592d + "'", double1 == 0.9657491536246592d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.transpose();
        try {
            double double12 = diagonalMatrix8.getEntry(4, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver8 = eigenDecomposition7.getSolver();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = eigenDecomposition7.getV();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(decompositionSolver8);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) (byte) 100, 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = array2DRowRealMatrix7.copy();
        double[] doubleArray52 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        org.apache.commons.math3.optim.PointValuePair pointValuePair63 = new org.apache.commons.math3.optim.PointValuePair(doubleArray60, (double) (byte) -1);
        boolean boolean65 = pointValuePair63.equals((java.lang.Object) 0);
        java.lang.Object obj66 = null;
        boolean boolean67 = pointValuePair63.equals(obj66);
        double[] doubleArray68 = pointValuePair63.getPoint();
        double[] doubleArray69 = pointValuePair63.getKey();
        boolean boolean70 = array2DRowRealMatrix54.equals((java.lang.Object) doubleArray69);
        double[] doubleArray71 = array2DRowRealMatrix7.preMultiply(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray71);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.RealVector realVector9 = openMapRealMatrix7.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix12.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix12);
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix17.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix20 = openMapRealMatrix7.add(openMapRealMatrix17);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor21.start(0, 247, 1, (int) (short) -1, 0, 0);
        double double29 = openMapRealMatrix17.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        double double30 = defaultRealMatrixPreservingVisitor21.end();
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealMatrix20);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector6.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector6.unitVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.copy();
        double[] doubleArray18 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (-1L));
        boolean boolean23 = arrayRealVector19.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.append((double) (short) 100);
        double double26 = arrayRealVector12.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double[] doubleArray32 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, false);
        double double35 = arrayRealVector34.getMaxValue();
        double[] doubleArray41 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.mapDivideToSelf((double) (-1L));
        boolean boolean45 = arrayRealVector42.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc47 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector42.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc47);
        org.apache.commons.math3.analysis.function.Sinc sinc50 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector42.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc50);
        double double52 = arrayRealVector34.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector12.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        java.lang.Double[] doubleArray54 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray54);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector53.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.0d + "'", double35 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 252.05440211108893d + "'", double52 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector53);
        org.junit.Assert.assertNotNull(doubleArray54);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(318.3959798741184d, (double) 0.0069203377f, 628.2788913603982d, 2.718281828459045d, (double) 0.29159784f, 1.2554203470773362E58d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.6607786547969245E57d + "'", double6 == 3.6607786547969245E57d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (short) 10, (int) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        long long2 = org.apache.commons.math3.util.FastMath.max(0L, (long) (-1555302186));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix8.copy();
        double[][] doubleArray10 = diagonalMatrix8.getData();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray10, 0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix2.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.RealVector realVector9 = openMapRealMatrix7.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) '4');
        openMapRealMatrix12.multiplyEntry(0, (int) ' ', (double) (short) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix12);
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix17.getColumnVector((int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix20 = openMapRealMatrix7.add(openMapRealMatrix17);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor21.start(0, 247, 1, (int) (short) -1, 0, 0);
        double double29 = openMapRealMatrix17.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        int int30 = openMapRealMatrix17.getColumnDimension();
        boolean boolean32 = openMapRealMatrix17.equals((java.lang.Object) "");
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix17, (-1809524577), (-1555302186), (int) (byte) 0, (-381728948));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,809,524,577)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealMatrix20);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 52 + "'", int30 == 52);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, (double) (byte) -1);
        boolean boolean18 = pointValuePair16.equals((java.lang.Object) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = pointValuePair16.equals(obj19);
        double[] doubleArray21 = pointValuePair16.getPoint();
        double[] doubleArray22 = pointValuePair16.getKey();
        boolean boolean23 = array2DRowRealMatrix7.equals((java.lang.Object) doubleArray22);
        double[] doubleArray25 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray29 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition31 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = eigenDecomposition31.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray39 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition41 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray35, doubleArray39, (double) (byte) 10);
        double[] doubleArray42 = eigenDecomposition41.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix33, (org.apache.commons.math3.linear.AnyMatrix) realMatrix43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix7.multiply(realMatrix33);
        try {
            double double48 = array2DRowRealMatrix7.getEntry(10, 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix45);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        boolean boolean10 = pointValuePair8.equals((java.lang.Object) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = pointValuePair8.equals(obj11);
        java.lang.Double double13 = pointValuePair8.getValue();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13.equals((-1.0d)));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double double8 = arrayRealVector7.getMaxValue();
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector15.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc20 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc20);
        org.apache.commons.math3.analysis.function.Sinc sinc23 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector15.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc23);
        double double25 = arrayRealVector7.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector24.copy();
        java.lang.Class<?> wildcardClass27 = arrayRealVector24.getClass();
        arrayRealVector24.unitize();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 252.05440211108893d + "'", double25 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double[] doubleArray1 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray5 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray5, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver8 = eigenDecomposition7.getSolver();
        double[] doubleArray9 = eigenDecomposition7.getImagEigenvalues();
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.optim.PointValuePair pointValuePair18 = new org.apache.commons.math3.optim.PointValuePair(doubleArray15, (double) (byte) -1);
        boolean boolean20 = pointValuePair18.equals((java.lang.Object) 0);
        java.lang.Object obj21 = null;
        boolean boolean22 = pointValuePair18.equals(obj21);
        double[] doubleArray23 = pointValuePair18.getPoint();
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        java.lang.Class<?> wildcardClass26 = array2DRowRealMatrix25.getClass();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix25, 93, 0, (int) (short) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (93)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(decompositionSolver8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(50, 7.909921332671597E-4d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double[] doubleArray8 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapDivideToSelf((double) (-1L));
        boolean boolean12 = arrayRealVector9.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector9.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        org.apache.commons.math3.analysis.function.Sinc sinc17 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector9.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc17);
        double double20 = sinc17.value((double) 0.5105547f);
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder23 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double24 = bracketFinder23.getHi();
        double double25 = bracketFinder23.getLo();
        org.apache.commons.math3.analysis.function.Sinc sinc27 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType28 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder23.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc27, goalType28, (double) '4', (double) 'a');
        bracketFinder2.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc17, goalType28, 0.9075712110370514d, 0.0d);
        double double35 = bracketFinder2.getFHi();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.957118376469154d + "'", double20 == 0.957118376469154d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType28 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType28.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.8682632767805497d + "'", double35 == 0.8682632767805497d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double[] doubleArray5 = new double[] { (-1L), (byte) 1, 100.0f, 52, 100.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double double8 = arrayRealVector7.getMaxValue();
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean18 = arrayRealVector15.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc20 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector15.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc20);
        org.apache.commons.math3.analysis.function.Sinc sinc23 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector15.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc23);
        double double25 = arrayRealVector7.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector24.copy();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector24.append(0.0d);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector24.mapAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector24.mapMultiplyToSelf((-0.8414709848078965d));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 252.05440211108893d + "'", double25 == 252.05440211108893d);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(realVector32);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        java.lang.String str2 = realMatrixFormat0.getColumnSeparator();
        java.lang.String str3 = realMatrixFormat0.getColumnSeparator();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ", " + "'", str2.equals(", "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ", " + "'", str3.equals(", "));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(0.5288560945221015d, (double) 0.094331026f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5288560945221015d + "'", double2 == 0.5288560945221015d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { 4, 52, 2147483647, 97, 97 };
        java.lang.Integer[] intArray15 = new java.lang.Integer[] { 52, 100, 2147483647, 4, 100, 2147483647 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException16 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable2, intArray8, intArray15);
        java.lang.Integer[] intArray17 = multiDimensionMismatchException16.getExpectedDimensions();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 1.5707963267948966d, (java.lang.Object[]) intArray17);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext19 = maxCountExceededException18.getContext();
        java.lang.Number number20 = maxCountExceededException18.getMax();
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(exceptionContext19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.5707963267948966d + "'", number20.equals(1.5707963267948966d));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((-381728948));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        java.lang.String str2 = realMatrixFormat0.getRowSeparator();
        double[] doubleArray4 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray8 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray4, doubleArray8, (double) (byte) 10);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray11);
        double[] doubleArray14 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray18 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition20 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray14, doubleArray18, (double) (byte) 10);
        double[] doubleArray21 = eigenDecomposition20.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray21);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix12, (org.apache.commons.math3.linear.AnyMatrix) realMatrix22);
        java.lang.String str24 = realMatrixFormat0.format(realMatrix22);
        java.lang.String str25 = realMatrixFormat0.getRowSeparator();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "[-0.0122337906]" + "'", str24.equals("[-0.0122337906]"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "; " + "'", str25.equals("; "));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        double[] doubleArray5 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[] doubleArray11 = new double[] { (-1.0f), (byte) -1, 100.0d, 10, 100L };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix15.copy();
        double[] doubleArray18 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray22 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray18, doubleArray22, (double) (byte) 10);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver25 = eigenDecomposition24.getSolver();
        double[] doubleArray26 = eigenDecomposition24.getImagEigenvalues();
        boolean boolean27 = array2DRowRealMatrix15.equals((java.lang.Object) eigenDecomposition24);
        double[] doubleArray29 = null;
        try {
            array2DRowRealMatrix15.setColumn(9, doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (9)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(decompositionSolver25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double3 = bracketFinder2.getHi();
        double double4 = bracketFinder2.getLo();
        org.apache.commons.math3.analysis.function.Sinc sinc6 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder2.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc6, goalType7, (double) '4', (double) 'a');
        double[] doubleArray16 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) (-1L));
        double[] doubleArray25 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) (-1L));
        boolean boolean30 = arrayRealVector26.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector26.append((double) (short) 100);
        double double33 = arrayRealVector17.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        double[] doubleArray39 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.mapDivideToSelf((double) (-1L));
        boolean boolean43 = arrayRealVector40.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc45 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector40.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc45);
        org.apache.commons.math3.analysis.function.Sinc sinc48 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector40.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector26.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc48);
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder53 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 3.8146973E-6f, (int) (short) 100);
        double double54 = bracketFinder53.getHi();
        double double55 = bracketFinder53.getLo();
        org.apache.commons.math3.analysis.function.Sinc sinc57 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType58 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder53.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc57, goalType58, (double) '4', (double) 'a');
        bracketFinder2.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc48, goalType58, (double) 100, 0.0d);
        boolean boolean67 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc48, (double) 0.3820138f, 0.0d);
        try {
            double[] doubleArray71 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc48, 1.2554203470773362E58d, (-4.665906673149045E9d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [12,554,203,470,773,362,000,000,000,000,000,000,000,000,000,000,000,000,000,000, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType7 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType7.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 18918.0d + "'", double33 == 18918.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType58 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType58.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean9 = arrayRealVector6.isNaN();
        double[] doubleArray15 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector16.isNaN();
        org.apache.commons.math3.analysis.function.Sinc sinc21 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc21);
        double double23 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector16.copy();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector16.getSubVector((int) (byte) 1, (int) (short) 1);
        org.apache.commons.math3.linear.RealVector realVector29 = realVector27.mapAdd((double) 0.18379879f);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector29);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        double double3 = org.apache.commons.math3.util.Precision.round((double) 12, (int) (short) 10, 5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer5 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType6 = nonLinearConjugateGradientOptimizer5.getGoalType();
        int int7 = nonLinearConjugateGradientOptimizer5.getIterations();
        double[] doubleArray8 = nonLinearConjugateGradientOptimizer5.getLowerBound();
        org.junit.Assert.assertNull(goalType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(doubleArray8);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        boolean boolean10 = arrayRealVector6.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector6.unitVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.copy();
        arrayRealVector12.unitize();
        try {
            org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector12.getSubVector(1678488564, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1,678,488,564)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        java.lang.String str2 = realMatrixFormat0.getRowSeparator();
        double[] doubleArray4 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray8 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray4, doubleArray8, (double) (byte) 10);
        double[] doubleArray11 = eigenDecomposition10.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray11);
        double[] doubleArray14 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray18 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition20 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray14, doubleArray18, (double) (byte) 10);
        double[] doubleArray21 = eigenDecomposition20.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray21);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix12, (org.apache.commons.math3.linear.AnyMatrix) realMatrix22);
        java.lang.String str24 = realMatrixFormat0.format(realMatrix22);
        java.text.NumberFormat numberFormat25 = realMatrixFormat0.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat26 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat25);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat27 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat25);
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "[-0.0122337906]" + "'", str24.equals("[-0.0122337906]"));
        org.junit.Assert.assertNotNull(numberFormat25);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        java.lang.Double double9 = pointValuePair8.getSecond();
        double[] doubleArray10 = pointValuePair8.getKey();
        double[] doubleArray16 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray10, doubleArray17);
        double[] doubleArray24 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24);
        org.apache.commons.math3.optim.PointValuePair pointValuePair27 = new org.apache.commons.math3.optim.PointValuePair(doubleArray24, (double) (byte) -1);
        java.lang.Double double28 = pointValuePair27.getSecond();
        java.lang.Double double29 = pointValuePair27.getValue();
        double[] doubleArray30 = pointValuePair27.getKey();
        double[] doubleArray36 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36);
        double double38 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray30, doubleArray36);
        java.lang.Number number40 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException42 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, number40, 97);
        int int43 = nonMonotonicSequenceException42.getIndex();
        java.lang.Number number44 = nonMonotonicSequenceException42.getPrevious();
        int int45 = nonMonotonicSequenceException42.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection46 = nonMonotonicSequenceException42.getDirection();
        boolean boolean48 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray30, orderDirection46, false);
        boolean boolean51 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray10, orderDirection46, true, false);
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray10, (double) 0.8993244f);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-1.0d) + "'", double28.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-1.0d) + "'", double29.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 97 + "'", int43 == 97);
        org.junit.Assert.assertNull(number44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 97 + "'", int45 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection46 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection46.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(1.4153232443518473d, 2.718281828459045d);
        int int3 = simplexOptimizer2.getMaxIterations();
        double[] doubleArray4 = simplexOptimizer2.getUpperBound();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertNull(doubleArray4);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        double double2 = org.apache.commons.math3.util.FastMath.log(0.019529180206536247d, 0.9836065573770492d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.004199682610674447d + "'", double2 == 0.004199682610674447d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6, 97);
        org.apache.commons.math3.optim.nonlinear.vector.Target target11 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray10);
        double[] doubleArray12 = target11.getTarget();
        double[] doubleArray13 = target11.getTarget();
        double[] doubleArray14 = target11.getTarget();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        double[] doubleArray0 = null;
        org.apache.commons.math3.optim.PointValuePair pointValuePair3 = new org.apache.commons.math3.optim.PointValuePair(doubleArray0, (-99.85121904920359d), false);
        java.lang.Double double4 = pointValuePair3.getValue();
        double[] doubleArray5 = pointValuePair3.getFirst();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-99.85121904920359d) + "'", double4.equals((-99.85121904920359d)));
        org.junit.Assert.assertNull(doubleArray5);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.apache.commons.math3.optim.MaxIter maxIter1 = new org.apache.commons.math3.optim.MaxIter(97);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        java.lang.Double double9 = pointValuePair8.getSecond();
        double[] doubleArray10 = pointValuePair8.getFirst();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 10L, (double) (short) 1, 0.0d);
        int int4 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        int int5 = levenbergMarquardtOptimizer3.getMaxIterations();
        double[] doubleArray6 = levenbergMarquardtOptimizer3.getStartPoint();
        int int7 = levenbergMarquardtOptimizer3.getMaxIterations();
        double[] doubleArray8 = levenbergMarquardtOptimizer3.getUpperBound();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertNull(doubleArray8);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(0);
        boolean boolean2 = arrayRealVector1.isNaN();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        arrayRealVector6.set((double) (byte) 0);
        boolean boolean11 = arrayRealVector6.isNaN();
        boolean boolean12 = arrayRealVector6.isNaN();
        double[] doubleArray19 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        org.apache.commons.math3.optim.PointValuePair pointValuePair30 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) (byte) -1);
        boolean boolean32 = pointValuePair30.equals((java.lang.Object) 0);
        java.lang.Object obj33 = null;
        boolean boolean34 = pointValuePair30.equals(obj33);
        double[] doubleArray35 = pointValuePair30.getPoint();
        double[] doubleArray36 = pointValuePair30.getKey();
        boolean boolean37 = array2DRowRealMatrix21.equals((java.lang.Object) doubleArray36);
        int int38 = org.apache.commons.math3.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math3.optim.PointValuePair pointValuePair40 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, (double) 2147483647);
        arrayRealVector6.setSubVector((int) (short) 0, doubleArray36);
        double[] doubleArray45 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray45);
        double[] doubleArray49 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray53 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition55 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray49, doubleArray53, (double) (byte) 10);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray53);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition58 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray45, doubleArray56, (double) (byte) -1);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray36, doubleArray56);
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1809524577) + "'", int38 == (-1809524577));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        double[] doubleArray5 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1L));
        double[] doubleArray14 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (-1L));
        boolean boolean19 = arrayRealVector15.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.append((double) (short) 100);
        double double22 = arrayRealVector6.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector6.mapSubtractToSelf(3.982441812995697E30d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector6.copy();
        double[] doubleArray31 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector32.mapDivideToSelf((double) (-1L));
        double[] doubleArray40 = new double[] { 'a', 10.0f, 0L, (short) 0, 97 };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40);
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector41.mapDivideToSelf((double) (-1L));
        boolean boolean45 = arrayRealVector41.equals((java.lang.Object) 10);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector41.append((double) (short) 100);
        double double48 = arrayRealVector32.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, (org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 18918.0d + "'", double22 == 18918.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 18918.0d + "'", double48 == 18918.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 1678488564, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.67848858E9f + "'", float2 == 1.67848858E9f);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, true);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0f + "'", number5.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0f + "'", number6.equals(1.0f));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 318.3959798741184d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 1, (double) (byte) 10);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.4153232443518473d, (double) Float.NaN, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        int int6 = brentOptimizer5.getIterations();
        int int7 = brentOptimizer5.getMaxIterations();
        double double8 = brentOptimizer5.getStartValue();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType9 = brentOptimizer5.getGoalType();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(goalType9);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        boolean boolean9 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix7, (double) (byte) 0);
        double[] doubleArray15 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray23 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray31 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray31);
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray31, (double) (byte) -1);
        boolean boolean36 = pointValuePair34.equals((java.lang.Object) 0);
        java.lang.Object obj37 = null;
        boolean boolean38 = pointValuePair34.equals(obj37);
        double[] doubleArray39 = pointValuePair34.getPoint();
        double[] doubleArray40 = pointValuePair34.getKey();
        boolean boolean41 = array2DRowRealMatrix25.equals((java.lang.Object) doubleArray40);
        double[] doubleArray43 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray47 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray43, doubleArray47, (double) (byte) 10);
        double[] doubleArray50 = eigenDecomposition49.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray50);
        double[] doubleArray53 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray57 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition59 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray53, doubleArray57, (double) (byte) 10);
        double[] doubleArray60 = eigenDecomposition59.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix61 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray60);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix51, (org.apache.commons.math3.linear.AnyMatrix) realMatrix61);
        org.apache.commons.math3.linear.RealMatrix realMatrix63 = array2DRowRealMatrix25.multiply(realMatrix51);
        double[][] doubleArray64 = array2DRowRealMatrix25.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix25.createMatrix((int) ' ', 4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = array2DRowRealMatrix17.add(array2DRowRealMatrix25);
        boolean boolean69 = array2DRowRealMatrix25.isSquare();
        boolean boolean70 = array2DRowRealMatrix25.isTransposable();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = array2DRowRealMatrix7.subtract(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix71);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5557.690612768985d + "'", double1 == 5557.690612768985d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.lang.String str1 = realVectorFormat0.getSuffix();
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double[] doubleArray5 = new double[] { (short) 10, 0.0d, (byte) 0, 10, 1.0d };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        org.apache.commons.math3.optim.PointValuePair pointValuePair8 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) (byte) -1);
        boolean boolean10 = pointValuePair8.equals((java.lang.Object) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = pointValuePair8.equals(obj11);
        double[] doubleArray13 = pointValuePair8.getPoint();
        double[] doubleArray17 = new double[] { (byte) 0, ' ' };
        org.apache.commons.math3.util.MathArrays.scaleInPlace(10.0d, doubleArray17);
        double[] doubleArray21 = new double[] { (-0.012233790557032886d) };
        double[] doubleArray25 = new double[] { (-1L), (-1.0f), 0.0d };
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition27 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray21, doubleArray25, (double) (byte) 10);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.scale(10.0d, doubleArray25);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition30 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray17, doubleArray28, (double) (byte) -1);
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray13, doubleArray17);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13, 1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
    }
}

