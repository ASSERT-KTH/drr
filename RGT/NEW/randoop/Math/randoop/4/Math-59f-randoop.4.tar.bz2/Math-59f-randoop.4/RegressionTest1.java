import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.918219700000001E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.817932315280979E9d + "'", double1 == 2.817932315280979E9d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 32768);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32768L + "'", long1 == 32768L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("1.000000000000e-1323625316");
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance(783014952);
        int int10 = dfp9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        int int10 = dfp3.log10K();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp3.newInstance((byte) 2);
        double[] doubleArray13 = dfp12.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.newInstance((double) 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode4);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.rint();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.floor();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.divide(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.negate();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.divide(dfp29);
        boolean boolean31 = dfp21.greaterThan(dfp29);
        boolean boolean32 = dfp21.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.Dfp.copysign(dfp9, dfp21);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance((byte) 1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.divide(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.power10K((-330906329));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp17);
        java.lang.Object obj19 = null;
        boolean boolean20 = dfp18.equals(obj19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(10);
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp();
        try {
            org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("hi!");
        dfpField1.setIEEEFlagsBits(100);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp("10.");
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.divide(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.negate();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.divide(dfp29);
        boolean boolean31 = dfp21.greaterThan(dfp29);
        boolean boolean32 = dfp21.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField33 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp39.divide(dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp39.negate();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp45.rint();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.newInstance();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp46.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp50 = org.apache.commons.math.dfp.DfpField.computeExp(dfp35, dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField1.newDfp(dfp50);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.newInstance((byte) 2, (byte) 100);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfpField33);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((int) (short) 100);
        long long3 = mersenneTwister0.nextLong();
        long long4 = mersenneTwister0.nextLong();
        int int5 = mersenneTwister0.nextInt();
        int[] intArray8 = new int[] { '#', '#' };
        mersenneTwister0.setSeed(intArray8);
        boolean boolean10 = mersenneTwister0.nextBoolean();
        double double11 = mersenneTwister0.nextGaussian();
        boolean boolean12 = mersenneTwister0.nextBoolean();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-8422692239103173864L) + "'", long3 == (-8422692239103173864L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5135008762804559719L + "'", long4 == 5135008762804559719L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1823289175 + "'", int5 == 1823289175);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.25714322453219346d + "'", double11 == 0.25714322453219346d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.594700892207039d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.11741660338413339d) + "'", double1 == (-0.11741660338413339d));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 5.298292365610486d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) 8, true);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException7.getSpecificPattern();
        java.lang.Class<?> wildcardClass9 = numberIsTooSmallException7.getClass();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number11 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.0f) + "'", number11.equals((-1.0f)));
        org.junit.Assert.assertNull(localizable12);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        int int10 = dfp3.log10K();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp3.newInstance((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp16.divide(dfp20);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) (-0.5440211108893698d), number24, false);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException26.getGeneralPattern();
        java.lang.Number number28 = numberIsTooSmallException26.getMin();
        java.lang.String str29 = numberIsTooSmallException26.toString();
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException26.getGeneralPattern();
        boolean boolean31 = dfp21.equals((java.lang.Object) localizable30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp3.newInstance(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField34.getESplit();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField34.newDfp((byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode40 = dfpField34.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField34.getSqr3();
        boolean boolean42 = dfp3.lessThan(dfp41);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str29.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + roundingMode40 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode40.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.negate();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10000, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 32760);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Throwable[] throwableArray3 = mathRuntimeException2.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        long long2 = org.apache.commons.math.util.FastMath.min((-5798740597388316909L), (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5798740597388316909L) + "'", long2 == (-5798740597388316909L));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-32767.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(10);
        int int9 = dfp8.intValue();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField11.getESplit();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp15.getField();
        org.apache.commons.math.dfp.Dfp dfp17 = org.apache.commons.math.dfp.Dfp.copysign(dfp8, dfp15);
        int int18 = dfp8.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        int int10 = dfp3.log10K();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp3.newInstance((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp16.divide(dfp20);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) (-0.5440211108893698d), number24, false);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException26.getGeneralPattern();
        java.lang.Number number28 = numberIsTooSmallException26.getMin();
        java.lang.String str29 = numberIsTooSmallException26.toString();
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException26.getGeneralPattern();
        boolean boolean31 = dfp21.equals((java.lang.Object) localizable30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp3.newInstance(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField36.getESplit();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField36.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField36.getLn10();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField36.newDfp(10);
        dfpField36.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField36.newDfp();
        org.apache.commons.math.dfp.Dfp dfp47 = null;
        org.apache.commons.math.dfp.Dfp dfp48 = dfp21.dotrap((int) (short) 0, "10.", dfp46, dfp47);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str29.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNull(dfp48);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("1.000000000000e-1323625316");
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance(783014952);
        int int10 = dfp9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.newInstance("org.apache.commons.math.exception.NumberIsTooSmallException: 2.718 is smaller than, or equal to, the minimum (100)");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        int int10 = dfp3.log10K();
        int int11 = dfp3.intValue();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)");
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.floor();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
        int[] intArray2 = null;
        mersenneTwister1.setSeed(intArray2);
        mersenneTwister1.setSeed((-8422692239103173864L));
        int int6 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-159860839) + "'", int6 == (-159860839));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) ' ');
        int[] intArray2 = null;
        mersenneTwister1.setSeed(intArray2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1323625316L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1097.9646428628653d) + "'", double1 == (-1097.9646428628653d));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 32760);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Throwable[] throwableArray3 = mathRuntimeException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (-0.5440211108893698d), number6, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) 1.0d);
        mathRuntimeException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) (-0.5440211108893698d), number17, false);
        org.apache.commons.math.exception.util.Localizable localizable20 = numberIsTooSmallException19.getGeneralPattern();
        java.lang.Number number21 = numberIsTooSmallException19.getMin();
        java.lang.String str22 = numberIsTooSmallException19.toString();
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = dfpField25.getRoundingMode();
        int int28 = dfpField25.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField25.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, (java.lang.Object[]) dfpArray29);
        notStrictlyPositiveException13.addSuppressed((java.lang.Throwable) mathIllegalArgumentException30);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str22.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
        org.junit.Assert.assertNotNull(dfpArray29);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp("10.");
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp17.divide(dfp21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.5440211108893698d), number25, false);
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooSmallException27.getGeneralPattern();
        java.lang.Number number29 = numberIsTooSmallException27.getMin();
        java.lang.String str30 = numberIsTooSmallException27.toString();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException27.getGeneralPattern();
        boolean boolean32 = dfp22.equals((java.lang.Object) localizable31);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp22.newInstance((byte) 0);
        int int35 = dfp34.log10K();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp34.newInstance("hi!");
        int int38 = dfp37.log10();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode42 = dfpField40.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp46.divide(dfp50);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField40.newDfp(dfp46);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField40.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField40.getLn2();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField40.newDfp((byte) 3, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp11.dotrap(1823289175, "-10.", dfp37, dfp57);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str30.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-4) + "'", int38 == (-4));
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + roundingMode42 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode42.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField10.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp17.divide(dfp21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.5440211108893698d), number25, false);
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooSmallException27.getGeneralPattern();
        java.lang.Number number29 = numberIsTooSmallException27.getMin();
        java.lang.String str30 = numberIsTooSmallException27.toString();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException27.getGeneralPattern();
        boolean boolean32 = dfp22.equals((java.lang.Object) localizable31);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp22.newInstance((byte) 0);
        int int35 = dfp34.log10K();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField10.newDfp(dfp34);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp34.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField39.getESplit();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField39.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField39.getLn10();
        int int45 = dfp44.log10();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp49.divide(dfp53);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Number number57 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable55, (java.lang.Number) (-0.5440211108893698d), number57, false);
        org.apache.commons.math.exception.util.Localizable localizable60 = numberIsTooSmallException59.getGeneralPattern();
        java.lang.Number number61 = numberIsTooSmallException59.getMin();
        java.lang.String str62 = numberIsTooSmallException59.toString();
        org.apache.commons.math.exception.util.Localizable localizable63 = numberIsTooSmallException59.getGeneralPattern();
        boolean boolean64 = dfp54.equals((java.lang.Object) localizable63);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp54.newInstance((long) 'a');
        org.apache.commons.math.dfp.Dfp dfp67 = org.apache.commons.math.dfp.Dfp.copysign(dfp44, dfp66);
        org.apache.commons.math.dfp.Dfp dfp68 = dfp37.subtract(dfp67);
        int int69 = dfp37.log10();
        org.apache.commons.math.dfp.Dfp dfp71 = dfp37.newInstance("1.000000000000e-1323625316");
        org.apache.commons.math.dfp.Dfp dfp72 = dfp8.add(dfp71);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str30.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfpArray42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str62.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable63.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp3.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getLn2();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField12.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField12.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField12.newDfp((double) (-5798740597388316909L));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField12.getLn2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp10.divide(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField23.getESplit();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.getSqr2Reciprocal();
        boolean boolean28 = dfp21.greaterThan(dfp27);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.4965075614664802d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8698950669667216d + "'", double1 == 1.8698950669667216d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 2, (byte) 0, (byte) 10 };
        mersenneTwister0.nextBytes(byteArray5);
        mersenneTwister0.setSeed((long) (byte) 2);
        int int9 = mersenneTwister0.nextInt();
        mersenneTwister0.setSeed(1);
        int int13 = mersenneTwister0.nextInt(16);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 49182197 + "'", int9 == 49182197);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.divide(dfp12);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (-0.5440211108893698d), number16, false);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        java.lang.Number number20 = numberIsTooSmallException18.getMin();
        java.lang.String str21 = numberIsTooSmallException18.toString();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException18.getGeneralPattern();
        boolean boolean23 = dfp13.equals((java.lang.Object) localizable22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.newInstance((byte) 0);
        int int26 = dfp25.log10K();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField1.newDfp(dfp25);
        int int28 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str21.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
        org.junit.Assert.assertNotNull(dfpArray29);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (-0.5440211108893698d), number11, false);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException13.getGeneralPattern();
        java.lang.Number number15 = numberIsTooSmallException13.getMin();
        java.lang.String str16 = numberIsTooSmallException13.toString();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException13.getGeneralPattern();
        boolean boolean18 = dfp8.equals((java.lang.Object) localizable17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.718281828459045d, (java.lang.Number) (byte) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooSmallException24.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp29.divide(dfp33);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Number number37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) (-0.5440211108893698d), number37, false);
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooSmallException39.getGeneralPattern();
        java.lang.Number number41 = numberIsTooSmallException39.getMin();
        java.lang.String str42 = numberIsTooSmallException39.toString();
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException39.getGeneralPattern();
        boolean boolean44 = dfp34.equals((java.lang.Object) localizable43);
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Number number47 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, (java.lang.Number) (-0.5440211108893698d), number47, false);
        org.apache.commons.math.exception.util.Localizable localizable50 = numberIsTooSmallException49.getGeneralPattern();
        java.lang.Object[] objArray51 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, objArray51);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) (-8422692239103173864L));
        java.lang.Object[] objArray55 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable50, objArray55);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException60 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) 8, true);
        java.lang.Throwable[] throwableArray61 = numberIsTooSmallException60.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, (java.lang.Object[]) throwableArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable25, (java.lang.Object[]) throwableArray61);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str16.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str42.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray61);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        dfpField1.setIEEEFlags((-1323625316));
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 9, (long) 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((int) (short) 100);
        long long3 = mersenneTwister0.nextLong();
        long long4 = mersenneTwister0.nextLong();
        int int5 = mersenneTwister0.nextInt();
        double double6 = mersenneTwister0.nextGaussian();
        mersenneTwister0.setSeed((long) 16);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-8422692239103173864L) + "'", long3 == (-8422692239103173864L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5135008762804559719L + "'", long4 == 5135008762804559719L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1823289175 + "'", int5 == 1823289175);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.9259055730677126d) + "'", double6 == (-1.9259055730677126d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        int int7 = dfpField6.getIEEEFlags();
        dfpField6.setIEEEFlags(8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.getPi();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField6.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray7);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister();
//        mersenneTwister2.setSeed((int) (short) 100);
//        long long5 = mersenneTwister2.nextLong();
//        long long6 = mersenneTwister2.nextLong();
//        int int7 = mersenneTwister2.nextInt();
//        int[] intArray10 = new int[] { '#', '#' };
//        mersenneTwister2.setSeed(intArray10);
//        mersenneTwister0.setSeed(intArray10);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister(intArray10);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1066796429 + "'", int1 == 1066796429);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-8422692239103173864L) + "'", long5 == (-8422692239103173864L));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5135008762804559719L + "'", long6 == 5135008762804559719L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1823289175 + "'", int7 == 1823289175);
//        org.junit.Assert.assertNotNull(intArray10);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.divide(dfp11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn5();
        int int10 = dfp9.classify();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed(10);
        long long3 = mersenneTwister0.nextLong();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-4218389569722409859L) + "'", long3 == (-4218389569722409859L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1764015537);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-330906329));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 330906329L + "'", long1 == 330906329L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1, (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.divide(dfp12);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (-0.5440211108893698d), number16, false);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        java.lang.Number number20 = numberIsTooSmallException18.getMin();
        java.lang.String str21 = numberIsTooSmallException18.toString();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException18.getGeneralPattern();
        boolean boolean23 = dfp13.equals((java.lang.Object) localizable22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.newInstance((byte) 0);
        int int26 = dfp25.log10K();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField1.newDfp(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode29 = dfpField1.getRoundingMode();
        int int30 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str21.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + roundingMode29 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode29.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfp31);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        mersenneTwister0.setSeed((int) (short) 100);
//        long long3 = mersenneTwister0.nextLong();
//        double double4 = mersenneTwister0.nextGaussian();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray10 = new byte[] { (byte) 100, (byte) 2, (byte) 0, (byte) 10 };
//        mersenneTwister5.nextBytes(byteArray10);
//        mersenneTwister5.setSeed((long) (byte) 2);
//        int int14 = mersenneTwister5.nextInt();
//        float float15 = mersenneTwister5.nextFloat();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister16 = new org.apache.commons.math.random.MersenneTwister();
//        float float17 = mersenneTwister16.nextFloat();
//        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 100 };
//        mersenneTwister16.nextBytes(byteArray20);
//        mersenneTwister5.nextBytes(byteArray20);
//        mersenneTwister0.nextBytes(byteArray20);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-8422692239103173864L) + "'", long3 == (-8422692239103173864L));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.2321040789270661d) + "'", double4 == (-0.2321040789270661d));
//        org.junit.Assert.assertNotNull(byteArray10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 49182197 + "'", int14 == 49182197);
//        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.48674452f + "'", float15 == 0.48674452f);
//        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.9314009f + "'", float17 == 0.9314009f);
//        org.junit.Assert.assertNotNull(byteArray20);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        int int7 = dfpField6.getIEEEFlags();
        dfpField6.setIEEEFlags(8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.getZero();
        dfpField6.setIEEEFlagsBits((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField6.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.getLn2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getLn10();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField15.newDfp((long) (-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField15.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField15.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 2.718 is smaller than, or equal to, the minimum (100)");
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField6.newDfp(dfp23);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((double) 5730L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) 8, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        java.lang.Class<?> wildcardClass5 = numberIsTooSmallException3.getClass();
        java.lang.Class<?> wildcardClass6 = numberIsTooSmallException3.getClass();
        boolean boolean7 = numberIsTooSmallException3.getBoundIsAllowed();
        boolean boolean8 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        boolean boolean10 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.5924273534318786d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5924273534318786d + "'", double1 == 0.5924273534318786d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.divide(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.power10K((-330906329));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp17);
        java.lang.Object obj19 = null;
        boolean boolean20 = dfp18.equals(obj19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode24 = dfpField22.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp28.divide(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField22.newDfp(dfp28);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp28.negate();
        org.apache.commons.math.dfp.Dfp dfp36 = org.apache.commons.math.dfp.DfpField.computeExp(dfp18, dfp28);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp28.sqrt();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + roundingMode24 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode24.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1764015537);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599454d + "'", double1 == 0.6931471805599454d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double1 = org.apache.commons.math.util.FastMath.asinh(43.66827237527655d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.469900062194581d + "'", double1 == 4.469900062194581d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        boolean boolean7 = dfp6.isInfinite();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((int) (short) 100);
        long long3 = mersenneTwister0.nextLong();
        long long4 = mersenneTwister0.nextLong();
        int int5 = mersenneTwister0.nextInt();
        int[] intArray8 = new int[] { '#', '#' };
        mersenneTwister0.setSeed(intArray8);
        boolean boolean10 = mersenneTwister0.nextBoolean();
        long long11 = mersenneTwister0.nextLong();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-8422692239103173864L) + "'", long3 == (-8422692239103173864L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5135008762804559719L + "'", long4 == 5135008762804559719L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1823289175 + "'", int5 == 1823289175);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4021280482298627657L + "'", long11 == 4021280482298627657L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-0.5440211108893698d), number2, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        java.lang.String str7 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException4.getGeneralPattern();
        boolean boolean9 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 32768.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.39720770839918d + "'", double1 == 10.39720770839918d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.01745417873758517d, 2.1487579971218467d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.017454178737585174d + "'", double2 == 0.017454178737585174d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.rint();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.floor();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.divide(dfp19);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) (-0.5440211108893698d), number23, false);
        org.apache.commons.math.exception.util.Localizable localizable26 = numberIsTooSmallException25.getGeneralPattern();
        java.lang.Number number27 = numberIsTooSmallException25.getMin();
        java.lang.String str28 = numberIsTooSmallException25.toString();
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooSmallException25.getGeneralPattern();
        boolean boolean30 = dfp20.equals((java.lang.Object) localizable29);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp20.newInstance((byte) 0);
        int int33 = dfp32.log10K();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.power10(0);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp11.subtract(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp42.divide(dfp46);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp42.negate();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp48.rint();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.floor();
        boolean boolean51 = dfp11.lessThan(dfp48);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str28.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        int[] intArray0 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1937831252), (float) (-1937831252));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.9378313E9f) + "'", float2 == (-1.9378313E9f));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.divide(dfp11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getSqr3Reciprocal();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1.9378313E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.937831296E9d + "'", double1 == 1.937831296E9d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 783014952);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 783014952L + "'", long1 == 783014952L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(100);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        double double3 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.6330277796015017d) + "'", double3 == (-0.6330277796015017d));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1.18995704E8f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.18995704E8d + "'", double1 == 1.18995704E8d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp3.power10K((-330906329));
        int int11 = dfp10.log10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.divide(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp15.power10K((-330906329));
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField24.getESplit();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField24.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp33.divide(dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp33.power10K((-330906329));
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField24.newDfp(dfp40);
        java.lang.Object obj42 = null;
        boolean boolean43 = dfp41.equals(obj42);
        boolean boolean44 = dfp41.isInfinite();
        boolean boolean45 = dfp22.lessThan(dfp41);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp49.divide(dfp53);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Number number57 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable55, (java.lang.Number) (-0.5440211108893698d), number57, false);
        org.apache.commons.math.exception.util.Localizable localizable60 = numberIsTooSmallException59.getGeneralPattern();
        java.lang.Number number61 = numberIsTooSmallException59.getMin();
        java.lang.String str62 = numberIsTooSmallException59.toString();
        org.apache.commons.math.exception.util.Localizable localizable63 = numberIsTooSmallException59.getGeneralPattern();
        boolean boolean64 = dfp54.equals((java.lang.Object) localizable63);
        boolean boolean65 = dfp41.greaterThan(dfp54);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp10.nextAfter(dfp54);
        org.apache.commons.math.dfp.Dfp dfp68 = dfp66.newInstance((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getLn2();
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField70.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode73 = dfpField70.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode74 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField70.setRoundingMode(roundingMode74);
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField70.newDfp((double) (-5798740597388316909L));
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField70.getLn2();
        org.apache.commons.math.dfp.Dfp dfp79 = dfp66.subtract(dfp78);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1323625316) + "'", int11 == (-1323625316));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str62.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable63.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertTrue("'" + roundingMode73 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode73.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode74 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode74.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp79);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) -1, 0.552952320082456d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
        int[] intArray2 = null;
        mersenneTwister1.setSeed(intArray2);
        mersenneTwister1.setSeed((-8422692239103173864L));
        mersenneTwister1.setSeed(0);
        mersenneTwister1.setSeed((long) 1823289175);
        mersenneTwister1.setSeed(783014952);
        int int13 = mersenneTwister1.nextInt(1764015537);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1695908574 + "'", int13 == 1695908574);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int int2 = org.apache.commons.math.util.FastMath.max((-1961060856), 1764015537);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1764015537 + "'", int2 == 1764015537);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) 0.8681892f, true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.500397838441971d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3532569106508485d + "'", double1 == 2.3532569106508485d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.divide(dfp17);
        boolean boolean19 = dfp9.greaterThan(dfp17);
        boolean boolean20 = dfp9.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp9.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10(619196946);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.divide(dfp12);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (-0.5440211108893698d), number16, false);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        java.lang.Number number20 = numberIsTooSmallException18.getMin();
        java.lang.String str21 = numberIsTooSmallException18.toString();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException18.getGeneralPattern();
        boolean boolean23 = dfp13.equals((java.lang.Object) localizable22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.newInstance((byte) 0);
        int int26 = dfp25.log10K();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField1.newDfp(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp25.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField30.getESplit();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField30.getLn10();
        int int36 = dfp35.log10();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp40.divide(dfp44);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Number number48 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable46, (java.lang.Number) (-0.5440211108893698d), number48, false);
        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooSmallException50.getGeneralPattern();
        java.lang.Number number52 = numberIsTooSmallException50.getMin();
        java.lang.String str53 = numberIsTooSmallException50.toString();
        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooSmallException50.getGeneralPattern();
        boolean boolean55 = dfp45.equals((java.lang.Object) localizable54);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp45.newInstance((long) 'a');
        org.apache.commons.math.dfp.Dfp dfp58 = org.apache.commons.math.dfp.Dfp.copysign(dfp35, dfp57);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp28.subtract(dfp58);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp58.floor();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str21.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str53.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.rint();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.floor();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.divide(dfp19);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) (-0.5440211108893698d), number23, false);
        org.apache.commons.math.exception.util.Localizable localizable26 = numberIsTooSmallException25.getGeneralPattern();
        java.lang.Number number27 = numberIsTooSmallException25.getMin();
        java.lang.String str28 = numberIsTooSmallException25.toString();
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooSmallException25.getGeneralPattern();
        boolean boolean30 = dfp20.equals((java.lang.Object) localizable29);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp20.newInstance((byte) 0);
        int int33 = dfp32.log10K();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.power10(0);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp11.subtract(dfp35);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp11.rint();
        int int40 = dfp39.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp39.newInstance("1.000000000000e-1323625316");
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField44.getESplit();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField44.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField44.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField55.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp53.divide(dfp57);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp53.power10K((-330906329));
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField44.newDfp(dfp60);
        java.lang.Object obj62 = null;
        boolean boolean63 = dfp61.equals(obj62);
        boolean boolean64 = dfp61.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField66.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray69 = dfpField66.getESplit();
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField66.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField66.getLn10();
        int int72 = dfp71.log10();
        org.apache.commons.math.dfp.DfpField dfpField74 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField74.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField78 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField78.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp81 = dfp76.divide(dfp80);
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        java.lang.Number number84 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException86 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable82, (java.lang.Number) (-0.5440211108893698d), number84, false);
        org.apache.commons.math.exception.util.Localizable localizable87 = numberIsTooSmallException86.getGeneralPattern();
        java.lang.Number number88 = numberIsTooSmallException86.getMin();
        java.lang.String str89 = numberIsTooSmallException86.toString();
        org.apache.commons.math.exception.util.Localizable localizable90 = numberIsTooSmallException86.getGeneralPattern();
        boolean boolean91 = dfp81.equals((java.lang.Object) localizable90);
        org.apache.commons.math.dfp.Dfp dfp93 = dfp81.newInstance((long) 'a');
        org.apache.commons.math.dfp.Dfp dfp94 = org.apache.commons.math.dfp.Dfp.copysign(dfp71, dfp93);
        boolean boolean95 = dfp61.unequal(dfp94);
        org.apache.commons.math.dfp.Dfp dfp97 = dfp94.power10K(16);
        org.apache.commons.math.dfp.Dfp dfp98 = dfp42.multiply(dfp97);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str28.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfpArray47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfpArray69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertTrue("'" + localizable87 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable87.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number88);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str89.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable90 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable90.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(dfp93);
        org.junit.Assert.assertNotNull(dfp94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertNotNull(dfp97);
        org.junit.Assert.assertNotNull(dfp98);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) 8, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100, (byte) 100, roundingMode8, 0.17453292519943295d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable4, localizable5, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) 8, true);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode22 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 100, (byte) 100, roundingMode22, 0.17453292519943295d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException17, localizable18, localizable19, objArray24);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException26 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException11, localizable12, localizable13, objArray24);
        java.lang.Throwable[] throwableArray27 = mathRuntimeException26.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable28 = mathRuntimeException26.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + roundingMode22 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode22.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNull(localizable28);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        dfpField1.setIEEEFlags((-1323625316));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField5.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField5.newDfp(dfp11);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField5.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField5.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField5.newDfp();
        boolean boolean22 = dfp3.unequal(dfp21);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-89.2328896037985d) + "'", double1 == (-89.2328896037985d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        long long1 = org.apache.commons.math.util.FastMath.round(5.184705528587073E21d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-32767), (-0.6658729011025105d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.570816648243336d) + "'", double2 == (-1.570816648243336d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        int int6 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.divide(dfp11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp7);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        int int6 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.atan(2979.3805346802806d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5704606865667323d + "'", double1 == 1.5704606865667323d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (-0.5440211108893698d), number11, false);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException13.getGeneralPattern();
        java.lang.Number number15 = numberIsTooSmallException13.getMin();
        java.lang.String str16 = numberIsTooSmallException13.toString();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException13.getGeneralPattern();
        boolean boolean18 = dfp8.equals((java.lang.Object) localizable17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp8.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp24.divide(dfp28);
        boolean boolean30 = dfp8.lessThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp28.rint();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField33.getESplit();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField33.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp42.divide(dfp46);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp42.power10K((-330906329));
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField33.newDfp(dfp49);
        java.lang.Object obj51 = null;
        boolean boolean52 = dfp50.equals(obj51);
        boolean boolean53 = dfp50.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp31.newInstance(dfp50);
        int int55 = dfp31.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str16.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 4 + "'", int55 == 4);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.divide(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.power10K((-330906329));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp17);
        java.lang.Object obj19 = null;
        boolean boolean20 = dfp18.equals(obj19);
        boolean boolean21 = dfp18.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField23.getESplit();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.getLn10();
        int int29 = dfp28.log10();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp33.divide(dfp37);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) (-0.5440211108893698d), number41, false);
        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooSmallException43.getGeneralPattern();
        java.lang.Number number45 = numberIsTooSmallException43.getMin();
        java.lang.String str46 = numberIsTooSmallException43.toString();
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooSmallException43.getGeneralPattern();
        boolean boolean48 = dfp38.equals((java.lang.Object) localizable47);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp38.newInstance((long) 'a');
        org.apache.commons.math.dfp.Dfp dfp51 = org.apache.commons.math.dfp.Dfp.copysign(dfp28, dfp50);
        boolean boolean52 = dfp18.unequal(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.power10K(16);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp51.newInstance(89.42706130231652d);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp51.newInstance(8L);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str46.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 15920179, (java.lang.Number) 8, false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp("10.");
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.divide(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.negate();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.divide(dfp29);
        boolean boolean31 = dfp21.greaterThan(dfp29);
        boolean boolean32 = dfp21.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField33 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp39.divide(dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp39.negate();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp45.rint();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.newInstance();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp46.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp50 = org.apache.commons.math.dfp.DfpField.computeExp(dfp35, dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField1.newDfp(dfp50);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfpField33);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.divide(dfp12);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (-0.5440211108893698d), number16, false);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        java.lang.Number number20 = numberIsTooSmallException18.getMin();
        java.lang.String str21 = numberIsTooSmallException18.toString();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException18.getGeneralPattern();
        boolean boolean23 = dfp13.equals((java.lang.Object) localizable22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.newInstance((byte) 0);
        int int26 = dfp25.log10K();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField1.newDfp(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp25.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField30.getESplit();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField30.getLn10();
        int int36 = dfp35.log10();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp40.divide(dfp44);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Number number48 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable46, (java.lang.Number) (-0.5440211108893698d), number48, false);
        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooSmallException50.getGeneralPattern();
        java.lang.Number number52 = numberIsTooSmallException50.getMin();
        java.lang.String str53 = numberIsTooSmallException50.toString();
        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooSmallException50.getGeneralPattern();
        boolean boolean55 = dfp45.equals((java.lang.Object) localizable54);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp45.newInstance((long) 'a');
        org.apache.commons.math.dfp.Dfp dfp58 = org.apache.commons.math.dfp.Dfp.copysign(dfp35, dfp57);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp28.subtract(dfp58);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp58.newInstance((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp65 = null;
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getZero();
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField67.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp58.dotrap((int) 'a', "org.apache.commons.math.exception.MathRuntimeException: ", dfp65, dfp70);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str21.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str53.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 2, (byte) 0, (byte) 10 };
        mersenneTwister0.nextBytes(byteArray5);
        boolean boolean7 = mersenneTwister0.nextBoolean();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
        int int2 = mersenneTwister1.nextInt();
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister3.setSeed((int) (short) 100);
        int[] intArray9 = new int[] { 0, (short) 10, (-32767) };
        mersenneTwister3.setSeed(intArray9);
        mersenneTwister1.setSeed(intArray9);
        double double12 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed(0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1937831252) + "'", int2 == (-1937831252));
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.6595609059416365d + "'", double12 == 0.6595609059416365d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int int2 = org.apache.commons.math.util.FastMath.min(32768, (-1961060856));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1961060856) + "'", int2 == (-1961060856));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.5704606865667323d, 2005.3522829578812d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.831344042933204E-4d + "'", double2 == 7.831344042933204E-4d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        int int7 = dfp5.classify();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.floor();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.divide(dfp12);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (-0.5440211108893698d), number16, false);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        java.lang.Number number20 = numberIsTooSmallException18.getMin();
        java.lang.String str21 = numberIsTooSmallException18.toString();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException18.getGeneralPattern();
        boolean boolean23 = dfp13.equals((java.lang.Object) localizable22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.newInstance((byte) 0);
        int int26 = dfp25.log10K();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField1.newDfp(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str21.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.divide(dfp17);
        boolean boolean19 = dfp9.greaterThan(dfp17);
        double[] doubleArray20 = dfp17.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (-0.5440211108893698d), number11, false);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException13.getGeneralPattern();
        java.lang.Number number15 = numberIsTooSmallException13.getMin();
        java.lang.String str16 = numberIsTooSmallException13.toString();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException13.getGeneralPattern();
        boolean boolean18 = dfp8.equals((java.lang.Object) localizable17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp8.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp24.divide(dfp28);
        boolean boolean30 = dfp8.lessThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp8.power10K((-1323625316));
        int int33 = dfp8.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str16.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.rint();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.divide((int) '4');
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField15.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp22.divide(dfp26);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) (-0.5440211108893698d), number30, false);
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooSmallException32.getGeneralPattern();
        java.lang.Number number34 = numberIsTooSmallException32.getMin();
        java.lang.String str35 = numberIsTooSmallException32.toString();
        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooSmallException32.getGeneralPattern();
        boolean boolean37 = dfp27.equals((java.lang.Object) localizable36);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp27.newInstance((byte) 0);
        int int40 = dfp39.log10K();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField15.newDfp(dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp39.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField44.getESplit();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField44.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField44.getLn10();
        int int50 = dfp49.log10();
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp54.divide(dfp58);
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        java.lang.Number number62 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException64 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable60, (java.lang.Number) (-0.5440211108893698d), number62, false);
        org.apache.commons.math.exception.util.Localizable localizable65 = numberIsTooSmallException64.getGeneralPattern();
        java.lang.Number number66 = numberIsTooSmallException64.getMin();
        java.lang.String str67 = numberIsTooSmallException64.toString();
        org.apache.commons.math.exception.util.Localizable localizable68 = numberIsTooSmallException64.getGeneralPattern();
        boolean boolean69 = dfp59.equals((java.lang.Object) localizable68);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp59.newInstance((long) 'a');
        org.apache.commons.math.dfp.Dfp dfp72 = org.apache.commons.math.dfp.Dfp.copysign(dfp49, dfp71);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp42.subtract(dfp72);
        int int74 = dfp42.log10();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp42.newInstance("1.000000000000e-1323625316");
        org.apache.commons.math.dfp.Dfp dfp77 = org.apache.commons.math.dfp.Dfp.copysign(dfp13, dfp42);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str35.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfpArray47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + localizable65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable65.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str67.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable68 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable68.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 15920179, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.5920179E7f + "'", float2 == 1.5920179E7f);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) (-5798740597388316909L));
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1937831252), (java.lang.Number) (-0.5063656411097588d), true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (-0.5440211108893698d), number6, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException8.getSpecificPattern();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        boolean boolean12 = numberIsTooSmallException8.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 2, (byte) 0, (byte) 10 };
        mersenneTwister0.nextBytes(byteArray5);
        mersenneTwister0.setSeed((long) (byte) 2);
        int int9 = mersenneTwister0.nextInt();
        double double10 = mersenneTwister0.nextDouble();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 49182197 + "'", int9 == 49182197);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.48674462267234375d + "'", double10 == 0.48674462267234375d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.divide(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.power10K((-330906329));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField20 = dfp19.getField();
        boolean boolean21 = dfp19.isInfinite();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.divide(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.power10K((-330906329));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp17);
        java.lang.Object obj19 = null;
        boolean boolean20 = dfp18.equals(obj19);
        boolean boolean21 = dfp18.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField23.getESplit();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.getLn10();
        int int29 = dfp28.log10();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp33.divide(dfp37);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) (-0.5440211108893698d), number41, false);
        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooSmallException43.getGeneralPattern();
        java.lang.Number number45 = numberIsTooSmallException43.getMin();
        java.lang.String str46 = numberIsTooSmallException43.toString();
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooSmallException43.getGeneralPattern();
        boolean boolean48 = dfp38.equals((java.lang.Object) localizable47);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp38.newInstance((long) 'a');
        org.apache.commons.math.dfp.Dfp dfp51 = org.apache.commons.math.dfp.Dfp.copysign(dfp28, dfp50);
        boolean boolean52 = dfp18.unequal(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.power10K(16);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray59 = dfpField56.getESplit();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField56.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField56.getLn10();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField56.newDfp(10);
        int int64 = dfp63.intValue();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp63.negate();
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField71.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp69.divide(dfp73);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp69.negate();
        int int76 = dfp69.log10K();
        org.apache.commons.math.dfp.Dfp dfp78 = dfp69.newInstance((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp79 = dfp65.divide(dfp78);
        boolean boolean80 = dfp51.unequal(dfp79);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str46.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfpArray59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 10 + "'", int64 == 10);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1323625316));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8341755376871028d + "'", double1 == 0.8341755376871028d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 10 + "'", number4.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.4901161193847656E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.rint();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.newInstance();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.ceil();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 5.298292365610486d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) 8, true);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException7.getSpecificPattern();
        java.lang.Class<?> wildcardClass9 = numberIsTooSmallException7.getClass();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number11 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 5.298292365610486d + "'", number11.equals(5.298292365610486d));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.5963239324915818d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Object[] objArray3 = notStrictlyPositiveException1.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField2.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp4.divide(dfp8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.negate();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.rint();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.divide((int) '4');
        try {
            org.apache.commons.math.dfp.Dfp dfp15 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-0.5440211108893698d), number2, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray6);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (-8422692239103173864L));
        org.apache.commons.math.exception.util.Localizable localizable10 = notStrictlyPositiveException9.getGeneralPattern();
        java.lang.Number number11 = notStrictlyPositiveException9.getArgument();
        java.lang.Number number12 = notStrictlyPositiveException9.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException9);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-8422692239103173864L) + "'", number11.equals((-8422692239103173864L)));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0 + "'", number12.equals(0));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) (-5798740597388316909L));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-4), (float) 4);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        int int7 = dfpField6.getIEEEFlags();
        dfpField6.setIEEEFlags(8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.getZero();
        dfpField6.setIEEEFlagsBits((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField6.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField6.getSqr2();
        int int15 = dfp14.log10K();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.43926598589774446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3572724245717709d) + "'", double1 == (-0.3572724245717709d));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        int int2 = org.apache.commons.math.util.FastMath.max(5, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1.091878406267369d), (-1.5331331785233413d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.divide(dfp17);
        boolean boolean19 = dfp9.greaterThan(dfp17);
        boolean boolean20 = dfp9.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp9.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp((byte) 0);
        int int25 = dfp24.intValue();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("hi!");
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("-10.");
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 5.298292365610486d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) 8, true);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException7.getSpecificPattern();
        java.lang.Class<?> wildcardClass9 = numberIsTooSmallException7.getClass();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number11 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) (-0.5440211108893698d), number14, false);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) (-0.5440211108893698d), number20, false);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException22.getGeneralPattern();
        java.lang.Number number24 = numberIsTooSmallException22.getMin();
        java.lang.String str25 = numberIsTooSmallException22.toString();
        org.apache.commons.math.exception.util.Localizable localizable26 = numberIsTooSmallException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) (-0.5440211108893698d), number29, false);
        org.apache.commons.math.exception.util.Localizable localizable32 = numberIsTooSmallException31.getGeneralPattern();
        java.lang.Number number33 = numberIsTooSmallException31.getMin();
        java.lang.String str34 = numberIsTooSmallException31.toString();
        org.apache.commons.math.exception.util.Localizable localizable35 = numberIsTooSmallException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) 8, true);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode45 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 100, (byte) 100, roundingMode45, 0.17453292519943295d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException40, localizable41, localizable42, objArray47);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) 8, true);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode59 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        java.lang.Object[] objArray61 = new java.lang.Object[] { 100, (byte) 100, roundingMode59, 0.17453292519943295d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException62 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException54, localizable55, localizable56, objArray61);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException63 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException48, localizable49, localizable50, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray61);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException65 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException16, localizable26, localizable35, objArray61);
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Number number68 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException70 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable66, (java.lang.Number) (-0.5440211108893698d), number68, false);
        org.apache.commons.math.exception.util.Localizable localizable71 = numberIsTooSmallException70.getGeneralPattern();
        java.lang.Number number72 = numberIsTooSmallException70.getMin();
        java.lang.String str73 = numberIsTooSmallException70.toString();
        org.apache.commons.math.exception.util.Localizable localizable74 = numberIsTooSmallException70.getGeneralPattern();
        java.lang.Object[] objArray75 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException76 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable35, localizable74, objArray75);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException77 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException76);
        java.lang.String str78 = mathRuntimeException76.toString();
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.0f) + "'", number11.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str25.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str34.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + roundingMode45 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode45.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + roundingMode59 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode59.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str73.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable74.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: {0} is smaller than, or equal to, the minimum ({1}): {0} is smaller than, or equal to, the minimum ({1})" + "'", str78.equals("org.apache.commons.math.exception.MathRuntimeException: {0} is smaller than, or equal to, the minimum ({1}): {0} is smaller than, or equal to, the minimum ({1})"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getOne();
        int int3 = dfp2.intValue();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.divide(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp7.power10K((-330906329));
        double double15 = dfp7.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp19.divide(dfp23);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) (-0.5440211108893698d), number27, false);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException29.getGeneralPattern();
        java.lang.Number number31 = numberIsTooSmallException29.getMin();
        java.lang.String str32 = numberIsTooSmallException29.toString();
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooSmallException29.getGeneralPattern();
        boolean boolean34 = dfp24.equals((java.lang.Object) localizable33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp24.newInstance((byte) 0);
        int int37 = dfp36.log10K();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp36.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp40 = dfp7.multiply(dfp36);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp2.multiply(dfp36);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str32.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.rint();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.floor();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.divide(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.negate();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.divide(dfp29);
        boolean boolean31 = dfp21.greaterThan(dfp29);
        boolean boolean32 = dfp21.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.Dfp.copysign(dfp9, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray38 = dfpField35.getESplit();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField35.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp44.divide(dfp48);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp44.power10K((-330906329));
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField35.newDfp(dfp51);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField35.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp21.remainder(dfp53);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfpArray38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.divide(dfp11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp6.newInstance((double) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.newInstance((byte) 10);
        int int15 = dfp14.classify();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.negate();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.rint();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp23.divide(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp23.negate();
        int int30 = dfp23.log10K();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp23.newInstance((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.divide(dfp40);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Number number44 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) (-0.5440211108893698d), number44, false);
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooSmallException46.getGeneralPattern();
        java.lang.Number number48 = numberIsTooSmallException46.getMin();
        java.lang.String str49 = numberIsTooSmallException46.toString();
        org.apache.commons.math.exception.util.Localizable localizable50 = numberIsTooSmallException46.getGeneralPattern();
        boolean boolean51 = dfp41.equals((java.lang.Object) localizable50);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp23.newInstance(dfp41);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp19.divide(dfp23);
        int int54 = dfp19.intValue();
        boolean boolean55 = dfp7.unequal(dfp19);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str49.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        int int8 = dfp7.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.divide(dfp12);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (-0.5440211108893698d), number16, false);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        java.lang.Number number20 = numberIsTooSmallException18.getMin();
        java.lang.String str21 = numberIsTooSmallException18.toString();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException18.getGeneralPattern();
        boolean boolean23 = dfp13.equals((java.lang.Object) localizable22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.newInstance((byte) 0);
        int int26 = dfp25.log10K();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField1.newDfp(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField1.newDfp((byte) -1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str21.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp32);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        int int2 = org.apache.commons.math.util.FastMath.max(20, (-330906329));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1695908574, (float) (-32767));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.69590861E9f + "'", float2 == 1.69590861E9f);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.divide(dfp11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray18);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("1.000000000000e-1323625316");
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance(783014952);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.divide(dfp17);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) (-0.5440211108893698d), number21, false);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooSmallException23.getGeneralPattern();
        java.lang.Number number25 = numberIsTooSmallException23.getMin();
        java.lang.String str26 = numberIsTooSmallException23.toString();
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException23.getGeneralPattern();
        boolean boolean28 = dfp18.equals((java.lang.Object) localizable27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp18.newInstance((byte) 0);
        int int31 = dfp30.log10K();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp30.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.power10(0);
        org.apache.commons.math.dfp.Dfp dfp36 = org.apache.commons.math.dfp.Dfp.copysign(dfp9, dfp35);
        boolean boolean37 = dfp35.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str26.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        int int10 = dfp3.log10K();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp3.newInstance((byte) 2);
        double[] doubleArray13 = dfp12.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.newInstance(0.017454178737585174d);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp3.power10K((-330906329));
        double double11 = dfp3.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.divide(dfp19);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) (-0.5440211108893698d), number23, false);
        org.apache.commons.math.exception.util.Localizable localizable26 = numberIsTooSmallException25.getGeneralPattern();
        java.lang.Number number27 = numberIsTooSmallException25.getMin();
        java.lang.String str28 = numberIsTooSmallException25.toString();
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooSmallException25.getGeneralPattern();
        boolean boolean30 = dfp20.equals((java.lang.Object) localizable29);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp20.newInstance((byte) 0);
        int int33 = dfp32.log10K();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp36 = dfp3.multiply(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp40.divide(dfp44);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Number number48 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable46, (java.lang.Number) (-0.5440211108893698d), number48, false);
        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooSmallException50.getGeneralPattern();
        java.lang.Number number52 = numberIsTooSmallException50.getMin();
        java.lang.String str53 = numberIsTooSmallException50.toString();
        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooSmallException50.getGeneralPattern();
        boolean boolean55 = dfp45.equals((java.lang.Object) localizable54);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp45.newInstance((long) 'a');
        org.apache.commons.math.dfp.Dfp dfp58 = dfp36.add(dfp57);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str28.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str53.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.4901161193847656E-8d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.divide(dfp12);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (-0.5440211108893698d), number16, false);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        java.lang.Number number20 = numberIsTooSmallException18.getMin();
        java.lang.String str21 = numberIsTooSmallException18.toString();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException18.getGeneralPattern();
        boolean boolean23 = dfp13.equals((java.lang.Object) localizable22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.newInstance((byte) 0);
        int int26 = dfp25.log10K();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField1.newDfp(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField1.newDfp(5.551115123125783E-17d);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str21.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((-1937831252L));
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.newInstance((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = new org.apache.commons.math.dfp.Dfp(dfp16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.divide(dfp12);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (-0.5440211108893698d), number16, false);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        java.lang.Number number20 = numberIsTooSmallException18.getMin();
        java.lang.String str21 = numberIsTooSmallException18.toString();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException18.getGeneralPattern();
        boolean boolean23 = dfp13.equals((java.lang.Object) localizable22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.newInstance((byte) 0);
        int int26 = dfp25.log10K();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField1.newDfp(dfp25);
        int int28 = dfpField1.getIEEEFlags();
        int int29 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str21.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10000, (java.lang.Number) 1.18995704E8d, false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.divide(dfp11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray19);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        dfpField1.setIEEEFlags(20);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((int) (short) 100);
        long long3 = mersenneTwister0.nextLong();
        long long4 = mersenneTwister0.nextLong();
        int int5 = mersenneTwister0.nextInt();
        int[] intArray8 = new int[] { '#', '#' };
        mersenneTwister0.setSeed(intArray8);
        boolean boolean10 = mersenneTwister0.nextBoolean();
        double double11 = mersenneTwister0.nextDouble();
        mersenneTwister0.setSeed((-1323625316L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-8422692239103173864L) + "'", long3 == (-8422692239103173864L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5135008762804559719L + "'", long4 == 5135008762804559719L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1823289175 + "'", int5 == 1823289175);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.21799404928584054d + "'", double11 == 0.21799404928584054d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(6.0d);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 10000, (long) 49182197);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 49182197L + "'", long2 == 49182197L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        long long1 = org.apache.commons.math.util.FastMath.round(1.4901161193847656E-8d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1937831252L), (float) (-1937831252L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.9378313E9f) + "'", float2 == (-1.9378313E9f));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(10);
        int int9 = dfp8.intValue();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.negate();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField12.getESplit();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp16.getField();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((-1937831252L));
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.newInstance((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp19.newInstance(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.Dfp.copysign(dfp10, dfp19);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp10.newInstance((byte) -1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpField17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1634394751));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (-0.5440211108893698d), number11, false);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException13.getGeneralPattern();
        java.lang.Number number15 = numberIsTooSmallException13.getMin();
        java.lang.String str16 = numberIsTooSmallException13.toString();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException13.getGeneralPattern();
        boolean boolean18 = dfp8.equals((java.lang.Object) localizable17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp8.newInstance((long) 'a');
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp8.getField();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp8.newInstance((byte) 2, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp8.negate();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.power10K(8);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str16.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.divide(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.power10K((-330906329));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp17.newInstance((long) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = new org.apache.commons.math.dfp.Dfp(dfp17);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance((double) 1.0f);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 0.417022f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.39509384206073767d + "'", double1 == 0.39509384206073767d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-0.5440211108893698d), number2, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        java.lang.String str7 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField10.getRoundingMode();
        int int13 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField10.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, (java.lang.Object[]) dfpArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) (-0.5440211108893698d), number18, false);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException20.getGeneralPattern();
        java.lang.Number number22 = numberIsTooSmallException20.getMin();
        java.lang.String str23 = numberIsTooSmallException20.toString();
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooSmallException20.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField26.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, (java.lang.Object[]) dfpArray29);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) 2.6881171418161356E43d, (java.lang.Number) 1.5707963579674198d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1937831252), (java.lang.Number) (-0.5063656411097588d), true);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) (-0.5440211108893698d), number41, false);
        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooSmallException43.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException43.getSpecificPattern();
        numberIsTooSmallException38.addSuppressed((java.lang.Throwable) numberIsTooSmallException43);
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooSmallException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException49 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.18995704E8f));
        java.lang.Object[] objArray50 = notStrictlyPositiveException49.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException15, localizable24, localizable47, objArray50);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str23.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable45);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray50);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn5();
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister10.setSeed((int) (short) 100);
        long long13 = mersenneTwister10.nextLong();
        long long14 = mersenneTwister10.nextLong();
        int int15 = mersenneTwister10.nextInt();
        int[] intArray18 = new int[] { '#', '#' };
        mersenneTwister10.setSeed(intArray18);
        boolean boolean20 = mersenneTwister10.nextBoolean();
        double double21 = mersenneTwister10.nextDouble();
        boolean boolean22 = dfp9.equals((java.lang.Object) mersenneTwister10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-8422692239103173864L) + "'", long13 == (-8422692239103173864L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5135008762804559719L + "'", long14 == 5135008762804559719L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1823289175 + "'", int15 == 1823289175);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.21799404928584054d + "'", double21 == 0.21799404928584054d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (-0.5440211108893698d), number11, false);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException13.getGeneralPattern();
        java.lang.Number number15 = numberIsTooSmallException13.getMin();
        java.lang.String str16 = numberIsTooSmallException13.toString();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException13.getGeneralPattern();
        boolean boolean18 = dfp8.equals((java.lang.Object) localizable17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp8.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp24.divide(dfp28);
        boolean boolean30 = dfp8.lessThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp8.power10K((-1323625316));
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField34.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp41.divide(dfp45);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        java.lang.Number number49 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable47, (java.lang.Number) (-0.5440211108893698d), number49, false);
        org.apache.commons.math.exception.util.Localizable localizable52 = numberIsTooSmallException51.getGeneralPattern();
        java.lang.Number number53 = numberIsTooSmallException51.getMin();
        java.lang.String str54 = numberIsTooSmallException51.toString();
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException51.getGeneralPattern();
        boolean boolean56 = dfp46.equals((java.lang.Object) localizable55);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp46.newInstance((byte) 0);
        int int59 = dfp58.log10K();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField34.newDfp(dfp58);
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField34.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode62 = dfpField34.getRoundingMode();
        int int63 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField34.newDfp("1.000000000000e-1323625316");
        org.apache.commons.math.dfp.Dfp dfp66 = dfp8.subtract(dfp65);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str16.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str54.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + roundingMode62 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode62.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 16 + "'", int63 == 16);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3953649341158527d + "'", double1 == 1.3953649341158527d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
        int[] intArray2 = null;
        mersenneTwister1.setSeed(intArray2);
        mersenneTwister1.setSeed((-8422692239103173864L));
        long long6 = mersenneTwister1.nextLong();
        mersenneTwister1.setSeed((long) 5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-686597072755548799L) + "'", long6 == (-686597072755548799L));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) (-0.5440211108893698d), number3, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 1.0d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) 8, true);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 100, (byte) 100, roundingMode19, 0.17453292519943295d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException14, localizable15, localizable16, objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray21);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) (-0.5440211108893698d), false);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) (-0.5440211108893698d), number30, false);
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooSmallException32.getGeneralPattern();
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray34);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) (-8422692239103173864L));
        org.apache.commons.math.exception.util.Localizable localizable38 = notStrictlyPositiveException37.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp42.divide(dfp46);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Number number50 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException52 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable48, (java.lang.Number) (-0.5440211108893698d), number50, false);
        org.apache.commons.math.exception.util.Localizable localizable53 = numberIsTooSmallException52.getGeneralPattern();
        java.lang.Number number54 = numberIsTooSmallException52.getMin();
        java.lang.String str55 = numberIsTooSmallException52.toString();
        org.apache.commons.math.exception.util.Localizable localizable56 = numberIsTooSmallException52.getGeneralPattern();
        boolean boolean57 = dfp47.equals((java.lang.Object) localizable56);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Number number60 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException62 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable58, (java.lang.Number) (-0.5440211108893698d), number60, false);
        org.apache.commons.math.exception.util.Localizable localizable63 = numberIsTooSmallException62.getGeneralPattern();
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, objArray64);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException67 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable63, (java.lang.Number) (-8422692239103173864L));
        java.lang.Object[] objArray68 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, localizable63, objArray68);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) 8, true);
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode78 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        java.lang.Object[] objArray80 = new java.lang.Object[] { 100, (byte) 100, roundingMode78, 0.17453292519943295d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException81 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException73, localizable74, localizable75, objArray80);
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        org.apache.commons.math.exception.util.Localizable localizable83 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException87 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) 8, true);
        org.apache.commons.math.exception.util.Localizable localizable88 = null;
        org.apache.commons.math.exception.util.Localizable localizable89 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode92 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        java.lang.Object[] objArray94 = new java.lang.Object[] { 100, (byte) 100, roundingMode92, 0.17453292519943295d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException95 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException87, localizable88, localizable89, objArray94);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException96 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException81, localizable82, localizable83, objArray94);
        java.lang.Throwable[] throwableArray97 = mathRuntimeException96.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException98 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, (java.lang.Object[]) throwableArray97);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException99 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable6, localizable38, (java.lang.Object[]) throwableArray97);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str55.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable56.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + localizable63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable63.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + roundingMode78 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode78.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertTrue("'" + roundingMode92 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode92.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(objArray94);
        org.junit.Assert.assertNotNull(throwableArray97);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp("10.");
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.divide(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.negate();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.divide(dfp29);
        boolean boolean31 = dfp21.greaterThan(dfp29);
        boolean boolean32 = dfp21.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField33 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp39.divide(dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp39.negate();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp45.rint();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.newInstance();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp46.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp50 = org.apache.commons.math.dfp.DfpField.computeExp(dfp35, dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField1.newDfp(dfp50);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField1.newDfp((int) (byte) 1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfpField33);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp53);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getOne();
        dfpField1.setIEEEFlags(1764015537);
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.19543322022264134d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19298251956599977d + "'", double1 == 0.19298251956599977d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp3.power10K((-330906329));
        double double11 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp3.newInstance((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp17.divide(dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.divide(dfp17);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 783014952, (java.lang.Number) 0.2158376f, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (-0.5440211108893698d), number6, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) (-8422692239103173864L));
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException13.getGeneralPattern();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException13);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-8422692239103173864L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.718281828459045d, (java.lang.Number) (byte) 100, false);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 2.718 is smaller than, or equal to, the minimum (100)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 2.718 is smaller than, or equal to, the minimum (100)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 2.718281828459045d + "'", number6.equals(2.718281828459045d));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.divide(dfp12);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (-0.5440211108893698d), number16, false);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        java.lang.Number number20 = numberIsTooSmallException18.getMin();
        java.lang.String str21 = numberIsTooSmallException18.toString();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException18.getGeneralPattern();
        boolean boolean23 = dfp13.equals((java.lang.Object) localizable22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.newInstance((byte) 0);
        int int26 = dfp25.log10K();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField1.newDfp(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField31.getESplit();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField31.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField31.getLn10();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField31.newDfp(10);
        dfpField31.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField31.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode42 = dfpField31.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode42);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str21.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + roundingMode42 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode42.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (-0.5440211108893698d), number11, false);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException13.getGeneralPattern();
        java.lang.Number number15 = numberIsTooSmallException13.getMin();
        java.lang.String str16 = numberIsTooSmallException13.toString();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException13.getGeneralPattern();
        boolean boolean18 = dfp8.equals((java.lang.Object) localizable17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp8.newInstance((long) 'a');
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp8.getField();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((double) (-8736701459191349328L));
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp("-10.");
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str16.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.5704606865667323d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.570460686566732d + "'", double2 == 1.570460686566732d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.2041199826559248d);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) notStrictlyPositiveException3);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) -1, (float) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.03700049997605E9d + "'", double1 == 3.03700049997605E9d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.6360918665423811d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.445379335477256d + "'", double1 == 36.445379335477256d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp("10.");
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.divide(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.negate();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.divide(dfp29);
        boolean boolean31 = dfp21.greaterThan(dfp29);
        boolean boolean32 = dfp21.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField33 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp39.divide(dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp39.negate();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp45.rint();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.newInstance();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp46.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp50 = org.apache.commons.math.dfp.DfpField.computeExp(dfp35, dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField1.newDfp(dfp50);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfpField33);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-4));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((-1323625316));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-330906329));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        int int2 = org.apache.commons.math.util.FastMath.min(1066796429, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 2, (byte) 0, (byte) 10 };
        mersenneTwister0.nextBytes(byteArray5);
        mersenneTwister0.setSeed((long) (byte) 2);
        int int9 = mersenneTwister0.nextInt();
        float float10 = mersenneTwister0.nextFloat();
        long long11 = mersenneTwister0.nextLong();
        double double12 = mersenneTwister0.nextGaussian();
        boolean boolean13 = mersenneTwister0.nextBoolean();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 49182197 + "'", int9 == 49182197);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.48674452f + "'", float10 == 0.48674452f);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-5798740597388316909L) + "'", long11 == (-5798740597388316909L));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.34237210095955267d + "'", double12 == 0.34237210095955267d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(20);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(56.52959697507498d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.51861669292131d + "'", double1 == 7.51861669292131d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed(10);
        mersenneTwister0.setSeed((int) '4');
        double double5 = mersenneTwister0.nextDouble();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.823110339393827d + "'", double5 == 0.823110339393827d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1323625316L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9075712110370514d + "'", double1 == 0.9075712110370514d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.divide(dfp11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.newDfp(5.283527526054842E-9d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.divide(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.negate();
        int int16 = dfp9.log10K();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp9.newInstance((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp(dfp9);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.divide(dfp17);
        boolean boolean19 = dfp9.greaterThan(dfp17);
        boolean boolean20 = dfp9.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp9.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.newDfp((-1.5331331785233413d));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.rint();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.floor();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.divide(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.negate();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.divide(dfp29);
        boolean boolean31 = dfp21.greaterThan(dfp29);
        boolean boolean32 = dfp21.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.Dfp.copysign(dfp9, dfp21);
        int int34 = dfp9.classify();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.divide(dfp12);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (-0.5440211108893698d), number16, false);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        java.lang.Number number20 = numberIsTooSmallException18.getMin();
        java.lang.String str21 = numberIsTooSmallException18.toString();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException18.getGeneralPattern();
        boolean boolean23 = dfp13.equals((java.lang.Object) localizable22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.newInstance((byte) 0);
        int int26 = dfp25.log10K();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField1.newDfp(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode29 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str21.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + roundingMode29 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode29.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 2, (byte) 0, (byte) 10 };
        mersenneTwister0.nextBytes(byteArray5);
        mersenneTwister0.setSeed((long) (byte) 2);
        int int9 = mersenneTwister0.nextInt();
        mersenneTwister0.setSeed(1);
        float float12 = mersenneTwister0.nextFloat();
        mersenneTwister0.setSeed(10L);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 49182197 + "'", int9 == 49182197);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.417022f + "'", float12 == 0.417022f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.5963239324915818d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6769409133417883d + "'", double2 == 1.6769409133417883d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp("10.");
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.divide(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.negate();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.divide(dfp29);
        boolean boolean31 = dfp21.greaterThan(dfp29);
        boolean boolean32 = dfp21.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField33 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp39.divide(dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp39.negate();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp45.rint();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.newInstance();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp46.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp50 = org.apache.commons.math.dfp.DfpField.computeExp(dfp35, dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField1.newDfp(dfp50);
        org.apache.commons.math.dfp.Dfp[] dfpArray52 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfpField33);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfpArray52);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide(dfp7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (-0.5440211108893698d), number11, false);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException13.getGeneralPattern();
        java.lang.Number number15 = numberIsTooSmallException13.getMin();
        java.lang.String str16 = numberIsTooSmallException13.toString();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException13.getGeneralPattern();
        boolean boolean18 = dfp8.equals((java.lang.Object) localizable17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp8.newInstance((long) 'a');
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp8.getField();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getLn10();
        int int23 = dfp22.classify();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str16.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.1487579971218467d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 2.1487579971218467d + "'", number2.equals(2.1487579971218467d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1937831252), (java.lang.Number) (-0.5063656411097588d), true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (-0.5440211108893698d), number6, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException8.getSpecificPattern();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.Throwable[] throwableArray13 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(10);
        int int9 = dfp8.intValue();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.negate();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField12.getESplit();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp16.getField();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((-1937831252L));
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.newInstance((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp19.newInstance(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.Dfp.copysign(dfp10, dfp19);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.negate();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpField17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField8.setRoundingMode(roundingMode12);
        dfpField6.setRoundingMode(roundingMode12);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("hi!");
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((double) 49182197);
        java.lang.Class<?> wildcardClass10 = dfpField1.getClass();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(10);
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        dfpField1.setIEEEFlags(9);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 3, 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField7.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp14.divide(dfp18);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) (-0.5440211108893698d), number22, false);
        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooSmallException24.getGeneralPattern();
        java.lang.Number number26 = numberIsTooSmallException24.getMin();
        java.lang.String str27 = numberIsTooSmallException24.toString();
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooSmallException24.getGeneralPattern();
        boolean boolean29 = dfp19.equals((java.lang.Object) localizable28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp19.newInstance((byte) 0);
        int int32 = dfp31.log10K();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField7.newDfp(dfp31);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp31.getTwo();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp5.divide(dfp34);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)" + "'", str27.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.544 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-159860839), (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((double) 9223372036854775807L);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("1.000000000000e-1323625316");
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.negate();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.rint();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp24.power10K((-330906329));
        double double32 = dfp24.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.divide(dfp40);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp36.power10K((-330906329));
        org.apache.commons.math.dfp.Dfp dfp44 = dfp17.dotrap((-118995705), "", dfp24, dfp43);
        boolean boolean45 = dfp7.greaterThan(dfp43);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp43.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField53.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp51.divide(dfp55);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp51.negate();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp57.rint();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp57.floor();
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField61.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField65.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp68 = dfp63.divide(dfp67);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp63.negate();
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField71.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField75.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp73.divide(dfp77);
        boolean boolean79 = dfp69.greaterThan(dfp77);
        boolean boolean80 = dfp69.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp81 = org.apache.commons.math.dfp.Dfp.copysign(dfp57, dfp69);
        org.apache.commons.math.dfp.Dfp dfp82 = org.apache.commons.math.dfp.Dfp.copysign(dfp47, dfp69);
        org.apache.commons.math.dfp.Dfp dfp83 = new org.apache.commons.math.dfp.Dfp(dfp47);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 10.0d + "'", double32 == 10.0d);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
    }
}

