import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 15820024220L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray21.getClass();
        java.lang.Class<?> wildcardClass25 = doubleArray21.getClass();
        double[] doubleArray27 = new double[] { 0.9882067021499548d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray27);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double[] doubleArray35 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray36 = new double[] {};
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray36);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray39 = null;
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray39);
        try {
            double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1769857260) + "'", int30 == (-1769857260));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1763317633 + "'", int38 == 1763317633);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection13, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException15.getDirection();
        java.lang.String str17 = nonMonotonousSequenceException15.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Number number19 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number20 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0 + "'", number19.equals(0));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (short) -1 + "'", number20.equals((short) -1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray20 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray21 = new double[] {};
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray21);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray21);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1763317633 + "'", int7 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(15820024220L, (long) 1072693248);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16892717468L + "'", long2 == 16892717468L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int[] intArray5 = new int[] { (byte) 0, 33, ' ', (short) 0, (byte) 1 };
        int[] intArray12 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray19 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray19);
        int[] intArray27 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray34 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray34);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray12);
        int[] intArray44 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray51 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray51);
        int[] intArray59 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray66 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray66);
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray66);
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray66);
        int[] intArray76 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray83 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double84 = org.apache.commons.math.util.MathUtils.distance(intArray76, intArray83);
        double double85 = org.apache.commons.math.util.MathUtils.distance(intArray66, intArray83);
        int[] intArray86 = null;
        try {
            int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray83, intArray86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 75.82875444051551d + "'", double20 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 75.82875444051551d + "'", double35 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 124 + "'", int36 == 124);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 92 + "'", int37 == 92);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 75.82875444051551d + "'", double52 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 75.82875444051551d + "'", double67 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 124 + "'", int68 == 124);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 68 + "'", int69 == 68);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 75.82875444051551d + "'", double84 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) '4', 0.9665499241544702d, 1.217652850343311d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 330, 56421);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 0L, 1.9855683087099187d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1513055268);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.cos(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double2 = org.apache.commons.math.util.MathUtils.round(4.605170185988092d, 114);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.605170185988092d + "'", double2 == 4.605170185988092d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.Number number1 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 92, (int) '4', orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 81.55795945611504d, number1, (-90), orderDirection6, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection14, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException16.getDirection();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0 + "'", number18.equals(0));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 10, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-22) + "'", int2 == (-22));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 159287153400L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3232425226381688d + "'", double1 == 1.3232425226381688d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 10, (int) ' ');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-22), (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.acos(9.889030319346946E42d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1820);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 33L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.4778563656446977d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3531897806405977d + "'", double1 == 1.3531897806405977d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 33);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1464357978591606E14d + "'", double1 == 2.1464357978591606E14d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double1 = org.apache.commons.math.util.FastMath.floor(904.1968923994399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 904.0d + "'", double1 == 904.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.FastMath.floor((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-58.0d) + "'", double1 == (-58.0d));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.acos(15.104412573075516d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double1 = org.apache.commons.math.util.FastMath.cos(8.684930272989595d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7385712524522046d) + "'", double1 == (-0.7385712524522046d));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (byte) -1, (int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.1f) + "'", float3 == (-1.1f));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(1820);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11846.669319939707d + "'", double1 == 11846.669319939707d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(5.198497031265826d, 48.49772265559348d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1495361471));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 100, 56421);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5642100 + "'", int2 == 5642100);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.38642798511405d, 1078034432, 921088691);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.3156541846684752E35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.00000000000001d + "'", double1 == 52.00000000000001d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        long long2 = org.apache.commons.math.util.MathUtils.pow(100L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-788545902));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) -1, (double) 99L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.0d + "'", double2 == 99.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1820));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8509826923271134d + "'", double1 == 0.8509826923271134d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-0.8980433709785038d), 330, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 56420);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1860947059), (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1860947058L) + "'", long2 == (-1860947058L));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number12 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection16, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException18.getDirection();
        java.lang.String str20 = nonMonotonousSequenceException18.toString();
        boolean boolean21 = nonMonotonousSequenceException18.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException18.getDirection();
        java.lang.Throwable[] throwableArray23 = nonMonotonousSequenceException18.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        int int25 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0 + "'", number12.equals(0));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.644298430695373d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.990383726223826d + "'", double1 == 51.990383726223826d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        int[] intArray6 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray13 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int[] intArray15 = null;
        try {
            double double16 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 75.82875444051551d + "'", double14 == 75.82875444051551d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2.1464357978591606E14d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7209306275075234E44d + "'", double2 == 2.7209306275075234E44d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.8189894035458565E-12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8189894035458565E-12d + "'", double1 == 1.8189894035458565E-12d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.5574077246549025d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 89.23288960379851d + "'", double1 == 89.23288960379851d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(6.794648664682791E19d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-0.7821091508568009d), 1.3956124250860895d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7821091508568009d) + "'", double2 == (-0.7821091508568009d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 176540, (long) 1715945959);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1716122499L + "'", long2 == 1716122499L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double2 = org.apache.commons.math.util.FastMath.max(999.9999999999999d, 1.078034432E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.078034432E9d + "'", double2 == 1.078034432E9d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.7821091508568009d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7821091508568009d + "'", double1 == 0.7821091508568009d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(33, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1763317633, (long) 114);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-25.092534979676547d) + "'", double1 == (-25.092534979676547d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.201032972726724d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1.1f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9503469458589033d) + "'", double1 == (-0.9503469458589033d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1716122499L, 2.7209306275075234E44d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.811791123649565d + "'", double2 == 4.811791123649565d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 16892717468L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        long long1 = org.apache.commons.math.util.MathUtils.sign(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.811791123649565d, (double) (byte) 100, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '4', (long) 5642100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1072693248, 1078034432);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-230), 56387L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 56387L + "'", long2 == 56387L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-1.1f), 330);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.100000023841858d) + "'", double2 == (-1.100000023841858d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.4426304E8f, (java.lang.Number) (short) 10, 1000);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(11013.232874703395d, 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 124);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 124, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double2 = org.apache.commons.math.util.FastMath.max(1.3383347192042695E42d, (-89.99999999999999d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3383347192042695E42d + "'", double2 == 1.3383347192042695E42d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1763317633);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.0120238672154904E83d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 10, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 744263018);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-744263018) + "'", int2 == (-744263018));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.8980433709785038d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.115301296526209d) + "'", double1 == (-1.115301296526209d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        int int2 = org.apache.commons.math.util.MathUtils.pow(124, 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.4392266385833326d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1075970048 + "'", int1 == 1075970048);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, (-6.740326560061405E-289d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 'a', (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1700);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1700 + "'", int1 == 1700);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-90), 56420);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 507780 + "'", int2 == 507780);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(92, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str12 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean14 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (short) 10, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-230));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1513055268, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1513055258 + "'", int2 == 1513055258);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.2479653611747976E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 566876.8954322702d + "'", double1 == 566876.8954322702d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1716122499L, 1.0d, 1700);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-90L), 7.305003746136002E-34d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-89.99999999999999d) + "'", double2 == (-89.99999999999999d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 34);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(4.644298430695373d, 904.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 903.1397973573762d + "'", double2 == 903.1397973573762d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray29 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray30 = new double[] {};
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray30);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection44, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 30.162848702026007d, (int) (byte) 10, orderDirection44, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 572.9577951308232d, (java.lang.Number) (-1L), (int) (short) 100, orderDirection44, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection44, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(124, 1078034432);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (-57.29577951308232d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 'a', 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1820, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1720L + "'", long2 == 1720L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 10.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.5663706143591725d) + "'", double2 == (-2.5663706143591725d));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.util.FastMath.log(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) -1, (long) (-788545902));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-788545903L) + "'", long2 == (-788545903L));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6610060414837631d + "'", double1 == 0.6610060414837631d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.sinh(904.1968923994399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1700);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-58.0d), 33, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(744263018L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        java.lang.Class<?> wildcardClass7 = doubleArray4.getClass();
        java.lang.Class<?> wildcardClass8 = doubleArray4.getClass();
        double[] doubleArray10 = new double[] { 0.9882067021499548d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8342233605065102d + "'", double1 == 0.8342233605065102d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1860947059), (long) (-1769857260));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-91089799L) + "'", long2 == (-91089799L));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-744263018), 1075970048);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 56421, 1000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 56421000L + "'", long2 == 56421000L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double2 = org.apache.commons.math.util.FastMath.min(2.1474835947411242E9d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(5642100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.206868008783169E7d + "'", double1 == 8.206868008783169E7d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(92L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 10, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        long long2 = org.apache.commons.math.util.FastMath.min(159287153400L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray29 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray30 = new double[] {};
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray30);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection38, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = nonMonotonousSequenceException40.getDirection();
        java.lang.Number number42 = nonMonotonousSequenceException40.getArgument();
        java.lang.String str43 = nonMonotonousSequenceException40.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = nonMonotonousSequenceException40.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection44, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection38.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0 + "'", number42.equals(0));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str43.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        int int2 = org.apache.commons.math.util.FastMath.max(9, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.605170185988092d, 6.910423230011184d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, 77L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection13, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException15.getDirection();
        java.lang.String str17 = nonMonotonousSequenceException15.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Number number19 = nonMonotonousSequenceException15.getArgument();
        int int20 = nonMonotonousSequenceException15.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0 + "'", number19.equals(0));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1820, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        long long2 = org.apache.commons.math.util.FastMath.min(1720L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1242703820 + "'", int1 == 1242703820);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.100000023841858d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double1 = org.apache.commons.math.util.FastMath.log1p(48.49772265559348d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9019266615585844d + "'", double1 == 3.9019266615585844d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.MathUtils.sign(3.560293163444669E53d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int int2 = org.apache.commons.math.util.FastMath.max(1820, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1820 + "'", int2 == 1820);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(0, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.3608363030788d + "'", double1 == 156.3608363030788d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1000.0d + "'", double1 == 1000.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0001523125762564d + "'", double1 == 1.0001523125762564d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(110.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.960486013832335E47d + "'", double1 == 2.960486013832335E47d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 9, (double) 99L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.091329169322069d + "'", double2 == 2.091329169322069d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.3383347192042695E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5474250491067253E26d + "'", double1 == 1.5474250491067253E26d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        long long1 = org.apache.commons.math.util.MathUtils.sign(970L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double2 = org.apache.commons.math.util.FastMath.atan2(81.55795945611504d, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5515388299761663d + "'", double2 == 1.5515388299761663d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        float float2 = org.apache.commons.math.util.MathUtils.round(10.0f, 1075970048);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1700);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-744263018), 1513055258);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1513055268, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1), (long) (-1820));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1820L) + "'", long2 == (-1820L));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1820);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(3.9019266615585844d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.381258645621002d) + "'", double2 == (-2.381258645621002d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0000000000000004d + "'", double1 == 2.0000000000000004d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Class<?> wildcardClass8 = nonMonotonousSequenceException5.getClass();
        int int9 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection19, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 30.162848702026007d, (int) (byte) 10, orderDirection19, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 572.9577951308232d, (java.lang.Number) (-1L), (int) (short) 100, orderDirection19, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        java.lang.Number number27 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (short) -1 + "'", number27.equals((short) -1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double2 = org.apache.commons.math.util.FastMath.max(2.6313083693369503E35d, (double) 739246080);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6313083693369503E35d + "'", double2 == 2.6313083693369503E35d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((-1820L), (-744263018));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 921088691, 8253758366346641408L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8253758367267730099L + "'", long2 == 8253758367267730099L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 192L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 192L + "'", long1 == 192L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 34L, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.3156541846684752E35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.086049513725576E11d + "'", double1 == 5.086049513725576E11d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection4, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        java.lang.String str8 = nonMonotonousSequenceException6.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException6.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 77L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1075970048);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1700, 1700);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(34);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 88.5808275421977d + "'", double1 == 88.5808275421977d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, 1715945959);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(34, 1696);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1696, 1000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2696L + "'", long2 == 2696L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double1 = org.apache.commons.math.util.FastMath.abs((-2.5663706143591725d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5663706143591725d + "'", double1 == 2.5663706143591725d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-3281440763214191347L), (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3281440763214191348L) + "'", long2 == (-3281440763214191348L));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1763261212, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1344012288 + "'", int2 == 1344012288);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (byte) 1, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 16892717468L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-6.740326560061405E-289d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.740326560061405E-289d) + "'", double1 == (-6.740326560061405E-289d));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-90), 114);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        int int2 = org.apache.commons.math.util.MathUtils.pow(176540, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 319815680 + "'", int2 == 319815680);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-230), 970L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) '4', (-22));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1763261212);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-3281440763214191347L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.28144078E18f + "'", float1 == 3.28144078E18f);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math.util.FastMath.floor(99.53096491487338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.0d + "'", double1 == 99.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-2.5663706143591725d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.044791617046997224d) + "'", double1 == (-0.044791617046997224d));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1072693248);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.486585557710477d + "'", double1 == 21.486585557710477d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, 15820024220L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 15820024220L + "'", long2 == 15820024220L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1513055258, (long) 1078034432);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2.220446049250313E-16d, 1715945959);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.872543021186608E130d + "'", double2 == 8.872543021186608E130d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str12 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean14 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number15 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (short) -1 + "'", number15.equals((short) -1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0001523125762564d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000761533884588d + "'", double1 == 1.0000761533884588d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1075970048);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 5642100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.313225746154785E-10d + "'", double1 == 9.313225746154785E-10d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(7.6007815097094434E-34d, 1.201032972726724d, 904.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 1, (long) 1078034432);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-0.7385712524522046d), (-1495361471), 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass10 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection14, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException16.getDirection();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        java.lang.Number number19 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        boolean boolean21 = nonMonotonousSequenceException16.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0 + "'", number18.equals(0));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0 + "'", number19.equals(0));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-1495361471), (-22));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-356.52195715904236d) + "'", double2 == (-356.52195715904236d));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) -1, 319815680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 319815680 + "'", int2 == 319815680);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(33, 1700);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) '#', 56421);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1247375891 + "'", int2 == 1247375891);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 2696L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(9.619275968248924E151d, 5.298342365610589d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 124);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.560293163444669E53d + "'", double1 == 3.560293163444669E53d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(22.140692632779267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0632442348382897E9d + "'", double1 == 2.0632442348382897E9d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.1464357978591606E14d, (-58.0d), (double) (-22));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 92.13617560368711d + "'", double1 == 92.13617560368711d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 507780);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray29 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray30 = new double[] {};
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray30);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray22);
        double[] doubleArray39 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray40 = new double[] {};
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray47 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray48 = new double[] {};
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray48);
        double[] doubleArray56 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray57 = new double[] {};
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray57);
        java.lang.Class<?> wildcardClass59 = doubleArray56.getClass();
        java.lang.Class<?> wildcardClass60 = doubleArray56.getClass();
        double[] doubleArray62 = new double[] { 0.9882067021499548d };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray62);
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double double66 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1769857260) + "'", int65 == (-1769857260));
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (byte) -1, (double) 1072693248);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.147483647E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.147483647E9d + "'", double1 == 2.147483647E9d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.1082099934797291d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3493911647007788d + "'", double1 == 1.3493911647007788d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection6, false);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3440585709080678E43d, (java.lang.Number) 4.9E-324d, 124, orderDirection10, false);
        java.lang.String str13 = nonMonotonousSequenceException12.toString();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 123 and 124 are not increasing (0 > 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 123 and 124 are not increasing (0 > 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000)"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(180.00000000000003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(363.7393755555636d, (double) (byte) 1, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1000.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1083129856 + "'", int1 == 1083129856);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        long long1 = org.apache.commons.math.util.FastMath.abs(1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100L, (float) 1075970048);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1860947059), 92);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        int[] intArray6 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray13 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int[] intArray21 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray28 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray21);
        int[] intArray37 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray44 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray44);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 75.82875444051551d + "'", double14 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 75.82875444051551d + "'", double29 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 124 + "'", int30 == 124);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 75.82875444051551d + "'", double45 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 75.82875444051551d + "'", double46 == 75.82875444051551d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        int int1 = org.apache.commons.math.util.MathUtils.hash(904.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1082933248 + "'", int1 == 1082933248);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1072693248, (double) 1715945959);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1082933248);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.49608634742987d + "'", double1 == 21.49608634742987d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1), (long) (-744263018));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 921088691, 1.3156541846684752E35d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3156541846684752E35d + "'", double2 == 1.3156541846684752E35d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(6.794648664682791E19d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4080584.1196973873d + "'", double1 == 4080584.1196973873d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 2147483646);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 2147483646);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 52);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.761115103842478E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.129462545777333d + "'", double1 == 20.129462545777333d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 35, (long) 176540);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6178900L + "'", long2 == 6178900L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.FastMath.atan(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2626272556789118d + "'", double1 == 1.2626272556789118d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.1752011936438016d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 739246080);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2902278078461403E7d + "'", double1 == 1.2902278078461403E7d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(56421, (-1820));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 15820024220L, 7.446921003909403E77d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.446921003909403E77d + "'", double2 == 7.446921003909403E77d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray21.getClass();
        java.lang.Class<?> wildcardClass25 = doubleArray21.getClass();
        double[] doubleArray27 = new double[] { 0.9882067021499548d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray27);
        double[] doubleArray34 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray35 = new double[] {};
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray35);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray43 = new double[] {};
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray50 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray51 = new double[] {};
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray51);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray51);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray34);
        java.lang.Number number57 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection60 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException62 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number57, (java.lang.Number) 92, (int) '4', orderDirection60, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection60, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not decreasing (-1 < 32)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1763317633 + "'", int37 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + orderDirection60 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection60.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.5063656411097588d), (double) 1820, (double) 1078034432);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1513055268);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4451928907652188d + "'", double1 == 0.4451928907652188d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math.util.FastMath.ulp(7.305003746136002E-34d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.552847072295026E-50d + "'", double1 == 8.552847072295026E-50d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-90));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.5607966601082315d, 1513055268, 1820);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1715945959, 114);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 744263018L, (double) 'a', 1.15708448781179d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-90), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (-1495361471));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.49536141E9f) + "'", float2 == (-1.49536141E9f));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1716122499L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1083129856, 1763261212);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.3531897806405977d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(5.086049513725576E11d, 8.872543021186608E130d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.872543021186608E130d + "'", double2 == 8.872543021186608E130d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        int[] intArray0 = null;
        int[] intArray6 = new int[] { (byte) 0, 33, ' ', (short) 0, (byte) 1 };
        int[] intArray13 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray20 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray20);
        int[] intArray28 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray35 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray35);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray35);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray13);
        int[] intArray45 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray52 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray52);
        int[] intArray60 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray67 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray67);
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray67);
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray67);
        try {
            int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 75.82875444051551d + "'", double21 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 75.82875444051551d + "'", double36 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 124 + "'", int37 == 124);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 92 + "'", int38 == 92);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 75.82875444051551d + "'", double53 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 75.82875444051551d + "'", double68 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 124 + "'", int69 == 124);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 68 + "'", int70 == 68);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double2 = org.apache.commons.math.util.FastMath.pow(99.53096491487338d, (-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.010047124539134915d + "'", double2 == 0.010047124539134915d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(192.21717495245437d, 1820, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.3232425226381688d, (double) 1.86094707E9f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int2 = org.apache.commons.math.util.FastMath.min(56420, 1344012288);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56420 + "'", int2 == 56420);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-1.115301296526209d), 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(10L, (-91089799L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str12 = nonMonotonousSequenceException5.toString();
        java.lang.Number number13 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0 + "'", number13.equals(0));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        float float1 = org.apache.commons.math.util.MathUtils.sign(35.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1820);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2600713879850747d + "'", double1 == 3.2600713879850747d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 0, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray21.getClass();
        java.lang.Class<?> wildcardClass25 = doubleArray21.getClass();
        double[] doubleArray27 = new double[] { 0.9882067021499548d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray27);
        double[] doubleArray34 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray35 = new double[] {};
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray35);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray43 = new double[] {};
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray50 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray51 = new double[] {};
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray51);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray51);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray34);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray62 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray63 = new double[] {};
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray63);
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray70 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray71 = new double[] {};
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray70, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        double[] doubleArray78 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray79 = new double[] {};
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray78, doubleArray79);
        double double81 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray79);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray79);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray79);
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray62);
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) (-90L));
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray86, 0.0d);
        double[] doubleArray93 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray94 = new double[] {};
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray93, doubleArray94);
        try {
            double double96 = org.apache.commons.math.util.MathUtils.distance1(doubleArray88, doubleArray94);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1763317633 + "'", int37 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1763317633 + "'", int65 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double2 = org.apache.commons.math.util.FastMath.min(1.5707963254512856d, (double) 192L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963254512856d + "'", double2 == 1.5707963254512856d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.0120238672154904E83d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.39363381683972537d) + "'", double1 == (-0.39363381683972537d));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1242703820);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 9L, 0.6483608274590866d, 5.288292537319899d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1495361471), 2147483646);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        float float2 = org.apache.commons.math.util.FastMath.max(35.0f, 3.28144078E18f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.28144078E18f + "'", float2 == 3.28144078E18f);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8212977905417654E24d + "'", double1 == 3.8212977905417654E24d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 34.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.3956124250860895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        java.lang.String str10 = nonMonotonousSequenceException8.toString();
        boolean boolean11 = nonMonotonousSequenceException8.getStrict();
        java.lang.Class<?> wildcardClass12 = nonMonotonousSequenceException8.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.761115103842478E8d, (java.lang.Number) 1.5707963254512856d, 52, orderDirection14, false);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 2.761115103842478E8d + "'", number18.equals(2.761115103842478E8d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.761115103842478E8d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-674092240) + "'", int1 == (-674092240));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(51.990383726223826d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1715945959, 100);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (short) 1, 1.3383347192042695E42d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray21.getClass();
        java.lang.Class<?> wildcardClass25 = doubleArray21.getClass();
        double[] doubleArray27 = new double[] { 0.9882067021499548d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray27);
        double[] doubleArray34 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray35 = new double[] {};
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray35);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray43 = new double[] {};
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray50 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray51 = new double[] {};
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray51);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray51);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray34);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        java.lang.Class<?> wildcardClass58 = doubleArray5.getClass();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1763317633 + "'", int37 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass58);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 9, 52.00000000000001d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 33);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 1082933248, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.5514266812416906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 31.59442154605463d + "'", double1 == 31.59442154605463d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-788545902), (-1769857260));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 34);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.219723898031069d + "'", double1 == 4.219723898031069d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1082933248);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1026.9135771649858d + "'", double1 == 1026.9135771649858d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 92, (int) '4', orderDirection3, false);
        java.lang.Class<?> wildcardClass6 = orderDirection3.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1), (long) 2147483646);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2147483645L + "'", long2 == 2147483645L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(2147483646, 176540);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 1, (long) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 10, 1078034432);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        long long2 = org.apache.commons.math.util.FastMath.max(15820024220L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 15820024220L + "'", long2 == 15820024220L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-744263018));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.4426304E8f + "'", float1 == 7.4426304E8f);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 319815680);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        int int2 = org.apache.commons.math.util.FastMath.max(1, 507780);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 507780 + "'", int2 == 507780);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 2147483647, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.9525060653686523d + "'", double2 == 3.9525060653686523d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1696);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1696.0f + "'", float1 == 1696.0f);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1.86094707E9f, 8.684930272989595d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.10127219765954285d + "'", double2 == 0.10127219765954285d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 6.283185307179586d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.013388202148675738d, 0.0d, 3.2479653611747976E7d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-2.381258645621002d), (double) (-3281440763214191348L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 5642100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 92L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 92.0f + "'", float1 == 92.0f);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str12 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number14 = nonMonotonousSequenceException5.getArgument();
        boolean boolean15 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0 + "'", number14.equals(0));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) -1, 124);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 124 + "'", int2 == 124);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-230), (long) (-22));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5060L + "'", long2 == 5060L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(330, 1513055268);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.3232425226381688d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.744654346838599d + "'", double1 == 1.744654346838599d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1860947059), 1696.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1696.0f + "'", float2 == 1696.0f);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 507780);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-90L), (double) 739246080, 5912.128178488171d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 319815680, 1072693248);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1247375891, 1344012288);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 33L, (double) 1763317633);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        int int2 = org.apache.commons.math.util.FastMath.max(1763261212, 1513055268);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1763261212 + "'", int2 == 1763261212);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 1513055258);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1763317633 + "'", int7 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1078034432, (-230));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double1 = org.apache.commons.math.util.FastMath.log(1.1082099934797291d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10274609516873542d + "'", double1 == 0.10274609516873542d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.10274609516873542d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09780351900252386d + "'", double1 == 0.09780351900252386d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection12, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException14.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException14.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        java.lang.Number number18 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0 + "'", number18.equals(0));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(77L, 110L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 187L + "'", long2 == 187L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(11846.669319939707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.79635555266977d + "'", double1 == 22.79635555266977d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 319815680);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.7209306275075234E44d, (java.lang.Number) Float.NaN, (int) ' ', orderDirection3, true);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-0.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(20.129462545777333d, 739246080, 1344012288);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int[] intArray5 = new int[] { (byte) 0, 33, ' ', (short) 0, (byte) 1 };
        int[] intArray12 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray19 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray19);
        int[] intArray27 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray34 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray34);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray12);
        int[] intArray44 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray51 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray51);
        int[] intArray59 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray66 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray66);
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray66);
        int[] intArray75 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray82 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double83 = org.apache.commons.math.util.MathUtils.distance(intArray75, intArray82);
        double double84 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray75);
        double double85 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray75);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 75.82875444051551d + "'", double20 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 75.82875444051551d + "'", double35 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 124 + "'", int36 == 124);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 92 + "'", int37 == 92);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 75.82875444051551d + "'", double52 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 75.82875444051551d + "'", double67 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 124 + "'", int68 == 124);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 75.82875444051551d + "'", double83 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5574077246549023d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0001523125762564d, 9.619275968248924E151d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) '4', (int) (short) 0, (-90));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        long long2 = org.apache.commons.math.util.FastMath.max(1716122499L, (long) 33);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1716122499L + "'", long2 == 1716122499L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(92.13617560368711d, 904.0d, 330);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 159287153400L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 399107.94705192227d + "'", double1 == 399107.94705192227d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1075970048, 110L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1075970158L + "'", long2 == 1075970158L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.9999389536658324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5571986291675608d + "'", double1 == 1.5571986291675608d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray6 = new double[] {};
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray13 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray14 = new double[] {};
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray14);
        double[] doubleArray22 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray23 = new double[] {};
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray23);
        java.lang.Class<?> wildcardClass25 = doubleArray22.getClass();
        java.lang.Class<?> wildcardClass26 = doubleArray22.getClass();
        double[] doubleArray28 = new double[] { 0.9882067021499548d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray28);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 744263018);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4142135623730951d + "'", double1 == 1.4142135623730951d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        int int1 = org.apache.commons.math.util.FastMath.abs(2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double double1 = org.apache.commons.math.util.FastMath.expm1(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.7385712524522046d), 0.09780351900252386d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.09780351900252386d + "'", double2 == 0.09780351900252386d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.2281293896483412d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 52, 1696);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.0030302937548627655d), 2.147483647E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.003030293754862765d) + "'", double2 == (-0.003030293754862765d));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1L), 1700, (int) ' ');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(56420, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56420 + "'", int2 == 56420);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double2 = org.apache.commons.math.util.FastMath.max(0.9882067021499548d, 0.5514266812416906d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9882067021499548d + "'", double2 == 0.9882067021499548d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.5514266812416906d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number12 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection16, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException18.getDirection();
        java.lang.String str20 = nonMonotonousSequenceException18.toString();
        boolean boolean21 = nonMonotonousSequenceException18.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException18.getDirection();
        java.lang.Throwable[] throwableArray23 = nonMonotonousSequenceException18.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        boolean boolean25 = nonMonotonousSequenceException5.getStrict();
        java.lang.Throwable[] throwableArray26 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0 + "'", number12.equals(0));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(throwableArray26);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 330, 1763317633);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double1 = org.apache.commons.math.util.FastMath.tan(11013.232874703395d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.504929904554044d) + "'", double1 == (-2.504929904554044d));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-308d + "'", double1 == 2.2250738585072014E-308d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.log10(11013.232874703392d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.041914822473389d + "'", double1 == 4.041914822473389d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-744263018));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1000, (float) 1700);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1700.0f + "'", float2 == 1700.0f);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.16227760542015932d), number1, (-1495361471), orderDirection10, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        int int2 = org.apache.commons.math.util.FastMath.max(1083129856, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1083129856 + "'", int2 == 1083129856);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 8253758367267730099L, 176540);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.729913973815664E142d + "'", double2 == 8.729913973815664E142d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10, 0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4947836489175637d + "'", double2 == 1.4947836489175637d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        int[] intArray6 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray13 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int[] intArray21 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray28 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray28);
        int[] intArray37 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray44 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray37);
        int[] intArray53 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray60 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray60);
        int[] intArray68 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray75 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray75);
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray68);
        int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray68);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 75.82875444051551d + "'", double14 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 75.82875444051551d + "'", double29 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 124 + "'", int30 == 124);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 75.82875444051551d + "'", double45 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 75.82875444051551d + "'", double61 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 75.82875444051551d + "'", double76 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 124 + "'", int77 == 124);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray21.getClass();
        java.lang.Class<?> wildcardClass25 = doubleArray21.getClass();
        double[] doubleArray27 = new double[] { 0.9882067021499548d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray27);
        double[] doubleArray34 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray35 = new double[] {};
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray42 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray43 = new double[] {};
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray43);
        double[] doubleArray51 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray52 = new double[] {};
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray59 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray60 = new double[] {};
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray60);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray52);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray35);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-25.092534979676547d), 80.8648122755551d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-25.092534979676547d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-25.0d) + "'", double1 == (-25.0d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Class<?> wildcardClass8 = nonMonotonousSequenceException5.getClass();
        int int9 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection19, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 30.162848702026007d, (int) (byte) 10, orderDirection19, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 572.9577951308232d, (java.lang.Number) (-1L), (int) (short) 100, orderDirection19, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        int int27 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-91089799L), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double double1 = org.apache.commons.math.util.FastMath.tan(9.619275968248924E151d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4752075402242797d) + "'", double1 == (-1.4752075402242797d));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double2 = org.apache.commons.math.util.FastMath.min(3.560293163444669E53d, (-1.100000023841858d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.100000023841858d) + "'", double2 == (-1.100000023841858d));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.0001523125762564d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 159287153400L, 81.55795945611504d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 81.55795945611504d + "'", double2 == 81.55795945611504d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1495361471), 176540);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103324d + "'", double1 == 11013.232920103324d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        int[] intArray0 = null;
        int[] intArray6 = new int[] { (byte) 0, 33, ' ', (short) 0, (byte) 1 };
        int[] intArray13 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray20 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray20);
        int[] intArray28 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray35 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray35);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray35);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray13);
        int[] intArray45 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray52 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray52);
        int[] intArray60 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray67 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray67);
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray67);
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray67);
        int[] intArray77 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray84 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double85 = org.apache.commons.math.util.MathUtils.distance(intArray77, intArray84);
        double double86 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray84);
        try {
            int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 75.82875444051551d + "'", double21 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 75.82875444051551d + "'", double36 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 124 + "'", int37 == 124);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 92 + "'", int38 == 92);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 75.82875444051551d + "'", double53 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 75.82875444051551d + "'", double68 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 124 + "'", int69 == 124);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 68 + "'", int70 == 68);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 75.82875444051551d + "'", double85 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.0d + "'", double1 == 99.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893697d) + "'", double1 == (-0.5440211108893697d));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.7209306275075234E44d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.933053378005127d + "'", double1 == 0.933053378005127d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 56421, (long) 56420);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3183272820L + "'", long2 == 3183272820L);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(6178900L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6178890L + "'", long2 == 6178890L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(99.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5672.28217179515d + "'", double1 == 5672.28217179515d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4758800785707605E27d + "'", double1 == 2.4758800785707605E27d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.09780351900252386d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09749286015091498d + "'", double1 == 0.09749286015091498d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1820), (long) 1242703820);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1242705640L) + "'", long2 == (-1242705640L));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray21.getClass();
        java.lang.Class<?> wildcardClass25 = doubleArray21.getClass();
        double[] doubleArray27 = new double[] { 0.9882067021499548d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray27);
        double[] doubleArray34 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray35 = new double[] {};
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray42 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray43 = new double[] {};
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray43);
        double[] doubleArray51 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray52 = new double[] {};
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray59 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray60 = new double[] {};
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray60);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray52);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray35);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        double double2 = org.apache.commons.math.util.FastMath.max(1.4947836489175637d, 15.104412573075516d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 15.104412573075516d + "'", double2 == 15.104412573075516d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        java.lang.Class<?> wildcardClass7 = doubleArray4.getClass();
        java.lang.Class<?> wildcardClass8 = doubleArray4.getClass();
        double[] doubleArray13 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray14 = new double[] {};
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray22);
        double[] doubleArray30 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray31 = new double[] {};
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray31);
        java.lang.Class<?> wildcardClass33 = doubleArray30.getClass();
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray30);
        double[] doubleArray39 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray40 = new double[] {};
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray40);
        java.lang.Class<?> wildcardClass42 = doubleArray39.getClass();
        java.lang.Class<?> wildcardClass43 = doubleArray39.getClass();
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray39);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 33.54101966249684d + "'", double45 == 33.54101966249684d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double double1 = org.apache.commons.math.util.FastMath.log(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1344012288);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double double1 = org.apache.commons.math.util.FastMath.atanh(8.872543021186608E130d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1820));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.4451928907652188d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.004451899496079857d + "'", double2 == 0.004451899496079857d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        double[] doubleArray2 = new double[] { 1.8189894035458565E-12d, 180.00000000000003d };
        double[] doubleArray7 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray8 = new double[] {};
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray15 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray16 = new double[] {};
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray16);
        double[] doubleArray24 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray25 = new double[] {};
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray25);
        java.lang.Class<?> wildcardClass27 = doubleArray24.getClass();
        java.lang.Class<?> wildcardClass28 = doubleArray24.getClass();
        double[] doubleArray30 = new double[] { 0.9882067021499548d };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray30);
        double[] doubleArray37 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray38 = new double[] {};
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray45 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray46 = new double[] {};
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray53 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray54 = new double[] {};
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray54);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray54);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray37);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 3.560293163444669E53d);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1763317633 + "'", int40 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 10, (-1495361471));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.9882067021499548d, 0.0d, 92);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1769857260), 92L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 92L + "'", long2 == 92L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1000, 1820, 1763317633);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        double double1 = org.apache.commons.math.util.FastMath.tan(21.486585557710477d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5522421710192368d) + "'", double1 == (-0.5522421710192368d));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray21.getClass();
        java.lang.Class<?> wildcardClass25 = doubleArray21.getClass();
        double[] doubleArray27 = new double[] { 0.9882067021499548d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray27);
        double[] doubleArray34 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray35 = new double[] {};
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray35);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray43 = new double[] {};
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray50 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray51 = new double[] {};
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray51);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray51);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray34);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection60 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException62 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection60, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection63 = nonMonotonousSequenceException62.getDirection();
        java.lang.String str64 = nonMonotonousSequenceException62.toString();
        boolean boolean65 = nonMonotonousSequenceException62.getStrict();
        java.lang.Class<?> wildcardClass66 = nonMonotonousSequenceException62.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection67 = nonMonotonousSequenceException62.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection68 = nonMonotonousSequenceException62.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection68, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1763317633 + "'", int37 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + orderDirection60 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection60.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection63 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection63.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str64.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertTrue("'" + orderDirection67 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection67.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection68 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection68.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        int[] intArray3 = new int[] { (short) 0, 2147483646, 56420 };
        int[] intArray10 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray17 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray17);
        int[] intArray25 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray32 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray32);
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray32);
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray42 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray49 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray49);
        int[] intArray57 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray64 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray64);
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray64);
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray64);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 75.82875444051551d + "'", double18 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 75.82875444051551d + "'", double33 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 124 + "'", int34 == 124);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 2.1474835947411242E9d + "'", double35 == 2.1474835947411242E9d);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 75.82875444051551d + "'", double50 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 75.82875444051551d + "'", double65 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 124 + "'", int66 == 124);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.1474836147411504E9d + "'", double67 == 2.1474836147411504E9d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        double double1 = org.apache.commons.math.util.MathUtils.sign(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.3956124250860895d, (-1.100000023841858d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6930406145786495d + "'", double2 == 0.6930406145786495d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.811791123649565d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 61.47988764279806d + "'", double1 == 61.47988764279806d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.013388202148675738d, 1.3493911647007788d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(114);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(739246080, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 92, (float) (-90));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-90.0f) + "'", float2 == (-90.0f));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-1.7101259231567383d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.029847327982792625d) + "'", double1 == (-0.029847327982792625d));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray21.getClass();
        java.lang.Class<?> wildcardClass25 = doubleArray21.getClass();
        double[] doubleArray27 = new double[] { 0.9882067021499548d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray27);
        double[] doubleArray34 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray35 = new double[] {};
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray35);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray43 = new double[] {};
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray50 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray51 = new double[] {};
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray51);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray51);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray34);
        double[] doubleArray57 = null;
        try {
            double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1763317633 + "'", int37 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 33L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double double1 = org.apache.commons.math.util.FastMath.ulp(9.313225746154785E-10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0679515313825692E-25d + "'", double1 == 2.0679515313825692E-25d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 33L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 33.0d + "'", double1 == 33.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.013388202148675738d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.013388202148675738d + "'", double2 == 0.013388202148675738d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1078034432);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.0679515313825692E-25d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1848489498583662E-23d + "'", double1 == 1.1848489498583662E-23d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.496025759922821d) + "'", double1 == (-0.496025759922821d));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 921088691, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 744263018);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        long long1 = org.apache.commons.math.util.FastMath.round(7.305003746136002E-34d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        long long1 = org.apache.commons.math.util.MathUtils.sign(52L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double[] doubleArray2 = new double[] { 1.8189894035458565E-12d, 180.00000000000003d };
        double[] doubleArray7 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray8 = new double[] {};
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray15 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray16 = new double[] {};
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray16);
        double[] doubleArray24 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray25 = new double[] {};
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray25);
        java.lang.Class<?> wildcardClass27 = doubleArray24.getClass();
        java.lang.Class<?> wildcardClass28 = doubleArray24.getClass();
        double[] doubleArray30 = new double[] { 0.9882067021499548d };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray30);
        double[] doubleArray37 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray38 = new double[] {};
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray45 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray46 = new double[] {};
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray53 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray54 = new double[] {};
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray54);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray54);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray37);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray65 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray66 = new double[] {};
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray73 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray74 = new double[] {};
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray73, doubleArray74);
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray74);
        double[] doubleArray82 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray83 = new double[] {};
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray82, doubleArray83);
        java.lang.Class<?> wildcardClass85 = doubleArray82.getClass();
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray74, doubleArray82);
        double double87 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray82);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray82);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1763317633 + "'", int40 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(wildcardClass85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 1696);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double double2 = org.apache.commons.math.util.FastMath.max(2.220446049250313E-16d, (double) 744263018);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.44263018E8d + "'", double2 == 7.44263018E8d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.3493911647007788d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1050432788003308d + "'", double1 == 1.1050432788003308d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (byte) -1, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1078034432, 124);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        double double1 = org.apache.commons.math.util.FastMath.log(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.896437609964467d + "'", double1 == 5.896437609964467d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.8980433709785038d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.462015656303025d) + "'", double1 == (-1.462015656303025d));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.5514266812416906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7425810940508051d + "'", double1 == 0.7425810940508051d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray20 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray21 = new double[] {};
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray21);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray21);
        double[] doubleArray30 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray31 = new double[] {};
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray38 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray39 = new double[] {};
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray39);
        double[] doubleArray47 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray48 = new double[] {};
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray48);
        java.lang.Class<?> wildcardClass50 = doubleArray47.getClass();
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray47);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray21, doubleArray39);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1763317633 + "'", int7 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        int[] intArray6 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray13 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int[] intArray21 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray28 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray28);
        int[] intArray37 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray44 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray37);
        int[] intArray50 = new int[] { (short) 0, 2147483646, 56420 };
        int[] intArray57 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray64 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray64);
        int[] intArray72 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray79 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray72, intArray79);
        int int81 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray79);
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray57);
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray57);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 75.82875444051551d + "'", double14 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 75.82875444051551d + "'", double29 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 124 + "'", int30 == 124);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 75.82875444051551d + "'", double45 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 75.82875444051551d + "'", double65 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 75.82875444051551d + "'", double80 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 124 + "'", int81 == 124);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 2.1474835947411242E9d + "'", double82 == 2.1474835947411242E9d);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 1075970048);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray21.getClass();
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray21);
        double[] doubleArray30 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray31 = new double[] {};
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray31);
        java.lang.Class<?> wildcardClass33 = doubleArray30.getClass();
        java.lang.Class<?> wildcardClass34 = doubleArray30.getClass();
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray30);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        java.lang.Class<?> wildcardClass7 = doubleArray4.getClass();
        java.lang.Class<?> wildcardClass8 = doubleArray4.getClass();
        double[] doubleArray13 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray14 = new double[] {};
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray22);
        double[] doubleArray30 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray31 = new double[] {};
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray31);
        java.lang.Class<?> wildcardClass33 = doubleArray30.getClass();
        java.lang.Class<?> wildcardClass34 = doubleArray30.getClass();
        double[] doubleArray36 = new double[] { 0.9882067021499548d };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray36);
        double[] doubleArray43 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray44 = new double[] {};
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray44);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double[] doubleArray51 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray52 = new double[] {};
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray59 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray60 = new double[] {};
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray60);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray60);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray43);
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        try {
            double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1763317633 + "'", int46 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 92, (int) '4', orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection9, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException11.getDirection();
        java.lang.String str13 = nonMonotonousSequenceException11.toString();
        boolean boolean14 = nonMonotonousSequenceException11.getStrict();
        java.lang.Class<?> wildcardClass15 = nonMonotonousSequenceException11.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException11.getDirection();
        java.lang.Number number18 = nonMonotonousSequenceException11.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection22, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException24.getDirection();
        java.lang.String str26 = nonMonotonousSequenceException24.toString();
        boolean boolean27 = nonMonotonousSequenceException24.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException24.getDirection();
        java.lang.Throwable[] throwableArray29 = nonMonotonousSequenceException24.getSuppressed();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        boolean boolean31 = nonMonotonousSequenceException11.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number33 = nonMonotonousSequenceException11.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0 + "'", number18.equals(0));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str26.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (short) -1 + "'", number33.equals((short) -1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1075970158L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.075970158E9d + "'", double1 == 1.075970158E9d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-744263018), (-1860947058L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-744263018L) + "'", long2 == (-744263018L));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.147483647E9d, 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.016129032258414052d + "'", double2 == 0.016129032258414052d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(2696L, (long) 1344012288);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 124);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.135528725660043d + "'", double1 == 11.135528725660043d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.1752011936438014d, 1.1050432788003308d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1953003365203483d + "'", double2 == 1.1953003365203483d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 744263018L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1075970158L, (java.lang.Number) 7.930067261567154E14d, (-788545902), orderDirection3, false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.1752011936438016d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        long long1 = org.apache.commons.math.util.FastMath.round(33.54101966249684d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 34L + "'", long1 == 34L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.9525060653686523d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.083128745448901d + "'", double1 == 2.083128745448901d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 77L, (float) (-90L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-90.0f) + "'", float2 == (-90.0f));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.933053378005127d, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double1 = org.apache.commons.math.util.FastMath.log10(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9867717342662448d + "'", double1 == 1.9867717342662448d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 16892717468L, (double) (-90));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6892717467999998E10d + "'", double2 == 1.6892717467999998E10d);
    }
}

