import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.14643579785916E14d, 8.206868008783169E7d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 744263018, (double) 9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.012269377708435d + "'", double2 == 8.012269377708435d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray21.getClass();
        java.lang.Class<?> wildcardClass25 = doubleArray21.getClass();
        double[] doubleArray27 = new double[] { 0.9882067021499548d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray27);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        java.lang.Class<?> wildcardClass31 = doubleArray27.getClass();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 2147483646);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 2147483646);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 2147483646);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger14);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 2147483646);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0L);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) 2147483646);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger25);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger25);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.5707961649537923d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.810476602432443d + "'", double1 == 4.810476602432443d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1082933248);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1515194496);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.636130838093536d + "'", double1 == 43.636130838093536d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        long long2 = org.apache.commons.math.util.FastMath.max((-2661627379775963136L), (-90L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-90L) + "'", long2 == (-90L));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray20 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray21 = new double[] {};
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray21);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray21);
        double[] doubleArray30 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray31 = new double[] {};
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray38 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray39 = new double[] {};
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray39);
        double[] doubleArray47 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray48 = new double[] {};
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray48);
        java.lang.Class<?> wildcardClass50 = doubleArray47.getClass();
        java.lang.Class<?> wildcardClass51 = doubleArray47.getClass();
        double[] doubleArray53 = new double[] { 0.9882067021499548d };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray53);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray31);
        double[] doubleArray57 = new double[] {};
        double[] doubleArray62 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray63 = new double[] {};
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double[] doubleArray70 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray71 = new double[] {};
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray70, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray71);
        double[] doubleArray79 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray80 = new double[] {};
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray79, doubleArray80);
        java.lang.Class<?> wildcardClass82 = doubleArray79.getClass();
        java.lang.Class<?> wildcardClass83 = doubleArray79.getClass();
        double[] doubleArray85 = new double[] { 0.9882067021499548d };
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray79, doubleArray85);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray85);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray63);
        double[] doubleArray89 = null;
        double double90 = org.apache.commons.math.util.MathUtils.distance(doubleArray57, doubleArray89);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray57);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray57);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1763317633 + "'", int7 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(wildcardClass82);
        org.junit.Assert.assertNotNull(wildcardClass83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1982748969, 2696);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Class<?> wildcardClass8 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection12, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException14.getDirection();
        java.lang.Number number16 = nonMonotonousSequenceException14.getArgument();
        boolean boolean17 = nonMonotonousSequenceException14.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        java.lang.Number number19 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0 + "'", number16.equals(0));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (short) -1 + "'", number19.equals((short) -1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1075970048, (-230));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(248547564, (-744263018));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 52, 1.0000761533884588d, (-0.0051522049933822095d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.2600713879850747d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 5060L, (double) (-90.0f), 9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray21.getClass();
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray21);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray31 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray32 = new double[] {};
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double[] doubleArray39 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray40 = new double[] {};
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray40);
        double[] doubleArray48 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray49 = new double[] {};
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray49);
        java.lang.Class<?> wildcardClass51 = doubleArray48.getClass();
        java.lang.Class<?> wildcardClass52 = doubleArray48.getClass();
        double[] doubleArray54 = new double[] { 0.9882067021499548d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray54);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        double[] doubleArray58 = null;
        double double59 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray58);
        try {
            double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 1, 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1820));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray21.getClass();
        java.lang.Class<?> wildcardClass25 = doubleArray21.getClass();
        double[] doubleArray27 = new double[] { 0.9882067021499548d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray27);
        double[] doubleArray34 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray35 = new double[] {};
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray35);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray43 = new double[] {};
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray50 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray51 = new double[] {};
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray51);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray51);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray34);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray62 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray63 = new double[] {};
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray63);
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray70 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray71 = new double[] {};
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray70, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        double[] doubleArray78 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray79 = new double[] {};
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray78, doubleArray79);
        double double81 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray79);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray79);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray79);
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray62);
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) (-90L));
        double[] doubleArray87 = null;
        try {
            double double88 = org.apache.commons.math.util.MathUtils.distance(doubleArray86, doubleArray87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1763317633 + "'", int37 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1763317633 + "'", int65 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray86);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 2147483646);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 114);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 2147483646);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 2147483646);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger18);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 9);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 56421000L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        double double1 = org.apache.commons.math.util.FastMath.acos((-3323.1552117587744d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1), (long) (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 15820024220L, (java.lang.Number) 1.15708448781179d, 1513055268);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1513055268 + "'", int4 == 1513055268);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.220446049250313E-16d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1495364167, 744263018);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Class<?> wildcardClass8 = nonMonotonousSequenceException5.getClass();
        int int9 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection19, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 30.162848702026007d, (int) (byte) 10, orderDirection19, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 572.9577951308232d, (java.lang.Number) (-1L), (int) (short) 100, orderDirection19, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 739246080, number28, 124);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        java.lang.Number number32 = nonMonotonousSequenceException30.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 739246080 + "'", number32.equals(739246080));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        int[] intArray6 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray13 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int[] intArray21 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray28 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray28);
        int[] intArray36 = new int[] { (byte) 0, 33, ' ', (short) 0, (byte) 1 };
        int[] intArray43 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray50 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray50);
        int[] intArray58 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray65 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray65);
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray65);
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray43);
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray43);
        java.lang.Class<?> wildcardClass70 = intArray28.getClass();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 75.82875444051551d + "'", double14 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 75.82875444051551d + "'", double29 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 124 + "'", int30 == 124);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 75.82875444051551d + "'", double51 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 75.82875444051551d + "'", double66 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 124 + "'", int67 == 124);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 92 + "'", int68 == 92);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 68 + "'", int69 == 68);
        org.junit.Assert.assertNotNull(wildcardClass70);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.5571986291675608d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        double double1 = org.apache.commons.math.util.FastMath.sinh(129971.98724340565d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 56421000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.848352005316222d + "'", double1 == 17.848352005316222d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray20 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray21 = new double[] {};
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray21);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray21);
        double[] doubleArray30 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray31 = new double[] {};
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray38 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray39 = new double[] {};
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray39);
        double[] doubleArray47 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray48 = new double[] {};
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray48);
        java.lang.Class<?> wildcardClass50 = doubleArray47.getClass();
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray47);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray21, doubleArray39);
        double[] doubleArray57 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray58 = new double[] {};
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray58);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double[] doubleArray65 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray66 = new double[] {};
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray73 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray74 = new double[] {};
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray73, doubleArray74);
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray74);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray74);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray74);
        java.lang.Class<?> wildcardClass80 = doubleArray21.getClass();
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1763317633 + "'", int7 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1763317633 + "'", int60 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1982748969, 124);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.004451899496079857d, 0.21997516380723744d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.004451899496079857d + "'", double2 == 0.004451899496079857d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1072693248L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 2696L, (double) 1.86094707E9f, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '4', (float) (-3281440763214191347L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-3.28144078E18f) + "'", float2 == (-3.28144078E18f));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-1.6022056209055229d), 0.0d, (double) 52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 2147483646);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 114);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 2147483646);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 2147483646);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger19);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger20);
        try {
            java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 100, (double) 1820);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6300356939925373d + "'", double2 == 1.6300356939925373d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        long long2 = org.apache.commons.math.util.FastMath.max(16892717468L, 2696L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16892717468L + "'", long2 == 16892717468L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 744263018L, 744263018, 32);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.7168146928204138d, (double) 4, 0.09749286015091498d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 57L, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1763261264L, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.76326131E9f + "'", float2 == 1.76326131E9f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1116);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.477874452256717d + "'", double1 == 19.477874452256717d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Class<?> wildcardClass8 = nonMonotonousSequenceException5.getClass();
        int int9 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection19, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 30.162848702026007d, (int) (byte) 10, orderDirection19, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 572.9577951308232d, (java.lang.Number) (-1L), (int) (short) 100, orderDirection19, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        java.lang.Number number27 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 0 + "'", number27.equals(0));
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 507780, 1000, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-2.504929904554044d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.3956124250860895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3956124250860897d + "'", double1 == 1.3956124250860897d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray8 = null;
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray8);
        double[] doubleArray14 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray15 = new double[] {};
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray22 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray23 = new double[] {};
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray23);
        double[] doubleArray31 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray32 = new double[] {};
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray32);
        java.lang.Class<?> wildcardClass34 = doubleArray31.getClass();
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray31);
        double[] doubleArray40 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray41 = new double[] {};
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray41);
        java.lang.Class<?> wildcardClass43 = doubleArray40.getClass();
        java.lang.Class<?> wildcardClass44 = doubleArray40.getClass();
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray40);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1763317633 + "'", int7 == 1763317633);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 33.54101966249684d + "'", double46 == 33.54101966249684d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        int int1 = org.apache.commons.math.util.FastMath.abs(1078034432);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078034432 + "'", int1 == 1078034432);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 97L, 1763317633);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 2147483646);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (-1495361471));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str12 = nonMonotonousSequenceException5.toString();
        int int13 = nonMonotonousSequenceException5.getIndex();
        java.lang.Class<?> wildcardClass14 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 77L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 77.0d + "'", double1 == 77.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1513055269, (-1860947059));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 114);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(53L, (-674092240));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        long long2 = org.apache.commons.math.util.MathUtils.pow(24L, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(2147483646);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.7585134545231703E33d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.814514224199219E31d + "'", double1 == 4.814514224199219E31d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray6 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double[] doubleArray14 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray15 = new double[] {};
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray15);
        double[] doubleArray23 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray24 = new double[] {};
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray24);
        java.lang.Class<?> wildcardClass26 = doubleArray23.getClass();
        java.lang.Class<?> wildcardClass27 = doubleArray23.getClass();
        double[] doubleArray29 = new double[] { 0.9882067021499548d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray29);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray33 = null;
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray33);
        double[] doubleArray39 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray40 = new double[] {};
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray40);
        java.lang.Class<?> wildcardClass42 = doubleArray39.getClass();
        java.lang.Class<?> wildcardClass43 = doubleArray39.getClass();
        double[] doubleArray45 = new double[] { 0.9882067021499548d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray45);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        double double1 = org.apache.commons.math.util.FastMath.sin((-2.566370614359172d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893706d) + "'", double1 == (-0.5440211108893706d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1696.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.44397762133943464d) + "'", double1 == (-0.44397762133943464d));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 3, (double) 292L, (double) 1696);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 1075970048);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(56422, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 2147483646);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 2147483646);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) 2147483646);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger16);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 2147483646);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger20);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger11);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0L);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0L);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) 2147483646);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 0);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger36);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger36);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 10);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        double double1 = org.apache.commons.math.util.FastMath.cos(11013.232874703395d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3707603104579494d + "'", double1 == 0.3707603104579494d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 3.28144078E18f, 2147483647);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.64072038802548326E18d + "'", double2 == 1.64072038802548326E18d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(55.78027715682522d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.395306816603052E23d + "'", double1 == 8.395306816603052E23d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) -1, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1515194496L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        long long1 = org.apache.commons.math.util.FastMath.round(0.6632456843634444d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(2696, (-22));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-59312) + "'", int2 == (-59312));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.9173087126372744E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5071569429518377d) + "'", double1 == (-0.5071569429518377d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 1344012288, 1089178752);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray20 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray21 = new double[] {};
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray21);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray21);
        double[] doubleArray30 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray31 = new double[] {};
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray38 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray39 = new double[] {};
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray39);
        double[] doubleArray47 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray48 = new double[] {};
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray48);
        java.lang.Class<?> wildcardClass50 = doubleArray47.getClass();
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray47);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray21, doubleArray39);
        double[] doubleArray57 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray58 = new double[] {};
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray58);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double[] doubleArray65 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray66 = new double[] {};
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray73 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray74 = new double[] {};
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray73, doubleArray74);
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray74);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray74);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray74);
        try {
            double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 97.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1763317633 + "'", int7 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1763317633 + "'", int60 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray6 = new double[] {};
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray13 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray14 = new double[] {};
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray14);
        double[] doubleArray22 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray23 = new double[] {};
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray23);
        java.lang.Class<?> wildcardClass25 = doubleArray22.getClass();
        java.lang.Class<?> wildcardClass26 = doubleArray22.getClass();
        double[] doubleArray28 = new double[] { 0.9882067021499548d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray28);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray32 = null;
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.7849803886813105d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9224714537157727d + "'", double1 == 0.9224714537157727d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 16892718468L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(56420, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56421 + "'", int2 == 56421);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1860947059));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6657737500283538d) + "'", double1 == (-0.6657737500283538d));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(52, 319815680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.6657737500283538d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-1820L), 904.1968923994399d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 906.9024233159403d + "'", double2 == 906.9024233159403d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        double double2 = org.apache.commons.math.util.FastMath.max((-3.423644604231992E154d), (double) (-788545903L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.88545903E8d) + "'", double2 == (-7.88545903E8d));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.09749286015091498d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.31223846680208217d + "'", double1 == 0.31223846680208217d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(2.1474835947411242E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        long long2 = org.apache.commons.math.util.MathUtils.pow(940L, 1763317633);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1982748969);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1982748928 + "'", int1 == 1982748928);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) 2147483646);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger10);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 6178900L);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection21, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException23.getDirection();
        java.lang.String str25 = nonMonotonousSequenceException23.toString();
        boolean boolean26 = nonMonotonousSequenceException23.getStrict();
        java.lang.Class<?> wildcardClass27 = nonMonotonousSequenceException23.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException23.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11846.669319939707d, (java.lang.Number) 0.9665499241544702d, 114, orderDirection28, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5681420794060111d, (java.lang.Number) 6178900L, 1715945959, orderDirection28, true);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str25.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-3.423644604231992E154d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray6 = new double[] {};
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray6);
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (short) 1, 230.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        int int9 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) -1 + "'", number8.equals((short) -1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) -1 + "'", number10.equals((short) -1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1082933248, 5.166573983193148E39d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.096037435102602E-31d + "'", double2 == 2.096037435102602E-31d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 572.9577951308232d, (java.lang.Number) (short) 0, (-1769857260));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 572.9577951308232d + "'", number4.equals(572.9577951308232d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 572.9577951308232d + "'", number6.equals(572.9577951308232d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1.76326131E9f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1579530674) + "'", int1 == (-1579530674));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 0, (-0.8980433709785038d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2696L, 1.58200238E10f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.58200238E10f + "'", float2 == 1.58200238E10f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        int int11 = nonMonotonousSequenceException5.getIndex();
        boolean boolean12 = nonMonotonousSequenceException5.getStrict();
        boolean boolean13 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(904.1968923994399d, (double) 248547564);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4854756087949207E8d + "'", double2 == 2.4854756087949207E8d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.5571986291675608d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999389536658324d + "'", double1 == 0.9999389536658324d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double2 = org.apache.commons.math.util.FastMath.min(0.016129032258414052d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.016129032258414052d + "'", double2 == 0.016129032258414052d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        int int2 = org.apache.commons.math.util.FastMath.max(1082933248, 921088691);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1082933248 + "'", int2 == 1082933248);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 1, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        double double2 = org.apache.commons.math.util.FastMath.max(3.4392266385833326d, 566876.8954322702d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 566876.8954322702d + "'", double2 == 566876.8954322702d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1820);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(187L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 188L + "'", long2 == 188L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 114);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079803904 + "'", int1 == 1079803904);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-1860947059), 1.5574077246549025d, 5.288292537319899d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 34L, 1.1071487177940906d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 33.99999999999999d + "'", double2 == 33.99999999999999d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray21.getClass();
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray21);
        double[] doubleArray30 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray31 = new double[] {};
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray31);
        java.lang.Class<?> wildcardClass33 = doubleArray30.getClass();
        java.lang.Class<?> wildcardClass34 = doubleArray30.getClass();
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray30);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection40, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = nonMonotonousSequenceException42.getDirection();
        java.lang.String str44 = nonMonotonousSequenceException42.toString();
        boolean boolean45 = nonMonotonousSequenceException42.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = nonMonotonousSequenceException42.getDirection();
        java.lang.Class<?> wildcardClass47 = orderDirection46.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection46, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 33.54101966249684d + "'", double36 == 33.54101966249684d);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection43 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection43.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str44.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + orderDirection46 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection46.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass47);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(113.76468402400728d, 4.814514224199219E31d, 92.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        long long2 = org.apache.commons.math.util.MathUtils.pow(3281440763214191347L, 2696);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7816688933938912735L) + "'", long2 == (-7816688933938912735L));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 77L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5578100438747242d + "'", double1 == 1.5578100438747242d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1513055268, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 19669718484L + "'", long2 == 19669718484L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1089178752);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        double[] doubleArray1 = new double[] { 970L };
        double[] doubleArray6 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray6.getClass();
        java.lang.Class<?> wildcardClass10 = doubleArray6.getClass();
        double[] doubleArray12 = new double[] { 0.9882067021499548d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 33.54101966249684d + "'", double15 == 33.54101966249684d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) -1, (long) 124);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1072693248, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1072693249 + "'", int2 == 1072693249);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        int[] intArray1 = new int[] { 921088691 };
        int[] intArray7 = new int[] { (byte) 0, 33, ' ', (short) 0, (byte) 1 };
        int[] intArray14 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray21 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray21);
        int[] intArray29 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray36 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray36);
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray14);
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray14);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 75.82875444051551d + "'", double22 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 75.82875444051551d + "'", double37 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 124 + "'", int38 == 124);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 92 + "'", int39 == 92);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 921088690 + "'", int40 == 921088690);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        int[] intArray6 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray13 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int[] intArray20 = new int[] { (byte) 0, 33, ' ', (short) 0, (byte) 1 };
        int[] intArray27 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray34 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray34);
        int[] intArray42 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray49 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray49);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray27);
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray27);
        int[] intArray54 = null;
        try {
            int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 75.82875444051551d + "'", double14 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 75.82875444051551d + "'", double35 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 75.82875444051551d + "'", double50 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 124 + "'", int51 == 124);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 92 + "'", int52 == 92);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 114);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2327411910848595E49d + "'", double1 == 3.2327411910848595E49d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-59312), 921088690);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(192L, (-1817352679040L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 64L + "'", long2 == 64L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1763317633, (-0.14550003380861354d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1495364167, 739246080);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        int int2 = org.apache.commons.math.util.MathUtils.pow(330, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.14643579785916E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.55155232151237d + "'", double1 == 0.55155232151237d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1083129866);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 68);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray21.getClass();
        java.lang.Class<?> wildcardClass25 = doubleArray21.getClass();
        double[] doubleArray27 = new double[] { 0.9882067021499548d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray27);
        double[] doubleArray34 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray35 = new double[] {};
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray35);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray43 = new double[] {};
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray50 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray51 = new double[] {};
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray51);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray51);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray34);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        try {
            double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) 92L);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1763317633 + "'", int37 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        long long2 = org.apache.commons.math.util.FastMath.min((-1860947058L), 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1860947058L) + "'", long2 == (-1860947058L));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        double double2 = org.apache.commons.math.util.FastMath.max(2.286720093620587E7d, 1.1953003365203483d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.286720093620587E7d + "'", double2 == 2.286720093620587E7d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(156.3608363030788d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.3873599684745175d + "'", double1 == 5.3873599684745175d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(921088690, 1083129866);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        int int2 = org.apache.commons.math.util.FastMath.min(68, 1072693248);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1820), (-1860947059));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.1752011936438016d, 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-6.740326560061405E-289d), 14.150444078461241d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.763332177200736E-290d) + "'", double2 == (-4.763332177200736E-290d));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-59312), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray29 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray30 = new double[] {};
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray30);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray22);
        try {
            double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, 230.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        boolean boolean10 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) -1 + "'", number8.equals((short) -1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1344012288, 319815680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 262144 + "'", int2 == 262144);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1860947059L), (float) 110L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.86094707E9f) + "'", float2 == (-1.86094707E9f));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1641790195);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double double1 = org.apache.commons.math.util.FastMath.sinh(5.3873599684745175d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 109.31043544950265d + "'", double1 == 109.31043544950265d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6574544541530771d + "'", double1 == 1.6574544541530771d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 1.6574544541530771d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(464968614, (-1579530674));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2044499288 + "'", int2 == 2044499288);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        double double1 = org.apache.commons.math.util.FastMath.atan(5.198497031265826d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3807544230500801d + "'", double1 == 1.3807544230500801d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number12 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection16, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException18.getDirection();
        java.lang.String str20 = nonMonotonousSequenceException18.toString();
        boolean boolean21 = nonMonotonousSequenceException18.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException18.getDirection();
        java.lang.Throwable[] throwableArray23 = nonMonotonousSequenceException18.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0 + "'", number12.equals(0));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.1464357978591606E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 33.00000000000001d + "'", double1 == 33.00000000000001d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.0000761533884588d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7184888427133869d + "'", double1 == 1.7184888427133869d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1344012288, (long) 115);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1344012403L + "'", long2 == 1344012403L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number12 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection16, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException18.getDirection();
        java.lang.String str20 = nonMonotonousSequenceException18.toString();
        boolean boolean21 = nonMonotonousSequenceException18.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException18.getDirection();
        java.lang.Throwable[] throwableArray23 = nonMonotonousSequenceException18.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        int int25 = nonMonotonousSequenceException18.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0 + "'", number12.equals(0));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.8509826923271134d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 48.75771670902346d + "'", double1 == 48.75771670902346d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        double double2 = org.apache.commons.math.util.FastMath.min(999.9999999999999d, 0.5836293809324178d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5836293809324178d + "'", double2 == 0.5836293809324178d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-788545902), (long) 1075970048);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        double double1 = org.apache.commons.math.util.FastMath.tanh(903.1397973573762d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 10, 319815680);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.9224714537157727d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        double double1 = org.apache.commons.math.util.FastMath.atan(9.011793297850046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4602827404065946d + "'", double1 == 1.4602827404065946d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.5574077246549025d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray6 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double[] doubleArray14 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray15 = new double[] {};
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray15);
        double[] doubleArray23 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray24 = new double[] {};
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray24);
        java.lang.Class<?> wildcardClass26 = doubleArray23.getClass();
        java.lang.Class<?> wildcardClass27 = doubleArray23.getClass();
        double[] doubleArray29 = new double[] { 0.9882067021499548d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray29);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray33 = null;
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray33);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray40 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray41 = new double[] {};
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double[] doubleArray48 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray49 = new double[] {};
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray49);
        double[] doubleArray57 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray58 = new double[] {};
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray58);
        java.lang.Class<?> wildcardClass60 = doubleArray57.getClass();
        java.lang.Class<?> wildcardClass61 = doubleArray57.getClass();
        double[] doubleArray63 = new double[] { 0.9882067021499548d };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray63);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray63);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray41);
        double[] doubleArray67 = null;
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray67);
        double[] doubleArray73 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray74 = new double[] {};
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray73, doubleArray74);
        java.lang.Class<?> wildcardClass76 = doubleArray73.getClass();
        java.lang.Class<?> wildcardClass77 = doubleArray73.getClass();
        double[] doubleArray79 = new double[] { 0.9882067021499548d };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray73, doubleArray79);
        double double81 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray79);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray79);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) 10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(103.00786523655448d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 103.0078652365545d + "'", double1 == 103.0078652365545d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.219723898031069d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8810754698901202d) + "'", double1 == (-0.8810754698901202d));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) 1513055268);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1515194496L, (long) (-71535587));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (short) 100, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        int int2 = org.apache.commons.math.util.FastMath.max(176540, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 176540 + "'", int2 == 176540);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 2147483646);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 6178900L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 1000L);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 2147483646);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 2147483646);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger24);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (long) 2147483646);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 0);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger28);
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 0L);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) 2147483646);
        java.math.BigInteger bigInteger39 = null;
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, 0L);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, (long) 2147483646);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, bigInteger43);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger43);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(180.00000000000003d, 11013.232874703395d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 180.00000000000006d + "'", double2 == 180.00000000000006d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 30.162848702026007d, (int) (byte) 10, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 572.9577951308232d, (java.lang.Number) (-1L), (int) (short) 100, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.910423230011184d, number1, 1820, orderDirection12, false);
        java.lang.String str21 = nonMonotonousSequenceException20.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection25, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException27.getDirection();
        java.lang.Number number29 = nonMonotonousSequenceException27.getArgument();
        java.lang.String str30 = nonMonotonousSequenceException27.toString();
        java.lang.Throwable[] throwableArray31 = nonMonotonousSequenceException27.getSuppressed();
        nonMonotonousSequenceException20.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        java.lang.Number number33 = nonMonotonousSequenceException27.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,819 and 1,820 are not increasing (null > 6.91)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,819 and 1,820 are not increasing (null > 6.91)"));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 0 + "'", number29.equals(0));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str30.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (short) -1 + "'", number33.equals((short) -1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 1078034432);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078034432 + "'", int2 == 1078034432);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(319815680, 1763261280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2083076960 + "'", int2 == 2083076960);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        int[] intArray6 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray13 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int[] intArray21 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray28 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray28);
        int[] intArray36 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray43 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray36, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray36);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray36);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 75.82875444051551d + "'", double14 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 75.82875444051551d + "'", double29 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 75.82875444051551d + "'", double44 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 124 + "'", int45 == 124);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        int int11 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) -1 + "'", number10.equals((short) -1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray6 = new double[] {};
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray13 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray14 = new double[] {};
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray14);
        double[] doubleArray22 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray23 = new double[] {};
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray23);
        java.lang.Class<?> wildcardClass25 = doubleArray22.getClass();
        java.lang.Class<?> wildcardClass26 = doubleArray22.getClass();
        double[] doubleArray28 = new double[] { 0.9882067021499548d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray28);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray32 = null;
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray32);
        double[] doubleArray38 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray39 = new double[] {};
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray39);
        java.lang.Class<?> wildcardClass41 = doubleArray38.getClass();
        java.lang.Class<?> wildcardClass42 = doubleArray38.getClass();
        double[] doubleArray44 = new double[] { 0.9882067021499548d };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray44);
        double[] doubleArray51 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray52 = new double[] {};
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray59 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray60 = new double[] {};
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray60);
        double[] doubleArray68 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray69 = new double[] {};
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray68, doubleArray69);
        java.lang.Class<?> wildcardClass71 = doubleArray68.getClass();
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray68);
        double[] doubleArray77 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray78 = new double[] {};
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray77, doubleArray78);
        java.lang.Class<?> wildcardClass80 = doubleArray77.getClass();
        java.lang.Class<?> wildcardClass81 = doubleArray77.getClass();
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray68, doubleArray77);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray20 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray21 = new double[] {};
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray21);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray21);
        double[] doubleArray30 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray31 = new double[] {};
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray38 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray39 = new double[] {};
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray39);
        double[] doubleArray47 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray48 = new double[] {};
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray48);
        java.lang.Class<?> wildcardClass50 = doubleArray47.getClass();
        java.lang.Class<?> wildcardClass51 = doubleArray47.getClass();
        double[] doubleArray53 = new double[] { 0.9882067021499548d };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray53);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection57 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection57, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1763317633 + "'", int7 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection57 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection57.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        long long1 = org.apache.commons.math.util.FastMath.round((-2.504929904554044d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-3L) + "'", long1 == (-3L));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 2147483646);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 2147483646);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 2147483646);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 2147483646);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 2147483646);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger27);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) 2147483646);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 0);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger31);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 0L);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) 2147483646);
        java.math.BigInteger bigInteger43 = null;
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, 0L);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, (long) 2147483646);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, bigInteger47);
        java.math.BigInteger bigInteger49 = null;
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, 0L);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, (long) 2147483646);
        java.math.BigInteger bigInteger54 = null;
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, 0L);
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, (long) 2147483646);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, bigInteger58);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, bigInteger58);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger60);
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger60);
        java.math.BigInteger bigInteger63 = null;
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, 0L);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, (long) 2147483646);
        java.math.BigInteger bigInteger68 = null;
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger68, 0L);
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger70, (long) 2147483646);
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, bigInteger72);
        java.math.BigInteger bigInteger74 = null;
        java.math.BigInteger bigInteger76 = org.apache.commons.math.util.MathUtils.pow(bigInteger74, 0L);
        java.math.BigInteger bigInteger78 = org.apache.commons.math.util.MathUtils.pow(bigInteger76, (long) 2147483646);
        java.math.BigInteger bigInteger79 = null;
        java.math.BigInteger bigInteger81 = org.apache.commons.math.util.MathUtils.pow(bigInteger79, 0L);
        java.math.BigInteger bigInteger83 = org.apache.commons.math.util.MathUtils.pow(bigInteger81, (long) 2147483646);
        java.math.BigInteger bigInteger84 = org.apache.commons.math.util.MathUtils.pow(bigInteger78, bigInteger83);
        java.math.BigInteger bigInteger85 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, bigInteger83);
        java.math.BigInteger bigInteger86 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, bigInteger67);
        java.math.BigInteger bigInteger87 = null;
        try {
            java.math.BigInteger bigInteger88 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, bigInteger87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(bigInteger76);
        org.junit.Assert.assertNotNull(bigInteger78);
        org.junit.Assert.assertNotNull(bigInteger81);
        org.junit.Assert.assertNotNull(bigInteger83);
        org.junit.Assert.assertNotNull(bigInteger84);
        org.junit.Assert.assertNotNull(bigInteger85);
        org.junit.Assert.assertNotNull(bigInteger86);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (double) 1715946289);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 64L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 64.0f + "'", float1 == 64.0f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray6 = new double[] {};
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray13 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray14 = new double[] {};
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray14);
        double[] doubleArray22 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray23 = new double[] {};
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray23);
        java.lang.Class<?> wildcardClass25 = doubleArray22.getClass();
        java.lang.Class<?> wildcardClass26 = doubleArray22.getClass();
        double[] doubleArray28 = new double[] { 0.9882067021499548d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray28);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray36 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray37 = new double[] {};
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray37);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray44 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray45 = new double[] {};
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double[] doubleArray52 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray53 = new double[] {};
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray53);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray53);
        double[] doubleArray62 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray63 = new double[] {};
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double[] doubleArray70 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray71 = new double[] {};
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray70, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray71);
        double[] doubleArray79 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray80 = new double[] {};
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray79, doubleArray80);
        java.lang.Class<?> wildcardClass82 = doubleArray79.getClass();
        java.lang.Class<?> wildcardClass83 = doubleArray79.getClass();
        double[] doubleArray85 = new double[] { 0.9882067021499548d };
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray79, doubleArray85);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray85);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray63);
        double double89 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray53);
        java.lang.Class<?> wildcardClass90 = doubleArray53.getClass();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1763317633 + "'", int39 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(wildcardClass82);
        org.junit.Assert.assertNotNull(wildcardClass83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass90);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1860947058L), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.9882067021499548d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9882067021499549d + "'", double1 == 0.9882067021499549d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1495361471), (-90));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        int[] intArray6 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray13 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int[] intArray21 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray28 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray21);
        int[] intArray37 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray44 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray44);
        int[] intArray51 = new int[] { (byte) 0, 33, ' ', (short) 0, (byte) 1 };
        int[] intArray58 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray65 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray65);
        int[] intArray73 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray80 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray73, intArray80);
        int int82 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray80);
        int int83 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray58);
        int int84 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray58);
        double double85 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray58);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 75.82875444051551d + "'", double14 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 75.82875444051551d + "'", double29 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 124 + "'", int30 == 124);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 75.82875444051551d + "'", double45 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 75.82875444051551d + "'", double66 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 75.82875444051551d + "'", double81 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 124 + "'", int82 == 124);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 92 + "'", int83 == 92);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.7821091508568009d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1242703820);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1242703820L + "'", long1 == 1242703820L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(921088691, 1513055269);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray6 = new double[] {};
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray13 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray14 = new double[] {};
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray14);
        double[] doubleArray22 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray23 = new double[] {};
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray23);
        java.lang.Class<?> wildcardClass25 = doubleArray22.getClass();
        java.lang.Class<?> wildcardClass26 = doubleArray22.getClass();
        double[] doubleArray28 = new double[] { 0.9882067021499548d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray28);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray32 = null;
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray32);
        double[] doubleArray38 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray39 = new double[] {};
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double[] doubleArray46 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray47 = new double[] {};
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray47);
        double[] doubleArray55 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray56 = new double[] {};
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray55, doubleArray56);
        java.lang.Class<?> wildcardClass58 = doubleArray55.getClass();
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray55);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray55);
        try {
            double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 129971.98724340565d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 129971.98724340565d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 129973.97126431692d + "'", double2 == 129973.97126431692d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.2250738585072014E-308d, 6965.74774693124d, 10.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.5707963267948963d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2334031175112168d + "'", double1 == 1.2334031175112168d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 2147483646);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 2147483646);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) 2147483646);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger16);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 2147483646);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger20);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger11);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0L);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0L);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) 2147483646);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 0);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger36);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger36);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) 114);
        java.math.BigInteger bigInteger41 = null;
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, 0L);
        java.math.BigInteger bigInteger44 = null;
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 0L);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (long) 2147483646);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, 0);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger50);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 6178900L);
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 1000L);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger56);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.4947836489175637d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 176540, 34L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        double double2 = org.apache.commons.math.util.FastMath.max(1.9155040003582885E22d, (double) 33L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9155040003582885E22d + "'", double2 == 1.9155040003582885E22d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 5060L, 9.011793297850046d, (double) 110.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        float float1 = org.apache.commons.math.util.MathUtils.sign(52.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        java.lang.Number number3 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, number4, 52);
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException6.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.744654346838599d, (java.lang.Number) 1763261212, 2147483647, orderDirection9, false);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1982748969, 1720L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(33.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.917308712637254E14d + "'", double1 == 2.917308712637254E14d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 921088690);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1763317633);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1583724923) + "'", int1 == (-1583724923));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number12 = nonMonotonousSequenceException5.getArgument();
        int int13 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass15 = nonMonotonousSequenceException5.getClass();
        int int16 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0 + "'", number12.equals(0));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 34L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5263605246161616d + "'", double1 == 3.5263605246161616d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        long long1 = org.apache.commons.math.util.MathUtils.sign(16892717468L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-2661627379775963136L), 192L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-32L) + "'", long2 == (-32L));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.6108652381980153d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1924527219551986d + "'", double1 == 1.1924527219551986d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(921088690, 1072693248);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 110L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str12 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean14 = nonMonotonousSequenceException5.getStrict();
        boolean boolean15 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 115, (java.lang.Number) 1.5571986291675608d, 1515194496);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray19 = new double[] { 970L };
        double[] doubleArray24 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray25 = new double[] {};
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray25);
        java.lang.Class<?> wildcardClass27 = doubleArray24.getClass();
        java.lang.Class<?> wildcardClass28 = doubleArray24.getClass();
        double[] doubleArray30 = new double[] { 0.9882067021499548d };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (byte) -1);
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray34);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection39, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = nonMonotonousSequenceException41.getDirection();
        java.lang.String str43 = nonMonotonousSequenceException41.toString();
        boolean boolean44 = nonMonotonousSequenceException41.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = nonMonotonousSequenceException41.getDirection();
        java.lang.Class<?> wildcardClass46 = orderDirection45.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13, orderDirection45, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str43.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass46);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        long long1 = org.apache.commons.math.util.FastMath.round(180.00000000000006d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 180L + "'", long1 == 180L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-1.5707963267948966d), (double) (-1769857260));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.7698572584538474E9d) + "'", double2 == (-1.7698572584538474E9d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        double[] doubleArray1 = new double[] { 970L };
        double[] doubleArray6 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray6.getClass();
        java.lang.Class<?> wildcardClass10 = doubleArray6.getClass();
        double[] doubleArray12 = new double[] { 0.9882067021499548d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (byte) -1);
        java.lang.Class<?> wildcardClass17 = doubleArray6.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-328358037884L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) '#', 8253758366346641408L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8253758366346641373L) + "'", long2 == (-8253758366346641373L));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.5707963262277658d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.220446049250313E-16d, (java.lang.Number) 81.55795945611504d, 68);
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Class<?> wildcardClass8 = nonMonotonousSequenceException5.getClass();
        int int9 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str10 = nonMonotonousSequenceException5.toString();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 56421);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1089178752, 1083129866);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 24L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 2147483647);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2147483647L + "'", long1 == 2147483647L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-91089799L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.7385712524522046d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 248547564);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 628.738184928179d + "'", double1 == 628.738184928179d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017302733123681042d + "'", double1 == 0.017302733123681042d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray6 = new double[] {};
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray13 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray14 = new double[] {};
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray14);
        double[] doubleArray22 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray23 = new double[] {};
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray23);
        java.lang.Class<?> wildcardClass25 = doubleArray22.getClass();
        java.lang.Class<?> wildcardClass26 = doubleArray22.getClass();
        double[] doubleArray28 = new double[] { 0.9882067021499548d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray28);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray36 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray37 = new double[] {};
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double[] doubleArray44 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray45 = new double[] {};
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray45);
        double[] doubleArray53 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray54 = new double[] {};
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray54);
        java.lang.Class<?> wildcardClass56 = doubleArray53.getClass();
        java.lang.Class<?> wildcardClass57 = doubleArray53.getClass();
        double[] doubleArray59 = new double[] { 0.9882067021499548d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray59);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray59);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        int int2 = org.apache.commons.math.util.FastMath.max(1715946289, 1715945959);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1715946289 + "'", int2 == 1715946289);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.141592653589793d, (java.lang.Number) 1.6892717467999998E10d, 1072693248);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1072693248 + "'", int4 == 1072693248);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1242703820, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1242703820L + "'", long2 == 1242703820L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) -1, (long) 56421);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        double double2 = org.apache.commons.math.util.MathUtils.log(20.129462545777333d, 0.013388202148675738d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.4367475879142093d) + "'", double2 == (-1.4367475879142093d));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-186094705900L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 21159135168L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.97344301858626d) + "'", double1 == (-0.97344301858626d));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        int[] intArray5 = new int[] { (byte) 0, 33, ' ', (short) 0, (byte) 1 };
        int[] intArray12 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray19 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray19);
        int[] intArray27 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray34 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray34);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray12);
        int[] intArray38 = null;
        try {
            int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 75.82875444051551d + "'", double20 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 75.82875444051551d + "'", double35 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 124 + "'", int36 == 124);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 92 + "'", int37 == 92);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        double double1 = org.apache.commons.math.util.FastMath.tan(55.78027715682522d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9665505568284869d) + "'", double1 == (-0.9665505568284869d));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        java.lang.Class<?> wildcardClass7 = doubleArray4.getClass();
        java.lang.Class<?> wildcardClass8 = doubleArray4.getClass();
        double[] doubleArray10 = new double[] { 0.9882067021499548d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double[] doubleArray16 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray17 = new double[] {};
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray24 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray25 = new double[] {};
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray25);
        double[] doubleArray33 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray34 = new double[] {};
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray34);
        java.lang.Class<?> wildcardClass36 = doubleArray33.getClass();
        java.lang.Class<?> wildcardClass37 = doubleArray33.getClass();
        double[] doubleArray39 = new double[] { 0.9882067021499548d };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray39);
        double[] doubleArray46 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray47 = new double[] {};
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray54 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray55 = new double[] {};
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        double[] doubleArray62 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray63 = new double[] {};
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray63);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray63);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray46);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1763317633 + "'", int49 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.5440211108893697d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6098494453571887d) + "'", double1 == (-0.6098494453571887d));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.915504000358302E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        double double1 = org.apache.commons.math.util.FastMath.abs(9.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.0d + "'", double1 == 9.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.7821091508568009d), (-0.16227760542015932d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray29 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray30 = new double[] {};
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray30);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray22);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray21.getClass();
        java.lang.Class<?> wildcardClass25 = doubleArray21.getClass();
        double[] doubleArray27 = new double[] { 0.9882067021499548d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray27);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double[] doubleArray31 = null;
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1769857260) + "'", int30 == (-1769857260));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1763261264L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.983578102795704d + "'", double1 == 21.983578102795704d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        int int1 = org.apache.commons.math.util.FastMath.abs((-59312));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 59312 + "'", int1 == 59312);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 3183272820L, (-0.6098494453571887d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.0594263076782227d) + "'", double2 == (-3.0594263076782227d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        java.math.BigInteger bigInteger2 = null;
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 2147483646);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 57.29577951308233d, (java.lang.Number) bigInteger4, 1083129856);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection15, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException17.getDirection();
        java.lang.String str19 = nonMonotonousSequenceException17.toString();
        boolean boolean20 = nonMonotonousSequenceException17.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException17.getDirection();
        java.lang.Class<?> wildcardClass22 = orderDirection21.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 16892717468L, (java.lang.Number) 57.29577951308233d, 248547564, orderDirection21, true);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(88.5808275421977d, 1242703820);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.966889485553962E-14d) + "'", double2 == (-1.966889485553962E-14d));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1072693249, 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.220446049250313E-16d, (java.lang.Number) 81.55795945611504d, 68);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.2600713879850747d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2696, 1982748928);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double double2 = org.apache.commons.math.util.FastMath.min(80.8648122755551d, 2.267391555979085d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.267391555979085d + "'", double2 == 2.267391555979085d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.37423070163184d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 2696);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3956124250860895d, (java.lang.Number) 159287153400L, 92, orderDirection14, true);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(4.321225925559567E25d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        int int1 = org.apache.commons.math.util.FastMath.abs(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 30.162848702026007d, (int) (byte) 10, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 572.9577951308232d, (java.lang.Number) (-1L), (int) (short) 100, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.910423230011184d, number4, 1820, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 628.738184928179d, (java.lang.Number) 1.0d, 1072693248, orderDirection15, false);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 3183272820L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1513055258);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(32238104185L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-59312));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        long long1 = org.apache.commons.math.util.FastMath.round(1.6892717467999998E10d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 16892717468L + "'", long1 == 16892717468L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 114, 1.0829332504221427E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.392328445645785d + "'", double2 == 4.392328445645785d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0 + "'", number6.equals(0));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 32, (long) 1000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1032L + "'", long2 == 1032L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, number1, 52);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection10, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException12.getDirection();
        java.lang.String str14 = nonMonotonousSequenceException12.toString();
        boolean boolean15 = nonMonotonousSequenceException12.getStrict();
        java.lang.Class<?> wildcardClass16 = nonMonotonousSequenceException12.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException12.getDirection();
        java.lang.Number number19 = nonMonotonousSequenceException12.getArgument();
        boolean boolean20 = nonMonotonousSequenceException12.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0 + "'", number19.equals(0));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1641790195, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.641790195E9d + "'", double2 == 1.641790195E9d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.016129032258414052d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.01612903225841405d + "'", double2 == 0.01612903225841405d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 192L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, number1, 921088691);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        double double1 = org.apache.commons.math.util.FastMath.log10(68564.39980011877d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.836098678629306d + "'", double1 == 4.836098678629306d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1716122499L, (long) (-90));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-154451024910L) + "'", long2 == (-154451024910L));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 64L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1175745404058084E27d + "'", double1 == 3.1175745404058084E27d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 2147483646);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 2147483646);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 2147483646);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 2147483646);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 2147483646);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger27);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) 2147483646);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 0);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger31);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 0L);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) 2147483646);
        java.math.BigInteger bigInteger43 = null;
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, 0L);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, (long) 2147483646);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, bigInteger47);
        java.math.BigInteger bigInteger49 = null;
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, 0L);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, (long) 2147483646);
        java.math.BigInteger bigInteger54 = null;
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, 0L);
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, (long) 2147483646);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, bigInteger58);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, bigInteger58);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger60);
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger60);
        java.math.BigInteger bigInteger63 = null;
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, 0L);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, (long) 2147483646);
        java.math.BigInteger bigInteger69 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, 0);
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, bigInteger69);
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger69, 1L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger69);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger72);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        double double1 = org.apache.commons.math.util.FastMath.asin(6.910423230011184d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.5681420794060111d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1247375891);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.146937402067061E10d + "'", double1 == 7.146937402067061E10d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 1072693248);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1763261212, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.76326118E9f + "'", float2 == 1.76326118E9f);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 33.0f, 0.9882067021499548d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 3L, (double) (-1242705640L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1715945959, 1696);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        double double1 = org.apache.commons.math.util.FastMath.tan(7.305003746136002E-34d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.305003746136002E-34d + "'", double1 == 7.305003746136002E-34d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        double[] doubleArray4 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray5);
        java.lang.Class<?> wildcardClass7 = doubleArray4.getClass();
        java.lang.Class<?> wildcardClass8 = doubleArray4.getClass();
        double[] doubleArray10 = new double[] { 0.9882067021499548d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double[] doubleArray16 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray17 = new double[] {};
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray24 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray25 = new double[] {};
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray25);
        double[] doubleArray33 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray34 = new double[] {};
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray34);
        java.lang.Class<?> wildcardClass36 = doubleArray33.getClass();
        java.lang.Class<?> wildcardClass37 = doubleArray33.getClass();
        double[] doubleArray39 = new double[] { 0.9882067021499548d };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray39);
        double[] doubleArray46 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray47 = new double[] {};
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray54 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray55 = new double[] {};
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        double[] doubleArray62 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray63 = new double[] {};
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray63);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray63);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray46);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1763317633 + "'", int49 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 507780, 921088690);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(739246080, 1763261212);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1495361471));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1495364167, 1083129856);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1242705640L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        double[] doubleArray2 = new double[] { 1.8189894035458565E-12d, 180.00000000000003d };
        double[] doubleArray7 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray8 = new double[] {};
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray15 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray16 = new double[] {};
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray16);
        double[] doubleArray24 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray25 = new double[] {};
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray25);
        java.lang.Class<?> wildcardClass27 = doubleArray24.getClass();
        java.lang.Class<?> wildcardClass28 = doubleArray24.getClass();
        double[] doubleArray30 = new double[] { 0.9882067021499548d };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray30);
        double[] doubleArray37 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray38 = new double[] {};
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray45 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray46 = new double[] {};
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray53 = new double[] { 10.0d, (-1.0f), ' ', 0L };
        double[] doubleArray54 = new double[] {};
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray54);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray54);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray37);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 3.560293163444669E53d);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 52);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1763317633 + "'", int40 == 1763317633);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3956124250860895d, (java.lang.Number) 159287153400L, 92, orderDirection3, true);
        int int6 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 92 + "'", int6 == 92);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.0030302937548627655d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0030257070489342107d) + "'", double1 == (-0.0030257070489342107d));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 77L, (java.lang.Number) 8253758366346641408L, (-1));
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-0.7821091508568009d), (int) ' ', 1763261212);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-186094705900L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        int[] intArray6 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray13 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int[] intArray21 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray28 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray21);
        int[] intArray37 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray44 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray44);
        int[] intArray52 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray59 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray59);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray59);
        int[] intArray68 = new int[] { 1, '4', (short) 1, (byte) 10, ' ', 0 };
        int[] intArray75 = new int[] { 1, ' ', (byte) 0, '#', (short) 100, 10 };
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray75);
        double double77 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray68);
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray37);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 75.82875444051551d + "'", double14 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 75.82875444051551d + "'", double29 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 124 + "'", int30 == 124);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 75.82875444051551d + "'", double45 == 75.82875444051551d);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 75.82875444051551d + "'", double60 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 124 + "'", int61 == 124);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 75.82875444051551d + "'", double76 == 75.82875444051551d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) (short) -1, (int) (short) 1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        java.lang.Class<?> wildcardClass10 = nonMonotonousSequenceException5.getClass();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        boolean boolean12 = nonMonotonousSequenceException5.getStrict();
        int int13 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }
}

