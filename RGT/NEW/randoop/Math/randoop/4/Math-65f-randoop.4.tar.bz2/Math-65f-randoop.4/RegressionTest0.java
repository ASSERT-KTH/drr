import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.String[] strArray4 = new java.lang.String[] { "", "hi!", "", "" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix5 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) (short) 1, localizable2, (java.lang.Object[]) doubleArray8);
        try {
            java.lang.String str10 = functionEvaluationException9.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test003");
//        org.apache.commons.math.exception.Localizable localizable0 = null;
//        java.lang.Throwable throwable1 = null;
//        org.apache.commons.math.exception.Localizable localizable3 = null;
//        double[] doubleArray4 = new double[] {};
//        double[] doubleArray5 = new double[] {};
//        double[] doubleArray6 = new double[] {};
//        double[] doubleArray7 = new double[] {};
//        double[][] doubleArray8 = new double[][] { doubleArray4, doubleArray5, doubleArray6, doubleArray7 };
//        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(throwable1, (double) (short) 1, localizable3, (java.lang.Object[]) doubleArray9);
//        try {
//            java.util.ConcurrentModificationException concurrentModificationException11 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException(localizable0, (java.lang.Object[]) doubleArray9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray4);
//        org.junit.Assert.assertNotNull(doubleArray5);
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertNotNull(doubleArray9);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix(0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = new double[] {};
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[][] doubleArray4 = new double[][] { doubleArray0, doubleArray1, doubleArray2, doubleArray3 };
        double[][] doubleArray5 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray4);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray4);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        int[] intArray12 = new int[] { (byte) 0, (byte) 0, 10, (-1), (byte) 10, (short) 10 };
        int[] intArray15 = new int[] { '4', '4' };
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math.exception.Localizable localizable18 = null;
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray19, doubleArray20, doubleArray21, doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(throwable16, (double) (short) 1, localizable18, (java.lang.Object[]) doubleArray24);
        try {
            array2DRowRealMatrix5.copySubMatrix(intArray12, intArray15, doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = new double[] {};
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[][] doubleArray4 = new double[][] { doubleArray0, doubleArray1, doubleArray2, doubleArray3 };
        double[][] doubleArray5 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray4);
        java.io.ObjectInputStream objectInputStream7 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector((java.lang.Object) doubleArray5, "hi!", objectInputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.math.BigDecimal[] bigDecimalArray0 = new java.math.BigDecimal[] {};
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(bigDecimalArray0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigDecimalArray0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        try {
            array2DRowRealMatrix5.addToEntry(1, (int) (short) -1, 1.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (1, -1) in a 2x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException(localizable0, objArray1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        try {
            array2DRowRealMatrix5.setEntry((int) (short) 10, (int) '4', (double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (10, 52) in a 2x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double[][] doubleArray2 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(0, 100);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        int[] intArray12 = new int[] { ' ', (short) 1, (byte) 100, (byte) -1, (byte) 100, ' ' };
        int[] intArray19 = new int[] { (byte) 10, 10, (byte) -1, (byte) 10, 0, ' ' };
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5, intArray12, intArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 32 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix5.createMatrix((int) (byte) -1, 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) 10L);
        java.lang.String str2 = functionEvaluationException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10" + "'", str2.equals("org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.multiply(array2DRowRealMatrix11);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) (short) 1, localizable2, (java.lang.Object[]) doubleArray8);
        double[] doubleArray16 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException9, doubleArray16);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException18 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) functionEvaluationException9);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.String[] strArray2 = new java.lang.String[] { "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", "hi!" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix3 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix5.inverse();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 2x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        try {
            array2DRowRealMatrix5.setEntry((-1), (int) (byte) 1, (double) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (-1, 1) in a 2x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        try {
            double double8 = array2DRowRealMatrix5.getEntry((int) (byte) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (0, -1) in a 2x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math.linear.FieldMatrix<org.apache.commons.math.fraction.Fraction> fractionFieldMatrix0 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math.linear.MatrixUtils.fractionMatrixToRealMatrix(fractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test024");
//        org.apache.commons.math.exception.Localizable localizable0 = null;
//        double[] doubleArray2 = new double[] { (short) 0 };
//        double[] doubleArray4 = new double[] { (short) 0 };
//        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray4 };
//        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray5);
//        try {
//            java.io.EOFException eOFException7 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable0, (java.lang.Object[]) doubleArray5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray2);
//        org.junit.Assert.assertNotNull(doubleArray4);
//        org.junit.Assert.assertNotNull(doubleArray5);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test025");
//        org.apache.commons.math.exception.Localizable localizable1 = null;
//        double[] doubleArray3 = new double[] { (short) 0 };
//        double[] doubleArray5 = new double[] { (short) 0 };
//        double[][] doubleArray6 = new double[][] { doubleArray3, doubleArray5 };
//        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
//        try {
//            java.text.ParseException parseException8 = org.apache.commons.math.MathRuntimeException.createParseException((-1), localizable1, (java.lang.Object[]) doubleArray6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray3);
//        org.junit.Assert.assertNotNull(doubleArray5);
//        org.junit.Assert.assertNotNull(doubleArray6);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix5.getSubMatrix(0, (int) ' ', (int) (byte) 1, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 32 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test027");
//        org.apache.commons.math.exception.Localizable localizable0 = null;
//        java.lang.Throwable throwable1 = null;
//        org.apache.commons.math.exception.Localizable localizable3 = null;
//        double[] doubleArray4 = new double[] {};
//        double[] doubleArray5 = new double[] {};
//        double[] doubleArray6 = new double[] {};
//        double[] doubleArray7 = new double[] {};
//        double[][] doubleArray8 = new double[][] { doubleArray4, doubleArray5, doubleArray6, doubleArray7 };
//        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(throwable1, (double) (short) 1, localizable3, (java.lang.Object[]) doubleArray9);
//        try {
//            java.lang.NullPointerException nullPointerException11 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable0, (java.lang.Object[]) doubleArray9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray4);
//        org.junit.Assert.assertNotNull(doubleArray5);
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertNotNull(doubleArray9);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        org.apache.commons.math.exception.Localizable localizable1 = null;
//        double[] doubleArray5 = new double[] {};
//        double[] doubleArray6 = new double[] {};
//        double[] doubleArray7 = new double[] {};
//        double[] doubleArray8 = new double[] {};
//        double[][] doubleArray9 = new double[][] { doubleArray5, doubleArray6, doubleArray7, doubleArray8 };
//        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray9);
//        java.lang.NullPointerException nullPointerException12 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray9);
//        double[] doubleArray14 = new double[] { 10L };
//        org.apache.commons.math.exception.Localizable localizable15 = null;
//        double[] doubleArray18 = new double[] {};
//        double[] doubleArray19 = new double[] {};
//        double[] doubleArray20 = new double[] {};
//        double[] doubleArray21 = new double[] {};
//        double[][] doubleArray22 = new double[][] { doubleArray18, doubleArray19, doubleArray20, doubleArray21 };
//        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
//        java.text.ParseException parseException24 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray22);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException12, doubleArray14, localizable15, (java.lang.Object[]) doubleArray22);
//        double[] doubleArray30 = new double[] {};
//        double[] doubleArray31 = new double[] {};
//        double[] doubleArray32 = new double[] {};
//        double[] doubleArray33 = new double[] {};
//        double[][] doubleArray34 = new double[][] { doubleArray30, doubleArray31, doubleArray32, doubleArray33 };
//        double[][] doubleArray35 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray34);
//        java.lang.NullPointerException nullPointerException37 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray34);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException12, "hi!", (java.lang.Object[]) doubleArray34);
//        java.lang.Throwable throwable39 = null;
//        org.apache.commons.math.exception.Localizable localizable41 = null;
//        double[] doubleArray42 = new double[] {};
//        double[] doubleArray43 = new double[] {};
//        double[] doubleArray44 = new double[] {};
//        double[] doubleArray45 = new double[] {};
//        double[][] doubleArray46 = new double[][] { doubleArray42, doubleArray43, doubleArray44, doubleArray45 };
//        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(throwable39, (double) (short) 1, localizable41, (java.lang.Object[]) doubleArray47);
//        double[] doubleArray55 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException48, doubleArray55);
//        org.apache.commons.math.exception.Localizable localizable57 = null;
//        double[] doubleArray58 = new double[] {};
//        double[] doubleArray59 = new double[] {};
//        double[] doubleArray60 = new double[] {};
//        double[] doubleArray61 = new double[] {};
//        double[][] doubleArray62 = new double[][] { doubleArray58, doubleArray59, doubleArray60, doubleArray61 };
//        double[][] doubleArray63 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray62);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException12, doubleArray55, localizable57, (java.lang.Object[]) doubleArray62);
//        double[] doubleArray68 = new double[] {};
//        double[] doubleArray69 = new double[] {};
//        double[] doubleArray70 = new double[] {};
//        double[] doubleArray71 = new double[] {};
//        double[][] doubleArray72 = new double[][] { doubleArray68, doubleArray69, doubleArray70, doubleArray71 };
//        double[][] doubleArray73 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray72);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray72);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException75 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException64, "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", (java.lang.Object[]) doubleArray72);
//        try {
//            java.text.ParseException parseException76 = org.apache.commons.math.MathRuntimeException.createParseException(100, localizable1, (java.lang.Object[]) doubleArray72);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray5);
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertNotNull(doubleArray9);
//        org.junit.Assert.assertNotNull(doubleArray10);
//        org.junit.Assert.assertNotNull(nullPointerException12);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertNotNull(doubleArray18);
//        org.junit.Assert.assertNotNull(doubleArray19);
//        org.junit.Assert.assertNotNull(doubleArray20);
//        org.junit.Assert.assertNotNull(doubleArray21);
//        org.junit.Assert.assertNotNull(doubleArray22);
//        org.junit.Assert.assertNotNull(doubleArray23);
//        org.junit.Assert.assertNotNull(parseException24);
//        org.junit.Assert.assertNotNull(doubleArray30);
//        org.junit.Assert.assertNotNull(doubleArray31);
//        org.junit.Assert.assertNotNull(doubleArray32);
//        org.junit.Assert.assertNotNull(doubleArray33);
//        org.junit.Assert.assertNotNull(doubleArray34);
//        org.junit.Assert.assertNotNull(doubleArray35);
//        org.junit.Assert.assertNotNull(nullPointerException37);
//        org.junit.Assert.assertNotNull(doubleArray42);
//        org.junit.Assert.assertNotNull(doubleArray43);
//        org.junit.Assert.assertNotNull(doubleArray44);
//        org.junit.Assert.assertNotNull(doubleArray45);
//        org.junit.Assert.assertNotNull(doubleArray46);
//        org.junit.Assert.assertNotNull(doubleArray47);
//        org.junit.Assert.assertNotNull(doubleArray55);
//        org.junit.Assert.assertNotNull(doubleArray58);
//        org.junit.Assert.assertNotNull(doubleArray59);
//        org.junit.Assert.assertNotNull(doubleArray60);
//        org.junit.Assert.assertNotNull(doubleArray61);
//        org.junit.Assert.assertNotNull(doubleArray62);
//        org.junit.Assert.assertNotNull(doubleArray63);
//        org.junit.Assert.assertNotNull(doubleArray68);
//        org.junit.Assert.assertNotNull(doubleArray69);
//        org.junit.Assert.assertNotNull(doubleArray70);
//        org.junit.Assert.assertNotNull(doubleArray71);
//        org.junit.Assert.assertNotNull(doubleArray72);
//        org.junit.Assert.assertNotNull(doubleArray73);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) (short) -1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double double13 = array2DRowRealMatrix11.getNorm();
        try {
            double[] doubleArray15 = array2DRowRealMatrix11.getColumn((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        try {
            array2DRowRealMatrix11.luDecompose();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 2x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray20 = new double[] { (short) 0 };
        double[] doubleArray22 = new double[] { (short) 0 };
        double[][] doubleArray23 = new double[][] { doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix18.add(array2DRowRealMatrix24);
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix24);
        org.apache.commons.math.linear.RealVector realVector27 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector28 = array2DRowRealMatrix5.operate(realVector27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix2 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix((int) 'a', (int) (byte) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        java.lang.Throwable throwable14 = null;
        org.apache.commons.math.exception.Localizable localizable16 = null;
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[][] doubleArray21 = new double[][] { doubleArray17, doubleArray18, doubleArray19, doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(throwable14, (double) (short) 1, localizable16, (java.lang.Object[]) doubleArray22);
        double[] doubleArray30 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException23, doubleArray30);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        double[][] doubleArray40 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray39);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray39);
        java.lang.NullPointerException nullPointerException42 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray39);
        double[] doubleArray44 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable45 = null;
        double[] doubleArray48 = new double[] {};
        double[] doubleArray49 = new double[] {};
        double[] doubleArray50 = new double[] {};
        double[] doubleArray51 = new double[] {};
        double[][] doubleArray52 = new double[][] { doubleArray48, doubleArray49, doubleArray50, doubleArray51 };
        double[][] doubleArray53 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray52);
        java.text.ParseException parseException54 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException42, doubleArray44, localizable45, (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair57 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray30, doubleArray44, true);
        org.apache.commons.math.linear.BigMatrix bigMatrix58 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray44);
        try {
            array2DRowRealMatrix5.setColumn(0, doubleArray44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 1x1 but expected 2x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(nullPointerException42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(parseException54);
        org.junit.Assert.assertNotNull(bigMatrix58);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        java.lang.String str13 = array2DRowRealMatrix11.toString();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix15 = array2DRowRealMatrix11.solve(realMatrix14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 2x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str13.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector((java.lang.Object) (short) 0, "hi!", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray10);
        java.lang.NullPointerException nullPointerException13 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray10);
        double[] doubleArray15 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable16 = null;
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray19, doubleArray20, doubleArray21, doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        java.text.ParseException parseException25 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException13, doubleArray15, localizable16, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.linear.BigMatrix bigMatrix27 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray15);
        try {
            double[] doubleArray28 = blockRealMatrix2.preMultiply(doubleArray15);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(nullPointerException13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(parseException25);
        org.junit.Assert.assertNotNull(bigMatrix27);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double4 = blockRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = blockRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor3, (int) 'a', (int) '4', (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        blockRealMatrix2.setEntry((int) (byte) 1, (int) '#', (double) (-1L));
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.getRowMatrix((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[][] doubleArray20 = new double[][] { doubleArray16, doubleArray17, doubleArray18, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray20);
        java.lang.NullPointerException nullPointerException23 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray20);
        double[] doubleArray25 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable26 = null;
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[] doubleArray32 = new double[] {};
        double[][] doubleArray33 = new double[][] { doubleArray29, doubleArray30, doubleArray31, doubleArray32 };
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray33);
        java.text.ParseException parseException35 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException23, doubleArray25, localizable26, (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.linear.BigMatrix bigMatrix37 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray25);
        try {
            double[] doubleArray38 = array2DRowRealMatrix5.preMultiply(doubleArray25);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(nullPointerException23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(parseException35);
        org.junit.Assert.assertNotNull(bigMatrix37);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        double[] doubleArray8 = new double[] { (short) 0 };
        double[] doubleArray10 = new double[] { (short) 0 };
        double[][] doubleArray11 = new double[][] { doubleArray8, doubleArray10 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix12.add(array2DRowRealMatrix18);
        java.lang.String str20 = array2DRowRealMatrix18.toString();
        org.apache.commons.math.linear.RealVector realVector22 = array2DRowRealMatrix18.getColumnVector(0);
        try {
            blockRealMatrix2.setRowVector(1, realVector22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 1x2 but expected 1x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str20.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(realVector22);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray7);
        java.lang.NullPointerException nullPointerException10 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray7);
        double[] doubleArray12 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[][] doubleArray20 = new double[][] { doubleArray16, doubleArray17, doubleArray18, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        java.text.ParseException parseException22 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException10, doubleArray12, localizable13, (java.lang.Object[]) doubleArray20);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[][] doubleArray32 = new double[][] { doubleArray28, doubleArray29, doubleArray30, doubleArray31 };
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray32);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray32);
        java.lang.NullPointerException nullPointerException35 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray32);
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException10, "hi!", (java.lang.Object[]) doubleArray32);
        java.lang.Throwable throwable37 = null;
        org.apache.commons.math.exception.Localizable localizable39 = null;
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[][] doubleArray44 = new double[][] { doubleArray40, doubleArray41, doubleArray42, doubleArray43 };
        double[][] doubleArray45 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException(throwable37, (double) (short) 1, localizable39, (java.lang.Object[]) doubleArray45);
        double[] doubleArray53 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException46, doubleArray53);
        org.apache.commons.math.exception.Localizable localizable55 = null;
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[][] doubleArray60 = new double[][] { doubleArray56, doubleArray57, doubleArray58, doubleArray59 };
        double[][] doubleArray61 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray60);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException10, doubleArray53, localizable55, (java.lang.Object[]) doubleArray60);
        org.apache.commons.math.exception.Localizable localizable63 = functionEvaluationException62.getLocalizablePattern();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(nullPointerException10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(parseException22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(nullPointerException35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNull(localizable63);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray7);
        java.lang.NullPointerException nullPointerException10 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray7);
        double[] doubleArray12 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[][] doubleArray20 = new double[][] { doubleArray16, doubleArray17, doubleArray18, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        java.text.ParseException parseException22 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException10, doubleArray12, localizable13, (java.lang.Object[]) doubleArray20);
        java.lang.RuntimeException runtimeException24 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) functionEvaluationException23);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(nullPointerException10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(parseException22);
        org.junit.Assert.assertNotNull(runtimeException24);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (byte) 10, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix1 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray5, doubleArray6, doubleArray7, doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray9);
        java.lang.NullPointerException nullPointerException12 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray9);
        double[] doubleArray14 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable15 = null;
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[] doubleArray21 = new double[] {};
        double[][] doubleArray22 = new double[][] { doubleArray18, doubleArray19, doubleArray20, doubleArray21 };
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        java.text.ParseException parseException24 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException12, doubleArray14, localizable15, (java.lang.Object[]) doubleArray22);
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[] doubleArray32 = new double[] {};
        double[] doubleArray33 = new double[] {};
        double[][] doubleArray34 = new double[][] { doubleArray30, doubleArray31, doubleArray32, doubleArray33 };
        double[][] doubleArray35 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray34);
        java.lang.NullPointerException nullPointerException37 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray34);
        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException12, "hi!", (java.lang.Object[]) doubleArray34);
        java.lang.Throwable throwable39 = null;
        org.apache.commons.math.exception.Localizable localizable41 = null;
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[][] doubleArray46 = new double[][] { doubleArray42, doubleArray43, doubleArray44, doubleArray45 };
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(throwable39, (double) (short) 1, localizable41, (java.lang.Object[]) doubleArray47);
        double[] doubleArray55 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException48, doubleArray55);
        org.apache.commons.math.exception.Localizable localizable57 = null;
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[] doubleArray60 = new double[] {};
        double[] doubleArray61 = new double[] {};
        double[][] doubleArray62 = new double[][] { doubleArray58, doubleArray59, doubleArray60, doubleArray61 };
        double[][] doubleArray63 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray62);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException12, doubleArray55, localizable57, (java.lang.Object[]) doubleArray62);
        double[] doubleArray68 = new double[] {};
        double[] doubleArray69 = new double[] {};
        double[] doubleArray70 = new double[] {};
        double[] doubleArray71 = new double[] {};
        double[][] doubleArray72 = new double[][] { doubleArray68, doubleArray69, doubleArray70, doubleArray71 };
        double[][] doubleArray73 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray72);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray72);
        org.apache.commons.math.MathRuntimeException mathRuntimeException75 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException64, "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", (java.lang.Object[]) doubleArray72);
        java.lang.Object[] objArray76 = mathRuntimeException75.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException77 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable1, objArray76);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(nullPointerException12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(parseException24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(nullPointerException37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[][] doubleArray13 = array2DRowRealMatrix11.getData();
        try {
            double double14 = array2DRowRealMatrix11.getDeterminant();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 2x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((-1));
        int int2 = maxEvaluationsExceededException1.getMaxEvaluations();
        java.lang.Object[] objArray4 = null;
        java.lang.IllegalStateException illegalStateException5 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray4);
        maxEvaluationsExceededException1.addSuppressed((java.lang.Throwable) illegalStateException5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(illegalStateException5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        blockRealMatrix2.setEntry((int) (byte) 1, (int) '#', (double) (-1L));
        try {
            blockRealMatrix2.addToEntry((int) (short) 100, (int) (byte) 10, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (100, 10) in a 52x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        try {
            double double13 = array2DRowRealMatrix12.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 2x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double double13 = array2DRowRealMatrix11.getNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor14 = null;
        try {
            double double15 = array2DRowRealMatrix11.walkInColumnOrder(realMatrixPreservingVisitor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double11 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor6, 100, (int) (byte) 0, 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double double13 = array2DRowRealMatrix11.getNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix11.inverse();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 2x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        java.lang.String str13 = array2DRowRealMatrix11.toString();
        double[] doubleArray19 = new double[] { (short) 0 };
        double[] doubleArray21 = new double[] { (short) 0 };
        double[][] doubleArray22 = new double[][] { doubleArray19, doubleArray21 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        try {
            array2DRowRealMatrix11.copySubMatrix((int) ' ', (int) (short) 10, 1, (int) '4', doubleArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 32 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str13.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10);
        java.lang.IllegalArgumentException illegalArgumentException2 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) maxIterationsExceededException1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[] doubleArray28 = new double[] {};
        double[] doubleArray29 = new double[] {};
        double[][] doubleArray30 = new double[][] { doubleArray26, doubleArray27, doubleArray28, doubleArray29 };
        double[][] doubleArray31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray30);
        java.lang.NullPointerException nullPointerException33 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray30);
        double[] doubleArray35 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[][] doubleArray43 = new double[][] { doubleArray39, doubleArray40, doubleArray41, doubleArray42 };
        double[][] doubleArray44 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray43);
        java.text.ParseException parseException45 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException33, doubleArray35, localizable36, (java.lang.Object[]) doubleArray43);
        double[] doubleArray51 = new double[] {};
        double[] doubleArray52 = new double[] {};
        double[] doubleArray53 = new double[] {};
        double[] doubleArray54 = new double[] {};
        double[][] doubleArray55 = new double[][] { doubleArray51, doubleArray52, doubleArray53, doubleArray54 };
        double[][] doubleArray56 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray55);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray55);
        java.lang.NullPointerException nullPointerException58 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray55);
        org.apache.commons.math.MathRuntimeException mathRuntimeException59 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException33, "hi!", (java.lang.Object[]) doubleArray55);
        java.lang.Throwable throwable60 = null;
        org.apache.commons.math.exception.Localizable localizable62 = null;
        double[] doubleArray63 = new double[] {};
        double[] doubleArray64 = new double[] {};
        double[] doubleArray65 = new double[] {};
        double[] doubleArray66 = new double[] {};
        double[][] doubleArray67 = new double[][] { doubleArray63, doubleArray64, doubleArray65, doubleArray66 };
        double[][] doubleArray68 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray67);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException(throwable60, (double) (short) 1, localizable62, (java.lang.Object[]) doubleArray68);
        double[] doubleArray76 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException77 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException69, doubleArray76);
        org.apache.commons.math.exception.Localizable localizable78 = null;
        double[] doubleArray79 = new double[] {};
        double[] doubleArray80 = new double[] {};
        double[] doubleArray81 = new double[] {};
        double[] doubleArray82 = new double[] {};
        double[][] doubleArray83 = new double[][] { doubleArray79, doubleArray80, doubleArray81, doubleArray82 };
        double[][] doubleArray84 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray83);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException85 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException33, doubleArray76, localizable78, (java.lang.Object[]) doubleArray83);
        double[] doubleArray89 = new double[] {};
        double[] doubleArray90 = new double[] {};
        double[] doubleArray91 = new double[] {};
        double[] doubleArray92 = new double[] {};
        double[][] doubleArray93 = new double[][] { doubleArray89, doubleArray90, doubleArray91, doubleArray92 };
        double[][] doubleArray94 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray93);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException95 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray93);
        org.apache.commons.math.MathRuntimeException mathRuntimeException96 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException85, "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", (java.lang.Object[]) doubleArray93);
        java.lang.Object[] objArray97 = mathRuntimeException96.getArguments();
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException98 = new org.apache.commons.math.linear.InvalidMatrixException("org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", objArray97);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException99 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException1, doubleArray19, "", objArray97);
        org.junit.Assert.assertNotNull(illegalArgumentException2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(nullPointerException33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(parseException45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(nullPointerException58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(objArray97);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        java.io.ObjectOutputStream objectOutputStream48 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math.linear.RealMatrix) blockRealMatrix2, objectOutputStream48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        blockRealMatrix2.setEntry((int) (byte) 1, (int) '#', (double) (-1L));
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        try {
            blockRealMatrix2.setRowMatrix(100, blockRealMatrix10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray20 = new double[] { (short) 0 };
        double[] doubleArray22 = new double[] { (short) 0 };
        double[][] doubleArray23 = new double[][] { doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix18.add(array2DRowRealMatrix24);
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix24);
        try {
            array2DRowRealMatrix24.multiplyEntry((int) (short) 1, 1, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (1, 1) in a 2x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        try {
            org.apache.commons.math.linear.RealVector realVector52 = blockRealMatrix2.getColumnVector((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 52 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double double13 = array2DRowRealMatrix11.getNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix15 = array2DRowRealMatrix11.getRowMatrix((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 35 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor13 = null;
        try {
            double double18 = array2DRowRealMatrix12.walkInRowOrder(realMatrixChangingVisitor13, (int) (byte) 0, 10, (int) '4', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor13 = null;
        try {
            double double18 = array2DRowRealMatrix12.walkInColumnOrder(realMatrixChangingVisitor13, (int) (short) 0, (int) '4', (int) (short) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((-1));
        org.apache.commons.math.optimization.OptimizationException optimizationException2 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException1);
        org.apache.commons.math.linear.SingularMatrixException singularMatrixException6 = new org.apache.commons.math.linear.SingularMatrixException();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray11 = new double[] { (short) 0 };
        double[] doubleArray13 = new double[] { (short) 0 };
        double[][] doubleArray14 = new double[][] { doubleArray11, doubleArray13 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException16 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "hi!", (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) singularMatrixException6, localizable7, (java.lang.Object[]) doubleArray14);
        java.lang.IllegalArgumentException illegalArgumentException18 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException2, (double) (-1), "Array2DRowRealMatrix{{0.0},{0.0}}", (java.lang.Object[]) doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(illegalArgumentException18);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        double[] doubleArray7 = blockRealMatrix2.getRow((int) (short) 0);
        double[][] doubleArray8 = blockRealMatrix2.getData();
        double[] doubleArray11 = new double[] {};
        double[] doubleArray12 = new double[] {};
        double[] doubleArray13 = new double[] {};
        double[] doubleArray14 = new double[] {};
        double[][] doubleArray15 = new double[][] { doubleArray11, doubleArray12, doubleArray13, doubleArray14 };
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray15);
        try {
            blockRealMatrix2.setSubMatrix(doubleArray15, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor51 = null;
        try {
            double double56 = blockRealMatrix50.walkInOptimizedOrder(realMatrixChangingVisitor51, (int) (short) 100, (int) (short) 0, (int) 'a', 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 96]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = org.apache.commons.math.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray20 = new double[] { (short) 0 };
        double[] doubleArray22 = new double[] { (short) 0 };
        double[][] doubleArray23 = new double[][] { doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix18.add(array2DRowRealMatrix24);
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix24);
        java.lang.Throwable throwable27 = null;
        org.apache.commons.math.exception.Localizable localizable29 = null;
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[] doubleArray32 = new double[] {};
        double[] doubleArray33 = new double[] {};
        double[][] doubleArray34 = new double[][] { doubleArray30, doubleArray31, doubleArray32, doubleArray33 };
        double[][] doubleArray35 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(throwable27, (double) (short) 1, localizable29, (java.lang.Object[]) doubleArray35);
        double[] doubleArray43 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException36, doubleArray43);
        double[] doubleArray48 = new double[] {};
        double[] doubleArray49 = new double[] {};
        double[] doubleArray50 = new double[] {};
        double[] doubleArray51 = new double[] {};
        double[][] doubleArray52 = new double[][] { doubleArray48, doubleArray49, doubleArray50, doubleArray51 };
        double[][] doubleArray53 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray52);
        java.lang.NullPointerException nullPointerException55 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray52);
        double[] doubleArray57 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable58 = null;
        double[] doubleArray61 = new double[] {};
        double[] doubleArray62 = new double[] {};
        double[] doubleArray63 = new double[] {};
        double[] doubleArray64 = new double[] {};
        double[][] doubleArray65 = new double[][] { doubleArray61, doubleArray62, doubleArray63, doubleArray64 };
        double[][] doubleArray66 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray65);
        java.text.ParseException parseException67 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray65);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException68 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException55, doubleArray57, localizable58, (java.lang.Object[]) doubleArray65);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair70 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray43, doubleArray57, true);
        double[] doubleArray71 = vectorialPointValuePair70.getPointRef();
        org.apache.commons.math.linear.BigMatrix bigMatrix72 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray71);
        try {
            double[] doubleArray73 = array2DRowRealMatrix24.preMultiply(doubleArray71);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(nullPointerException55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(parseException67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(bigMatrix72);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        double[] doubleArray7 = blockRealMatrix2.getRow((int) (short) 0);
        double[][] doubleArray8 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double10 = blockRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor((double) (short) 10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray20 = new double[] { (short) 0 };
        double[] doubleArray22 = new double[] { (short) 0 };
        double[][] doubleArray23 = new double[][] { doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix18.add(array2DRowRealMatrix24);
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix24);
        try {
            org.apache.commons.math.linear.RealVector realVector28 = array2DRowRealMatrix5.getRowVector(36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 36 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable51 = null;
        org.apache.commons.math.exception.Localizable localizable53 = null;
        double[] doubleArray54 = new double[] {};
        double[] doubleArray55 = new double[] {};
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[][] doubleArray58 = new double[][] { doubleArray54, doubleArray55, doubleArray56, doubleArray57 };
        double[][] doubleArray59 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException(throwable51, (double) (short) 1, localizable53, (java.lang.Object[]) doubleArray59);
        double[] doubleArray67 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException68 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException60, doubleArray67);
        double[] doubleArray72 = new double[] {};
        double[] doubleArray73 = new double[] {};
        double[] doubleArray74 = new double[] {};
        double[] doubleArray75 = new double[] {};
        double[][] doubleArray76 = new double[][] { doubleArray72, doubleArray73, doubleArray74, doubleArray75 };
        double[][] doubleArray77 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray76);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray76);
        java.lang.NullPointerException nullPointerException79 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray76);
        double[] doubleArray81 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable82 = null;
        double[] doubleArray85 = new double[] {};
        double[] doubleArray86 = new double[] {};
        double[] doubleArray87 = new double[] {};
        double[] doubleArray88 = new double[] {};
        double[][] doubleArray89 = new double[][] { doubleArray85, doubleArray86, doubleArray87, doubleArray88 };
        double[][] doubleArray90 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray89);
        java.text.ParseException parseException91 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray89);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException92 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException79, doubleArray81, localizable82, (java.lang.Object[]) doubleArray89);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair94 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray67, doubleArray81, true);
        double[] doubleArray95 = blockRealMatrix50.operate(doubleArray81);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix98 = blockRealMatrix50.createMatrix((int) 'a', (int) ' ');
        try {
            org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix2, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix50);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(nullPointerException79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(parseException91);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertNotNull(blockRealMatrix98);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        java.lang.String str13 = array2DRowRealMatrix11.toString();
        int[] intArray18 = new int[] { (byte) 100, (byte) 10, (byte) 10, (byte) 0 };
        int[] intArray20 = new int[] { 2147483647 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        java.lang.Throwable throwable22 = null;
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[] doubleArray28 = new double[] {};
        double[][] doubleArray29 = new double[][] { doubleArray25, doubleArray26, doubleArray27, doubleArray28 };
        double[][] doubleArray30 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(throwable22, (double) (short) 1, localizable24, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.optimization.OptimizationException optimizationException32 = new org.apache.commons.math.optimization.OptimizationException(localizable21, (java.lang.Object[]) doubleArray30);
        try {
            array2DRowRealMatrix11.copySubMatrix(intArray18, intArray20, doubleArray30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str13.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        java.lang.String str13 = array2DRowRealMatrix11.toString();
        org.apache.commons.math.linear.RealVector realVector15 = array2DRowRealMatrix11.getColumnVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix11.scalarAdd((double) 0.0f);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double23 = blockRealMatrix20.getEntry(0, 0);
        double[] doubleArray25 = blockRealMatrix20.getRow((int) (short) 0);
        try {
            double[] doubleArray26 = array2DRowRealMatrix11.solve(doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 2x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str13.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor48 = null;
        try {
            double double53 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor48, (int) (short) 100, 0, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = blockRealMatrix2.scalarMultiply((double) (short) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double55 = blockRealMatrix52.getEntry(0, 0);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix56 = blockRealMatrix2.multiply((org.apache.commons.math.linear.RealMatrix) blockRealMatrix52);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix7 = blockRealMatrix2.getColumnMatrix(2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 2,147,483,647 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix2.transpose();
        try {
            double[] doubleArray53 = blockRealMatrix51.getColumn((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 97 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray20 = new double[] { (short) 0 };
        double[] doubleArray22 = new double[] { (short) 0 };
        double[][] doubleArray23 = new double[][] { doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix18.add(array2DRowRealMatrix24);
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix24);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix5.inverse();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 2x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.Object[] objArray1 = null;
        java.lang.IllegalStateException illegalStateException2 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray1);
        org.junit.Assert.assertNotNull(illegalStateException2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double[] doubleArray3 = new double[] { 10, (short) 100, ' ' };
        org.apache.commons.math.linear.RealMatrix realMatrix4 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realMatrix4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        java.lang.String str13 = array2DRowRealMatrix11.toString();
        org.apache.commons.math.linear.RealVector realVector15 = array2DRowRealMatrix11.getColumnVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix11.scalarAdd((double) 0.0f);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable22 = null;
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[] doubleArray28 = new double[] {};
        double[][] doubleArray29 = new double[][] { doubleArray25, doubleArray26, doubleArray27, doubleArray28 };
        double[][] doubleArray30 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(throwable22, (double) (short) 1, localizable24, (java.lang.Object[]) doubleArray30);
        double[] doubleArray38 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException31, doubleArray38);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[][] doubleArray47 = new double[][] { doubleArray43, doubleArray44, doubleArray45, doubleArray46 };
        double[][] doubleArray48 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray47);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray47);
        java.lang.NullPointerException nullPointerException50 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray47);
        double[] doubleArray52 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable53 = null;
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[][] doubleArray60 = new double[][] { doubleArray56, doubleArray57, doubleArray58, doubleArray59 };
        double[][] doubleArray61 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray60);
        java.text.ParseException parseException62 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray60);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException50, doubleArray52, localizable53, (java.lang.Object[]) doubleArray60);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair65 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray38, doubleArray52, true);
        double[] doubleArray66 = blockRealMatrix21.operate(doubleArray52);
        org.apache.commons.math.linear.RealVector realVector67 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray52);
        try {
            array2DRowRealMatrix11.setColumnVector((int) '4', realVector67);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 52 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str13.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(nullPointerException50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(parseException62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realVector67);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray4, doubleArray5, doubleArray6, doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray8);
        java.lang.NullPointerException nullPointerException11 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray8);
        double[] doubleArray13 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable14 = null;
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[][] doubleArray21 = new double[][] { doubleArray17, doubleArray18, doubleArray19, doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        java.text.ParseException parseException23 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray21);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException11, doubleArray13, localizable14, (java.lang.Object[]) doubleArray21);
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[] doubleArray32 = new double[] {};
        double[][] doubleArray33 = new double[][] { doubleArray29, doubleArray30, doubleArray31, doubleArray32 };
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray33);
        java.lang.NullPointerException nullPointerException36 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException11, "hi!", (java.lang.Object[]) doubleArray33);
        java.lang.Throwable throwable38 = null;
        org.apache.commons.math.exception.Localizable localizable40 = null;
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[][] doubleArray45 = new double[][] { doubleArray41, doubleArray42, doubleArray43, doubleArray44 };
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException(throwable38, (double) (short) 1, localizable40, (java.lang.Object[]) doubleArray46);
        double[] doubleArray54 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException47, doubleArray54);
        org.apache.commons.math.exception.Localizable localizable56 = null;
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[] doubleArray60 = new double[] {};
        double[][] doubleArray61 = new double[][] { doubleArray57, doubleArray58, doubleArray59, doubleArray60 };
        double[][] doubleArray62 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray61);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException11, doubleArray54, localizable56, (java.lang.Object[]) doubleArray61);
        double[] doubleArray67 = new double[] {};
        double[] doubleArray68 = new double[] {};
        double[] doubleArray69 = new double[] {};
        double[] doubleArray70 = new double[] {};
        double[][] doubleArray71 = new double[][] { doubleArray67, doubleArray68, doubleArray69, doubleArray70 };
        double[][] doubleArray72 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray71);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray71);
        org.apache.commons.math.MathRuntimeException mathRuntimeException74 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException63, "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", (java.lang.Object[]) doubleArray71);
        java.lang.Object[] objArray75 = mathRuntimeException74.getArguments();
        org.apache.commons.math.exception.Localizable localizable76 = mathRuntimeException74.getLocalizablePattern();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException78 = new org.apache.commons.math.MaxEvaluationsExceededException((-1));
        org.apache.commons.math.optimization.OptimizationException optimizationException79 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException78);
        java.lang.Throwable[] throwableArray80 = optimizationException79.getSuppressed();
        java.text.ParseException parseException81 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) 10, localizable76, (java.lang.Object[]) throwableArray80);
        org.apache.commons.math.linear.SingularMatrixException singularMatrixException85 = new org.apache.commons.math.linear.SingularMatrixException();
        org.apache.commons.math.exception.Localizable localizable86 = null;
        double[] doubleArray90 = new double[] { (short) 0 };
        double[] doubleArray92 = new double[] { (short) 0 };
        double[][] doubleArray93 = new double[][] { doubleArray90, doubleArray92 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix94 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray93);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException95 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "hi!", (java.lang.Object[]) doubleArray93);
        org.apache.commons.math.MathRuntimeException mathRuntimeException96 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) singularMatrixException85, localizable86, (java.lang.Object[]) doubleArray93);
        java.lang.IllegalArgumentException illegalArgumentException97 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", (java.lang.Object[]) doubleArray93);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException98 = new org.apache.commons.math.FunctionEvaluationException((double) (-1L), "", (java.lang.Object[]) doubleArray93);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException99 = new org.apache.commons.math.linear.MatrixIndexException(localizable76, (java.lang.Object[]) doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(nullPointerException11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(parseException23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(nullPointerException36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(localizable76);
        org.junit.Assert.assertNotNull(throwableArray80);
        org.junit.Assert.assertNotNull(parseException81);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(illegalArgumentException97);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigIdentityMatrix((int) (short) 100);
        org.junit.Assert.assertNotNull(bigMatrix1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double double13 = array2DRowRealMatrix11.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix11.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double21 = blockRealMatrix18.getEntry(0, 0);
        double[] doubleArray23 = blockRealMatrix18.getRow((int) (short) 0);
        try {
            array2DRowRealMatrix11.setColumn(0, doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 1x1 but expected 2x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        java.lang.String str13 = array2DRowRealMatrix11.toString();
        org.apache.commons.math.linear.RealVector realVector15 = array2DRowRealMatrix11.getColumnVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix11.scalarAdd((double) 0.0f);
        boolean boolean18 = array2DRowRealMatrix11.isSquare();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str13.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor52 = null;
        try {
            double double57 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor52, (int) (byte) 0, 100, (int) (byte) 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        java.lang.String str13 = array2DRowRealMatrix11.toString();
        org.apache.commons.math.linear.RealVector realVector15 = array2DRowRealMatrix11.getColumnVector(0);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix11.scalarAdd((double) 0.0f);
        double[] doubleArray20 = new double[] { (short) 0 };
        double[] doubleArray22 = new double[] { (short) 0 };
        double[][] doubleArray23 = new double[][] { doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        array2DRowRealMatrix24.multiplyEntry((int) (byte) 1, 0, (double) 0);
        try {
            array2DRowRealMatrix11.setColumnMatrix((int) (byte) 100, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str13.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[][] doubleArray21 = new double[][] { doubleArray17, doubleArray18, doubleArray19, doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray21);
        java.lang.NullPointerException nullPointerException24 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray21);
        double[] doubleArray26 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[] doubleArray32 = new double[] {};
        double[] doubleArray33 = new double[] {};
        double[][] doubleArray34 = new double[][] { doubleArray30, doubleArray31, doubleArray32, doubleArray33 };
        double[][] doubleArray35 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        java.text.ParseException parseException36 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException24, doubleArray26, localizable27, (java.lang.Object[]) doubleArray34);
        org.apache.commons.math.linear.BigMatrix bigMatrix38 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray26);
        try {
            array2DRowRealMatrix11.setColumn(0, doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 1x1 but expected 2x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(nullPointerException24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(parseException36);
        org.junit.Assert.assertNotNull(bigMatrix38);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        try {
            array2DRowRealMatrix5.setRowMatrix((int) (short) 100, (org.apache.commons.math.linear.RealMatrix) blockRealMatrix16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        double[] doubleArray7 = blockRealMatrix2.getRow((int) (short) 0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double9 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix2.transpose();
        double[][] doubleArray52 = blockRealMatrix51.getData();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor53 = null;
        try {
            double double58 = blockRealMatrix51.walkInRowOrder(realMatrixPreservingVisitor53, 100, (int) 'a', 1, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigIdentityMatrix((int) (byte) 1);
        org.junit.Assert.assertNotNull(bigMatrix1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) 10L);
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray5, doubleArray6, doubleArray7, doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray9);
        java.lang.NullPointerException nullPointerException12 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray9);
        double[] doubleArray14 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable15 = null;
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[] doubleArray21 = new double[] {};
        double[][] doubleArray22 = new double[][] { doubleArray18, doubleArray19, doubleArray20, doubleArray21 };
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        java.text.ParseException parseException24 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException12, doubleArray14, localizable15, (java.lang.Object[]) doubleArray22);
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[] doubleArray32 = new double[] {};
        double[] doubleArray33 = new double[] {};
        double[][] doubleArray34 = new double[][] { doubleArray30, doubleArray31, doubleArray32, doubleArray33 };
        double[][] doubleArray35 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray34);
        java.lang.NullPointerException nullPointerException37 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray34);
        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException12, "hi!", (java.lang.Object[]) doubleArray34);
        java.lang.Throwable throwable39 = null;
        org.apache.commons.math.exception.Localizable localizable41 = null;
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[][] doubleArray46 = new double[][] { doubleArray42, doubleArray43, doubleArray44, doubleArray45 };
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(throwable39, (double) (short) 1, localizable41, (java.lang.Object[]) doubleArray47);
        double[] doubleArray55 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException48, doubleArray55);
        org.apache.commons.math.exception.Localizable localizable57 = null;
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[] doubleArray60 = new double[] {};
        double[] doubleArray61 = new double[] {};
        double[][] doubleArray62 = new double[][] { doubleArray58, doubleArray59, doubleArray60, doubleArray61 };
        double[][] doubleArray63 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray62);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException12, doubleArray55, localizable57, (java.lang.Object[]) doubleArray62);
        double[] doubleArray68 = new double[] {};
        double[] doubleArray69 = new double[] {};
        double[] doubleArray70 = new double[] {};
        double[] doubleArray71 = new double[] {};
        double[][] doubleArray72 = new double[][] { doubleArray68, doubleArray69, doubleArray70, doubleArray71 };
        double[][] doubleArray73 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray72);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray72);
        org.apache.commons.math.MathRuntimeException mathRuntimeException75 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException64, "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", (java.lang.Object[]) doubleArray72);
        functionEvaluationException1.addSuppressed((java.lang.Throwable) functionEvaluationException64);
        java.lang.String str77 = functionEvaluationException64.toString();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(nullPointerException12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(parseException24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(nullPointerException37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "org.apache.commons.math.FunctionEvaluationException: " + "'", str77.equals("org.apache.commons.math.FunctionEvaluationException: "));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException2 = new org.apache.commons.math.linear.MatrixIndexException("", objArray1);
        java.lang.String str3 = matrixIndexException2.getPattern();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int0 = org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer.DEFAULT_MAX_ITERATIONS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setMaxIterations((int) (short) 0);
        int int3 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray20 = new double[] { (short) 0 };
        double[] doubleArray22 = new double[] { (short) 0 };
        double[][] doubleArray23 = new double[][] { doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix18.add(array2DRowRealMatrix24);
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix24);
        double[] doubleArray30 = new double[] { '4', 10.0f, ' ' };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray30);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix5.subtract(array2DRowRealMatrix31);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        blockRealMatrix2.setEntry((int) (byte) 1, (int) '#', (double) (-1L));
        double[] doubleArray8 = new double[] { (short) 0 };
        double[] doubleArray10 = new double[] { (short) 0 };
        double[][] doubleArray11 = new double[][] { doubleArray8, doubleArray10 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix12.add(array2DRowRealMatrix18);
        double[][] doubleArray20 = array2DRowRealMatrix18.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix18.getColumnMatrix((int) (short) 0);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix2.multiply(realMatrix22);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double[] doubleArray4 = new double[] { (short) 0 };
        double[] doubleArray6 = new double[] { (short) 0 };
        double[][] doubleArray7 = new double[][] { doubleArray4, doubleArray6 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException9 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "hi!", (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException10 = new org.apache.commons.math.linear.InvalidMatrixException("", (java.lang.Object[]) doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix50.getSubMatrix((int) (byte) 10, 10, 36, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 36 out of allowed range [0, 31]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setQRRankingThreshold(0.0d);
        levenbergMarquardtOptimizer0.setOrthoTolerance(0.0d);
        levenbergMarquardtOptimizer0.setCostRelativeTolerance((double) (-1L));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray20 = new double[] { (short) 0 };
        double[] doubleArray22 = new double[] { (short) 0 };
        double[][] doubleArray23 = new double[][] { doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix18.add(array2DRowRealMatrix24);
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix24);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double28 = array2DRowRealMatrix5.walkInColumnOrder(realMatrixPreservingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = blockRealMatrix2.scalarMultiply((double) (short) 0);
        blockRealMatrix2.multiplyEntry((int) (byte) 1, (int) (byte) 1, 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realMatrix49);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[][] doubleArray13 = array2DRowRealMatrix11.getData();
        boolean boolean14 = array2DRowRealMatrix11.isSquare();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException2 = new org.apache.commons.math.FunctionEvaluationException(throwable0, 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        blockRealMatrix2.setEntry((int) (byte) 0, (int) (short) 10, (-1.0d));
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor10 = null;
        try {
            double double15 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor10, (int) (short) 10, (int) (short) 100, (int) (short) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double double13 = array2DRowRealMatrix11.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix11.transpose();
        double[] doubleArray16 = new double[] { (short) 0 };
        double[] doubleArray18 = new double[] { (short) 0 };
        double[][] doubleArray19 = new double[][] { doubleArray16, doubleArray18 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 0 };
        double[][] doubleArray25 = new double[][] { doubleArray22, doubleArray24 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = array2DRowRealMatrix20.add(array2DRowRealMatrix26);
        java.lang.String str28 = array2DRowRealMatrix26.toString();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix11.multiply(array2DRowRealMatrix26);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str28.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray2, doubleArray3, doubleArray4, doubleArray5 };
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray6);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[] doubleArray16 = new double[] {};
        double[][] doubleArray17 = new double[][] { doubleArray13, doubleArray14, doubleArray15, doubleArray16 };
        double[][] doubleArray18 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray17);
        java.lang.NullPointerException nullPointerException20 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray17);
        double[] doubleArray22 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[] doubleArray28 = new double[] {};
        double[] doubleArray29 = new double[] {};
        double[][] doubleArray30 = new double[][] { doubleArray26, doubleArray27, doubleArray28, doubleArray29 };
        double[][] doubleArray31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        java.text.ParseException parseException32 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException20, doubleArray22, localizable23, (java.lang.Object[]) doubleArray30);
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = new double[] {};
        double[][] doubleArray42 = new double[][] { doubleArray38, doubleArray39, doubleArray40, doubleArray41 };
        double[][] doubleArray43 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray42);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray42);
        java.lang.NullPointerException nullPointerException45 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.MathRuntimeException mathRuntimeException46 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException20, "hi!", (java.lang.Object[]) doubleArray42);
        java.lang.Throwable throwable47 = null;
        org.apache.commons.math.exception.Localizable localizable49 = null;
        double[] doubleArray50 = new double[] {};
        double[] doubleArray51 = new double[] {};
        double[] doubleArray52 = new double[] {};
        double[] doubleArray53 = new double[] {};
        double[][] doubleArray54 = new double[][] { doubleArray50, doubleArray51, doubleArray52, doubleArray53 };
        double[][] doubleArray55 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray54);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException(throwable47, (double) (short) 1, localizable49, (java.lang.Object[]) doubleArray55);
        double[] doubleArray63 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException56, doubleArray63);
        org.apache.commons.math.exception.Localizable localizable65 = null;
        double[] doubleArray66 = new double[] {};
        double[] doubleArray67 = new double[] {};
        double[] doubleArray68 = new double[] {};
        double[] doubleArray69 = new double[] {};
        double[][] doubleArray70 = new double[][] { doubleArray66, doubleArray67, doubleArray68, doubleArray69 };
        double[][] doubleArray71 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray70);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException72 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException20, doubleArray63, localizable65, (java.lang.Object[]) doubleArray70);
        double[] doubleArray76 = new double[] {};
        double[] doubleArray77 = new double[] {};
        double[] doubleArray78 = new double[] {};
        double[] doubleArray79 = new double[] {};
        double[][] doubleArray80 = new double[][] { doubleArray76, doubleArray77, doubleArray78, doubleArray79 };
        double[][] doubleArray81 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray80);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray80);
        org.apache.commons.math.MathRuntimeException mathRuntimeException83 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException72, "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", (java.lang.Object[]) doubleArray80);
        java.lang.Object[] objArray84 = mathRuntimeException83.getArguments();
        org.apache.commons.math.exception.Localizable localizable85 = mathRuntimeException83.getLocalizablePattern();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix88 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double91 = blockRealMatrix88.getEntry(0, 0);
        double[] doubleArray93 = blockRealMatrix88.getRow((int) (short) 0);
        double[][] doubleArray94 = blockRealMatrix88.getData();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException95 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException8, (double) (short) 0, localizable85, (java.lang.Object[]) doubleArray94);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(nullPointerException20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(parseException32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(nullPointerException45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(localizable85);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray94);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        double[] doubleArray7 = blockRealMatrix2.getRow((int) (short) 0);
        double[][] doubleArray8 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable12 = null;
        org.apache.commons.math.exception.Localizable localizable14 = null;
        double[] doubleArray15 = new double[] {};
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[][] doubleArray19 = new double[][] { doubleArray15, doubleArray16, doubleArray17, doubleArray18 };
        double[][] doubleArray20 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(throwable12, (double) (short) 1, localizable14, (java.lang.Object[]) doubleArray20);
        double[] doubleArray28 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException21, doubleArray28);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[][] doubleArray37 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36 };
        double[][] doubleArray38 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray37);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray37);
        java.lang.NullPointerException nullPointerException40 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray37);
        double[] doubleArray42 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable43 = null;
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[] doubleArray48 = new double[] {};
        double[] doubleArray49 = new double[] {};
        double[][] doubleArray50 = new double[][] { doubleArray46, doubleArray47, doubleArray48, doubleArray49 };
        double[][] doubleArray51 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray50);
        java.text.ParseException parseException52 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException40, doubleArray42, localizable43, (java.lang.Object[]) doubleArray50);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair55 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray28, doubleArray42, true);
        double[] doubleArray56 = blockRealMatrix11.operate(doubleArray42);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix2.multiply((org.apache.commons.math.linear.RealMatrix) blockRealMatrix11);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(nullPointerException40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(parseException52);
        org.junit.Assert.assertNotNull(doubleArray56);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix55 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        try {
            blockRealMatrix2.setRowMatrix((int) (byte) 1, blockRealMatrix55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 52x1 but expected 1x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double[][] doubleArray2 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 10, 0);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        double[] doubleArray7 = blockRealMatrix2.getRow((int) (short) 0);
        double[][] doubleArray8 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double10 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double11 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor6, 0, (int) (byte) 100, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor51 = null;
        try {
            double double52 = blockRealMatrix50.walkInOptimizedOrder(realMatrixPreservingVisitor51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) (short) 1, localizable2, (java.lang.Object[]) doubleArray8);
        double[] doubleArray16 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException9, doubleArray16);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.lang.String[] strArray4 = new java.lang.String[] { "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", "Array2DRowRealMatrix{{0.0},{0.0}}", "", "Array2DRowRealMatrix{{0.0},{0.0}}" };
        java.lang.String[] strArray9 = new java.lang.String[] { "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", "Array2DRowRealMatrix{{0.0},{0.0}}", "", "Array2DRowRealMatrix{{0.0},{0.0}}" };
        java.lang.String[] strArray14 = new java.lang.String[] { "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", "Array2DRowRealMatrix{{0.0},{0.0}}", "", "Array2DRowRealMatrix{{0.0},{0.0}}" };
        java.lang.String[] strArray19 = new java.lang.String[] { "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", "Array2DRowRealMatrix{{0.0},{0.0}}", "", "Array2DRowRealMatrix{{0.0},{0.0}}" };
        java.lang.String[][] strArray20 = new java.lang.String[][] { strArray4, strArray9, strArray14, strArray19 };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix21 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(strArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray20);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        blockRealMatrix2.setEntry((int) (byte) 1, (int) '#', (double) (-1L));
        int int7 = blockRealMatrix2.getColumnDimension();
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 0 };
        double[][] doubleArray13 = new double[][] { doubleArray10, doubleArray12 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        double[] doubleArray16 = new double[] { (short) 0 };
        double[] doubleArray18 = new double[] { (short) 0 };
        double[][] doubleArray19 = new double[][] { doubleArray16, doubleArray18 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = array2DRowRealMatrix14.add(array2DRowRealMatrix20);
        java.lang.String str22 = array2DRowRealMatrix20.toString();
        org.apache.commons.math.linear.RealVector realVector24 = array2DRowRealMatrix20.getColumnVector(0);
        try {
            blockRealMatrix2.setRowVector(2147483647, realVector24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 2,147,483,647 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str22.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(realVector24);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = blockRealMatrix2.scalarMultiply((double) (short) 0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor50 = null;
        try {
            double double51 = blockRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realMatrix49);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        blockRealMatrix2.multiplyEntry(10, (int) (byte) -1, (double) '#');
        int[] intArray52 = new int[] {};
        int[] intArray57 = new int[] { (byte) 1, '4', '4', 1 };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix58 = blockRealMatrix2.getSubMatrix(intArray52, intArray57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: empty selected row index array");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray57);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        double double50 = blockRealMatrix2.getEntry((int) (byte) 1, 1);
        org.apache.commons.math.linear.RealVector realVector52 = null;
        try {
            blockRealMatrix2.setRowVector((int) (byte) 100, realVector52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray5, doubleArray6, doubleArray7, doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray9);
        java.lang.NullPointerException nullPointerException12 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray9);
        double[] doubleArray14 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable15 = null;
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[] doubleArray21 = new double[] {};
        double[][] doubleArray22 = new double[][] { doubleArray18, doubleArray19, doubleArray20, doubleArray21 };
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        java.text.ParseException parseException24 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException12, doubleArray14, localizable15, (java.lang.Object[]) doubleArray22);
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[] doubleArray32 = new double[] {};
        double[] doubleArray33 = new double[] {};
        double[][] doubleArray34 = new double[][] { doubleArray30, doubleArray31, doubleArray32, doubleArray33 };
        double[][] doubleArray35 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray34);
        java.lang.NullPointerException nullPointerException37 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray34);
        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException12, "hi!", (java.lang.Object[]) doubleArray34);
        java.lang.Throwable throwable39 = null;
        org.apache.commons.math.exception.Localizable localizable41 = null;
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[][] doubleArray46 = new double[][] { doubleArray42, doubleArray43, doubleArray44, doubleArray45 };
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(throwable39, (double) (short) 1, localizable41, (java.lang.Object[]) doubleArray47);
        double[] doubleArray55 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException48, doubleArray55);
        org.apache.commons.math.exception.Localizable localizable57 = null;
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[] doubleArray60 = new double[] {};
        double[] doubleArray61 = new double[] {};
        double[][] doubleArray62 = new double[][] { doubleArray58, doubleArray59, doubleArray60, doubleArray61 };
        double[][] doubleArray63 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray62);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException12, doubleArray55, localizable57, (java.lang.Object[]) doubleArray62);
        double[] doubleArray68 = new double[] {};
        double[] doubleArray69 = new double[] {};
        double[] doubleArray70 = new double[] {};
        double[] doubleArray71 = new double[] {};
        double[][] doubleArray72 = new double[][] { doubleArray68, doubleArray69, doubleArray70, doubleArray71 };
        double[][] doubleArray73 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray72);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray72);
        org.apache.commons.math.MathRuntimeException mathRuntimeException75 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException64, "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", (java.lang.Object[]) doubleArray72);
        java.lang.Object[] objArray76 = mathRuntimeException75.getArguments();
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException77 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", objArray76);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException("org.apache.commons.math.FunctionEvaluationException: ", objArray76);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(nullPointerException12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(parseException24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(nullPointerException37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException77);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double[][] doubleArray0 = null;
        try {
            double[][] doubleArray1 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        blockRealMatrix2.setEntry((int) (byte) 1, (int) '#', (double) (-1L));
        int int7 = blockRealMatrix2.getColumnDimension();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.getSubMatrix((int) (byte) -1, (int) (byte) 100, 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray2, doubleArray3, doubleArray4, doubleArray5 };
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        java.text.ParseException parseException8 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray6);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double14 = blockRealMatrix11.getEntry(0, 0);
        double[] doubleArray16 = blockRealMatrix11.getRow((int) (short) 0);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) parseException8, doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(parseException8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.RealVector realVector48 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray33);
        java.io.ObjectOutputStream objectOutputStream49 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealVector(realVector48, objectOutputStream49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector48);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[][] doubleArray13 = array2DRowRealMatrix11.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix15 = array2DRowRealMatrix11.getColumnMatrix((int) (short) 0);
        try {
            double double16 = array2DRowRealMatrix11.getDeterminant();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 2x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        org.apache.commons.math.linear.SingularMatrixException singularMatrixException17 = new org.apache.commons.math.linear.SingularMatrixException();
        org.apache.commons.math.exception.Localizable localizable18 = null;
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 0 };
        double[][] doubleArray25 = new double[][] { doubleArray22, doubleArray24 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException27 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "hi!", (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) singularMatrixException17, localizable18, (java.lang.Object[]) doubleArray25);
        try {
            array2DRowRealMatrix12.copySubMatrix((int) (byte) 100, (int) (byte) 1, (int) (byte) 0, 10, doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        blockRealMatrix2.setEntry((int) (byte) 1, (int) '#', (double) (-1L));
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double12 = blockRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor7, (int) (short) 100, (int) (short) -1, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray7);
        java.lang.NullPointerException nullPointerException10 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray7);
        double[] doubleArray12 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[][] doubleArray20 = new double[][] { doubleArray16, doubleArray17, doubleArray18, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        java.text.ParseException parseException22 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException10, doubleArray12, localizable13, (java.lang.Object[]) doubleArray20);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[][] doubleArray32 = new double[][] { doubleArray28, doubleArray29, doubleArray30, doubleArray31 };
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray32);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray32);
        java.lang.NullPointerException nullPointerException35 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray32);
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException10, "hi!", (java.lang.Object[]) doubleArray32);
        java.lang.Throwable throwable37 = null;
        org.apache.commons.math.exception.Localizable localizable39 = null;
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[][] doubleArray44 = new double[][] { doubleArray40, doubleArray41, doubleArray42, doubleArray43 };
        double[][] doubleArray45 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException(throwable37, (double) (short) 1, localizable39, (java.lang.Object[]) doubleArray45);
        double[] doubleArray53 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException46, doubleArray53);
        org.apache.commons.math.exception.Localizable localizable55 = null;
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[][] doubleArray60 = new double[][] { doubleArray56, doubleArray57, doubleArray58, doubleArray59 };
        double[][] doubleArray61 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray60);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException10, doubleArray53, localizable55, (java.lang.Object[]) doubleArray60);
        double[] doubleArray66 = new double[] {};
        double[] doubleArray67 = new double[] {};
        double[] doubleArray68 = new double[] {};
        double[] doubleArray69 = new double[] {};
        double[][] doubleArray70 = new double[][] { doubleArray66, doubleArray67, doubleArray68, doubleArray69 };
        double[][] doubleArray71 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray70);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray70);
        org.apache.commons.math.MathRuntimeException mathRuntimeException73 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException62, "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", (java.lang.Object[]) doubleArray70);
        java.lang.Object[] objArray74 = mathRuntimeException73.getArguments();
        org.apache.commons.math.exception.Localizable localizable75 = mathRuntimeException73.getLocalizablePattern();
        double[] doubleArray77 = new double[] { (short) 0 };
        double[] doubleArray79 = new double[] { (short) 0 };
        double[][] doubleArray80 = new double[][] { doubleArray77, doubleArray79 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray80);
        double[][] doubleArray82 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray80);
        org.apache.commons.math.MathRuntimeException mathRuntimeException83 = new org.apache.commons.math.MathRuntimeException(localizable75, (java.lang.Object[]) doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(nullPointerException10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(parseException22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(nullPointerException35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(localizable75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setQRRankingThreshold(0.0d);
        double double3 = levenbergMarquardtOptimizer0.getChiSquare();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) '#');
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.exception.Localizable localizable9 = null;
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[] doubleArray13 = new double[] {};
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[] doubleArray16 = new double[] {};
        double[][] doubleArray17 = new double[][] { doubleArray13, doubleArray14, doubleArray15, doubleArray16 };
        double[][] doubleArray18 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(throwable10, (double) (short) 1, localizable12, (java.lang.Object[]) doubleArray18);
        org.apache.commons.math.optimization.OptimizationException optimizationException20 = new org.apache.commons.math.optimization.OptimizationException(localizable9, (java.lang.Object[]) doubleArray18);
        java.lang.Object[] objArray22 = new java.lang.Object[] { ' ', doubleArray7, optimizationException20, 0L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "", objArray22);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException24 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) maxIterationsExceededException23);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (short) 0, (double) (short) 100);
        java.lang.Throwable throwable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray7, doubleArray8, doubleArray9, doubleArray10 };
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(throwable4, (double) (short) 1, localizable6, (java.lang.Object[]) doubleArray12);
        double[] doubleArray20 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException13, doubleArray20);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[] doubleArray28 = new double[] {};
        double[][] doubleArray29 = new double[][] { doubleArray25, doubleArray26, doubleArray27, doubleArray28 };
        double[][] doubleArray30 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray29);
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray29);
        double[] doubleArray34 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable35 = null;
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = new double[] {};
        double[][] doubleArray42 = new double[][] { doubleArray38, doubleArray39, doubleArray40, doubleArray41 };
        double[][] doubleArray43 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray42);
        java.text.ParseException parseException44 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException32, doubleArray34, localizable35, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair47 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray20, doubleArray34, true);
        java.lang.Throwable throwable48 = null;
        org.apache.commons.math.exception.Localizable localizable50 = null;
        double[] doubleArray51 = new double[] {};
        double[] doubleArray52 = new double[] {};
        double[] doubleArray53 = new double[] {};
        double[] doubleArray54 = new double[] {};
        double[][] doubleArray55 = new double[][] { doubleArray51, doubleArray52, doubleArray53, doubleArray54 };
        double[][] doubleArray56 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException(throwable48, (double) (short) 1, localizable50, (java.lang.Object[]) doubleArray56);
        double[] doubleArray64 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException57, doubleArray64);
        double[] doubleArray69 = new double[] {};
        double[] doubleArray70 = new double[] {};
        double[] doubleArray71 = new double[] {};
        double[] doubleArray72 = new double[] {};
        double[][] doubleArray73 = new double[][] { doubleArray69, doubleArray70, doubleArray71, doubleArray72 };
        double[][] doubleArray74 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray73);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray73);
        java.lang.NullPointerException nullPointerException76 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray73);
        double[] doubleArray78 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable79 = null;
        double[] doubleArray82 = new double[] {};
        double[] doubleArray83 = new double[] {};
        double[] doubleArray84 = new double[] {};
        double[] doubleArray85 = new double[] {};
        double[][] doubleArray86 = new double[][] { doubleArray82, doubleArray83, doubleArray84, doubleArray85 };
        double[][] doubleArray87 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray86);
        java.text.ParseException parseException88 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray86);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException89 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException76, doubleArray78, localizable79, (java.lang.Object[]) doubleArray86);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair91 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray64, doubleArray78, true);
        double[] doubleArray92 = vectorialPointValuePair91.getPointRef();
        boolean boolean93 = simpleVectorialValueChecker2.converged((int) (byte) 0, vectorialPointValuePair47, vectorialPointValuePair91);
        double[] doubleArray94 = vectorialPointValuePair91.getPoint();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(parseException44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(nullPointerException76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(parseException88);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertNotNull(doubleArray94);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        blockRealMatrix2.multiplyEntry(10, (int) (byte) -1, (double) '#');
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor52 = null;
        try {
            double double53 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double[] doubleArray3 = new double[] { (short) 0 };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[][] doubleArray6 = new double[][] { doubleArray3, doubleArray5 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException8 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "hi!", (java.lang.Object[]) doubleArray6);
        int int9 = maxEvaluationsExceededException8.getMaxEvaluations();
        org.apache.commons.math.exception.Localizable localizable10 = maxEvaluationsExceededException8.getLocalizablePattern();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(localizable10);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((-1));
        org.apache.commons.math.optimization.OptimizationException optimizationException2 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException1);
        java.lang.RuntimeException runtimeException3 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) optimizationException2);
        org.junit.Assert.assertNotNull(runtimeException3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) (short) 1, localizable2, (java.lang.Object[]) doubleArray8);
        double[] doubleArray16 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException9, doubleArray16);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray21, doubleArray22, doubleArray23, doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray25);
        java.lang.NullPointerException nullPointerException28 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray25);
        double[] doubleArray30 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[][] doubleArray38 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37 };
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        java.text.ParseException parseException40 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException28, doubleArray30, localizable31, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray30, true);
        org.apache.commons.math.linear.BigMatrix bigMatrix44 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray30);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(nullPointerException28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(parseException40);
        org.junit.Assert.assertNotNull(bigMatrix44);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double11 = array2DRowRealMatrix5.walkInOptimizedOrder(realMatrixChangingVisitor6, (int) (short) 100, (int) (byte) 0, (int) (short) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray20 = new double[] { (short) 0 };
        double[] doubleArray22 = new double[] { (short) 0 };
        double[][] doubleArray23 = new double[][] { doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix18.add(array2DRowRealMatrix24);
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix24);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double32 = array2DRowRealMatrix5.walkInColumnOrder(realMatrixPreservingVisitor27, (int) (byte) 10, 10, (int) (byte) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[][] doubleArray13 = array2DRowRealMatrix11.getData();
        try {
            double double16 = array2DRowRealMatrix11.getEntry((-1), 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (-1, 1) in a 2x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix5.transpose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = array2DRowRealMatrix5.add(array2DRowRealMatrix14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = blockRealMatrix2.scalarMultiply((double) (short) 0);
        blockRealMatrix2.addToEntry((int) (byte) 1, (int) '#', (double) (byte) 1);
        blockRealMatrix2.multiplyEntry((int) (byte) 1, (int) (short) -1, (double) 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realMatrix49);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable51 = null;
        org.apache.commons.math.exception.Localizable localizable53 = null;
        double[] doubleArray54 = new double[] {};
        double[] doubleArray55 = new double[] {};
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[][] doubleArray58 = new double[][] { doubleArray54, doubleArray55, doubleArray56, doubleArray57 };
        double[][] doubleArray59 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException(throwable51, (double) (short) 1, localizable53, (java.lang.Object[]) doubleArray59);
        double[] doubleArray67 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException68 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException60, doubleArray67);
        double[] doubleArray72 = new double[] {};
        double[] doubleArray73 = new double[] {};
        double[] doubleArray74 = new double[] {};
        double[] doubleArray75 = new double[] {};
        double[][] doubleArray76 = new double[][] { doubleArray72, doubleArray73, doubleArray74, doubleArray75 };
        double[][] doubleArray77 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray76);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray76);
        java.lang.NullPointerException nullPointerException79 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray76);
        double[] doubleArray81 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable82 = null;
        double[] doubleArray85 = new double[] {};
        double[] doubleArray86 = new double[] {};
        double[] doubleArray87 = new double[] {};
        double[] doubleArray88 = new double[] {};
        double[][] doubleArray89 = new double[][] { doubleArray85, doubleArray86, doubleArray87, doubleArray88 };
        double[][] doubleArray90 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray89);
        java.text.ParseException parseException91 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray89);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException92 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException79, doubleArray81, localizable82, (java.lang.Object[]) doubleArray89);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair94 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray67, doubleArray81, true);
        double[] doubleArray95 = blockRealMatrix50.operate(doubleArray81);
        org.apache.commons.math.linear.RealVector realVector96 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray81);
        try {
            org.apache.commons.math.linear.RealVector realVector97 = blockRealMatrix2.preMultiply(realVector96);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(nullPointerException79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(parseException91);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertNotNull(realVector96);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix5.transpose();
        double[] doubleArray15 = new double[] { (short) 0 };
        double[] doubleArray17 = new double[] { (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        double[] doubleArray21 = new double[] { (short) 0 };
        double[] doubleArray23 = new double[] { (short) 0 };
        double[][] doubleArray24 = new double[][] { doubleArray21, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix19.add(array2DRowRealMatrix25);
        double[][] doubleArray27 = array2DRowRealMatrix25.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix5.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix25);
        java.lang.Throwable throwable29 = null;
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray32 = new double[] {};
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[][] doubleArray36 = new double[][] { doubleArray32, doubleArray33, doubleArray34, doubleArray35 };
        double[][] doubleArray37 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(throwable29, (double) (short) 1, localizable31, (java.lang.Object[]) doubleArray37);
        double[] doubleArray45 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException38, doubleArray45);
        double[] doubleArray50 = new double[] {};
        double[] doubleArray51 = new double[] {};
        double[] doubleArray52 = new double[] {};
        double[] doubleArray53 = new double[] {};
        double[][] doubleArray54 = new double[][] { doubleArray50, doubleArray51, doubleArray52, doubleArray53 };
        double[][] doubleArray55 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray54);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray54);
        java.lang.NullPointerException nullPointerException57 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray54);
        double[] doubleArray59 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable60 = null;
        double[] doubleArray63 = new double[] {};
        double[] doubleArray64 = new double[] {};
        double[] doubleArray65 = new double[] {};
        double[] doubleArray66 = new double[] {};
        double[][] doubleArray67 = new double[][] { doubleArray63, doubleArray64, doubleArray65, doubleArray66 };
        double[][] doubleArray68 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray67);
        java.text.ParseException parseException69 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray67);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException70 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException57, doubleArray59, localizable60, (java.lang.Object[]) doubleArray67);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair72 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray45, doubleArray59, true);
        double[] doubleArray73 = vectorialPointValuePair72.getPointRef();
        try {
            double[] doubleArray74 = array2DRowRealMatrix5.preMultiply(doubleArray73);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(nullPointerException57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(parseException69);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double7 = blockRealMatrix4.getEntry(0, 0);
        double[] doubleArray9 = blockRealMatrix4.getRow((int) (short) 0);
        double[][] doubleArray10 = blockRealMatrix4.getData();
        java.util.ConcurrentModificationException concurrentModificationException11 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", (java.lang.Object[]) doubleArray10);
        java.lang.ArithmeticException arithmeticException12 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", (java.lang.Object[]) doubleArray10);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(concurrentModificationException11);
        org.junit.Assert.assertNotNull(arithmeticException12);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray4, doubleArray5, doubleArray6, doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray8);
        java.lang.NullPointerException nullPointerException11 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray8);
        double[] doubleArray13 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable14 = null;
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[][] doubleArray21 = new double[][] { doubleArray17, doubleArray18, doubleArray19, doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        java.text.ParseException parseException23 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray21);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException11, doubleArray13, localizable14, (java.lang.Object[]) doubleArray21);
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[] doubleArray32 = new double[] {};
        double[][] doubleArray33 = new double[][] { doubleArray29, doubleArray30, doubleArray31, doubleArray32 };
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray33);
        java.lang.NullPointerException nullPointerException36 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException11, "hi!", (java.lang.Object[]) doubleArray33);
        java.lang.NullPointerException nullPointerException38 = org.apache.commons.math.MathRuntimeException.createNullPointerException("org.apache.commons.math.FunctionEvaluationException: ", (java.lang.Object[]) doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(nullPointerException11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(parseException23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(nullPointerException36);
        org.junit.Assert.assertNotNull(nullPointerException38);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        blockRealMatrix2.setEntry((int) (byte) 0, (int) (short) 10, (-1.0d));
        int[] intArray12 = new int[] { 10, (byte) 0 };
        int[] intArray18 = new int[] { 100, (short) 1, (short) 100, (byte) -1, '#' };
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray21, doubleArray22, doubleArray23, doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        java.text.ParseException parseException27 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray25);
        java.lang.Throwable[] throwableArray28 = parseException27.getSuppressed();
        org.apache.commons.math.exception.Localizable localizable29 = null;
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[][] doubleArray37 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36 };
        double[][] doubleArray38 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray37);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray37);
        java.lang.NullPointerException nullPointerException40 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray37);
        double[] doubleArray42 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable43 = null;
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[] doubleArray48 = new double[] {};
        double[] doubleArray49 = new double[] {};
        double[][] doubleArray50 = new double[][] { doubleArray46, doubleArray47, doubleArray48, doubleArray49 };
        double[][] doubleArray51 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray50);
        java.text.ParseException parseException52 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException40, doubleArray42, localizable43, (java.lang.Object[]) doubleArray50);
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[] doubleArray60 = new double[] {};
        double[] doubleArray61 = new double[] {};
        double[][] doubleArray62 = new double[][] { doubleArray58, doubleArray59, doubleArray60, doubleArray61 };
        double[][] doubleArray63 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray62);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray62);
        java.lang.NullPointerException nullPointerException65 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray62);
        org.apache.commons.math.MathRuntimeException mathRuntimeException66 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException40, "hi!", (java.lang.Object[]) doubleArray62);
        java.lang.Throwable throwable67 = null;
        org.apache.commons.math.exception.Localizable localizable69 = null;
        double[] doubleArray70 = new double[] {};
        double[] doubleArray71 = new double[] {};
        double[] doubleArray72 = new double[] {};
        double[] doubleArray73 = new double[] {};
        double[][] doubleArray74 = new double[][] { doubleArray70, doubleArray71, doubleArray72, doubleArray73 };
        double[][] doubleArray75 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray74);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException76 = new org.apache.commons.math.FunctionEvaluationException(throwable67, (double) (short) 1, localizable69, (java.lang.Object[]) doubleArray75);
        double[] doubleArray83 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException84 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException76, doubleArray83);
        org.apache.commons.math.exception.Localizable localizable85 = null;
        double[] doubleArray86 = new double[] {};
        double[] doubleArray87 = new double[] {};
        double[] doubleArray88 = new double[] {};
        double[] doubleArray89 = new double[] {};
        double[][] doubleArray90 = new double[][] { doubleArray86, doubleArray87, doubleArray88, doubleArray89 };
        double[][] doubleArray91 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray90);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException92 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException40, doubleArray83, localizable85, (java.lang.Object[]) doubleArray90);
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) parseException27, localizable29, (java.lang.Object[]) doubleArray90);
        try {
            blockRealMatrix2.copySubMatrix(intArray12, intArray18, doubleArray90);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(parseException27);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(nullPointerException40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(parseException52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(nullPointerException65);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        blockRealMatrix2.multiplyEntry(10, (int) (byte) -1, (double) '#');
        java.lang.Throwable throwable52 = null;
        org.apache.commons.math.exception.Localizable localizable54 = null;
        double[] doubleArray55 = new double[] {};
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[][] doubleArray59 = new double[][] { doubleArray55, doubleArray56, doubleArray57, doubleArray58 };
        double[][] doubleArray60 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray59);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException61 = new org.apache.commons.math.FunctionEvaluationException(throwable52, (double) (short) 1, localizable54, (java.lang.Object[]) doubleArray60);
        double[] doubleArray68 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException61, doubleArray68);
        double[] doubleArray73 = new double[] {};
        double[] doubleArray74 = new double[] {};
        double[] doubleArray75 = new double[] {};
        double[] doubleArray76 = new double[] {};
        double[][] doubleArray77 = new double[][] { doubleArray73, doubleArray74, doubleArray75, doubleArray76 };
        double[][] doubleArray78 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray77);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray77);
        java.lang.NullPointerException nullPointerException80 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray77);
        double[] doubleArray82 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable83 = null;
        double[] doubleArray86 = new double[] {};
        double[] doubleArray87 = new double[] {};
        double[] doubleArray88 = new double[] {};
        double[] doubleArray89 = new double[] {};
        double[][] doubleArray90 = new double[][] { doubleArray86, doubleArray87, doubleArray88, doubleArray89 };
        double[][] doubleArray91 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray90);
        java.text.ParseException parseException92 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray90);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException93 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException80, doubleArray82, localizable83, (java.lang.Object[]) doubleArray90);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair95 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray68, doubleArray82, true);
        double[] doubleArray96 = vectorialPointValuePair95.getPointRef();
        org.apache.commons.math.linear.BigMatrix bigMatrix97 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray96);
        try {
            double[] doubleArray98 = blockRealMatrix2.preMultiply(doubleArray96);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(nullPointerException80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(parseException92);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertNotNull(bigMatrix97);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        array2DRowRealMatrix5.multiplyEntry((int) (byte) 1, 0, (double) 0);
        double[][] doubleArray10 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix5.transpose();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray4, doubleArray5, doubleArray6, doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray8);
        java.lang.NullPointerException nullPointerException11 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray8);
        double[] doubleArray13 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable14 = null;
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[][] doubleArray21 = new double[][] { doubleArray17, doubleArray18, doubleArray19, doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        java.text.ParseException parseException23 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray21);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException11, doubleArray13, localizable14, (java.lang.Object[]) doubleArray21);
        java.util.NoSuchElementException noSuchElementException25 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", (java.lang.Object[]) doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(nullPointerException11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(parseException23);
        org.junit.Assert.assertNotNull(noSuchElementException25);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix5.transpose();
        double[] doubleArray15 = new double[] { (short) 0 };
        double[] doubleArray17 = new double[] { (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        double[] doubleArray21 = new double[] { (short) 0 };
        double[] doubleArray23 = new double[] { (short) 0 };
        double[][] doubleArray24 = new double[][] { doubleArray21, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix19.add(array2DRowRealMatrix25);
        double[][] doubleArray27 = array2DRowRealMatrix25.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix5.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix25);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix5.scalarMultiply(1.0d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix30);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        java.lang.String str13 = array2DRowRealMatrix11.toString();
        org.apache.commons.math.linear.RealVector realVector15 = array2DRowRealMatrix11.getColumnVector(0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor16 = null;
        try {
            double double21 = array2DRowRealMatrix11.walkInColumnOrder(realMatrixChangingVisitor16, 2147483647, (int) 'a', (int) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 2,147,483,647 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str13.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setMaxIterations((int) (short) 100);
        int int3 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setMaxIterations((-1));
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) 10L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        blockRealMatrix2.setEntry((int) (byte) 1, (int) '#', (double) (-1L));
        int int7 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable11 = null;
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[][] doubleArray18 = new double[][] { doubleArray14, doubleArray15, doubleArray16, doubleArray17 };
        double[][] doubleArray19 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray18);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(throwable11, (double) (short) 1, localizable13, (java.lang.Object[]) doubleArray19);
        double[] doubleArray27 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException20, doubleArray27);
        double[] doubleArray32 = new double[] {};
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[][] doubleArray36 = new double[][] { doubleArray32, doubleArray33, doubleArray34, doubleArray35 };
        double[][] doubleArray37 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray36);
        java.lang.NullPointerException nullPointerException39 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray36);
        double[] doubleArray41 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable42 = null;
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[] doubleArray48 = new double[] {};
        double[][] doubleArray49 = new double[][] { doubleArray45, doubleArray46, doubleArray47, doubleArray48 };
        double[][] doubleArray50 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray49);
        java.text.ParseException parseException51 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray49);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException39, doubleArray41, localizable42, (java.lang.Object[]) doubleArray49);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair54 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray27, doubleArray41, true);
        double[] doubleArray55 = blockRealMatrix10.operate(doubleArray41);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix10.createMatrix((int) 'a', (int) ' ');
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix59 = blockRealMatrix2.subtract(blockRealMatrix58);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(nullPointerException39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(parseException51);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        blockRealMatrix2.setEntry((int) (byte) 0, (int) (short) 10, (-1.0d));
        try {
            org.apache.commons.math.linear.RealVector realVector11 = blockRealMatrix2.getColumnVector(36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 36 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[][] doubleArray13 = array2DRowRealMatrix11.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix15 = array2DRowRealMatrix11.getColumnMatrix((int) (short) 0);
        int[] intArray16 = new int[] {};
        int[] intArray22 = new int[] { (byte) 10, (short) 10, (short) 1, 10, 'a' };
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) realMatrix15, intArray16, intArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: empty selected row index array");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.scalarAdd((double) 0.0f);
        double[] doubleArray9 = new double[] { (short) 0 };
        double[] doubleArray11 = new double[] { (short) 0 };
        double[][] doubleArray12 = new double[][] { doubleArray9, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        double[] doubleArray15 = new double[] { (short) 0 };
        double[] doubleArray17 = new double[] { (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix13.add(array2DRowRealMatrix19);
        double double21 = array2DRowRealMatrix19.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix19.transpose();
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 0 };
        double[][] doubleArray27 = new double[][] { doubleArray24, doubleArray26 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        double[] doubleArray30 = new double[] { (short) 0 };
        double[] doubleArray32 = new double[] { (short) 0 };
        double[][] doubleArray33 = new double[][] { doubleArray30, doubleArray32 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = array2DRowRealMatrix28.add(array2DRowRealMatrix34);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = array2DRowRealMatrix19.add(array2DRowRealMatrix28);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix5.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        java.lang.Throwable throwable39 = null;
        org.apache.commons.math.exception.Localizable localizable41 = null;
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[][] doubleArray46 = new double[][] { doubleArray42, doubleArray43, doubleArray44, doubleArray45 };
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(throwable39, (double) (short) 1, localizable41, (java.lang.Object[]) doubleArray47);
        double[] doubleArray55 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException48, doubleArray55);
        try {
            array2DRowRealMatrix5.setColumn(0, doubleArray55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 6x1 but expected 2x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix35);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix36);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double8 = blockRealMatrix5.getEntry(0, 0);
        double[] doubleArray10 = blockRealMatrix5.getRow((int) (short) 0);
        double[][] doubleArray11 = blockRealMatrix5.getData();
        java.util.ConcurrentModificationException concurrentModificationException12 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException13 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', "", (java.lang.Object[]) doubleArray11);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(concurrentModificationException12);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException3 = new org.apache.commons.math.FunctionEvaluationException(100.0d);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        java.text.ParseException parseException14 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray12);
        java.lang.Throwable[] throwableArray15 = parseException14.getSuppressed();
        org.apache.commons.math.exception.Localizable localizable16 = null;
        double[] doubleArray20 = new double[] {};
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[][] doubleArray24 = new double[][] { doubleArray20, doubleArray21, doubleArray22, doubleArray23 };
        double[][] doubleArray25 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray24);
        java.lang.NullPointerException nullPointerException27 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray24);
        double[] doubleArray29 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable30 = null;
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[][] doubleArray37 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36 };
        double[][] doubleArray38 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray37);
        java.text.ParseException parseException39 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException27, doubleArray29, localizable30, (java.lang.Object[]) doubleArray37);
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[] doubleArray48 = new double[] {};
        double[][] doubleArray49 = new double[][] { doubleArray45, doubleArray46, doubleArray47, doubleArray48 };
        double[][] doubleArray50 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray49);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray49);
        java.lang.NullPointerException nullPointerException52 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException53 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException27, "hi!", (java.lang.Object[]) doubleArray49);
        java.lang.Throwable throwable54 = null;
        org.apache.commons.math.exception.Localizable localizable56 = null;
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[] doubleArray60 = new double[] {};
        double[][] doubleArray61 = new double[][] { doubleArray57, doubleArray58, doubleArray59, doubleArray60 };
        double[][] doubleArray62 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray61);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException(throwable54, (double) (short) 1, localizable56, (java.lang.Object[]) doubleArray62);
        double[] doubleArray70 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException71 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException63, doubleArray70);
        org.apache.commons.math.exception.Localizable localizable72 = null;
        double[] doubleArray73 = new double[] {};
        double[] doubleArray74 = new double[] {};
        double[] doubleArray75 = new double[] {};
        double[] doubleArray76 = new double[] {};
        double[][] doubleArray77 = new double[][] { doubleArray73, doubleArray74, doubleArray75, doubleArray76 };
        double[][] doubleArray78 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray77);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException79 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException27, doubleArray70, localizable72, (java.lang.Object[]) doubleArray77);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) parseException14, localizable16, (java.lang.Object[]) doubleArray77);
        java.io.EOFException eOFException81 = org.apache.commons.math.MathRuntimeException.createEOFException("", (java.lang.Object[]) doubleArray77);
        double[][] doubleArray82 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray77);
        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException3, "org.apache.commons.math.FunctionEvaluationException: ", (java.lang.Object[]) doubleArray82);
        java.text.ParseException parseException84 = org.apache.commons.math.MathRuntimeException.createParseException((int) ' ', "", (java.lang.Object[]) doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(parseException14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(nullPointerException27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(parseException39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(nullPointerException52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(eOFException81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(parseException84);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setMaxIterations(0);
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) (short) 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        double[] doubleArray7 = blockRealMatrix2.getRow((int) (short) 0);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.createMatrix((int) (short) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        java.lang.String str13 = array2DRowRealMatrix11.toString();
        org.apache.commons.math.linear.RealVector realVector15 = array2DRowRealMatrix11.getColumnVector(0);
        try {
            array2DRowRealMatrix11.luDecompose();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 2x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str13.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setMaxIterations((int) (short) 100);
        int int3 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        int int4 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        levenbergMarquardtOptimizer0.setOrthoTolerance(0.0d);
        try {
            double[] doubleArray7 = levenbergMarquardtOptimizer0.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.optimization.OptimizationException; message: no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.optimization.OptimizationException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.lang.String[] strArray0 = null;
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.scalarAdd((double) 0.0f);
        double[] doubleArray9 = new double[] { (short) 0 };
        double[] doubleArray11 = new double[] { (short) 0 };
        double[][] doubleArray12 = new double[][] { doubleArray9, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        double[] doubleArray15 = new double[] { (short) 0 };
        double[] doubleArray17 = new double[] { (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix13.add(array2DRowRealMatrix19);
        double double21 = array2DRowRealMatrix19.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix19.transpose();
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 0 };
        double[][] doubleArray27 = new double[][] { doubleArray24, doubleArray26 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        double[] doubleArray30 = new double[] { (short) 0 };
        double[] doubleArray32 = new double[] { (short) 0 };
        double[][] doubleArray33 = new double[][] { doubleArray30, doubleArray32 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = array2DRowRealMatrix28.add(array2DRowRealMatrix34);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = array2DRowRealMatrix19.add(array2DRowRealMatrix28);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix5.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor38 = null;
        try {
            double double43 = array2DRowRealMatrix19.walkInColumnOrder(realMatrixPreservingVisitor38, (int) (byte) 0, 100, (int) '4', 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix35);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix36);
        org.junit.Assert.assertNotNull(realMatrix37);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math.linear.SingularMatrixException singularMatrixException0 = new org.apache.commons.math.linear.SingularMatrixException();
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 0 };
        double[][] doubleArray8 = new double[][] { doubleArray5, doubleArray7 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException10 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "hi!", (java.lang.Object[]) doubleArray8);
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) singularMatrixException0, localizable1, (java.lang.Object[]) doubleArray8);
        java.lang.String str12 = singularMatrixException0.getPattern();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "matrix is singular" + "'", str12.equals("matrix is singular"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException3 = new org.apache.commons.math.FunctionEvaluationException(0.0d, "", objArray2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray7);
        java.lang.NullPointerException nullPointerException10 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray7);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray7);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(nullPointerException10);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.math.BigDecimal bigDecimal0 = null;
        java.math.BigDecimal[] bigDecimalArray1 = new java.math.BigDecimal[] { bigDecimal0 };
        java.math.BigDecimal bigDecimal2 = null;
        java.math.BigDecimal[] bigDecimalArray3 = new java.math.BigDecimal[] { bigDecimal2 };
        java.math.BigDecimal bigDecimal4 = null;
        java.math.BigDecimal[] bigDecimalArray5 = new java.math.BigDecimal[] { bigDecimal4 };
        java.math.BigDecimal bigDecimal6 = null;
        java.math.BigDecimal[] bigDecimalArray7 = new java.math.BigDecimal[] { bigDecimal6 };
        java.math.BigDecimal bigDecimal8 = null;
        java.math.BigDecimal[] bigDecimalArray9 = new java.math.BigDecimal[] { bigDecimal8 };
        java.math.BigDecimal bigDecimal10 = null;
        java.math.BigDecimal[] bigDecimalArray11 = new java.math.BigDecimal[] { bigDecimal10 };
        java.math.BigDecimal[][] bigDecimalArray12 = new java.math.BigDecimal[][] { bigDecimalArray1, bigDecimalArray3, bigDecimalArray5, bigDecimalArray7, bigDecimalArray9, bigDecimalArray11 };
        org.apache.commons.math.linear.BigMatrix bigMatrix14 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(bigDecimalArray12, true);
        org.junit.Assert.assertNotNull(bigDecimalArray1);
        org.junit.Assert.assertNotNull(bigDecimalArray3);
        org.junit.Assert.assertNotNull(bigDecimalArray5);
        org.junit.Assert.assertNotNull(bigDecimalArray7);
        org.junit.Assert.assertNotNull(bigDecimalArray9);
        org.junit.Assert.assertNotNull(bigDecimalArray11);
        org.junit.Assert.assertNotNull(bigDecimalArray12);
        org.junit.Assert.assertNotNull(bigMatrix14);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        double double50 = blockRealMatrix2.getEntry((int) (byte) 1, 1);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor51 = null;
        try {
            double double56 = blockRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor51, (int) 'a', (int) (short) 0, (int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[][] doubleArray13 = array2DRowRealMatrix11.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix15 = array2DRowRealMatrix11.getColumnMatrix((int) (short) 0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor16 = null;
        try {
            double double17 = array2DRowRealMatrix11.walkInRowOrder(realMatrixChangingVisitor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        blockRealMatrix2.setEntry((int) (byte) 1, (int) '#', (double) (-1L));
        int int7 = blockRealMatrix2.getColumnDimension();
        try {
            double[] doubleArray9 = blockRealMatrix2.getRow((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setMaxIterations((int) (short) 100);
        int int3 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setMaxIterations((-1));
        int int6 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        java.lang.String str13 = array2DRowRealMatrix11.toString();
        org.apache.commons.math.linear.RealVector realVector15 = array2DRowRealMatrix11.getColumnVector(0);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 0 };
        double[][] doubleArray20 = new double[][] { doubleArray17, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray23 = new double[] { (short) 0 };
        double[] doubleArray25 = new double[] { (short) 0 };
        double[][] doubleArray26 = new double[][] { doubleArray23, doubleArray25 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = array2DRowRealMatrix21.add(array2DRowRealMatrix27);
        java.lang.String str29 = array2DRowRealMatrix27.toString();
        org.apache.commons.math.linear.RealVector realVector31 = array2DRowRealMatrix27.getColumnVector(0);
        try {
            org.apache.commons.math.linear.RealVector realVector32 = array2DRowRealMatrix11.operate(realVector31);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str13.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str29.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(realVector31);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (short) 0, (double) (short) 100);
        java.lang.Throwable throwable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray7, doubleArray8, doubleArray9, doubleArray10 };
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(throwable4, (double) (short) 1, localizable6, (java.lang.Object[]) doubleArray12);
        double[] doubleArray20 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException13, doubleArray20);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[] doubleArray28 = new double[] {};
        double[][] doubleArray29 = new double[][] { doubleArray25, doubleArray26, doubleArray27, doubleArray28 };
        double[][] doubleArray30 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray29);
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray29);
        double[] doubleArray34 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable35 = null;
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = new double[] {};
        double[][] doubleArray42 = new double[][] { doubleArray38, doubleArray39, doubleArray40, doubleArray41 };
        double[][] doubleArray43 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray42);
        java.text.ParseException parseException44 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException32, doubleArray34, localizable35, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair47 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray20, doubleArray34, true);
        java.lang.Throwable throwable48 = null;
        org.apache.commons.math.exception.Localizable localizable50 = null;
        double[] doubleArray51 = new double[] {};
        double[] doubleArray52 = new double[] {};
        double[] doubleArray53 = new double[] {};
        double[] doubleArray54 = new double[] {};
        double[][] doubleArray55 = new double[][] { doubleArray51, doubleArray52, doubleArray53, doubleArray54 };
        double[][] doubleArray56 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException(throwable48, (double) (short) 1, localizable50, (java.lang.Object[]) doubleArray56);
        double[] doubleArray64 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException57, doubleArray64);
        double[] doubleArray69 = new double[] {};
        double[] doubleArray70 = new double[] {};
        double[] doubleArray71 = new double[] {};
        double[] doubleArray72 = new double[] {};
        double[][] doubleArray73 = new double[][] { doubleArray69, doubleArray70, doubleArray71, doubleArray72 };
        double[][] doubleArray74 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray73);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray73);
        java.lang.NullPointerException nullPointerException76 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray73);
        double[] doubleArray78 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable79 = null;
        double[] doubleArray82 = new double[] {};
        double[] doubleArray83 = new double[] {};
        double[] doubleArray84 = new double[] {};
        double[] doubleArray85 = new double[] {};
        double[][] doubleArray86 = new double[][] { doubleArray82, doubleArray83, doubleArray84, doubleArray85 };
        double[][] doubleArray87 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray86);
        java.text.ParseException parseException88 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray86);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException89 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException76, doubleArray78, localizable79, (java.lang.Object[]) doubleArray86);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair91 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray64, doubleArray78, true);
        double[] doubleArray92 = vectorialPointValuePair91.getPointRef();
        boolean boolean93 = simpleVectorialValueChecker2.converged((int) (byte) 0, vectorialPointValuePair47, vectorialPointValuePair91);
        double[] doubleArray94 = vectorialPointValuePair47.getPoint();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(parseException44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(nullPointerException76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(parseException88);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertNotNull(doubleArray94);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray7);
        java.lang.NullPointerException nullPointerException10 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray7);
        java.io.IOException iOException11 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) nullPointerException10);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(nullPointerException10);
        org.junit.Assert.assertNotNull(iOException11);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray20 = new double[] { (short) 0 };
        double[] doubleArray22 = new double[] { (short) 0 };
        double[][] doubleArray23 = new double[][] { doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix18.add(array2DRowRealMatrix24);
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix24);
        int[] intArray27 = new int[] {};
        int[] intArray34 = new int[] { (-1), (short) 1, (byte) 10, (byte) -1, (byte) 10, (-1) };
        double[][] doubleArray35 = null;
        try {
            array2DRowRealMatrix24.copySubMatrix(intArray27, intArray34, doubleArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: empty selected row index array");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        blockRealMatrix50.multiplyEntry((int) (byte) 1, (int) '#', (double) ' ');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double60 = blockRealMatrix57.getEntry(0, 0);
        double[] doubleArray62 = blockRealMatrix57.getRow((int) (short) 0);
        try {
            double[] doubleArray63 = blockRealMatrix50.operate(doubleArray62);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math.linear.SingularMatrixException singularMatrixException1 = new org.apache.commons.math.linear.SingularMatrixException();
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 0 };
        double[][] doubleArray9 = new double[][] { doubleArray6, doubleArray8 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException11 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "hi!", (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) singularMatrixException1, localizable2, (java.lang.Object[]) doubleArray9);
        java.lang.IllegalArgumentException illegalArgumentException13 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", (java.lang.Object[]) doubleArray9);
        java.lang.Throwable[] throwableArray14 = illegalArgumentException13.getSuppressed();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(illegalArgumentException13);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor13 = null;
        try {
            double double14 = array2DRowRealMatrix11.walkInOptimizedOrder(realMatrixPreservingVisitor13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setQRRankingThreshold(0.0d);
        levenbergMarquardtOptimizer0.setOrthoTolerance(0.0d);
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) (byte) 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        array2DRowRealMatrix5.multiplyEntry((int) (byte) 1, 0, (double) 0);
        double[][] doubleArray10 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor11 = null;
        try {
            double double12 = array2DRowRealMatrix5.walkInOptimizedOrder(realMatrixPreservingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) (short) 1, localizable2, (java.lang.Object[]) doubleArray8);
        double[] doubleArray16 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException9, doubleArray16);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray21, doubleArray22, doubleArray23, doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray25);
        java.lang.NullPointerException nullPointerException28 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray25);
        double[] doubleArray30 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[][] doubleArray38 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37 };
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        java.text.ParseException parseException40 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException28, doubleArray30, localizable31, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray30, true);
        double[] doubleArray44 = vectorialPointValuePair43.getPointRef();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(doubleArray44);
        java.lang.Class<?> wildcardClass46 = functionEvaluationException45.getClass();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(nullPointerException28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(parseException40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(wildcardClass46);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray4, doubleArray5, doubleArray6, doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray8);
        java.lang.NullPointerException nullPointerException11 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray8);
        double[] doubleArray13 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable14 = null;
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[][] doubleArray21 = new double[][] { doubleArray17, doubleArray18, doubleArray19, doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        java.text.ParseException parseException23 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray21);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException11, doubleArray13, localizable14, (java.lang.Object[]) doubleArray21);
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[] doubleArray32 = new double[] {};
        double[][] doubleArray33 = new double[][] { doubleArray29, doubleArray30, doubleArray31, doubleArray32 };
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray33);
        java.lang.NullPointerException nullPointerException36 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException11, "hi!", (java.lang.Object[]) doubleArray33);
        java.lang.Throwable throwable38 = null;
        org.apache.commons.math.exception.Localizable localizable40 = null;
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[][] doubleArray45 = new double[][] { doubleArray41, doubleArray42, doubleArray43, doubleArray44 };
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException(throwable38, (double) (short) 1, localizable40, (java.lang.Object[]) doubleArray46);
        double[] doubleArray54 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException47, doubleArray54);
        org.apache.commons.math.exception.Localizable localizable56 = null;
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[] doubleArray60 = new double[] {};
        double[][] doubleArray61 = new double[][] { doubleArray57, doubleArray58, doubleArray59, doubleArray60 };
        double[][] doubleArray62 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray61);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException11, doubleArray54, localizable56, (java.lang.Object[]) doubleArray61);
        double[] doubleArray67 = new double[] {};
        double[] doubleArray68 = new double[] {};
        double[] doubleArray69 = new double[] {};
        double[] doubleArray70 = new double[] {};
        double[][] doubleArray71 = new double[][] { doubleArray67, doubleArray68, doubleArray69, doubleArray70 };
        double[][] doubleArray72 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray71);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray71);
        org.apache.commons.math.MathRuntimeException mathRuntimeException74 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException63, "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", (java.lang.Object[]) doubleArray71);
        java.lang.Object[] objArray75 = mathRuntimeException74.getArguments();
        org.apache.commons.math.exception.Localizable localizable76 = mathRuntimeException74.getLocalizablePattern();
        java.lang.Object[] objArray77 = null;
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException78 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable76, objArray77);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException80 = new org.apache.commons.math.MaxEvaluationsExceededException((-1));
        org.apache.commons.math.optimization.OptimizationException optimizationException81 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException80);
        java.lang.Throwable[] throwableArray82 = optimizationException81.getSuppressed();
        java.lang.IllegalStateException illegalStateException83 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable76, (java.lang.Object[]) throwableArray82);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(nullPointerException11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(parseException23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(nullPointerException36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(localizable76);
        org.junit.Assert.assertNotNull(throwableArray82);
        org.junit.Assert.assertNotNull(illegalStateException83);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.scalarAdd((double) 0.0f);
        double[] doubleArray9 = new double[] { (short) 0 };
        double[] doubleArray11 = new double[] { (short) 0 };
        double[][] doubleArray12 = new double[][] { doubleArray9, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        double[] doubleArray15 = new double[] { (short) 0 };
        double[] doubleArray17 = new double[] { (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix13.add(array2DRowRealMatrix19);
        double double21 = array2DRowRealMatrix19.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix19.transpose();
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 0 };
        double[][] doubleArray27 = new double[][] { doubleArray24, doubleArray26 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        double[] doubleArray30 = new double[] { (short) 0 };
        double[] doubleArray32 = new double[] { (short) 0 };
        double[][] doubleArray33 = new double[][] { doubleArray30, doubleArray32 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = array2DRowRealMatrix28.add(array2DRowRealMatrix34);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = array2DRowRealMatrix19.add(array2DRowRealMatrix28);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix5.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        double[] doubleArray39 = new double[] { (short) 0 };
        double[] doubleArray41 = new double[] { (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray39, doubleArray41 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray42);
        double[] doubleArray45 = new double[] { (short) 0 };
        double[] doubleArray47 = new double[] { (short) 0 };
        double[][] doubleArray48 = new double[][] { doubleArray45, doubleArray47 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = array2DRowRealMatrix43.add(array2DRowRealMatrix49);
        org.apache.commons.math.linear.RealMatrix realMatrix51 = array2DRowRealMatrix43.transpose();
        double[] doubleArray53 = new double[] { (short) 0 };
        double[] doubleArray55 = new double[] { (short) 0 };
        double[][] doubleArray56 = new double[][] { doubleArray53, doubleArray55 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray56);
        double[] doubleArray59 = new double[] { (short) 0 };
        double[] doubleArray61 = new double[] { (short) 0 };
        double[][] doubleArray62 = new double[][] { doubleArray59, doubleArray61 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = array2DRowRealMatrix57.add(array2DRowRealMatrix63);
        double[][] doubleArray65 = array2DRowRealMatrix63.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix66 = array2DRowRealMatrix43.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix63);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix67 = array2DRowRealMatrix5.multiply(realMatrix66);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix35);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix36);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix66);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray7);
        java.lang.NullPointerException nullPointerException10 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray7);
        double[] doubleArray12 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[][] doubleArray20 = new double[][] { doubleArray16, doubleArray17, doubleArray18, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        java.text.ParseException parseException22 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException10, doubleArray12, localizable13, (java.lang.Object[]) doubleArray20);
        java.io.IOException iOException24 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) functionEvaluationException23);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(nullPointerException10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(parseException22);
        org.junit.Assert.assertNotNull(iOException24);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        try {
            org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl14 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 2x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (short) 0, (int) ' ');
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray7);
        java.lang.NullPointerException nullPointerException10 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray7);
        double[] doubleArray12 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[][] doubleArray20 = new double[][] { doubleArray16, doubleArray17, doubleArray18, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        java.text.ParseException parseException22 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException10, doubleArray12, localizable13, (java.lang.Object[]) doubleArray20);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[][] doubleArray32 = new double[][] { doubleArray28, doubleArray29, doubleArray30, doubleArray31 };
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray32);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray32);
        java.lang.NullPointerException nullPointerException35 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray32);
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException10, "hi!", (java.lang.Object[]) doubleArray32);
        java.lang.Throwable throwable37 = null;
        org.apache.commons.math.exception.Localizable localizable39 = null;
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[][] doubleArray44 = new double[][] { doubleArray40, doubleArray41, doubleArray42, doubleArray43 };
        double[][] doubleArray45 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException(throwable37, (double) (short) 1, localizable39, (java.lang.Object[]) doubleArray45);
        double[] doubleArray53 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException46, doubleArray53);
        org.apache.commons.math.exception.Localizable localizable55 = null;
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[][] doubleArray60 = new double[][] { doubleArray56, doubleArray57, doubleArray58, doubleArray59 };
        double[][] doubleArray61 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray60);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException10, doubleArray53, localizable55, (java.lang.Object[]) doubleArray60);
        double[] doubleArray66 = new double[] {};
        double[] doubleArray67 = new double[] {};
        double[] doubleArray68 = new double[] {};
        double[] doubleArray69 = new double[] {};
        double[][] doubleArray70 = new double[][] { doubleArray66, doubleArray67, doubleArray68, doubleArray69 };
        double[][] doubleArray71 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray70);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray70);
        org.apache.commons.math.MathRuntimeException mathRuntimeException73 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException62, "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", (java.lang.Object[]) doubleArray70);
        java.lang.Object[] objArray74 = mathRuntimeException73.getArguments();
        org.apache.commons.math.exception.Localizable localizable75 = mathRuntimeException73.getLocalizablePattern();
        double[] doubleArray77 = new double[] { (short) 0 };
        double[] doubleArray79 = new double[] { (short) 0 };
        double[][] doubleArray80 = new double[][] { doubleArray77, doubleArray79 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray80);
        double[] doubleArray83 = new double[] { (short) 0 };
        double[] doubleArray85 = new double[] { (short) 0 };
        double[][] doubleArray86 = new double[][] { doubleArray83, doubleArray85 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix87 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray86);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix88 = array2DRowRealMatrix81.add(array2DRowRealMatrix87);
        double[][] doubleArray89 = array2DRowRealMatrix87.getDataRef();
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException90 = new org.apache.commons.math.linear.InvalidMatrixException(localizable75, (java.lang.Object[]) doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(nullPointerException10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(parseException22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(nullPointerException35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(localizable75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix88);
        org.junit.Assert.assertNotNull(doubleArray89);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double[] doubleArray3 = new double[] { '4', 10.0f, ' ' };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        try {
            boolean boolean5 = array2DRowRealMatrix4.isSingular();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 3x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray5, doubleArray6, doubleArray7, doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray9);
        java.lang.NullPointerException nullPointerException12 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray9);
        double[] doubleArray14 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable15 = null;
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[] doubleArray21 = new double[] {};
        double[][] doubleArray22 = new double[][] { doubleArray18, doubleArray19, doubleArray20, doubleArray21 };
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        java.text.ParseException parseException24 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException12, doubleArray14, localizable15, (java.lang.Object[]) doubleArray22);
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[] doubleArray32 = new double[] {};
        double[] doubleArray33 = new double[] {};
        double[][] doubleArray34 = new double[][] { doubleArray30, doubleArray31, doubleArray32, doubleArray33 };
        double[][] doubleArray35 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray34);
        java.lang.NullPointerException nullPointerException37 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray34);
        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException12, "hi!", (java.lang.Object[]) doubleArray34);
        java.lang.Throwable throwable39 = null;
        org.apache.commons.math.exception.Localizable localizable41 = null;
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[][] doubleArray46 = new double[][] { doubleArray42, doubleArray43, doubleArray44, doubleArray45 };
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(throwable39, (double) (short) 1, localizable41, (java.lang.Object[]) doubleArray47);
        double[] doubleArray55 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException48, doubleArray55);
        org.apache.commons.math.exception.Localizable localizable57 = null;
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[] doubleArray60 = new double[] {};
        double[] doubleArray61 = new double[] {};
        double[][] doubleArray62 = new double[][] { doubleArray58, doubleArray59, doubleArray60, doubleArray61 };
        double[][] doubleArray63 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray62);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException12, doubleArray55, localizable57, (java.lang.Object[]) doubleArray62);
        java.util.ConcurrentModificationException concurrentModificationException65 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.FunctionEvaluationException: ", (java.lang.Object[]) doubleArray62);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException66 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", (java.lang.Object[]) doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(nullPointerException12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(parseException24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(nullPointerException37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(concurrentModificationException65);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        try {
            array2DRowRealMatrix12.luDecompose();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 2x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.lang.Throwable throwable0 = null;
        try {
            java.io.IOException iOException1 = org.apache.commons.math.MathRuntimeException.createIOException(throwable0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[] doubleArray12 = new double[] {};
        double[] doubleArray13 = new double[] {};
        double[][] doubleArray14 = new double[][] { doubleArray10, doubleArray11, doubleArray12, doubleArray13 };
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray14);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray14);
        java.lang.NullPointerException nullPointerException17 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray14);
        double[] doubleArray19 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable20 = null;
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[][] doubleArray27 = new double[][] { doubleArray23, doubleArray24, doubleArray25, doubleArray26 };
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray27);
        java.text.ParseException parseException29 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException17, doubleArray19, localizable20, (java.lang.Object[]) doubleArray27);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        double[][] doubleArray40 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray39);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray39);
        java.lang.NullPointerException nullPointerException42 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.MathRuntimeException mathRuntimeException43 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException17, "hi!", (java.lang.Object[]) doubleArray39);
        java.lang.Throwable throwable44 = null;
        org.apache.commons.math.exception.Localizable localizable46 = null;
        double[] doubleArray47 = new double[] {};
        double[] doubleArray48 = new double[] {};
        double[] doubleArray49 = new double[] {};
        double[] doubleArray50 = new double[] {};
        double[][] doubleArray51 = new double[][] { doubleArray47, doubleArray48, doubleArray49, doubleArray50 };
        double[][] doubleArray52 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray51);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(throwable44, (double) (short) 1, localizable46, (java.lang.Object[]) doubleArray52);
        double[] doubleArray60 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException61 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException53, doubleArray60);
        org.apache.commons.math.exception.Localizable localizable62 = null;
        double[] doubleArray63 = new double[] {};
        double[] doubleArray64 = new double[] {};
        double[] doubleArray65 = new double[] {};
        double[] doubleArray66 = new double[] {};
        double[][] doubleArray67 = new double[][] { doubleArray63, doubleArray64, doubleArray65, doubleArray66 };
        double[][] doubleArray68 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray67);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException17, doubleArray60, localizable62, (java.lang.Object[]) doubleArray67);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray60);
        try {
            blockRealMatrix2.setRowMatrix((int) (byte) -1, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix70);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(nullPointerException17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(parseException29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(nullPointerException42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.getRowMatrix((int) (byte) 0);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix57 = blockRealMatrix52.getSubMatrix((int) (byte) -1, (int) (short) 10, (int) (byte) 1, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        blockRealMatrix2.setEntry((int) (byte) 1, (int) '#', (double) (-1L));
        int int7 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double9 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        java.lang.String str13 = array2DRowRealMatrix11.toString();
        org.apache.commons.math.linear.RealVector realVector15 = array2DRowRealMatrix11.getColumnVector(0);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor16 = null;
        try {
            double double17 = array2DRowRealMatrix11.walkInRowOrder(realMatrixPreservingVisitor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str13.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        double[] doubleArray7 = blockRealMatrix2.getRow((int) (short) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = blockRealMatrix2.scalarMultiply((double) 0L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[][] doubleArray13 = array2DRowRealMatrix11.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix15 = array2DRowRealMatrix11.getColumnMatrix((int) (short) 0);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[][] doubleArray24 = new double[][] { doubleArray20, doubleArray21, doubleArray22, doubleArray23 };
        double[][] doubleArray25 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray24);
        java.lang.NullPointerException nullPointerException27 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray24);
        double[] doubleArray29 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable30 = null;
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[][] doubleArray37 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36 };
        double[][] doubleArray38 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray37);
        java.text.ParseException parseException39 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException27, doubleArray29, localizable30, (java.lang.Object[]) doubleArray37);
        try {
            array2DRowRealMatrix11.setColumn((int) 'a', doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 97 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(nullPointerException27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(parseException39);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        double double50 = blockRealMatrix2.getEntry((int) (byte) 1, 1);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix2, (int) (short) 0, 1, (int) (byte) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        double double50 = blockRealMatrix2.getEntry((int) (byte) 1, 1);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix2, (int) (byte) 1, (int) (byte) 1, (int) (short) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setMaxIterations((int) (short) 100);
        int int3 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        int int4 = levenbergMarquardtOptimizer0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        double[][] doubleArray48 = null;
        try {
            blockRealMatrix2.setSubMatrix(doubleArray48, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray20 = new double[] { (short) 0 };
        double[] doubleArray22 = new double[] { (short) 0 };
        double[][] doubleArray23 = new double[][] { doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix18.add(array2DRowRealMatrix24);
        double double26 = array2DRowRealMatrix24.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix24.transpose();
        double[] doubleArray29 = new double[] { (short) 0 };
        double[] doubleArray31 = new double[] { (short) 0 };
        double[][] doubleArray32 = new double[][] { doubleArray29, doubleArray31 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (short) 0 };
        double[] doubleArray37 = new double[] { (short) 0 };
        double[][] doubleArray38 = new double[][] { doubleArray35, doubleArray37 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = array2DRowRealMatrix33.add(array2DRowRealMatrix39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = array2DRowRealMatrix24.add(array2DRowRealMatrix33);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = array2DRowRealMatrix11.add(array2DRowRealMatrix33);
        double[] doubleArray44 = new double[] { (short) 0 };
        double[] doubleArray46 = new double[] { (short) 0 };
        double[][] doubleArray47 = new double[][] { doubleArray44, doubleArray46 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        double[] doubleArray50 = new double[] { (short) 0 };
        double[] doubleArray52 = new double[] { (short) 0 };
        double[][] doubleArray53 = new double[][] { doubleArray50, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = array2DRowRealMatrix48.add(array2DRowRealMatrix54);
        double double56 = array2DRowRealMatrix54.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix57 = array2DRowRealMatrix54.transpose();
        org.apache.commons.math.linear.RealMatrix realMatrix59 = array2DRowRealMatrix54.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix42, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix54);
        int[] intArray66 = new int[] { 0, (byte) 100, 'a', (byte) -1, (short) -1 };
        int[] intArray67 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix68 = array2DRowRealMatrix42.getSubMatrix(intArray66, intArray67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix40);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix41);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(intArray66);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double double13 = array2DRowRealMatrix11.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix11.transpose();
        double[] doubleArray16 = new double[] { (short) 0 };
        double[] doubleArray18 = new double[] { (short) 0 };
        double[][] doubleArray19 = new double[][] { doubleArray16, doubleArray18 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 0 };
        double[][] doubleArray25 = new double[][] { doubleArray22, doubleArray24 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = array2DRowRealMatrix20.add(array2DRowRealMatrix26);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = array2DRowRealMatrix11.add(array2DRowRealMatrix20);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix28.copy();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix27);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setMaxIterations((int) (short) 0);
        int int3 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray20 = new double[] { (short) 0 };
        double[] doubleArray22 = new double[] { (short) 0 };
        double[][] doubleArray23 = new double[][] { doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix18.add(array2DRowRealMatrix24);
        double[] doubleArray27 = new double[] { (short) 0 };
        double[] doubleArray29 = new double[] { (short) 0 };
        double[][] doubleArray30 = new double[][] { doubleArray27, doubleArray29 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray30);
        double[] doubleArray33 = new double[] { (short) 0 };
        double[] doubleArray35 = new double[] { (short) 0 };
        double[][] doubleArray36 = new double[][] { doubleArray33, doubleArray35 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = array2DRowRealMatrix31.add(array2DRowRealMatrix37);
        double double39 = array2DRowRealMatrix37.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix40 = array2DRowRealMatrix37.transpose();
        double[] doubleArray42 = new double[] { (short) 0 };
        double[] doubleArray44 = new double[] { (short) 0 };
        double[][] doubleArray45 = new double[][] { doubleArray42, doubleArray44 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray45);
        double[] doubleArray48 = new double[] { (short) 0 };
        double[] doubleArray50 = new double[] { (short) 0 };
        double[][] doubleArray51 = new double[][] { doubleArray48, doubleArray50 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = array2DRowRealMatrix46.add(array2DRowRealMatrix52);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = array2DRowRealMatrix37.add(array2DRowRealMatrix46);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = array2DRowRealMatrix24.add(array2DRowRealMatrix46);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix56 = array2DRowRealMatrix12.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix24);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix53);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix54);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix55);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix2.transpose();
        try {
            double double52 = blockRealMatrix2.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 52x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double[] doubleArray3 = new double[] { (short) 0 };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[][] doubleArray6 = new double[][] { doubleArray3, doubleArray5 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        array2DRowRealMatrix7.multiplyEntry((int) (byte) 1, 0, (double) 0);
        double[][] doubleArray12 = array2DRowRealMatrix7.getDataRef();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException13 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 100, "Array2DRowRealMatrix{{0.0},{0.0}}", (java.lang.Object[]) doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double[] doubleArray4 = new double[] { (short) 0 };
        double[] doubleArray6 = new double[] { (short) 0 };
        double[][] doubleArray7 = new double[][] { doubleArray4, doubleArray6 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "matrix is singular", (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException10 = new org.apache.commons.math.linear.InvalidMatrixException("Array2DRowRealMatrix{{0.0},{0.0}}", (java.lang.Object[]) doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) (short) 1, localizable2, (java.lang.Object[]) doubleArray8);
        double[] doubleArray16 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException9, doubleArray16);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray21, doubleArray22, doubleArray23, doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray25);
        java.lang.NullPointerException nullPointerException28 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray25);
        double[] doubleArray30 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[][] doubleArray38 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37 };
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        java.text.ParseException parseException40 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException28, doubleArray30, localizable31, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray30, true);
        double[] doubleArray44 = vectorialPointValuePair43.getPointRef();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(doubleArray44);
        org.apache.commons.math.exception.Localizable localizable46 = functionEvaluationException45.getLocalizablePattern();
        java.io.ObjectInputStream objectInputStream48 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) localizable46, "matrix is singular", objectInputStream48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(nullPointerException28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(parseException40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.EVALUATION_FAILED + "'", localizable46.equals(org.apache.commons.math.exception.LocalizedFormats.EVALUATION_FAILED));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math.linear.SingularMatrixException singularMatrixException0 = new org.apache.commons.math.linear.SingularMatrixException();
        java.lang.Object[] objArray1 = singularMatrixException0.getArguments();
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[][] doubleArray13 = array2DRowRealMatrix11.getDataRef();
        double[] doubleArray21 = new double[] { 10.0f, (byte) 0, 10.0f, 10.0d, (short) -1, (-1.0d) };
        try {
            array2DRowRealMatrix11.setColumn((int) (byte) -1, doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((-1));
        org.apache.commons.math.optimization.OptimizationException optimizationException2 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException1);
        java.io.ObjectInputStream objectInputStream4 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector((java.lang.Object) maxEvaluationsExceededException1, "", objectInputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix2.createMatrix(1, 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.MathRuntimeException(throwable0);
        org.apache.commons.math.exception.Localizable localizable2 = mathRuntimeException1.getLocalizablePattern();
        java.lang.Object[] objArray3 = null;
        java.util.NoSuchElementException noSuchElementException4 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable2, objArray3);
        java.lang.Object[] objArray5 = null;
        java.lang.IllegalArgumentException illegalArgumentException6 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable2, objArray5);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable2.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(noSuchElementException4);
        org.junit.Assert.assertNotNull(illegalArgumentException6);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math.linear.SingularMatrixException singularMatrixException2 = new org.apache.commons.math.linear.SingularMatrixException();
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException12 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "hi!", (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) singularMatrixException2, localizable3, (java.lang.Object[]) doubleArray10);
        java.io.EOFException eOFException14 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException("Array2DRowRealMatrix{{0.0},{0.0}}", (java.lang.Object[]) doubleArray10);
        java.lang.Object[] objArray16 = mathRuntimeException15.getArguments();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(eOFException14);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix51.getColumnMatrix((int) (short) 1);
        try {
            org.apache.commons.math.linear.RealVector realVector55 = blockRealMatrix53.getRowVector((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.lang.String[][] strArray0 = new java.lang.String[][] {};
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(strArray0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) (short) 1, localizable2, (java.lang.Object[]) doubleArray8);
        double[] doubleArray16 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException9, doubleArray16);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray21, doubleArray22, doubleArray23, doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray25);
        java.lang.NullPointerException nullPointerException28 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray25);
        double[] doubleArray30 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[][] doubleArray38 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37 };
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        java.text.ParseException parseException40 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException28, doubleArray30, localizable31, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray30, true);
        double[] doubleArray44 = vectorialPointValuePair43.getPointRef();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(doubleArray44);
        org.apache.commons.math.linear.BigMatrix bigMatrix46 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(nullPointerException28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(parseException40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(bigMatrix46);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix2.transpose();
        java.lang.Throwable throwable53 = null;
        org.apache.commons.math.exception.Localizable localizable55 = null;
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[][] doubleArray60 = new double[][] { doubleArray56, doubleArray57, doubleArray58, doubleArray59 };
        double[][] doubleArray61 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray60);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException(throwable53, (double) (short) 1, localizable55, (java.lang.Object[]) doubleArray61);
        double[] doubleArray69 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException70 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException62, doubleArray69);
        double[] doubleArray74 = new double[] {};
        double[] doubleArray75 = new double[] {};
        double[] doubleArray76 = new double[] {};
        double[] doubleArray77 = new double[] {};
        double[][] doubleArray78 = new double[][] { doubleArray74, doubleArray75, doubleArray76, doubleArray77 };
        double[][] doubleArray79 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray78);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray78);
        java.lang.NullPointerException nullPointerException81 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray78);
        double[] doubleArray83 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable84 = null;
        double[] doubleArray87 = new double[] {};
        double[] doubleArray88 = new double[] {};
        double[] doubleArray89 = new double[] {};
        double[] doubleArray90 = new double[] {};
        double[][] doubleArray91 = new double[][] { doubleArray87, doubleArray88, doubleArray89, doubleArray90 };
        double[][] doubleArray92 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray91);
        java.text.ParseException parseException93 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray91);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException94 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException81, doubleArray83, localizable84, (java.lang.Object[]) doubleArray91);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair96 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray69, doubleArray83, true);
        blockRealMatrix51.setColumn((int) '#', doubleArray83);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix99 = blockRealMatrix51.getColumnMatrix((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(nullPointerException81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(parseException93);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix2.transpose();
        java.lang.Throwable throwable53 = null;
        org.apache.commons.math.exception.Localizable localizable55 = null;
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[][] doubleArray60 = new double[][] { doubleArray56, doubleArray57, doubleArray58, doubleArray59 };
        double[][] doubleArray61 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray60);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException(throwable53, (double) (short) 1, localizable55, (java.lang.Object[]) doubleArray61);
        double[] doubleArray69 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException70 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException62, doubleArray69);
        double[] doubleArray74 = new double[] {};
        double[] doubleArray75 = new double[] {};
        double[] doubleArray76 = new double[] {};
        double[] doubleArray77 = new double[] {};
        double[][] doubleArray78 = new double[][] { doubleArray74, doubleArray75, doubleArray76, doubleArray77 };
        double[][] doubleArray79 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray78);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray78);
        java.lang.NullPointerException nullPointerException81 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray78);
        double[] doubleArray83 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable84 = null;
        double[] doubleArray87 = new double[] {};
        double[] doubleArray88 = new double[] {};
        double[] doubleArray89 = new double[] {};
        double[] doubleArray90 = new double[] {};
        double[][] doubleArray91 = new double[][] { doubleArray87, doubleArray88, doubleArray89, doubleArray90 };
        double[][] doubleArray92 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray91);
        java.text.ParseException parseException93 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray91);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException94 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException81, doubleArray83, localizable84, (java.lang.Object[]) doubleArray91);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair96 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray69, doubleArray83, true);
        blockRealMatrix51.setColumn((int) '#', doubleArray83);
        org.apache.commons.math.linear.RealVector realVector99 = blockRealMatrix51.getRowVector((int) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(nullPointerException81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(parseException93);
        org.junit.Assert.assertNotNull(realVector99);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) (short) 1, localizable2, (java.lang.Object[]) doubleArray8);
        double[] doubleArray16 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException9, doubleArray16);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray21, doubleArray22, doubleArray23, doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray25);
        java.lang.NullPointerException nullPointerException28 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray25);
        double[] doubleArray30 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[][] doubleArray38 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37 };
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        java.text.ParseException parseException40 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException28, doubleArray30, localizable31, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray30, true);
        double[] doubleArray44 = vectorialPointValuePair43.getPointRef();
        double[] doubleArray45 = vectorialPointValuePair43.getValue();
        double[] doubleArray46 = vectorialPointValuePair43.getValue();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(nullPointerException28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(parseException40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix2.transpose();
        java.lang.Throwable throwable53 = null;
        org.apache.commons.math.exception.Localizable localizable55 = null;
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[][] doubleArray60 = new double[][] { doubleArray56, doubleArray57, doubleArray58, doubleArray59 };
        double[][] doubleArray61 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray60);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException(throwable53, (double) (short) 1, localizable55, (java.lang.Object[]) doubleArray61);
        double[] doubleArray69 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException70 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException62, doubleArray69);
        double[] doubleArray74 = new double[] {};
        double[] doubleArray75 = new double[] {};
        double[] doubleArray76 = new double[] {};
        double[] doubleArray77 = new double[] {};
        double[][] doubleArray78 = new double[][] { doubleArray74, doubleArray75, doubleArray76, doubleArray77 };
        double[][] doubleArray79 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray78);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray78);
        java.lang.NullPointerException nullPointerException81 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray78);
        double[] doubleArray83 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable84 = null;
        double[] doubleArray87 = new double[] {};
        double[] doubleArray88 = new double[] {};
        double[] doubleArray89 = new double[] {};
        double[] doubleArray90 = new double[] {};
        double[][] doubleArray91 = new double[][] { doubleArray87, doubleArray88, doubleArray89, doubleArray90 };
        double[][] doubleArray92 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray91);
        java.text.ParseException parseException93 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray91);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException94 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException81, doubleArray83, localizable84, (java.lang.Object[]) doubleArray91);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair96 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray69, doubleArray83, true);
        blockRealMatrix51.setColumn((int) '#', doubleArray83);
        try {
            double double98 = blockRealMatrix51.getDeterminant();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 1x52 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(nullPointerException81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(parseException93);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double double13 = array2DRowRealMatrix11.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix11.transpose();
        double[] doubleArray16 = new double[] { (short) 0 };
        double[] doubleArray18 = new double[] { (short) 0 };
        double[][] doubleArray19 = new double[][] { doubleArray16, doubleArray18 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 0 };
        double[][] doubleArray25 = new double[][] { doubleArray22, doubleArray24 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = array2DRowRealMatrix20.add(array2DRowRealMatrix26);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = array2DRowRealMatrix11.add(array2DRowRealMatrix20);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix11.inverse();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 2x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix27);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix28);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.linear.AnyMatrix anyMatrix0 = null;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray4, doubleArray5, doubleArray6, doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(throwable1, (double) (short) 1, localizable3, (java.lang.Object[]) doubleArray9);
        double[] doubleArray17 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException10, doubleArray17);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible(anyMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        double double50 = blockRealMatrix2.getEntry((int) (byte) 1, 1);
        blockRealMatrix2.setEntry((-1), (int) (byte) 1, (double) (short) 100);
        double[] doubleArray56 = new double[] { (short) 0 };
        double[] doubleArray58 = new double[] { (short) 0 };
        double[][] doubleArray59 = new double[][] { doubleArray56, doubleArray58 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59);
        double[] doubleArray62 = new double[] { (short) 0 };
        double[] doubleArray64 = new double[] { (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray62, doubleArray64 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray65);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = array2DRowRealMatrix60.add(array2DRowRealMatrix66);
        double[][] doubleArray68 = array2DRowRealMatrix66.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix70 = array2DRowRealMatrix66.getColumnMatrix((int) (short) 0);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix71 = blockRealMatrix2.solve(realMatrix70);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 52x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(realMatrix70);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        double double50 = blockRealMatrix2.getEntry((int) (byte) 1, 1);
        try {
            double[] doubleArray52 = blockRealMatrix2.getColumn((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray7);
        java.lang.NullPointerException nullPointerException10 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray7);
        double[] doubleArray12 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[][] doubleArray20 = new double[][] { doubleArray16, doubleArray17, doubleArray18, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        java.text.ParseException parseException22 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException10, doubleArray12, localizable13, (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.linear.BigMatrix bigMatrix24 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray12);
        org.apache.commons.math.linear.BigMatrix bigMatrix25 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray12);
        java.io.ObjectInputStream objectInputStream27 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) doubleArray12, "hi!", objectInputStream27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(nullPointerException10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(parseException22);
        org.junit.Assert.assertNotNull(bigMatrix24);
        org.junit.Assert.assertNotNull(bigMatrix25);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) 10L);
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray5, doubleArray6, doubleArray7, doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray9);
        java.lang.NullPointerException nullPointerException12 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray9);
        double[] doubleArray14 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable15 = null;
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[] doubleArray21 = new double[] {};
        double[][] doubleArray22 = new double[][] { doubleArray18, doubleArray19, doubleArray20, doubleArray21 };
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        java.text.ParseException parseException24 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException12, doubleArray14, localizable15, (java.lang.Object[]) doubleArray22);
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[] doubleArray32 = new double[] {};
        double[] doubleArray33 = new double[] {};
        double[][] doubleArray34 = new double[][] { doubleArray30, doubleArray31, doubleArray32, doubleArray33 };
        double[][] doubleArray35 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray34);
        java.lang.NullPointerException nullPointerException37 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray34);
        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException12, "hi!", (java.lang.Object[]) doubleArray34);
        java.lang.Throwable throwable39 = null;
        org.apache.commons.math.exception.Localizable localizable41 = null;
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[][] doubleArray46 = new double[][] { doubleArray42, doubleArray43, doubleArray44, doubleArray45 };
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(throwable39, (double) (short) 1, localizable41, (java.lang.Object[]) doubleArray47);
        double[] doubleArray55 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException48, doubleArray55);
        org.apache.commons.math.exception.Localizable localizable57 = null;
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[] doubleArray60 = new double[] {};
        double[] doubleArray61 = new double[] {};
        double[][] doubleArray62 = new double[][] { doubleArray58, doubleArray59, doubleArray60, doubleArray61 };
        double[][] doubleArray63 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray62);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException12, doubleArray55, localizable57, (java.lang.Object[]) doubleArray62);
        double[] doubleArray68 = new double[] {};
        double[] doubleArray69 = new double[] {};
        double[] doubleArray70 = new double[] {};
        double[] doubleArray71 = new double[] {};
        double[][] doubleArray72 = new double[][] { doubleArray68, doubleArray69, doubleArray70, doubleArray71 };
        double[][] doubleArray73 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray72);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray72);
        org.apache.commons.math.MathRuntimeException mathRuntimeException75 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException64, "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = 10", (java.lang.Object[]) doubleArray72);
        functionEvaluationException1.addSuppressed((java.lang.Throwable) functionEvaluationException64);
        double[] doubleArray77 = null;
        try {
            org.apache.commons.math.FunctionEvaluationException functionEvaluationException78 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException1, doubleArray77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(nullPointerException12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(parseException24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(nullPointerException37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.math.BigDecimal[][] bigDecimalArray0 = null;
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(bigDecimalArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray5, doubleArray6, doubleArray7, doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        java.text.ParseException parseException11 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray9);
        java.lang.Throwable[] throwableArray12 = parseException11.getSuppressed();
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[][] doubleArray21 = new double[][] { doubleArray17, doubleArray18, doubleArray19, doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray21);
        java.lang.NullPointerException nullPointerException24 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray21);
        double[] doubleArray26 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[] doubleArray32 = new double[] {};
        double[] doubleArray33 = new double[] {};
        double[][] doubleArray34 = new double[][] { doubleArray30, doubleArray31, doubleArray32, doubleArray33 };
        double[][] doubleArray35 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        java.text.ParseException parseException36 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException24, doubleArray26, localizable27, (java.lang.Object[]) doubleArray34);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[][] doubleArray46 = new double[][] { doubleArray42, doubleArray43, doubleArray44, doubleArray45 };
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray46);
        java.lang.NullPointerException nullPointerException49 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray46);
        org.apache.commons.math.MathRuntimeException mathRuntimeException50 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException24, "hi!", (java.lang.Object[]) doubleArray46);
        java.lang.Throwable throwable51 = null;
        org.apache.commons.math.exception.Localizable localizable53 = null;
        double[] doubleArray54 = new double[] {};
        double[] doubleArray55 = new double[] {};
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[][] doubleArray58 = new double[][] { doubleArray54, doubleArray55, doubleArray56, doubleArray57 };
        double[][] doubleArray59 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException(throwable51, (double) (short) 1, localizable53, (java.lang.Object[]) doubleArray59);
        double[] doubleArray67 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException68 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException60, doubleArray67);
        org.apache.commons.math.exception.Localizable localizable69 = null;
        double[] doubleArray70 = new double[] {};
        double[] doubleArray71 = new double[] {};
        double[] doubleArray72 = new double[] {};
        double[] doubleArray73 = new double[] {};
        double[][] doubleArray74 = new double[][] { doubleArray70, doubleArray71, doubleArray72, doubleArray73 };
        double[][] doubleArray75 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray74);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException76 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException24, doubleArray67, localizable69, (java.lang.Object[]) doubleArray74);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) parseException11, localizable13, (java.lang.Object[]) doubleArray74);
        java.io.EOFException eOFException78 = org.apache.commons.math.MathRuntimeException.createEOFException("", (java.lang.Object[]) doubleArray74);
        double[][] doubleArray79 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray74);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "Array2DRowRealMatrix{{0.0},{0.0}}", (java.lang.Object[]) doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(parseException11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(nullPointerException24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(parseException36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(nullPointerException49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(eOFException78);
        org.junit.Assert.assertNotNull(doubleArray79);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        java.lang.String str13 = array2DRowRealMatrix11.toString();
        try {
            array2DRowRealMatrix11.multiplyEntry((int) '4', (int) (short) 100, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (52, 100) in a 2x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str13.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        double[] doubleArray7 = blockRealMatrix2.getRow((int) (short) 0);
        double[][] doubleArray8 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable13 = null;
        org.apache.commons.math.exception.Localizable localizable15 = null;
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[][] doubleArray20 = new double[][] { doubleArray16, doubleArray17, doubleArray18, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(throwable13, (double) (short) 1, localizable15, (java.lang.Object[]) doubleArray21);
        double[] doubleArray29 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException22, doubleArray29);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[][] doubleArray38 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37 };
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray38);
        java.lang.NullPointerException nullPointerException41 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray38);
        double[] doubleArray43 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable44 = null;
        double[] doubleArray47 = new double[] {};
        double[] doubleArray48 = new double[] {};
        double[] doubleArray49 = new double[] {};
        double[] doubleArray50 = new double[] {};
        double[][] doubleArray51 = new double[][] { doubleArray47, doubleArray48, doubleArray49, doubleArray50 };
        double[][] doubleArray52 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray51);
        java.text.ParseException parseException53 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray51);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException41, doubleArray43, localizable44, (java.lang.Object[]) doubleArray51);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair56 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray29, doubleArray43, true);
        double[] doubleArray57 = blockRealMatrix12.operate(doubleArray43);
        org.apache.commons.math.linear.RealVector realVector59 = blockRealMatrix12.getRowVector((int) '#');
        try {
            blockRealMatrix2.setColumnVector((int) (byte) 0, realVector59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 1x1 but expected 52x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(nullPointerException41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(parseException53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realVector59);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double[] doubleArray3 = new double[] { '4', 10.0f, ' ' };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 36 out of allowed range [0, 2]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.createMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.getRowMatrix((int) (byte) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = null;
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix52.subtract(blockRealMatrix53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (short) 10, 36);
        org.apache.commons.math.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nonSquareMatrixException2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        double[] doubleArray7 = blockRealMatrix2.getRow((int) (short) 0);
        double double8 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double10 = blockRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor13 = null;
        try {
            double double18 = array2DRowRealMatrix5.walkInColumnOrder(realMatrixChangingVisitor13, 10, 0, 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double double13 = array2DRowRealMatrix11.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix11.transpose();
        double[] doubleArray16 = null;
        try {
            array2DRowRealMatrix11.setRow((int) (short) 100, doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        double[] doubleArray7 = blockRealMatrix2.getRow((int) (short) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix9 = blockRealMatrix2.solve((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 52x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray5, doubleArray6, doubleArray7, doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        java.text.ParseException parseException11 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray9);
        java.lang.Throwable[] throwableArray12 = parseException11.getSuppressed();
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[][] doubleArray21 = new double[][] { doubleArray17, doubleArray18, doubleArray19, doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray21);
        java.lang.NullPointerException nullPointerException24 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray21);
        double[] doubleArray26 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[] doubleArray32 = new double[] {};
        double[] doubleArray33 = new double[] {};
        double[][] doubleArray34 = new double[][] { doubleArray30, doubleArray31, doubleArray32, doubleArray33 };
        double[][] doubleArray35 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        java.text.ParseException parseException36 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException24, doubleArray26, localizable27, (java.lang.Object[]) doubleArray34);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[][] doubleArray46 = new double[][] { doubleArray42, doubleArray43, doubleArray44, doubleArray45 };
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray46);
        java.lang.NullPointerException nullPointerException49 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray46);
        org.apache.commons.math.MathRuntimeException mathRuntimeException50 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException24, "hi!", (java.lang.Object[]) doubleArray46);
        java.lang.Throwable throwable51 = null;
        org.apache.commons.math.exception.Localizable localizable53 = null;
        double[] doubleArray54 = new double[] {};
        double[] doubleArray55 = new double[] {};
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[][] doubleArray58 = new double[][] { doubleArray54, doubleArray55, doubleArray56, doubleArray57 };
        double[][] doubleArray59 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException(throwable51, (double) (short) 1, localizable53, (java.lang.Object[]) doubleArray59);
        double[] doubleArray67 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException68 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException60, doubleArray67);
        org.apache.commons.math.exception.Localizable localizable69 = null;
        double[] doubleArray70 = new double[] {};
        double[] doubleArray71 = new double[] {};
        double[] doubleArray72 = new double[] {};
        double[] doubleArray73 = new double[] {};
        double[][] doubleArray74 = new double[][] { doubleArray70, doubleArray71, doubleArray72, doubleArray73 };
        double[][] doubleArray75 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray74);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException76 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException24, doubleArray67, localizable69, (java.lang.Object[]) doubleArray74);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) parseException11, localizable13, (java.lang.Object[]) doubleArray74);
        java.io.EOFException eOFException78 = org.apache.commons.math.MathRuntimeException.createEOFException("", (java.lang.Object[]) doubleArray74);
        double[][] doubleArray79 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray74);
        java.lang.IllegalStateException illegalStateException80 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", (java.lang.Object[]) doubleArray79);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException81 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.FunctionEvaluationException: ", (java.lang.Object[]) doubleArray79);
        java.lang.String str82 = matrixIndexException81.getPattern();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(parseException11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(nullPointerException24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(parseException36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(nullPointerException49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(eOFException78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(illegalStateException80);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "org.apache.commons.math.FunctionEvaluationException: " + "'", str82.equals("org.apache.commons.math.FunctionEvaluationException: "));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) (short) 1, localizable2, (java.lang.Object[]) doubleArray8);
        double[] doubleArray16 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException9, doubleArray16);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray21, doubleArray22, doubleArray23, doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray25);
        java.lang.NullPointerException nullPointerException28 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray25);
        double[] doubleArray30 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[][] doubleArray38 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37 };
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        java.text.ParseException parseException40 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException28, doubleArray30, localizable31, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray30, true);
        org.apache.commons.math.linear.BigMatrix bigMatrix44 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray30);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray30);
        double[] doubleArray47 = new double[] { (short) 0 };
        double[] doubleArray49 = new double[] { (short) 0 };
        double[][] doubleArray50 = new double[][] { doubleArray47, doubleArray49 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray50);
        array2DRowRealMatrix51.multiplyEntry((int) (byte) 1, 0, (double) 0);
        double[][] doubleArray56 = array2DRowRealMatrix51.getDataRef();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) realMatrix45, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix51);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(nullPointerException28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(parseException40);
        org.junit.Assert.assertNotNull(bigMatrix44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        blockRealMatrix2.multiplyEntry(10, (int) (byte) -1, (double) '#');
        int int52 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor53 = null;
        try {
            double double58 = blockRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor53, 0, 100, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        double[] doubleArray7 = blockRealMatrix2.getRow((int) (short) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = blockRealMatrix2.scalarMultiply((double) 0);
        int int10 = blockRealMatrix2.getRowDimension();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        try {
            array2DRowRealMatrix11.multiplyEntry((int) (short) 0, 10, (double) 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (0, 10) in a 2x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) (short) 1, localizable2, (java.lang.Object[]) doubleArray8);
        double[] doubleArray16 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException9, doubleArray16);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray21, doubleArray22, doubleArray23, doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray25);
        java.lang.NullPointerException nullPointerException28 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray25);
        double[] doubleArray30 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[][] doubleArray38 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37 };
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        java.text.ParseException parseException40 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException28, doubleArray30, localizable31, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray30, true);
        double[] doubleArray44 = vectorialPointValuePair43.getPointRef();
        double[] doubleArray45 = vectorialPointValuePair43.getValue();
        double[] doubleArray46 = vectorialPointValuePair43.getValueRef();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(nullPointerException28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(parseException40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[][] doubleArray13 = array2DRowRealMatrix11.getDataRef();
        double[] doubleArray15 = new double[] { (short) 0 };
        double[] doubleArray17 = new double[] { (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        double[] doubleArray21 = new double[] { (short) 0 };
        double[] doubleArray23 = new double[] { (short) 0 };
        double[][] doubleArray24 = new double[][] { doubleArray21, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix19.add(array2DRowRealMatrix25);
        double[] doubleArray28 = new double[] { (short) 0 };
        double[] doubleArray30 = new double[] { (short) 0 };
        double[][] doubleArray31 = new double[][] { doubleArray28, doubleArray30 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        double[] doubleArray34 = new double[] { (short) 0 };
        double[] doubleArray36 = new double[] { (short) 0 };
        double[][] doubleArray37 = new double[][] { doubleArray34, doubleArray36 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = array2DRowRealMatrix32.add(array2DRowRealMatrix38);
        double double40 = array2DRowRealMatrix38.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix41 = array2DRowRealMatrix38.transpose();
        double[] doubleArray43 = new double[] { (short) 0 };
        double[] doubleArray45 = new double[] { (short) 0 };
        double[][] doubleArray46 = new double[][] { doubleArray43, doubleArray45 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray49 = new double[] { (short) 0 };
        double[] doubleArray51 = new double[] { (short) 0 };
        double[][] doubleArray52 = new double[][] { doubleArray49, doubleArray51 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray52);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = array2DRowRealMatrix47.add(array2DRowRealMatrix53);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = array2DRowRealMatrix38.add(array2DRowRealMatrix47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix25.add(array2DRowRealMatrix47);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = array2DRowRealMatrix11.multiply(array2DRowRealMatrix25);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix54);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix55);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray20 = new double[] { (short) 0 };
        double[] doubleArray22 = new double[] { (short) 0 };
        double[][] doubleArray23 = new double[][] { doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix18.add(array2DRowRealMatrix24);
        java.lang.String str26 = array2DRowRealMatrix24.toString();
        org.apache.commons.math.linear.RealVector realVector28 = array2DRowRealMatrix24.getColumnVector(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix24);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor30 = null;
        try {
            double double31 = array2DRowRealMatrix24.walkInRowOrder(realMatrixChangingVisitor30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray7);
        java.lang.NullPointerException nullPointerException10 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray7);
        double[] doubleArray12 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[][] doubleArray20 = new double[][] { doubleArray16, doubleArray17, doubleArray18, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        java.text.ParseException parseException22 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException10, doubleArray12, localizable13, (java.lang.Object[]) doubleArray20);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[][] doubleArray32 = new double[][] { doubleArray28, doubleArray29, doubleArray30, doubleArray31 };
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray32);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray32);
        java.lang.NullPointerException nullPointerException35 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray32);
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException10, "hi!", (java.lang.Object[]) doubleArray32);
        java.lang.String str37 = mathRuntimeException36.getPattern();
        java.lang.Class<?> wildcardClass38 = mathRuntimeException36.getClass();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(nullPointerException10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(parseException22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(nullPointerException35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertNotNull(wildcardClass38);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 1, localizable5, (java.lang.Object[]) doubleArray11);
        double[] doubleArray19 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray28);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray28);
        double[] doubleArray33 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.text.ParseException parseException43 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, doubleArray33, localizable34, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray33, true);
        double[] doubleArray47 = blockRealMatrix2.operate(doubleArray33);
        org.apache.commons.math.linear.RealVector realVector49 = blockRealMatrix2.getRowVector((int) '#');
        java.lang.String str50 = blockRealMatrix2.toString();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(parseException43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "BlockRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}" + "'", str50.equals("BlockRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math.linear.FieldMatrix<org.apache.commons.math.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        blockRealMatrix2.setEntry((int) (byte) 0, (int) (short) 10, (-1.0d));
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix2.scalarAdd(10.0d);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray20 = new double[] { (short) 0 };
        double[] doubleArray22 = new double[] { (short) 0 };
        double[][] doubleArray23 = new double[][] { doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix18.add(array2DRowRealMatrix24);
        java.lang.String str26 = array2DRowRealMatrix24.toString();
        org.apache.commons.math.linear.RealVector realVector28 = array2DRowRealMatrix24.getColumnVector(0);
        try {
            blockRealMatrix2.setColumnVector(10, realVector28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        double double5 = blockRealMatrix2.getEntry(0, 0);
        double[] doubleArray7 = blockRealMatrix2.getRow((int) (short) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = blockRealMatrix2.scalarMultiply((double) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable13 = null;
        org.apache.commons.math.exception.Localizable localizable15 = null;
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[][] doubleArray20 = new double[][] { doubleArray16, doubleArray17, doubleArray18, doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(throwable13, (double) (short) 1, localizable15, (java.lang.Object[]) doubleArray21);
        double[] doubleArray29 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException22, doubleArray29);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[][] doubleArray38 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37 };
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray38);
        java.lang.NullPointerException nullPointerException41 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray38);
        double[] doubleArray43 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable44 = null;
        double[] doubleArray47 = new double[] {};
        double[] doubleArray48 = new double[] {};
        double[] doubleArray49 = new double[] {};
        double[] doubleArray50 = new double[] {};
        double[][] doubleArray51 = new double[][] { doubleArray47, doubleArray48, doubleArray49, doubleArray50 };
        double[][] doubleArray52 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray51);
        java.text.ParseException parseException53 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray51);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException41, doubleArray43, localizable44, (java.lang.Object[]) doubleArray51);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair56 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray29, doubleArray43, true);
        double[] doubleArray57 = blockRealMatrix12.operate(doubleArray43);
        double double60 = blockRealMatrix12.getEntry((int) (byte) 1, 1);
        blockRealMatrix12.setEntry((-1), (int) (byte) 1, (double) (short) 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix12);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix70 = blockRealMatrix2.getSubMatrix((int) '4', (int) (short) 10, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(nullPointerException41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(parseException53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix65);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigIdentityMatrix(100);
        org.junit.Assert.assertNotNull(bigMatrix1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double[] doubleArray4 = new double[] { (short) 0 };
        double[] doubleArray6 = new double[] { (short) 0 };
        double[][] doubleArray7 = new double[][] { doubleArray4, doubleArray6 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException9 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "hi!", (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException10 = new org.apache.commons.math.linear.MatrixIndexException("hi!", (java.lang.Object[]) doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[][] doubleArray13 = array2DRowRealMatrix11.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix15 = array2DRowRealMatrix11.getColumnMatrix((int) (short) 0);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((double) 10L);
        double[] doubleArray19 = functionEvaluationException18.getArgument();
        array2DRowRealMatrix11.setRow(0, doubleArray19);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix11.scalarMultiply((double) '4');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double[][] doubleArray13 = array2DRowRealMatrix11.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix15 = array2DRowRealMatrix11.getColumnMatrix((int) (short) 0);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor16 = null;
        try {
            double double17 = array2DRowRealMatrix11.walkInColumnOrder(realMatrixPreservingVisitor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setMaxIterations(0);
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction3 = null;
        java.lang.Throwable throwable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray7, doubleArray8, doubleArray9, doubleArray10 };
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(throwable4, (double) (short) 1, localizable6, (java.lang.Object[]) doubleArray12);
        double[] doubleArray20 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException13, doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        java.lang.Throwable throwable26 = null;
        org.apache.commons.math.exception.Localizable localizable28 = null;
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[] doubleArray32 = new double[] {};
        double[][] doubleArray33 = new double[][] { doubleArray29, doubleArray30, doubleArray31, doubleArray32 };
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(throwable26, (double) (short) 1, localizable28, (java.lang.Object[]) doubleArray34);
        double[] doubleArray42 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException35, doubleArray42);
        double[] doubleArray47 = new double[] {};
        double[] doubleArray48 = new double[] {};
        double[] doubleArray49 = new double[] {};
        double[] doubleArray50 = new double[] {};
        double[][] doubleArray51 = new double[][] { doubleArray47, doubleArray48, doubleArray49, doubleArray50 };
        double[][] doubleArray52 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray51);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray51);
        java.lang.NullPointerException nullPointerException54 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray51);
        double[] doubleArray56 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable57 = null;
        double[] doubleArray60 = new double[] {};
        double[] doubleArray61 = new double[] {};
        double[] doubleArray62 = new double[] {};
        double[] doubleArray63 = new double[] {};
        double[][] doubleArray64 = new double[][] { doubleArray60, doubleArray61, doubleArray62, doubleArray63 };
        double[][] doubleArray65 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray64);
        java.text.ParseException parseException66 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray64);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException67 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException54, doubleArray56, localizable57, (java.lang.Object[]) doubleArray64);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair69 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray42, doubleArray56, true);
        double[] doubleArray70 = blockRealMatrix25.operate(doubleArray56);
        double[] doubleArray74 = new double[] { '4', 10.0f, ' ' };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray74);
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair76 = levenbergMarquardtOptimizer0.optimize(differentiableMultivariateVectorialFunction3, doubleArray20, doubleArray70, doubleArray74);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.optimization.OptimizationException; message: dimensions mismatch 6 != 52");
        } catch (org.apache.commons.math.optimization.OptimizationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(nullPointerException54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(parseException66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray74);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 0 };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.add(array2DRowRealMatrix11);
        double double13 = array2DRowRealMatrix11.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix11.transpose();
        double[] doubleArray16 = new double[] { (short) 0 };
        double[] doubleArray18 = new double[] { (short) 0 };
        double[][] doubleArray19 = new double[][] { doubleArray16, doubleArray18 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 0 };
        double[][] doubleArray25 = new double[][] { doubleArray22, doubleArray24 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = array2DRowRealMatrix20.add(array2DRowRealMatrix26);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = array2DRowRealMatrix11.add(array2DRowRealMatrix20);
        try {
            boolean boolean29 = array2DRowRealMatrix28.isSingular();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 2x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix27);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix28);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) (short) 1, localizable2, (java.lang.Object[]) doubleArray8);
        double[] doubleArray16 = new double[] { 1.0f, 100L, (byte) 0, (short) 1, (-1.0f), 100 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException9, doubleArray16);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray21, doubleArray22, doubleArray23, doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "hi!", (java.lang.Object[]) doubleArray25);
        java.lang.NullPointerException nullPointerException28 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray25);
        double[] doubleArray30 = new double[] { 10L };
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[][] doubleArray38 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37 };
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        java.text.ParseException parseException40 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, "", (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException28, doubleArray30, localizable31, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray30, true);
        double[] doubleArray44 = vectorialPointValuePair43.getPointRef();
        double[] doubleArray45 = vectorialPointValuePair43.getValue();
        double[] doubleArray46 = vectorialPointValuePair43.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(nullPointerException28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(parseException40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }
}

