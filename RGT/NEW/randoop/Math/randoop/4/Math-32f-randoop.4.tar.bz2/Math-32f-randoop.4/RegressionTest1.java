import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.scalarMultiply((double) 1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = vector2D4.add(8.87409624E8d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double11 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D16);
        org.apache.commons.math3.exception.util.Localizable localizable18 = null;
        double[] doubleArray24 = new double[] { Double.NaN, 100L, 100.4987562112089d, (byte) 100, 1.0f };
        double[] doubleArray30 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray36 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray42 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray48 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray54 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray60 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[][] doubleArray61 = new double[][] { doubleArray30, doubleArray36, doubleArray42, doubleArray48, doubleArray54, doubleArray60 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray24, doubleArray61);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException63 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable18, (java.lang.Object[]) doubleArray61);
        boolean boolean64 = vector2D16.equals((java.lang.Object) localizable18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = vector2D0.subtract(0.5031416550830627d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D16);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10231.640042480607d + "'", double11 == 10231.640042480607d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(vector2D65);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D3);
        double double5 = vector2D4.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-1023), 6.283185307179586d);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D13);
        double[] doubleArray15 = vector2D14.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = vector2D14.scalarMultiply(0.026873352908792118d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = plane9.getPointAt(vector2D14, 35.0d);
        double double20 = vector2D4.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103478.05575104892d + "'", double5 == 103478.05575104892d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(13.19090595827292d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2741085251138746d + "'", double1 == 3.2741085251138746d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double[] doubleArray5 = new double[] { Double.NaN, 100L, 100.4987562112089d, (byte) 100, 1.0f };
        double[] doubleArray11 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray17 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray23 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray29 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray35 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray41 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[][] doubleArray42 = new double[][] { doubleArray11, doubleArray17, doubleArray23, doubleArray29, doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray42);
        double[] doubleArray46 = new double[] { 1.0d, 100.4987562112089d };
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray46);
        boolean boolean49 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D7);
        double double9 = vector3D7.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = plane10.getU();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet12 = plane10.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D14.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D17.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D20);
        double double22 = vector3D20.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane23 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D18, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = plane23.getU();
        boolean boolean25 = plane10.isSimilarTo(plane23);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(polyhedronsSet12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.0d) + "'", double22 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 10.0f, (-2.185039863261519d), 1.5707963256028037d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-1023), 6.283185307179586d);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 100.0f, (double) (-1023));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(7.896296018268069E13d, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D2.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double2 = vector3D1.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.normalize();
        double double5 = vector3D4.getX();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 10, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D3);
        double double5 = vector2D4.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D9.scalarMultiply((double) 1);
        double double13 = vector2D4.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D9.scalarMultiply((double) 100L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103478.05575104892d + "'", double5 == 103478.05575104892d);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103579.20732069803d + "'", double13 == 103579.20732069803d);
        org.junit.Assert.assertNotNull(vector2D15);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        float float2 = org.apache.commons.math3.util.Precision.round(0.0f, (int) (byte) 100);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D2, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D5, true);
        boolean boolean8 = orientedPoint4.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint7);
        org.apache.commons.math3.exception.util.Localizable localizable9 = null;
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math3.exception.NullArgumentException(localizable10, objArray11);
        java.lang.Object[] objArray13 = new java.lang.Object[] { nullArgumentException12 };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) orientedPoint4, localizable9, objArray13);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, objArray13);
        org.apache.commons.math3.exception.MathInternalError mathInternalError16 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray13);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree3 = intervalsSet1.getTree(true);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector4 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree5 = euclidean1DBSPTree3.getCell(euclidean1DVector4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = euclidean1DBSPTree3.getParent();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSubHyperplane7 = euclidean1DBSPTree3.getCut();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree8 = euclidean1DBSPTree3.getPlus();
        org.junit.Assert.assertNotNull(euclidean1DBSPTree3);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree5);
        org.junit.Assert.assertNull(euclidean1DBSPTree6);
        org.junit.Assert.assertNull(euclidean1DSubHyperplane7);
        org.junit.Assert.assertNull(euclidean1DBSPTree8);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math3.geometry.partitioning.Side side3 = org.apache.commons.math3.geometry.partitioning.Side.MINUS;
        org.apache.commons.math3.geometry.partitioning.Side side4 = org.apache.commons.math3.geometry.partitioning.Side.PLUS;
        org.apache.commons.math3.geometry.partitioning.Side side5 = org.apache.commons.math3.geometry.partitioning.Side.PLUS;
        org.apache.commons.math3.geometry.partitioning.Side side6 = org.apache.commons.math3.geometry.partitioning.Side.MINUS;
        org.apache.commons.math3.geometry.partitioning.Side[] sideArray7 = new org.apache.commons.math3.geometry.partitioning.Side[] { side3, side4, side5, side6 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection8 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.isMonotonic(sideArray7, orderDirection8, true);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) (-1.5439197382811571d), (int) (short) -1, orderDirection8, true);
        boolean boolean13 = nonMonotonicSequenceException12.getStrict();
        boolean boolean14 = nonMonotonicSequenceException12.getStrict();
        org.junit.Assert.assertTrue("'" + side3 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side3.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertTrue("'" + side4 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side4.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertTrue("'" + side5 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side5.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertTrue("'" + side6 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side6.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(sideArray7);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.scalarMultiply((double) 1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = vector2D4.add(8.87409624E8d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double11 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.Space space12 = vector2D0.getSpace();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line14 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D13);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10231.640042480607d + "'", double11 == 10231.640042480607d);
        org.junit.Assert.assertNotNull(space12);
        org.junit.Assert.assertNotNull(vector2D13);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D7);
        double double9 = vector3D7.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D12.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D18);
        double double20 = vector3D18.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D16, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D23.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D26.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D29);
        double double31 = vector3D29.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D27, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Line line33 = plane21.intersection(plane32);
        boolean boolean34 = plane10.isSimilarTo(plane21);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane35 = plane10.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D37.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = vector3D40.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D43);
        double double45 = vector3D43.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane46 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D41, vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = vector3D48.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = vector3D51.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D54);
        double double56 = vector3D54.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane57 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D52, vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Line line58 = plane46.intersection(plane57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = plane46.getOrigin();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane60 = plane10.translate(vector3D59);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-1.0d) + "'", double31 == (-1.0d));
        org.junit.Assert.assertNull(line33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(plane35);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + (-1.0d) + "'", double45 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-1.0d) + "'", double56 == (-1.0d));
        org.junit.Assert.assertNull(line58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(plane60);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) (-1L), (double) 1.0f);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList3 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet4 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = intervalsSet4.getTree(true);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = intervalsSet2.buildNew(euclidean1DBSPTree6);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree9 = intervalsSet2.getTree(false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree11 = intervalsSet2.getTree(false);
        double double12 = intervalsSet2.getSize();
        org.junit.Assert.assertNotNull(euclidean1DBSPTree6);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree9);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray1);
        try {
            java.lang.String str3 = nullArgumentException2.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D5.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D8.getZero();
        double double10 = vector3D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet12 = plane11.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D14.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D17.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D20);
        double double22 = vector3D20.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane23 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D18, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D25.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D28.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D31);
        double double33 = vector3D31.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane34 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D29, vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Line line35 = plane23.intersection(plane34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = vector3D38.scalarMultiply(32.0d);
        double double42 = vector3D41.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D41.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = vector3D36.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = vector3D47.scalarMultiply(32.0d);
        double double51 = vector3D50.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = vector3D50.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = vector3D45.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D50);
        double double54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D41, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D56);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = vector3D56.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D59.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D45, vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D64);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = vector3D64.scalarMultiply(32.0d);
        double double68 = vector3D67.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = vector3D67.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = vector3D62.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = vector3D73.scalarMultiply(32.0d);
        double double77 = vector3D76.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = vector3D76.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = vector3D71.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D76);
        double double80 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D67, vector3D71);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D82);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D85 = vector3D82.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D86 = vector3D85.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D71, vector3D85);
        double double88 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D59, vector3D87);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane89 = plane23.translate(vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet90 = plane89.wholeSpace();
        boolean boolean91 = polyhedronsSet90.isEmpty();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree93 = polyhedronsSet90.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet94 = polyhedronsSet12.buildNew(euclidean3DBSPTree93);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector95 = polyhedronsSet12.getBarycenter();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 31.0d + "'", double10 == 31.0d);
        org.junit.Assert.assertNotNull(polyhedronsSet12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.0d) + "'", double22 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-1.0d) + "'", double33 == (-1.0d));
        org.junit.Assert.assertNull(line35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 3.141592653589793d + "'", double42 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 3.141592653589793d + "'", double51 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 31.0d + "'", double54 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 3.141592653589793d + "'", double68 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 3.141592653589793d + "'", double77 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNotNull(vector3D79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 31.0d + "'", double80 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D82);
        org.junit.Assert.assertNotNull(vector3D85);
        org.junit.Assert.assertNotNull(vector3D86);
        org.junit.Assert.assertNotNull(vector3D87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 1024.0d + "'", double88 == 1024.0d);
        org.junit.Assert.assertNotNull(plane89);
        org.junit.Assert.assertNotNull(polyhedronsSet90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree93);
        org.junit.Assert.assertNotNull(polyhedronsSet94);
        org.junit.Assert.assertNotNull(euclidean3DVector95);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D4.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D7.getZero();
        double double9 = vector3D1.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D13.scalarMultiply(32.0d);
        double double17 = vector3D16.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D16.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D11.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D23.scalarMultiply(32.0d);
        double double27 = vector3D26.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D26.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D21.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2.99822295029797d, vector3D19, 31.0d, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D7.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        double[] doubleArray32 = vector3D31.toArray();
        double double33 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray32);
        double[][] doubleArray34 = null;
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray32, doubleArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 31.0d + "'", double9 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.141592653589793d + "'", double17 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.141592653589793d + "'", double27 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 0L, (float) 100L, (-0.5f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 174);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 10.04987562112089d, 2.2250738585072014E-308d, 1.3492883949421581d, 7.896296018267969E15d, 6.283185307179586d, 0.0d, (-0.22498402054573294d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.9613891123121976E16d + "'", double8 == 4.9613891123121976E16d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D3.scalarMultiply(32.0d);
        double double7 = vector3D6.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D6.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D1.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D6);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 10, vector3D6);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '4', (double) (byte) 1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D17);
        org.apache.commons.math3.geometry.Space space19 = vector3D18.getSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D22.scalarMultiply(32.0d);
        double double26 = vector3D25.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D25.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D20.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        double double29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D18, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.0d, vector3D14, 8.87409624E8d, vector3D18);
        double double31 = vector3D6.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.141592653589793d + "'", double7 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(space19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.141592653589793d + "'", double26 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1024.0d + "'", double29 == 1024.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 32.0d + "'", double31 == 32.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D7);
        double double9 = vector3D7.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D12.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D18);
        double double20 = vector3D18.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D16, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Line line22 = plane10.intersection(plane21);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet23 = plane21.wholeSpace();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector24 = polyhedronsSet23.getBarycenter();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
        org.junit.Assert.assertNull(line22);
        org.junit.Assert.assertNotNull(polyhedronsSet23);
        org.junit.Assert.assertNotNull(euclidean3DVector24);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(4.61512051684126d, 1.7802032992083176E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.61512051684126d + "'", double2 == 4.61512051684126d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double[] doubleArray2 = new double[] { 10.04987562112089d, 3.141592653589793d };
        double[] doubleArray8 = new double[] { Double.NaN, 100L, 100.4987562112089d, (byte) 100, 1.0f };
        double[] doubleArray14 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray20 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray26 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray32 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray38 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray44 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[][] doubleArray45 = new double[][] { doubleArray14, doubleArray20, doubleArray26, doubleArray32, doubleArray38, doubleArray44 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray8, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray53 = new double[] { Double.NaN, 100L, 100.4987562112089d, (byte) 100, 1.0f };
        double[] doubleArray59 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray65 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray71 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray77 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray83 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray89 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[][] doubleArray90 = new double[][] { doubleArray59, doubleArray65, doubleArray71, doubleArray77, doubleArray83, doubleArray89 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray53, doubleArray90);
        double double92 = org.apache.commons.math3.util.MathArrays.distance(doubleArray2, doubleArray53);
        double[] doubleArray95 = new double[] { 7.6293945E-6f, 2.302585092994046d };
        double[][] doubleArray96 = new double[][] { doubleArray95 };
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray53, doubleArray96);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 97.28027201052065d + "'", double92 == 97.28027201052065d);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertNotNull(doubleArray96);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D1, vector1D2);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = vector1D2.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double7 = vector1D6.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = vector1D6.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 'a', vector1D2, 7.896296018268069E13d, vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = vector1D2.negate();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D10);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = vector2D3.scalarMultiply((double) 1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = vector2D3.add(8.87409624E8d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-1023), 6.283185307179586d);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane13 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D17);
        double[] doubleArray19 = vector2D18.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D18.scalarMultiply(0.026873352908792118d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = plane13.getPointAt(vector2D18, 35.0d);
        double double24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D8, vector2D18);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 103478.05575104892d + "'", double24 == 103478.05575104892d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D5.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D8.getZero();
        double double10 = vector3D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet12 = plane11.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D14.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D17.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D20);
        double double22 = vector3D20.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane23 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D18, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D25.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D28.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D31);
        double double33 = vector3D31.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane34 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D29, vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Line line35 = plane23.intersection(plane34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = vector3D38.scalarMultiply(32.0d);
        double double42 = vector3D41.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D41.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = vector3D36.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = vector3D47.scalarMultiply(32.0d);
        double double51 = vector3D50.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = vector3D50.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = vector3D45.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D50);
        double double54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D41, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D56);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = vector3D56.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D59.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D45, vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D64);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = vector3D64.scalarMultiply(32.0d);
        double double68 = vector3D67.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = vector3D67.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = vector3D62.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = vector3D73.scalarMultiply(32.0d);
        double double77 = vector3D76.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = vector3D76.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = vector3D71.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D76);
        double double80 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D67, vector3D71);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D82);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D85 = vector3D82.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D86 = vector3D85.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D71, vector3D85);
        double double88 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D59, vector3D87);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane89 = plane23.translate(vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet90 = plane89.wholeSpace();
        boolean boolean91 = polyhedronsSet90.isEmpty();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree93 = polyhedronsSet90.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet94 = polyhedronsSet12.buildNew(euclidean3DBSPTree93);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree96 = polyhedronsSet94.getTree(false);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 31.0d + "'", double10 == 31.0d);
        org.junit.Assert.assertNotNull(polyhedronsSet12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.0d) + "'", double22 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-1.0d) + "'", double33 == (-1.0d));
        org.junit.Assert.assertNull(line35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 3.141592653589793d + "'", double42 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 3.141592653589793d + "'", double51 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 31.0d + "'", double54 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 3.141592653589793d + "'", double68 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 3.141592653589793d + "'", double77 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNotNull(vector3D79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 31.0d + "'", double80 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D82);
        org.junit.Assert.assertNotNull(vector3D85);
        org.junit.Assert.assertNotNull(vector3D86);
        org.junit.Assert.assertNotNull(vector3D87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 1024.0d + "'", double88 == 1024.0d);
        org.junit.Assert.assertNotNull(plane89);
        org.junit.Assert.assertNotNull(polyhedronsSet90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree93);
        org.junit.Assert.assertNotNull(polyhedronsSet94);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree96);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double[] doubleArray2 = new double[] { 1.0d, 100.4987562112089d };
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray2);
        org.apache.commons.math3.geometry.partitioning.Side side4 = org.apache.commons.math3.geometry.partitioning.Side.MINUS;
        org.apache.commons.math3.geometry.partitioning.Side side5 = org.apache.commons.math3.geometry.partitioning.Side.PLUS;
        org.apache.commons.math3.geometry.partitioning.Side side6 = org.apache.commons.math3.geometry.partitioning.Side.PLUS;
        org.apache.commons.math3.geometry.partitioning.Side side7 = org.apache.commons.math3.geometry.partitioning.Side.MINUS;
        org.apache.commons.math3.geometry.partitioning.Side[] sideArray8 = new org.apache.commons.math3.geometry.partitioning.Side[] { side4, side5, side6, side7 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection9 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.isMonotonic(sideArray8, orderDirection9, true);
        boolean boolean13 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray2, orderDirection9, true);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray2, 2.0d);
        org.apache.commons.math3.geometry.partitioning.Side side19 = org.apache.commons.math3.geometry.partitioning.Side.MINUS;
        org.apache.commons.math3.geometry.partitioning.Side side20 = org.apache.commons.math3.geometry.partitioning.Side.PLUS;
        org.apache.commons.math3.geometry.partitioning.Side side21 = org.apache.commons.math3.geometry.partitioning.Side.PLUS;
        org.apache.commons.math3.geometry.partitioning.Side side22 = org.apache.commons.math3.geometry.partitioning.Side.MINUS;
        org.apache.commons.math3.geometry.partitioning.Side[] sideArray23 = new org.apache.commons.math3.geometry.partitioning.Side[] { side19, side20, side21, side22 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection24 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.isMonotonic(sideArray23, orderDirection24, true);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException28 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) (-1.5439197382811571d), (int) (short) -1, orderDirection24, true);
        boolean boolean29 = nonMonotonicSequenceException28.getStrict();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection30 = nonMonotonicSequenceException28.getDirection();
        boolean boolean32 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray15, orderDirection30, false);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple33 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + side4 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side4.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertTrue("'" + side5 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side5.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertTrue("'" + side6 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side6.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertTrue("'" + side7 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side7.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(sideArray8);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + side19 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side19.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertTrue("'" + side20 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side20.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertTrue("'" + side21 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side21.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertTrue("'" + side22 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side22.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(sideArray23);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree3 = intervalsSet1.getTree(true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint6 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D4, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree7 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet8 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree7);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint9 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint6, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet8);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = euclidean1DBSPTree3.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint9);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree11 = euclidean1DBSPTree10.getMinus();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSubHyperplane12 = euclidean1DBSPTree10.getCut();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree13 = euclidean1DBSPTree10.getMinus();
        org.junit.Assert.assertNotNull(euclidean1DBSPTree3);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree10);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree11);
        org.junit.Assert.assertNotNull(euclidean1DSubHyperplane12);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree13);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { 0, (byte) 0, 10 };
        int[] intArray9 = new int[] { '4', (short) 100, ' ', 10 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray4, intArray9);
        try {
            int int11 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray0, intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 174 + "'", int10 == 174);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(271.8281831203941d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2088857170 + "'", int1 == 2088857170);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double1 = vector1D0.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = vector1D0.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double5 = vector1D4.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = vector1D0.add(2.302585092994046d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double8 = vector1D7.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = vector1D7.getZero();
        double double10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D6, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint13 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D11, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree14 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet15 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree14);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint16 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint13, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet15);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList17 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList17);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree20 = intervalsSet18.getTree(true);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector21 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree22 = euclidean1DBSPTree20.getCell(euclidean1DVector21);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree23 = euclidean1DBSPTree20.getParent();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSubHyperplane24 = euclidean1DBSPTree20.getCut();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet27 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) (-1L), (double) 1.0f);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList28 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet29 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList28);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree31 = intervalsSet29.getTree(true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint34 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D32, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree35 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet36 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree35);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint37 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint34, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet36);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree38 = euclidean1DBSPTree31.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint37);
        java.lang.Object obj39 = euclidean1DBSPTree31.getAttribute();
        boolean boolean40 = intervalsSet27.isEmpty(euclidean1DBSPTree31);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double44 = vector1D43.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = vector1D43.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double48 = vector1D47.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = vector1D43.add(2.302585092994046d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D47);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double52 = vector1D51.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = vector1D51.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double56 = vector1D55.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = vector1D51.add(2.302585092994046d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D55);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = vector1D47.subtract(8.87409624E8d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D51);
        boolean boolean59 = vector1D58.isNaN();
        double double60 = vector1D42.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D58);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double63 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D61, vector1D62);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = vector1D62.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D66, vector1D67);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D69 = vector1D62.add(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D66);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D70 = vector1D58.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D66);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree71 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint16, euclidean1DBSPTree20, euclidean1DBSPTree31, (java.lang.Object) vector1D70);
        double double72 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D7, vector1D70);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint74 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D70, false);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree20);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree22);
        org.junit.Assert.assertNull(euclidean1DBSPTree23);
        org.junit.Assert.assertNull(euclidean1DSubHyperplane24);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree31);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree38);
        org.junit.Assert.assertTrue("'" + obj39 + "' != '" + true + "'", obj39.equals(true));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + Double.POSITIVE_INFINITY + "'", double44 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.POSITIVE_INFINITY + "'", double52 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.POSITIVE_INFINITY + "'", double56 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertNotNull(vector1D58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertEquals((double) double60, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D61);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertNotNull(vector1D67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D69);
        org.junit.Assert.assertNotNull(vector1D70);
        org.junit.Assert.assertEquals((double) double72, Double.NaN, 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.scalarMultiply(32.0d);
        double[] doubleArray7 = new double[] { 1.0d, 100.4987562112089d };
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = vector2D9.getZero();
        boolean boolean11 = vector3D4.equals((java.lang.Object) vector2D9);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector13 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D4.add((double) (-1.0f), euclidean3DVector13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math3.geometry.partitioning.Side side3 = org.apache.commons.math3.geometry.partitioning.Side.MINUS;
        org.apache.commons.math3.geometry.partitioning.Side side4 = org.apache.commons.math3.geometry.partitioning.Side.PLUS;
        org.apache.commons.math3.geometry.partitioning.Side side5 = org.apache.commons.math3.geometry.partitioning.Side.PLUS;
        org.apache.commons.math3.geometry.partitioning.Side side6 = org.apache.commons.math3.geometry.partitioning.Side.MINUS;
        org.apache.commons.math3.geometry.partitioning.Side[] sideArray7 = new org.apache.commons.math3.geometry.partitioning.Side[] { side3, side4, side5, side6 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection8 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.isMonotonic(sideArray7, orderDirection8, true);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-57.29577951308232d), (java.lang.Number) (-0.22498402054573294d), (int) (short) 100, orderDirection8, false);
        org.junit.Assert.assertTrue("'" + side3 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side3.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertTrue("'" + side4 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side4.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertTrue("'" + side5 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side5.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertTrue("'" + side6 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side6.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(sideArray7);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 174, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 174L + "'", long2 == 174L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D1, vector1D2);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = vector1D2.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double7 = vector1D6.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = vector1D6.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 'a', vector1D2, 7.896296018268069E13d, vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double12 = vector1D11.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = vector1D11.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double16 = vector1D15.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = vector1D11.add(2.302585092994046d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = vector1D8.add((double) (-1L), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        double double19 = vector1D15.getNorm();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D5.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D8.getZero();
        double double10 = vector3D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D0.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D14.scalarMultiply(32.0d);
        try {
            double double18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D12, vector3D14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 31.0d + "'", double10 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D17);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D7);
        double double9 = vector3D7.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = plane10.getU();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList12 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet13 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList12);
        boolean boolean14 = polygonsSet13.isEmpty();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList15 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet16 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList15);
        boolean boolean17 = polygonsSet16.isEmpty();
        boolean boolean18 = polygonsSet13.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D22);
        boolean boolean24 = vector2D23.isNaN();
        double double25 = vector2D23.getNormSq();
        double double26 = vector2D23.getNormSq();
        org.apache.commons.math3.geometry.partitioning.Region.Location location27 = polygonsSet16.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane28 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane10, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet16);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion29 = subPlane28.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DHyperplane30 = subPlane28.getHyperplane();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList31 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet32 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList31);
        boolean boolean33 = polygonsSet32.isEmpty();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList34 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet35 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList34);
        boolean boolean36 = polygonsSet35.isEmpty();
        boolean boolean37 = polygonsSet32.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet35);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane38 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane(euclidean3DHyperplane30, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet32);
        double double39 = subPlane38.getSize();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane40 = subPlane38.copySelf();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0707708022017187E10d + "'", double25 == 1.0707708022017187E10d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0707708022017187E10d + "'", double26 == 1.0707708022017187E10d);
        org.junit.Assert.assertTrue("'" + location27 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location27.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(euclidean2DRegion29);
        org.junit.Assert.assertNotNull(euclidean3DHyperplane30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane40);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane1 = null;
        org.apache.commons.math3.geometry.partitioning.BoundaryAttribute<org.apache.commons.math3.geometry.Space> spaceBoundaryAttribute2 = new org.apache.commons.math3.geometry.partitioning.BoundaryAttribute<org.apache.commons.math3.geometry.Space>(spaceSubHyperplane0, spaceSubHyperplane1);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane3 = spaceBoundaryAttribute2.getPlusInside();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane4 = spaceBoundaryAttribute2.getPlusOutside();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane5 = spaceBoundaryAttribute2.getPlusInside();
        org.junit.Assert.assertNull(spaceSubHyperplane3);
        org.junit.Assert.assertNull(spaceSubHyperplane4);
        org.junit.Assert.assertNull(spaceSubHyperplane5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree3 = intervalsSet1.getTree(true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint6 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D4, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree7 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet8 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree7);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint9 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint6, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet8);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = euclidean1DBSPTree3.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint9);
        java.lang.Object obj11 = euclidean1DBSPTree10.getAttribute();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint14 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D12, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree15 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet16 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree15);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint17 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint14, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet16);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList18 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet19 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList18);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree21 = intervalsSet19.getTree(true);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector22 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree23 = euclidean1DBSPTree21.getCell(euclidean1DVector22);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree24 = euclidean1DBSPTree21.getParent();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSubHyperplane25 = euclidean1DBSPTree21.getCut();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet28 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) (-1L), (double) 1.0f);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList29 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet30 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList29);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree32 = intervalsSet30.getTree(true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint35 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D33, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree36 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet37 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree36);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint38 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint35, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet37);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree39 = euclidean1DBSPTree32.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint38);
        java.lang.Object obj40 = euclidean1DBSPTree32.getAttribute();
        boolean boolean41 = intervalsSet28.isEmpty(euclidean1DBSPTree32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double45 = vector1D44.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = vector1D44.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double49 = vector1D48.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = vector1D44.add(2.302585092994046d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D48);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double53 = vector1D52.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = vector1D52.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double57 = vector1D56.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = vector1D52.add(2.302585092994046d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D56);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = vector1D48.subtract(8.87409624E8d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D52);
        boolean boolean60 = vector1D59.isNaN();
        double double61 = vector1D43.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D59);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double64 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D62, vector1D63);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = vector1D63.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double69 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D67, vector1D68);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D70 = vector1D63.add(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D67);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D71 = vector1D59.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D67);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree72 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint17, euclidean1DBSPTree21, euclidean1DBSPTree32, (java.lang.Object) vector1D71);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D73 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint75 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D73, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree76 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet77 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree76);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint78 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint75, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet77);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree79 = euclidean1DBSPTree32.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint78);
        try {
            euclidean1DBSPTree10.insertInTree(euclidean1DBSPTree32, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DBSPTree3);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree21);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree23);
        org.junit.Assert.assertNull(euclidean1DBSPTree24);
        org.junit.Assert.assertNull(euclidean1DSubHyperplane25);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree32);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree39);
        org.junit.Assert.assertTrue("'" + obj40 + "' != '" + true + "'", obj40.equals(true));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.POSITIVE_INFINITY + "'", double45 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.POSITIVE_INFINITY + "'", double49 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + Double.POSITIVE_INFINITY + "'", double57 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D58);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertEquals((double) double64, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D65);
        org.junit.Assert.assertNotNull(vector1D67);
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D70);
        org.junit.Assert.assertNotNull(vector1D71);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree79);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-1023), 6.283185307179586d);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D8);
        double[] doubleArray10 = vector2D9.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D9.scalarMultiply(0.026873352908792118d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = plane4.getPointAt(vector2D9, 35.0d);
        double double15 = vector2D0.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double16 = vector2D9.getNorm();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103478.05575104892d + "'", double16 == 103478.05575104892d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D5.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D8.getZero();
        double double10 = vector3D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet12 = plane11.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet13 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane14 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane11, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet13);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 31.0d + "'", double10 == 31.0d);
        org.junit.Assert.assertNotNull(polyhedronsSet12);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D7);
        double double9 = vector3D7.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = plane10.getU();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList12 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet13 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList12);
        boolean boolean14 = polygonsSet13.isEmpty();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList15 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet16 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList15);
        boolean boolean17 = polygonsSet16.isEmpty();
        boolean boolean18 = polygonsSet13.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D22);
        boolean boolean24 = vector2D23.isNaN();
        double double25 = vector2D23.getNormSq();
        double double26 = vector2D23.getNormSq();
        org.apache.commons.math3.geometry.partitioning.Region.Location location27 = polygonsSet16.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane28 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane10, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet16);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane29 = subPlane28.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane30 = euclidean3DAbstractSubHyperplane29.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane31 = euclidean3DAbstractSubHyperplane29.copySelf();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0707708022017187E10d + "'", double25 == 1.0707708022017187E10d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0707708022017187E10d + "'", double26 == 1.0707708022017187E10d);
        org.junit.Assert.assertTrue("'" + location27 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location27.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane29);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane30);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane31);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree3 = intervalsSet1.getTree(true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree5 = intervalsSet1.getTree(true);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree3);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        boolean boolean2 = polygonsSet1.isEmpty();
        double[] doubleArray5 = new double[] { 1.0d, 100.4987562112089d };
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D7.getZero();
        org.apache.commons.math3.geometry.partitioning.Region.Location location9 = polygonsSet1.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + location9 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location9.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) (-23), (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 23L + "'", long2 == 23L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(10.0f, (float) (-23L), 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = new org.apache.commons.math3.geometry.euclidean.oned.Interval((double) 100, (double) 1774819148);
        double double3 = interval2.getMidPoint();
        double double4 = interval2.getMidPoint();
        double double5 = interval2.getMidPoint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.87409624E8d + "'", double3 == 8.87409624E8d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.87409624E8d + "'", double4 == 8.87409624E8d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.87409624E8d + "'", double5 == 8.87409624E8d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D7);
        double double9 = vector3D7.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = plane10.getU();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList12 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet13 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList12);
        boolean boolean14 = polygonsSet13.isEmpty();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList15 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet16 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList15);
        boolean boolean17 = polygonsSet16.isEmpty();
        boolean boolean18 = polygonsSet13.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D22);
        boolean boolean24 = vector2D23.isNaN();
        double double25 = vector2D23.getNormSq();
        double double26 = vector2D23.getNormSq();
        org.apache.commons.math3.geometry.partitioning.Region.Location location27 = polygonsSet16.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane28 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane10, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet16);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion29 = subPlane28.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DHyperplane30 = subPlane28.getHyperplane();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList31 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet32 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList31);
        boolean boolean33 = polygonsSet32.isEmpty();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList34 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet35 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList34);
        boolean boolean36 = polygonsSet35.isEmpty();
        boolean boolean37 = polygonsSet32.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet35);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane38 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane(euclidean3DHyperplane30, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet32);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion39 = subPlane38.getRemainingRegion();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0707708022017187E10d + "'", double25 == 1.0707708022017187E10d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0707708022017187E10d + "'", double26 == 1.0707708022017187E10d);
        org.junit.Assert.assertTrue("'" + location27 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location27.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(euclidean2DRegion29);
        org.junit.Assert.assertNotNull(euclidean3DHyperplane30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(euclidean2DRegion39);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-1023), 6.283185307179586d);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = plane3.getNormal();
        org.junit.Assert.assertNotNull(vector3D4);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D3);
        boolean boolean5 = vector2D4.isNaN();
        double double6 = vector2D4.getNormSq();
        double double7 = vector2D4.getNormSq();
        boolean boolean9 = vector2D4.equals((java.lang.Object) 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0707708022017187E10d + "'", double6 == 1.0707708022017187E10d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0707708022017187E10d + "'", double7 == 1.0707708022017187E10d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math3.geometry.partitioning.RegionFactory<org.apache.commons.math3.geometry.Space> spaceRegionFactory0 = new org.apache.commons.math3.geometry.partitioning.RegionFactory<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.Space> spaceRegion1 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.Space> spaceRegion2 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.Space> spaceRegion3 = spaceRegionFactory0.union(spaceRegion1, spaceRegion2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D0, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint5 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D3, true);
        boolean boolean6 = orientedPoint2.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint5);
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        org.apache.commons.math3.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException10 = new org.apache.commons.math3.exception.NullArgumentException(localizable8, objArray9);
        java.lang.Object[] objArray11 = new java.lang.Object[] { nullArgumentException10 };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) orientedPoint2, localizable7, objArray11);
        orientedPoint2.revertSelf();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        int int1 = org.apache.commons.math3.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D7);
        double double9 = vector3D7.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D12.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D18);
        double double20 = vector3D18.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D16, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Line line22 = plane10.intersection(plane21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D25.scalarMultiply(32.0d);
        double double29 = vector3D28.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D28.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D23.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D34.scalarMultiply(32.0d);
        double double38 = vector3D37.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D37.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D32.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        double double41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D28, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = vector3D43.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D46.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D32, vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D51.scalarMultiply(32.0d);
        double double55 = vector3D54.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = vector3D54.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = vector3D49.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D60);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = vector3D60.scalarMultiply(32.0d);
        double double64 = vector3D63.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = vector3D63.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = vector3D58.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D63);
        double double67 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D54, vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D69);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = vector3D69.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = vector3D72.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D58, vector3D72);
        double double75 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D46, vector3D74);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane76 = plane10.translate(vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet77 = plane76.wholeSpace();
        boolean boolean78 = polyhedronsSet77.isEmpty();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree80 = polyhedronsSet77.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet81 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet(euclidean3DBSPTree80);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
        org.junit.Assert.assertNull(line22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.141592653589793d + "'", double29 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.141592653589793d + "'", double38 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 31.0d + "'", double41 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 3.141592653589793d + "'", double55 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 3.141592653589793d + "'", double64 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 31.0d + "'", double67 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1024.0d + "'", double75 == 1024.0d);
        org.junit.Assert.assertNotNull(plane76);
        org.junit.Assert.assertNotNull(polyhedronsSet77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree80);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D7);
        double double9 = vector3D7.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = plane10.getU();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet12 = plane10.wholeSpace();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector13 = polyhedronsSet12.getBarycenter();
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractRegion14 = polyhedronsSet12.copySelf();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector15 = polyhedronsSet12.getBarycenter();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(polyhedronsSet12);
        org.junit.Assert.assertNotNull(euclidean3DVector13);
        org.junit.Assert.assertNotNull(euclidean3DAbstractRegion14);
        org.junit.Assert.assertNotNull(euclidean3DVector15);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double1 = vector1D0.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = vector1D0.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double5 = vector1D4.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = vector1D0.add(2.302585092994046d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double8 = vector1D7.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = vector1D6.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = vector1D7.negate();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1.0f);
        double double13 = vector1D7.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D15, vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = vector1D16.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double21 = vector1D20.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = vector1D20.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 'a', vector1D16, 7.896296018268069E13d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double26 = vector1D25.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = vector1D25.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double30 = vector1D29.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = vector1D25.add(2.302585092994046d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = vector1D22.add((double) (-1L), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D29);
        double double33 = vector1D7.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D29);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.POSITIVE_INFINITY + "'", double26 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.POSITIVE_INFINITY + "'", double30 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (-1023));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D7);
        double double9 = vector3D7.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D12.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D18);
        double double20 = vector3D18.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D16, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Line line22 = plane10.intersection(plane21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D25.scalarMultiply(32.0d);
        double double29 = vector3D28.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D28.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D23.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D34.scalarMultiply(32.0d);
        double double38 = vector3D37.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D37.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D32.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        double double41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D28, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = vector3D43.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D46.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D32, vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D51.scalarMultiply(32.0d);
        double double55 = vector3D54.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = vector3D54.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = vector3D49.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D60);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = vector3D60.scalarMultiply(32.0d);
        double double64 = vector3D63.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = vector3D63.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = vector3D58.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D63);
        double double67 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D54, vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D69);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = vector3D69.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = vector3D72.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D58, vector3D72);
        double double75 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D46, vector3D74);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane76 = plane10.translate(vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet77 = plane76.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D81 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D82 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D81);
        boolean boolean83 = vector2D82.isNaN();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D84 = plane76.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D82);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D85 = plane76.getNormal();
        double double86 = vector3D85.getNorm();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector87 = null;
        try {
            double double88 = vector3D85.dotProduct(euclidean3DVector87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
        org.junit.Assert.assertNull(line22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.141592653589793d + "'", double29 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.141592653589793d + "'", double38 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 31.0d + "'", double41 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 3.141592653589793d + "'", double55 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 3.141592653589793d + "'", double64 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 31.0d + "'", double67 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1024.0d + "'", double75 == 1024.0d);
        org.junit.Assert.assertNotNull(plane76);
        org.junit.Assert.assertNotNull(polyhedronsSet77);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(vector3D84);
        org.junit.Assert.assertNotNull(vector3D85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 1.0d + "'", double86 == 1.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection0 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.junit.Assert.assertTrue("'" + orderDirection0 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection0.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '4', (double) (byte) 1);
        double[] doubleArray3 = vector3D2.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(doubleArray3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = vector2D0.negate();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D0, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree3 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet4 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree3);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint5 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint2, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet4);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList6 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList6);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree9 = intervalsSet7.getTree(true);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector10 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree11 = euclidean1DBSPTree9.getCell(euclidean1DVector10);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree12 = euclidean1DBSPTree9.getParent();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSubHyperplane13 = euclidean1DBSPTree9.getCut();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet16 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) (-1L), (double) 1.0f);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList17 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList17);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree20 = intervalsSet18.getTree(true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint23 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D21, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree24 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet25 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree24);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint26 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint23, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet25);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree27 = euclidean1DBSPTree20.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint26);
        java.lang.Object obj28 = euclidean1DBSPTree20.getAttribute();
        boolean boolean29 = intervalsSet16.isEmpty(euclidean1DBSPTree20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double33 = vector1D32.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = vector1D32.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double37 = vector1D36.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = vector1D32.add(2.302585092994046d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D36);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double41 = vector1D40.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = vector1D40.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double45 = vector1D44.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = vector1D40.add(2.302585092994046d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = vector1D36.subtract(8.87409624E8d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D40);
        boolean boolean48 = vector1D47.isNaN();
        double double49 = vector1D31.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D47);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D50, vector1D51);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = vector1D51.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D55, vector1D56);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = vector1D51.add(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D55);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = vector1D47.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D55);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree60 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint5, euclidean1DBSPTree9, euclidean1DBSPTree20, (java.lang.Object) vector1D59);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint63 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D61, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree64 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet65 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree64);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint66 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint63, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet65);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree67 = euclidean1DBSPTree20.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint66);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane68 = subOrientedPoint66.copySelf();
        org.junit.Assert.assertNotNull(euclidean1DBSPTree9);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree11);
        org.junit.Assert.assertNull(euclidean1DBSPTree12);
        org.junit.Assert.assertNull(euclidean1DSubHyperplane13);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree20);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree27);
        org.junit.Assert.assertTrue("'" + obj28 + "' != '" + true + "'", obj28.equals(true));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.POSITIVE_INFINITY + "'", double33 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.POSITIVE_INFINITY + "'", double37 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + Double.POSITIVE_INFINITY + "'", double41 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.POSITIVE_INFINITY + "'", double45 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D58);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree67);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane68);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(1.5707963267948966d, (double) (-0.5f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8789653979108816d + "'", double2 == 1.8789653979108816d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.scalarMultiply((double) 1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = vector2D4.add(8.87409624E8d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double11 = vector2D10.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) Float.NaN, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine21 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D15, vector2D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D26.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D29.getZero();
        double double31 = vector3D23.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D35.scalarMultiply(32.0d);
        double double39 = vector3D38.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D38.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = vector3D33.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = vector3D45.scalarMultiply(32.0d);
        double double49 = vector3D48.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = vector3D48.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = vector3D43.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2.99822295029797d, vector3D41, 31.0d, vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = vector3D29.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D52);
        boolean boolean54 = vector2D19.equals((java.lang.Object) vector3D53);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = vector2D19.normalize();
        double double56 = vector2D55.getX();
        double double57 = vector2D12.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D55);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = vector2D62.scalarMultiply((double) 1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = vector2D62.add(8.87409624E8d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        double double69 = vector2D68.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) Float.NaN, vector2D68);
        org.apache.commons.math3.geometry.euclidean.twod.Line line71 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D12, vector2D68);
        org.apache.commons.math3.geometry.euclidean.twod.Line line72 = line71.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D80 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D79);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine81 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D75, vector2D79);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D82 = line71.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D79);
        double double83 = line71.getOriginOffset();
        line71.setAngle((double) 0L);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 103.83332020743448d + "'", double11 == 103.83332020743448d);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 31.0d + "'", double31 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 3.141592653589793d + "'", double39 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 3.141592653589793d + "'", double49 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.026873352908792118d + "'", double56 == 0.026873352908792118d);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 103.83332020743448d + "'", double69 == 103.83332020743448d);
        org.junit.Assert.assertNotNull(line72);
        org.junit.Assert.assertNotNull(vector1D82);
        org.junit.Assert.assertEquals((double) double83, Double.NaN, 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double1 = org.apache.commons.math3.util.FastMath.asin(8.197911118990036E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D5.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D8.getZero();
        double double10 = vector3D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet12 = plane11.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform13 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractRegion14 = polyhedronsSet12.applyTransform(euclidean3DTransform13);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector15 = polyhedronsSet12.getBarycenter();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 31.0d + "'", double10 == 31.0d);
        org.junit.Assert.assertNotNull(polyhedronsSet12);
        org.junit.Assert.assertNotNull(euclidean3DAbstractRegion14);
        org.junit.Assert.assertNotNull(euclidean3DVector15);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (int) '4');
        java.lang.Throwable[] throwableArray3 = dimensionMismatchException2.getSuppressed();
        java.lang.Number number4 = dimensionMismatchException2.getArgument();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) 'a', (int) (short) 0);
        int int4 = dimensionMismatchException3.getDimension();
        java.lang.Number number5 = dimensionMismatchException3.getArgument();
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) dimensionMismatchException3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 97 + "'", number5.equals(97));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2146435072 + "'", int1 == 2146435072);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 10L, 0.0d, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.026873352908792118d, 2.99822295029797d);
        org.apache.commons.math3.geometry.Space space3 = vector2D2.getSpace();
        org.junit.Assert.assertNotNull(space3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree3 = intervalsSet1.getTree(true);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet6 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) (-1L), (double) 1.0f);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList7 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet8 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList7);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = intervalsSet8.getTree(true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint13 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D11, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree14 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet15 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree14);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint16 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint13, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet15);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree17 = euclidean1DBSPTree10.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint16);
        java.lang.Object obj18 = euclidean1DBSPTree10.getAttribute();
        boolean boolean19 = intervalsSet6.isEmpty(euclidean1DBSPTree10);
        euclidean1DBSPTree3.insertInTree(euclidean1DBSPTree10, true);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree3);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree10);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree17);
        org.junit.Assert.assertTrue("'" + obj18 + "' != '" + true + "'", obj18.equals(true));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D4.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D7.getZero();
        double double9 = vector3D1.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D13.scalarMultiply(32.0d);
        double double17 = vector3D16.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D16.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D11.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D23.scalarMultiply(32.0d);
        double double27 = vector3D26.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D26.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D21.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2.99822295029797d, vector3D19, 31.0d, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D7.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        double[] doubleArray32 = vector3D31.toArray();
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32, (int) 'a');
        double[] doubleArray37 = new double[] { 1.0d, 100.4987562112089d };
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray37);
        org.apache.commons.math3.geometry.partitioning.Side side42 = org.apache.commons.math3.geometry.partitioning.Side.MINUS;
        org.apache.commons.math3.geometry.partitioning.Side side43 = org.apache.commons.math3.geometry.partitioning.Side.PLUS;
        org.apache.commons.math3.geometry.partitioning.Side side44 = org.apache.commons.math3.geometry.partitioning.Side.PLUS;
        org.apache.commons.math3.geometry.partitioning.Side side45 = org.apache.commons.math3.geometry.partitioning.Side.MINUS;
        org.apache.commons.math3.geometry.partitioning.Side[] sideArray46 = new org.apache.commons.math3.geometry.partitioning.Side[] { side42, side43, side44, side45 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection47 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean49 = org.apache.commons.math3.util.MathArrays.isMonotonic(sideArray46, orderDirection47, true);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException51 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) (-1.5439197382811571d), (int) (short) -1, orderDirection47, true);
        boolean boolean52 = nonMonotonicSequenceException51.getStrict();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection53 = nonMonotonicSequenceException51.getDirection();
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray37, orderDirection53, true);
        try {
            double double56 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray32, doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 31.0d + "'", double9 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.141592653589793d + "'", double17 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.141592653589793d + "'", double27 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + side42 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side42.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertTrue("'" + side43 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side43.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertTrue("'" + side44 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side44.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertTrue("'" + side45 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side45.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(sideArray46);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection53.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion2 = polygonsSet1.copySelf();
        boolean boolean3 = polygonsSet1.isEmpty();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList4 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList4);
        boolean boolean6 = polygonsSet5.isEmpty();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList7 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet8 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList7);
        boolean boolean9 = polygonsSet8.isEmpty();
        boolean boolean10 = polygonsSet5.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet8);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList11 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet12 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList11);
        boolean boolean13 = polygonsSet12.isEmpty();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList14 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet15 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList14);
        boolean boolean16 = polygonsSet15.isEmpty();
        boolean boolean17 = polygonsSet12.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet15);
        double double18 = polygonsSet12.getSize();
        boolean boolean19 = polygonsSet8.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet12);
        boolean boolean20 = polygonsSet1.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet8);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.POSITIVE_INFINITY + "'", double18 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((-2.765584592358123E27d), 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.531169184716246E27d) + "'", double2 == (-5.531169184716246E27d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((double) Float.NaN, 0.0d, Double.NaN, (double) 100.0f);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList5 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet6 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList5);
        boolean boolean7 = polygonsSet6.isEmpty();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList8 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet9 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList8);
        boolean boolean10 = polygonsSet9.isEmpty();
        boolean boolean11 = polygonsSet6.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet9);
        boolean boolean12 = polygonsSet4.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet9);
        double double13 = polygonsSet4.getBoundarySize();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D18.scalarMultiply((double) 1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = vector2D18.add(8.87409624E8d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        double double25 = vector2D24.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) Float.NaN, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D33);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine35 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D29, vector2D33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D40.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = vector3D43.getZero();
        double double45 = vector3D37.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = vector3D49.scalarMultiply(32.0d);
        double double53 = vector3D52.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D52.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = vector3D47.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = vector3D59.scalarMultiply(32.0d);
        double double63 = vector3D62.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = vector3D62.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = vector3D57.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2.99822295029797d, vector3D55, 31.0d, vector3D65);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = vector3D43.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D66);
        boolean boolean68 = vector2D33.equals((java.lang.Object) vector3D67);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = vector2D33.normalize();
        double double70 = vector2D69.getX();
        double double71 = vector2D26.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D69);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D77 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D76);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = vector2D76.scalarMultiply((double) 1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D81 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D82 = vector2D76.add(8.87409624E8d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D81);
        double double83 = vector2D82.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D84 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) Float.NaN, vector2D82);
        org.apache.commons.math3.geometry.euclidean.twod.Line line85 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D26, vector2D82);
        org.apache.commons.math3.geometry.euclidean.twod.Line line86 = line85.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D89 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D93 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D94 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D93);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine95 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D89, vector2D93);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D96 = line85.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D93);
        double double97 = line85.getOriginOffset();
        org.apache.commons.math3.geometry.partitioning.Side side98 = polygonsSet4.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line85);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 103.83332020743448d + "'", double25 == 103.83332020743448d);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 31.0d + "'", double45 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 3.141592653589793d + "'", double53 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 3.141592653589793d + "'", double63 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(vector2D69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.026873352908792118d + "'", double70 == 0.026873352908792118d);
        org.junit.Assert.assertEquals((double) double71, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertNotNull(vector2D81);
        org.junit.Assert.assertNotNull(vector2D82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 103.83332020743448d + "'", double83 == 103.83332020743448d);
        org.junit.Assert.assertNotNull(line86);
        org.junit.Assert.assertNotNull(vector1D96);
        org.junit.Assert.assertEquals((double) double97, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + side98 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side98.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        boolean boolean2 = polygonsSet1.isEmpty();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList3 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList3);
        boolean boolean5 = polygonsSet4.isEmpty();
        boolean boolean6 = polygonsSet1.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet4);
        double double7 = polygonsSet1.getSize();
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion8 = polygonsSet1.copySelf();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree10 = polygonsSet1.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet11 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion8);
        org.junit.Assert.assertNotNull(euclidean2DBSPTree10);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100L, (java.lang.Number) (-1.0f), (int) ' ');
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D3.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D9.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D6.add((double) (short) 0, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = vector3D17.scalarMultiply(32.0d);
        double double21 = vector3D20.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = vector3D20.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D15.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 10, vector3D20);
        double double25 = vector3D12.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D31.scalarMultiply(32.0d);
        double double35 = vector3D34.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D34.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D29.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        double double38 = vector3D34.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = vector3D45.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D48.getZero();
        double double50 = vector3D42.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = vector3D42.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D57.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = vector3D60.getZero();
        double double62 = vector3D54.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D60);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = vector3D42.subtract((double) 32, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((-0.48121182505960347d), vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D71);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = vector3D71.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = vector3D74.getZero();
        double double76 = vector3D68.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D74);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane77 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D66, vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((-0.7615941559557649d), vector3D34, 2.220446049250313E-16d, vector3D54, 101.15156964911917d, vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((-0.6734029996004699d), vector3D26, 0.0d, vector3D54);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.141592653589793d + "'", double21 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 10240.0d + "'", double25 == 10240.0d);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 3.141592653589793d + "'", double35 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 31.0d + "'", double50 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 31.0d + "'", double62 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertNotNull(vector3D75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 31.0d + "'", double76 == 31.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0, 174);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) 100, 7.896296018267969E15d);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList3 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet4 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = intervalsSet4.getTree(true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint9 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D7, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet11 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree10);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint12 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint9, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet11);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree13 = euclidean1DBSPTree6.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint12);
        java.lang.Object obj14 = euclidean1DBSPTree6.getAttribute();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint17 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D15, true);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint18 = orientedPoint17.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane19 = subOrientedPoint18.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane20 = subOrientedPoint18.copySelf();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree21 = euclidean1DBSPTree6.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint18);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet22 = intervalsSet2.buildNew(euclidean1DBSPTree21);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree6);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree13);
        org.junit.Assert.assertTrue("'" + obj14 + "' != '" + true + "'", obj14.equals(true));
        org.junit.Assert.assertNotNull(subOrientedPoint18);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane19);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane20);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree21);
        org.junit.Assert.assertNotNull(intervalsSet22);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math3.geometry.partitioning.Side side3 = org.apache.commons.math3.geometry.partitioning.Side.MINUS;
        org.apache.commons.math3.geometry.partitioning.Side side4 = org.apache.commons.math3.geometry.partitioning.Side.PLUS;
        org.apache.commons.math3.geometry.partitioning.Side side5 = org.apache.commons.math3.geometry.partitioning.Side.PLUS;
        org.apache.commons.math3.geometry.partitioning.Side side6 = org.apache.commons.math3.geometry.partitioning.Side.MINUS;
        org.apache.commons.math3.geometry.partitioning.Side[] sideArray7 = new org.apache.commons.math3.geometry.partitioning.Side[] { side3, side4, side5, side6 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection8 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.isMonotonic(sideArray7, orderDirection8, true);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) (-1.5439197382811571d), (int) (short) -1, orderDirection8, true);
        boolean boolean13 = nonMonotonicSequenceException12.getStrict();
        java.lang.Number number14 = nonMonotonicSequenceException12.getPrevious();
        org.junit.Assert.assertTrue("'" + side3 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side3.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertTrue("'" + side4 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side4.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertTrue("'" + side5 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side5.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertTrue("'" + side6 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side6.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(sideArray7);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-1.5439197382811571d) + "'", number14.equals((-1.5439197382811571d)));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D7);
        double double9 = vector3D7.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D12.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D18);
        double double20 = vector3D18.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D16, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Line line22 = plane10.intersection(plane21);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet23 = plane21.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D29.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D32.getZero();
        double double34 = vector3D26.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D26.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D38);
        org.apache.commons.math3.geometry.Space space40 = vector3D39.getSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = vector3D43.scalarMultiply(32.0d);
        double double47 = vector3D46.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = vector3D46.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D41.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D46);
        double double50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D39, vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 100.0f, (double) (-1023));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(7.896296018268069E13d, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.0d, vector3D35, 0.0d, vector3D46, Double.NaN, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane58 = plane21.translate(vector3D46);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
        org.junit.Assert.assertNull(line22);
        org.junit.Assert.assertNotNull(polyhedronsSet23);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 31.0d + "'", double34 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(space40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 3.141592653589793d + "'", double47 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1024.0d + "'", double50 == 1024.0d);
        org.junit.Assert.assertNotNull(plane58);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree3 = intervalsSet1.getTree(true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint6 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D4, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree7 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet8 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree7);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint9 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint6, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet8);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = euclidean1DBSPTree3.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint9);
        java.lang.Object obj11 = euclidean1DBSPTree3.getAttribute();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint14 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D12, true);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint15 = orientedPoint14.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane16 = subOrientedPoint15.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane17 = subOrientedPoint15.copySelf();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree18 = euclidean1DBSPTree3.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double20 = vector1D19.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = vector1D19.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint23 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D21, true);
        try {
            org.apache.commons.math3.geometry.partitioning.Side side24 = subOrientedPoint15.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DBSPTree3);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree10);
        org.junit.Assert.assertTrue("'" + obj11 + "' != '" + true + "'", obj11.equals(true));
        org.junit.Assert.assertNotNull(subOrientedPoint15);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane16);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane17);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree18);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D21);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.scalarMultiply((double) 1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = vector2D4.add(8.87409624E8d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double11 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-1023), 6.283185307179586d);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane15 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D19);
        double[] doubleArray21 = vector2D20.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = vector2D20.scalarMultiply(0.026873352908792118d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = plane15.getPointAt(vector2D20, 35.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = vector2D20.normalize();
        double double27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D0, vector2D20);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10231.640042480607d + "'", double11 == 10231.640042480607d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 103440.68426169187d + "'", double27 == 103440.68426169187d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(Double.NEGATIVE_INFINITY, (double) (-1.58456325E29f));
        double[] doubleArray3 = vector3D2.toArray();
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double1 = vector1D0.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = vector1D0.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double5 = vector1D4.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = vector1D0.add(2.302585092994046d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double8 = vector1D7.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = vector1D6.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = vector1D7.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double13 = vector1D12.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = vector1D12.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double17 = vector1D16.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = vector1D12.add(2.302585092994046d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = vector1D10.add((double) (byte) 0, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertNotNull(vector1D19);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D0, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree3 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet4 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree3);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint5 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint2, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet4);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet6 = orientedPoint2.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree7 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet8 = intervalsSet6.buildNew(euclidean1DBSPTree7);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList9 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet10 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList9);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree12 = intervalsSet10.getTree(true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D13, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree16 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet17 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree16);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint18 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet17);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree19 = euclidean1DBSPTree12.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint18);
        java.lang.Class<?> wildcardClass20 = euclidean1DBSPTree19.getClass();
        euclidean1DBSPTree7.insertInTree(euclidean1DBSPTree19, true);
        org.apache.commons.math3.geometry.partitioning.BSPTreeVisitor<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTreeVisitor23 = null;
        try {
            euclidean1DBSPTree7.visit(euclidean1DBSPTreeVisitor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intervalsSet6);
        org.junit.Assert.assertNotNull(intervalsSet8);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree12);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D7);
        double double9 = vector3D7.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = plane10.getU();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList12 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet13 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList12);
        boolean boolean14 = polygonsSet13.isEmpty();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList15 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet16 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList15);
        boolean boolean17 = polygonsSet16.isEmpty();
        boolean boolean18 = polygonsSet13.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D22);
        boolean boolean24 = vector2D23.isNaN();
        double double25 = vector2D23.getNormSq();
        double double26 = vector2D23.getNormSq();
        org.apache.commons.math3.geometry.partitioning.Region.Location location27 = polygonsSet16.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane28 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane10, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet16);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion29 = subPlane28.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DHyperplane30 = subPlane28.getHyperplane();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList31 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet32 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList31);
        boolean boolean33 = polygonsSet32.isEmpty();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList34 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet35 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList34);
        boolean boolean36 = polygonsSet35.isEmpty();
        boolean boolean37 = polygonsSet32.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet35);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane38 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane(euclidean3DHyperplane30, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet32);
        boolean boolean39 = subPlane38.isEmpty();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0707708022017187E10d + "'", double25 == 1.0707708022017187E10d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0707708022017187E10d + "'", double26 == 1.0707708022017187E10d);
        org.junit.Assert.assertTrue("'" + location27 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location27.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(euclidean2DRegion29);
        org.junit.Assert.assertNotNull(euclidean3DHyperplane30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getNorm1();
        double[] doubleArray4 = new double[] { 1.0d, 100.4987562112089d };
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray4);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D6, line7);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D3.scalarMultiply(32.0d);
        double double7 = vector3D6.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D6.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D1.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D6);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D13.scalarMultiply(32.0d);
        double double17 = vector3D16.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D16.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D11.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2.99822295029797d, vector3D9, 31.0d, vector3D19);
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D20.orthogonal();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.141592653589793d + "'", double7 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.141592653589793d + "'", double17 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math3.util.FastMath.asin(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D5);
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        double[] doubleArray13 = new double[] { Double.NaN, 100L, 100.4987562112089d, (byte) 100, 1.0f };
        double[] doubleArray19 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray25 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray31 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray37 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray43 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[] doubleArray49 = new double[] { 32.0d, (short) 10, (byte) 10, (-1023), '4' };
        double[][] doubleArray50 = new double[][] { doubleArray19, doubleArray25, doubleArray31, doubleArray37, doubleArray43, doubleArray49 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray13, doubleArray50);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException52 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable7, (java.lang.Object[]) doubleArray50);
        boolean boolean53 = vector2D5.equals((java.lang.Object) localizable7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D58);
        boolean boolean60 = vector2D59.isNaN();
        double double61 = vector2D59.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D66);
        double[] doubleArray68 = vector2D67.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D5, 35.0d, vector2D59, (double) (short) 0, vector2D67);
        double double70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D0, vector2D67);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D74);
        boolean boolean76 = vector2D75.isNaN();
        double double77 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D67, vector2D75);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = vector2D75.normalize();
        double[] doubleArray81 = new double[] { 1.0d, 100.4987562112089d };
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray81);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D83 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray81);
        double double84 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D78, vector2D83);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.0707708022017187E10d + "'", double61 == 1.0707708022017187E10d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 101.4983950574446d + "'", double84 == 101.4983950574446d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D7);
        double double9 = vector3D7.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D12.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D18);
        double double20 = vector3D18.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D16, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Line line22 = plane10.intersection(plane21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D25.scalarMultiply(32.0d);
        double double29 = vector3D28.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D28.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D23.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D34.scalarMultiply(32.0d);
        double double38 = vector3D37.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D37.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D32.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        double double41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D28, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = vector3D43.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D46.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D32, vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D51.scalarMultiply(32.0d);
        double double55 = vector3D54.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = vector3D54.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = vector3D49.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D60);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = vector3D60.scalarMultiply(32.0d);
        double double64 = vector3D63.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = vector3D63.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = vector3D58.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D63);
        double double67 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D54, vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D69);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = vector3D69.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = vector3D72.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D58, vector3D72);
        double double75 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D46, vector3D74);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane76 = plane10.translate(vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D78);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = vector3D78.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = vector3D81.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D84 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D85 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D84);
        double double86 = vector3D84.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane87 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D82, vector3D84);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D88 = plane87.getU();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet89 = plane87.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Line line90 = plane10.intersection(plane87);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
        org.junit.Assert.assertNull(line22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.141592653589793d + "'", double29 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.141592653589793d + "'", double38 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 31.0d + "'", double41 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 3.141592653589793d + "'", double55 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 3.141592653589793d + "'", double64 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 31.0d + "'", double67 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1024.0d + "'", double75 == 1024.0d);
        org.junit.Assert.assertNotNull(plane76);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNotNull(vector3D81);
        org.junit.Assert.assertNotNull(vector3D82);
        org.junit.Assert.assertNotNull(vector3D84);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + (-1.0d) + "'", double86 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D88);
        org.junit.Assert.assertNotNull(polyhedronsSet89);
        org.junit.Assert.assertNull(line90);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree3 = intervalsSet1.getTree(true);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector4 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree5 = euclidean1DBSPTree3.getCell(euclidean1DVector4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = euclidean1DBSPTree3.getParent();
        try {
            org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSubHyperplane7 = euclidean1DBSPTree6.getCut();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DBSPTree3);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree5);
        org.junit.Assert.assertNull(euclidean1DBSPTree6);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-1023), 6.283185307179586d);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D8);
        double[] doubleArray10 = vector2D9.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D9.scalarMultiply(0.026873352908792118d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = plane4.getPointAt(vector2D9, 35.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D18.scalarMultiply(32.0d);
        double double22 = vector3D21.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D21.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D16.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D28.scalarMultiply(32.0d);
        double double32 = vector3D31.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D31.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D26.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D31);
        double double35 = vector3D31.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D24.add(5.298342365610589d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = vector3D41.scalarMultiply(32.0d);
        double double45 = vector3D44.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = vector3D44.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D39.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D51.scalarMultiply(32.0d);
        double double55 = vector3D54.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = vector3D54.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = vector3D49.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2.99822295029797d, vector3D47, 31.0d, vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = vector3D59.scalarMultiply((-0.5872139151569291d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = vector3D58.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D65);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = vector3D68.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = vector3D71.getZero();
        double double73 = vector3D65.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D71);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = vector3D65.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D77);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D80);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = vector3D80.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D84 = vector3D83.getZero();
        double double85 = vector3D77.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D83);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D86 = vector3D65.subtract((double) 32, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D77);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(103.83332020743448d, vector3D14, 1089.0d, vector3D24, (double) 7.629395E-6f, vector3D61, (double) 32, vector3D77);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.141592653589793d + "'", double22 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.141592653589793d + "'", double32 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 3.141592653589793d + "'", double45 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 3.141592653589793d + "'", double55 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 31.0d + "'", double73 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector3D80);
        org.junit.Assert.assertNotNull(vector3D83);
        org.junit.Assert.assertNotNull(vector3D84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 31.0d + "'", double85 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D86);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D2.scalarMultiply(32.0d);
        double double6 = vector3D5.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D0.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D11.scalarMultiply(32.0d);
        double double15 = vector3D14.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D14.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D9.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        double double18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D5, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D20.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D23.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D9, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D28.scalarMultiply(32.0d);
        double double32 = vector3D31.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D31.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D26.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D37.scalarMultiply(32.0d);
        double double41 = vector3D40.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D40.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D35.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D40);
        double double44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D31, vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D46.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = vector3D49.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D35, vector3D49);
        double double52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D23, vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = vector3D54.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D57.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D60);
        double double62 = vector3D60.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane63 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D58, vector3D60);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D65);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = vector3D65.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = vector3D68.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D71);
        double double73 = vector3D71.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane74 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D69, vector3D71);
        org.apache.commons.math3.geometry.euclidean.threed.Line line75 = plane63.intersection(plane74);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = plane63.getOrigin();
        double double77 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D23, vector3D76);
        boolean boolean79 = vector3D23.equals((java.lang.Object) 0.02687982482000279d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = vector3D23.orthogonal();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.141592653589793d + "'", double6 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.141592653589793d + "'", double15 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 31.0d + "'", double18 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.141592653589793d + "'", double32 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 3.141592653589793d + "'", double41 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 31.0d + "'", double44 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1024.0d + "'", double52 == 1024.0d);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + (-1.0d) + "'", double62 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + (-1.0d) + "'", double73 == (-1.0d));
        org.junit.Assert.assertNull(line75);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(vector3D80);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double2 = vector3D1.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D9.scalarMultiply(32.0d);
        double double13 = vector3D12.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D12.normalize();
        double double15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D7, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '4', (double) (byte) 1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(52.0d, vector3D12, (double) 100.0f, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D24.scalarMultiply(32.0d);
        double double28 = vector3D27.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D27.normalize();
        boolean boolean30 = vector3D29.isNaN();
        org.apache.commons.math3.geometry.Space space31 = vector3D29.getSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '4', (double) (byte) 1);
        double[] doubleArray36 = vector3D35.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-1023), 6.283185307179586d);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane41 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = vector3D43.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D46.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D49);
        double double51 = vector3D49.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane52 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D47, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = vector3D54.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D57.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D60);
        double double62 = vector3D60.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane63 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D58, vector3D60);
        org.apache.commons.math3.geometry.euclidean.threed.Line line64 = plane52.intersection(plane63);
        double double65 = plane41.getOffset(plane52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = plane52.getU();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2.99822295029797d, vector3D29, (double) (-1.0f), vector3D35, 2.2250738585072014E-308d, vector3D66);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2.0d, vector3D12, (double) (short) 10, vector3D35);
        double double69 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D1, vector3D12);
        double double70 = vector3D1.getZ();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.141592653589793d + "'", double13 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 33.0d + "'", double15 == 33.0d);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.141592653589793d + "'", double28 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(space31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + (-1.0d) + "'", double51 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + (-1.0d) + "'", double62 == (-1.0d));
        org.junit.Assert.assertNull(line64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 31.0d + "'", double69 == 31.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree2 = polyhedronsSet0.getTree(false);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D0, true);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint3 = orientedPoint2.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane4 = subOrientedPoint3.copySelf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform5 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane6 = subOrientedPoint3.applyTransform(euclidean1DTransform5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(subOrientedPoint3);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane4);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math3.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) 0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1023) + "'", int1 == (-1023));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 50.0f, 7.896296018267969E15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 50.00000000000001d + "'", double2 == 50.00000000000001d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList2 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList2);
        boolean boolean4 = polygonsSet3.isEmpty();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList5 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet6 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList5);
        boolean boolean7 = polygonsSet6.isEmpty();
        boolean boolean8 = polygonsSet3.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet6);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList9 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet10 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList9);
        boolean boolean11 = polygonsSet10.isEmpty();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList12 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet13 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList12);
        boolean boolean14 = polygonsSet13.isEmpty();
        boolean boolean15 = polygonsSet10.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet13);
        double double16 = polygonsSet10.getSize();
        boolean boolean17 = polygonsSet6.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet10);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion18 = polygonsSet6.copySelf();
        boolean boolean19 = polygonsSet1.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet6);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion20 = polygonsSet6.copySelf();
        double double21 = euclidean2DAbstractRegion20.getBoundarySize();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double1 = org.apache.commons.math3.util.FastMath.sin(1.3492883949421581d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9755672645293311d + "'", double1 == 0.9755672645293311d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        float float2 = org.apache.commons.math3.util.FastMath.min(9.999999f, (float) 174L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.999999f + "'", float2 == 9.999999f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getNorm1();
        double[] doubleArray4 = new double[] { 1.0d, 100.4987562112089d };
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray4);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D6, line7);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion10 = subLine9.getRemainingRegion();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(euclidean1DRegion10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet2 = polyhedronsSet0.buildNew(euclidean3DBSPTree1);
        org.junit.Assert.assertNotNull(polyhedronsSet2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((double) Float.NaN, 0.0d, Double.NaN, (double) 100.0f);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine13 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D11);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane14 = subLine13.getHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(2.718281828459045d, 101.11503837897544d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1023), vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine23 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D17, vector2D21);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane24 = subLine23.getHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane25 = subLine13.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine23);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane26 = subLine23.copySelf();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSubHyperplane27 = polygonsSet4.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine23);
        double double28 = subLine23.getSize();
        org.junit.Assert.assertNotNull(euclidean2DHyperplane14);
        org.junit.Assert.assertNotNull(euclidean2DHyperplane24);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane25);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane26);
        org.junit.Assert.assertNotNull(euclidean2DSubHyperplane27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double2 = vector3D1.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D7.scalarMultiply(32.0d);
        double double11 = vector3D10.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D10.normalize();
        double double13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D5, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '4', (double) (byte) 1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(52.0d, vector3D10, (double) 100.0f, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D23.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D26.getZero();
        double double28 = vector3D20.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D32.scalarMultiply(32.0d);
        double double36 = vector3D35.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D35.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D30.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = vector3D42.scalarMultiply(32.0d);
        double double46 = vector3D45.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D45.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = vector3D40.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2.99822295029797d, vector3D38, 31.0d, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = vector3D26.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = vector3D10.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D53);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = vector3D53.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = vector3D59.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = vector3D56.add((double) (short) 0, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = vector3D67.scalarMultiply(32.0d);
        double double71 = vector3D70.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = vector3D70.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = vector3D65.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D70);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 10, vector3D70);
        double double75 = vector3D62.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D74);
        plane3.reset(vector3D51, vector3D74);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-1023), 6.283185307179586d);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane80 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D79);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = vector3D74.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D79);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.141592653589793d + "'", double11 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 33.0d + "'", double13 == 33.0d);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 31.0d + "'", double28 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 3.141592653589793d + "'", double36 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 3.141592653589793d + "'", double46 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 3.141592653589793d + "'", double71 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 10240.0d + "'", double75 == 10240.0d);
        org.junit.Assert.assertNotNull(vector3D81);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        boolean boolean2 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray0, doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (byte) 1, (float) (-23), (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math3.util.FastMath.exp(1.774819048E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double1 = vector1D0.getNormInf();
        org.apache.commons.math3.geometry.Space space2 = vector1D0.getSpace();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = vector1D4.negate();
        double double6 = vector1D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(space2);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D5.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D8.getZero();
        double double10 = vector3D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet12 = plane11.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D18.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = vector3D21.getZero();
        double double23 = vector3D15.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D15.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D30.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D33.getZero();
        double double35 = vector3D27.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D15.subtract((double) 32, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = vector3D42.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = vector3D45.getZero();
        double double47 = vector3D39.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = vector3D39.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = vector3D54.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D57.getZero();
        double double59 = vector3D51.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D39.subtract((double) 32, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D63);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = vector3D63.scalarMultiply(32.0d);
        double double67 = vector3D66.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D72);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = vector3D72.scalarMultiply(32.0d);
        double double76 = vector3D75.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D75.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = vector3D70.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D75);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D82);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D85 = vector3D82.scalarMultiply(32.0d);
        double double86 = vector3D85.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = vector3D85.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D88 = vector3D80.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D85);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D89 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2.99822295029797d, vector3D78, 31.0d, vector3D88);
        double double90 = vector3D89.getNormSq();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D91 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 0, vector3D36, 4.61512051684126d, vector3D51, 0.0d, vector3D66, 32.0d, vector3D89);
        boolean boolean92 = plane11.contains(vector3D66);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D93 = plane11.getNormal();
        double double94 = vector3D93.getNorm1();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 31.0d + "'", double10 == 31.0d);
        org.junit.Assert.assertNotNull(polyhedronsSet12);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 31.0d + "'", double23 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 31.0d + "'", double35 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 31.0d + "'", double47 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 31.0d + "'", double59 == 31.0d);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 3.141592653589793d + "'", double67 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertNotNull(vector3D75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 3.141592653589793d + "'", double76 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNotNull(vector3D80);
        org.junit.Assert.assertNotNull(vector3D82);
        org.junit.Assert.assertNotNull(vector3D85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 3.141592653589793d + "'", double86 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D87);
        org.junit.Assert.assertNotNull(vector3D88);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(vector3D93);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 1.0d + "'", double94 == 1.0d);
    }
}

