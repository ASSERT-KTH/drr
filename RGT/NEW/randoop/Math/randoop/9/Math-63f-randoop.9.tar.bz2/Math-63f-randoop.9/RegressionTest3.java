import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray7 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray12);
        double[] doubleArray18 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray31 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray25);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray18);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray41 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray41);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 35)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 105.95753866525968d + "'", double34 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.028838157314254d + "'", double43 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 118.14397995666135d + "'", double44 == 118.14397995666135d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1076494336);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray8 = null;
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray8);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 102.0d, (java.lang.Number) 5729.5779513082325d, 1869155502);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        int[] intArray0 = new int[] {};
        int[] intArray3 = new int[] { 'a', (short) 100 };
        int[] intArray7 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray7);
        int[] intArray11 = new int[] { 'a', (short) 100 };
        int[] intArray15 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray11);
        int[] intArray22 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray22);
        int[] intArray27 = new int[] { 'a', (short) 100 };
        int[] intArray31 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray31);
        int[] intArray35 = new int[] { 'a', (short) 100 };
        int[] intArray39 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray35);
        int[] intArray44 = new int[] { 'a', (short) 100 };
        int[] intArray48 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray48);
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray44);
        int[] intArray53 = new int[] { 'a', (short) 100 };
        int[] intArray57 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray53);
        int[] intArray62 = new int[] { 'a', (short) 100 };
        int[] intArray66 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray66);
        int[] intArray72 = new int[] { (short) 0, 2087196554, (short) 0, '4' };
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray72);
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray27);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1869155502 + "'", int8 == 1869155502);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1869155502 + "'", int16 == 1869155502);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 140.03570973148243d + "'", double23 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1869155502 + "'", int32 == 1869155502);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1869155502 + "'", int40 == 1869155502);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1869155502 + "'", int49 == 1869155502);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1869155502 + "'", int58 == 1869155502);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1869155502 + "'", int67 == 1869155502);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-338615436) + "'", int73 == (-338615436));
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 2.0871964540000021E9d + "'", double74 == 2.0871964540000021E9d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.25737558682330647d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2546155728904494d + "'", double1 == 0.2546155728904494d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray33 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray33);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray42 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double[] doubleArray45 = new double[] {};
        double[] doubleArray50 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray50);
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 97L);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray42, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 105.95753866525968d + "'", double27 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 118.14397995666135d + "'", double35 == 118.14397995666135d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 105.95753866525968d + "'", double36 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 52.028838157314254d + "'", double44 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 52.028838157314254d + "'", double52 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 46.90196078431373d + "'", double55 == 46.90196078431373d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 101.0d + "'", double56 == 101.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 1.3954144401702078d, (int) (byte) -1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-5.283185307179586d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1806627613) + "'", int1 == (-1806627613));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-338615436), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.3861544E8d) + "'", double2 == (-3.3861544E8d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        long long2 = org.apache.commons.math.util.FastMath.max(34393292800L, (-52179912350L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34393292800L + "'", long2 == 34393292800L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 24, (float) (-2087196569));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.08719654E9f) + "'", float2 == (-2.08719654E9f));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, (int) (short) 100, 11);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.3608363030788d + "'", double1 == 156.3608363030788d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.16227766016837933d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16227766016837933d + "'", double1 == 0.16227766016837933d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(8.03350394E8d, 1.1304652476096E15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1304652476095998E15d + "'", double2 == 1.1304652476095998E15d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        double double1 = org.apache.commons.math.util.FastMath.asin((-126.0783456901072d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(800);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 4L, (double) 2083567755L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 15.478204434707898d + "'", double2 == 15.478204434707898d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection6, false);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.1752011936438014d), (java.lang.Number) (short) 1, (int) '#', orderDirection11, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        java.lang.String str15 = nonMonotonousSequenceException13.toString();
        java.lang.Number number16 = nonMonotonousSequenceException13.getArgument();
        java.lang.Class<?> wildcardClass17 = number16.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.37340787437896594d + "'", number9.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not decreasing (1 < -1.175)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not decreasing (1 < -1.175)"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-1.1752011936438014d) + "'", number16.equals((-1.1752011936438014d)));
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-8343109359L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (short) 100);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 0);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (short) 100);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger18);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 0);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 0);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger27);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 823869626L);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger30);
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (long) 0);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, (long) 0);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, bigInteger39);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, 32L);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, bigInteger42);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 43003972865228800L, (java.lang.Number) bigInteger42, 2141433185, orderDirection45, false);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.8691555020000002E9d, 7.198742177054674E287d, 2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1869155405L, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1748581120);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1869155502);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-2000574869), (-24));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double double2 = org.apache.commons.math.util.FastMath.max(0.9913289158005998d, (double) 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 5151787258411483137L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1869155500L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        int int2 = org.apache.commons.math.util.FastMath.min(2087196545, (-2000574848));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2000574848) + "'", int2 == (-2000574848));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (short) -1, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-33L) + "'", long2 == (-33L));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.23879450315858d, (double) (-2087196494L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(6.261589146124386E9d, 0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(9.931324180688272E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 401.07045659157626d + "'", double1 == 401.07045659157626d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-65L), 2, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        double double1 = org.apache.commons.math.util.FastMath.acos(12.566370614359172d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.274444589E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22469287128233573d + "'", double1 == 0.22469287128233573d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        double double1 = org.apache.commons.math.util.MathUtils.sign(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(3.9512437185814275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 26.009615384615387d + "'", double1 == 26.009615384615387d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException12.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Number number16 = nonMonotonousSequenceException5.getPrevious();
        int int17 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number19 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.37340787437896594d + "'", number13.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.8623188722876839d + "'", number14.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.8623188722876839d + "'", number16.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.8623188722876839d + "'", number19.equals(0.8623188722876839d));
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass7 = orderDirection6.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.672431920797983d, (java.lang.Number) 1.5515785828445499d, 2087196555, orderDirection6, false);
        java.lang.Class<?> wildcardClass10 = orderDirection6.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4L, (java.lang.Number) 1.5395564933646284d, 1074790400, orderDirection6, true);
        int int13 = nonMonotonousSequenceException12.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1074790400 + "'", int13 == 1074790400);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.8674043350929254d, 118.14397995666135d, 0.37340787437896594d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        java.lang.Number number3 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection9, false);
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        java.lang.Number number14 = nonMonotonousSequenceException11.getArgument();
        int int15 = nonMonotonousSequenceException11.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection19, false);
        java.lang.Number number22 = nonMonotonousSequenceException21.getArgument();
        java.lang.Number number23 = nonMonotonousSequenceException21.getPrevious();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException21.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) (-7.5722327E18f), (int) (short) 10, orderDirection25, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5607966601082315d, (java.lang.Number) 13.638181696985855d, (int) '4', orderDirection25, false);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.37340787437896594d + "'", number12.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.37340787437896594d + "'", number14.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.37340787437896594d + "'", number22.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.8623188722876839d + "'", number23.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection9, false);
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.1752011936438014d), (java.lang.Number) (short) 1, (int) '#', orderDirection14, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9367122197325302d, (java.lang.Number) (-3L), (int) (byte) 0, orderDirection17, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException19.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.37340787437896594d + "'", number12.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1730796417, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1763.445371201671d + "'", double2 == 1763.445371201671d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-65), (long) 2561);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2626L) + "'", long2 == (-2626L));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        double double1 = org.apache.commons.math.util.FastMath.atanh(156.3608363030788d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray10 = new int[] { 'a', (short) 100 };
        int[] intArray14 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray10);
        int[] intArray19 = new int[] { 'a', (short) 100 };
        int[] intArray23 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray19);
        int[] intArray26 = new int[] {};
        int[] intArray29 = new int[] { 'a', (short) 100 };
        int[] intArray33 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray33);
        int[] intArray37 = new int[] { 'a', (short) 100 };
        int[] intArray41 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray41);
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray37);
        int[] intArray48 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray48);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray48);
        int[] intArray51 = null;
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray51);
        int[] intArray53 = new int[] {};
        int[] intArray56 = new int[] { 'a', (short) 100 };
        int[] intArray60 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray60);
        int[] intArray64 = new int[] { 'a', (short) 100 };
        int[] intArray68 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray64, intArray68);
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray56, intArray64);
        int[] intArray75 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray56, intArray75);
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray75);
        int[] intArray80 = new int[] { 'a', (short) 100 };
        int[] intArray84 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int85 = org.apache.commons.math.util.MathUtils.distance1(intArray80, intArray84);
        int[] intArray88 = new int[] { 'a', (short) 100 };
        int[] intArray92 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray88, intArray92);
        int int94 = org.apache.commons.math.util.MathUtils.distanceInf(intArray80, intArray88);
        int int95 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray80);
        int int96 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray80);
        try {
            int int97 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1869155502 + "'", int15 == 1869155502);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1869155502 + "'", int24 == 1869155502);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1869155502 + "'", int34 == 1869155502);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1869155502 + "'", int42 == 1869155502);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 140.03570973148243d + "'", double49 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1869155502 + "'", int61 == 1869155502);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1869155502 + "'", int69 == 1869155502);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 140.03570973148243d + "'", double76 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1869155502 + "'", int85 == 1869155502);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1869155502 + "'", int93 == 1869155502);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(156.3608363030788d, 0.009997667086565265d, 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1869155500L, 25, (-2083567744));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        double double1 = org.apache.commons.math.util.FastMath.acosh(847.3520979704383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.435263140728928d + "'", double1 == 7.435263140728928d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 0.0d, 5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        long long2 = org.apache.commons.math.util.FastMath.max(6261589707L, 12L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6261589707L + "'", long2 == 6261589707L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        java.lang.Class<?> wildcardClass28 = doubleArray18.getClass();
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (-1074790400));
        double[] doubleArray31 = new double[] {};
        double[] doubleArray36 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray36);
        double[] doubleArray42 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray42);
        double[] doubleArray44 = new double[] {};
        double[] doubleArray49 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray49);
        double[] doubleArray55 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray49);
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double[] doubleArray62 = new double[] { 10.0d, 32.0f, 100.0f };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray62);
        double[] doubleArray65 = null;
        double[] doubleArray66 = new double[] {};
        double[] doubleArray67 = new double[] {};
        double[] doubleArray72 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray72);
        double[] doubleArray77 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double78 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray77);
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray67);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray67);
        try {
            double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray67);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2087196545 + "'", int27 == 2087196545);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 105.95753866525968d + "'", double58 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 3.6262449E10f, (-0.7853981633974483d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(3, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        int int2 = org.apache.commons.math.util.FastMath.max(25, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(2561);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-2087196672), (long) 90);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2087196762L) + "'", long2 == (-2087196762L));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        double double2 = org.apache.commons.math.util.FastMath.min(1.8691555020000002E9d, 10.784313725490195d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.784313725490195d + "'", double2 == 10.784313725490195d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray23 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray23);
        try {
            double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.8691555E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-52179912350L), (-0.9171523356672744d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963268124734d) + "'", double2 == (-1.5707963268124734d));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-1869155405));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1748581108), (float) 4L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.74858112E9f) + "'", float2 == (-1.74858112E9f));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.38535742648327137d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9266641386935751d + "'", double1 == 0.9266641386935751d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 4.644483341943245d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        int int1 = org.apache.commons.math.util.FastMath.abs(2141433185);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2141433185 + "'", int1 == 2141433185);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = new double[] {};
        double[] doubleArray6 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray6);
        double[] doubleArray11 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray1);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray19 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray19);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray26 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray26);
        double[] doubleArray32 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray39 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray39);
        double[] doubleArray45 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray39);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray32);
        double[] doubleArray50 = new double[] {};
        double[] doubleArray55 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray55);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray55);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray61 = new double[] {};
        double[] doubleArray66 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 97L);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 105.95753866525968d + "'", double48 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 52.028838157314254d + "'", double57 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 118.14397995666135d + "'", double58 == 118.14397995666135d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 52.028838157314254d + "'", double68 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        int int2 = org.apache.commons.math.util.MathUtils.pow(197, 1730796417);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-64963899) + "'", int2 == (-64963899));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(2400, (-1594323));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection6, false);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        java.lang.Number number11 = nonMonotonousSequenceException8.getArgument();
        int int12 = nonMonotonousSequenceException8.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection16, false);
        java.lang.Number number19 = nonMonotonousSequenceException18.getArgument();
        java.lang.Number number20 = nonMonotonousSequenceException18.getPrevious();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException18.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-7.5722327E18f), (int) (short) 10, orderDirection22, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection28, false);
        java.lang.Number number31 = nonMonotonousSequenceException30.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection35, false);
        java.lang.Number number38 = nonMonotonousSequenceException37.getArgument();
        java.lang.Number number39 = nonMonotonousSequenceException37.getPrevious();
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException37);
        java.lang.Number number41 = nonMonotonousSequenceException30.getPrevious();
        int int42 = nonMonotonousSequenceException30.getIndex();
        java.lang.Throwable[] throwableArray43 = nonMonotonousSequenceException30.getSuppressed();
        nonMonotonousSequenceException24.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.37340787437896594d + "'", number9.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.37340787437896594d + "'", number11.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.37340787437896594d + "'", number19.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.8623188722876839d + "'", number20.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.37340787437896594d + "'", number31.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 0.37340787437896594d + "'", number38.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 0.8623188722876839d + "'", number39.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 0.8623188722876839d + "'", number41.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(throwableArray43);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        int int1 = org.apache.commons.math.util.MathUtils.sign(59049);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(59049, 7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 68.37734319580831d + "'", double2 == 68.37734319580831d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 1.869155502E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.869155504822953E9d + "'", double2 == 1.869155504822953E9d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.3841857910155797E-7d, (java.lang.Number) 0.5914186782181569d, 2147483647);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass7 = orderDirection6.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.672431920797983d, (java.lang.Number) 1.5515785828445499d, 2087196555, orderDirection6, false);
        java.lang.Class<?> wildcardClass10 = orderDirection6.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.745323795375774d, (java.lang.Number) 0.9367122197325302d, (-1362265433), orderDirection6, true);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 31L, (float) 24L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 24.0f + "'", float2 == 24.0f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Float.POSITIVE_INFINITY, number1, 2000574848);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray10 = new int[] { 'a', (short) 100 };
        int[] intArray14 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray10);
        int[] intArray19 = new int[] { 'a', (short) 100 };
        int[] intArray23 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray19);
        int[] intArray28 = new int[] { 'a', (short) 100 };
        int[] intArray32 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray32);
        int[] intArray36 = new int[] { 'a', (short) 100 };
        int[] intArray40 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray36);
        int[] intArray47 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray28);
        int[] intArray52 = new int[] { 'a', (short) 100 };
        int[] intArray56 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray52, intArray56);
        int[] intArray60 = new int[] { 'a', (short) 100 };
        int[] intArray64 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int65 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray64);
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray60);
        int[] intArray69 = new int[] { 'a', (short) 100 };
        int[] intArray73 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int74 = org.apache.commons.math.util.MathUtils.distance1(intArray69, intArray73);
        int[] intArray78 = new int[] { 10, 10, 'a' };
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray73, intArray78);
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray73);
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray60);
        java.lang.Class<?> wildcardClass82 = intArray60.getClass();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1869155502 + "'", int15 == 1869155502);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1869155502 + "'", int24 == 1869155502);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1869155502 + "'", int33 == 1869155502);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1869155502 + "'", int41 == 1869155502);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 140.03570973148243d + "'", double48 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1869155502 + "'", int57 == 1869155502);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1869155502 + "'", int65 == 1869155502);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1869155502 + "'", int74 == 1869155502);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.8691554150000048E9d + "'", double79 == 1.8691554150000048E9d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 1.869155502E9d + "'", double80 == 1.869155502E9d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass82);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.16227766016837933d, 2.0871964540000021E9d, (double) 709077286L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.8691555020000002E9d, 4.605170185988092d, 197);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-4.440892098500626E-16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-2083567756L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.9977979834822049d), 3.9240765430997624d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9977979834822048d) + "'", double2 == (-0.9977979834822048d));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.09786116982311284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09801804645260047d + "'", double1 == 0.09801804645260047d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 1.3954144401702078d, (int) (byte) -1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(4.672431920797983d, 1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.672431920797983d + "'", double2 == 4.672431920797983d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray13 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 97L);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray17);
        double[] doubleArray19 = new double[] {};
        double[] doubleArray24 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray24);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray31 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray31);
        double[] doubleArray37 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray37);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray44 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray44);
        double[] doubleArray50 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray50);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray44);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray37);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray60 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray60);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray37);
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.028838157314254d + "'", double7 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 52.028838157314254d + "'", double15 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 46.90196078431373d + "'", double18 == 46.90196078431373d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 105.95753866525968d + "'", double53 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 52.028838157314254d + "'", double62 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 118.14397995666135d + "'", double63 == 118.14397995666135d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 101.90196078431373d + "'", double64 == 101.90196078431373d);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-386492543) + "'", int65 == (-386492543));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray12 = new int[] { (short) 0, 2087196554, (short) 0, '4' };
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray12);
        int[] intArray16 = new int[] { 'a', (short) 100 };
        int[] intArray20 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray20);
        int[] intArray24 = new int[] { 'a', (short) 100 };
        int[] intArray28 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray24);
        int[] intArray33 = new int[] { 'a', (short) 100 };
        int[] intArray37 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray33);
        int[] intArray42 = new int[] { 'a', (short) 100 };
        int[] intArray46 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray42);
        try {
            int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-338615436) + "'", int13 == (-338615436));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1869155502 + "'", int21 == 1869155502);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1869155502 + "'", int29 == 1869155502);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1869155502 + "'", int38 == 1869155502);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1869155502 + "'", int47 == 1869155502);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.2124676738864984E29d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.162133867853438d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06525615793505231d + "'", double1 == 0.06525615793505231d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(37413.75877729883d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 652.9932762107926d + "'", double1 == 652.9932762107926d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(2087196555L, (long) (-428686558));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2515883113L + "'", long2 == 2515883113L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1748581120, 1784404547);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-6.4306130247196315E93d), 1.4419647419307422d, 1.7266028267644384d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 310L, 3.4965075614664802d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.4965075614664802d + "'", double2 == 3.4965075614664802d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.672431920797983d, (java.lang.Number) 1.5515785828445499d, 2087196555, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException12.getPrevious();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.String str16 = nonMonotonousSequenceException6.toString();
        boolean boolean17 = nonMonotonousSequenceException6.getStrict();
        java.lang.Number number18 = nonMonotonousSequenceException6.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.37340787437896594d + "'", number13.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.8623188722876839d + "'", number14.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.5515785828445499d + "'", number18.equals(1.5515785828445499d));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5091784786580567d + "'", double1 == 2.5091784786580567d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(22.041899743160855d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8691555019999983E9d + "'", double1 == 1.8691555019999983E9d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1748581106);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-2000574869));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.087196545E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0871965450000002E9d + "'", double1 == 2.0871965450000002E9d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 3628800L, (double) 2400, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.672431920797983d, (java.lang.Number) 1.5515785828445499d, 2087196555, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException12.getPrevious();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.String str16 = nonMonotonousSequenceException6.toString();
        boolean boolean17 = nonMonotonousSequenceException6.getStrict();
        java.lang.String str18 = nonMonotonousSequenceException6.toString();
        int int19 = nonMonotonousSequenceException6.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.37340787437896594d + "'", number13.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.8623188722876839d + "'", number14.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)" + "'", str18.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2087196555 + "'", int19 == 2087196555);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        double double2 = org.apache.commons.math.util.MathUtils.log((-126.0783456901072d), 1.0000000000000002d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray32 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray32);
        double[] doubleArray37 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray37);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray44 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray44);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 52.028838157314254d + "'", double46 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 7.7134543004380856d + "'", double47 == 7.7134543004380856d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2087196545 + "'", int48 == 2087196545);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray33 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray33);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray41 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray41);
        double[] doubleArray46 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray46);
        double[] doubleArray48 = new double[] {};
        double[] doubleArray53 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray53);
        double[] doubleArray57 = new double[] {};
        double[] doubleArray62 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray62);
        double[] doubleArray68 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray68);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) (byte) 10);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray71);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray71);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection80 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass81 = orderDirection80.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException83 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.672431920797983d, (java.lang.Number) 1.5515785828445499d, 2087196555, orderDirection80, false);
        java.lang.Class<?> wildcardClass84 = orderDirection80.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException86 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.745323795375774d, (java.lang.Number) 0.9367122197325302d, (-1362265433), orderDirection80, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray71, orderDirection80, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (-0.196 <= 0.196)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 105.95753866525968d + "'", double27 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 118.14397995666135d + "'", double35 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 52.028838157314254d + "'", double55 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 7.7134543004380856d + "'", double56 == 7.7134543004380856d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + orderDirection80 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection80.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertNotNull(wildcardClass84);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(3L, (-2087196494L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6261589482L + "'", long2 == 6261589482L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-2087196570), 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        int int2 = org.apache.commons.math.util.FastMath.max((-1074790400), (-1806627613));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790400) + "'", int2 == (-1074790400));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 310L, 8.03350394E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.03350394E8d + "'", double2 == 8.03350394E8d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (-1593835520));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 0, (-1274444575));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1274444575 + "'", int2 == 1274444575);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(52, 1784404547);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1784404495) + "'", int2 == (-1784404495));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 118.14397995666135d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str10 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.8623188722876839d + "'", number7.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 0.373)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 0.373)"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-1.1624473515096265d), (-386492543));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.83225147413948E-39d) + "'", double2 == (-6.83225147413948E-39d));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.8691554019999998E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.041899689660756d + "'", double1 == 22.041899689660756d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection6, false);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.1752011936438014d), (java.lang.Number) (short) 1, (int) '#', orderDirection11, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        java.lang.String str15 = nonMonotonousSequenceException13.toString();
        java.lang.Number number16 = nonMonotonousSequenceException13.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException13.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.37340787437896594d + "'", number9.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not decreasing (1 < -1.175)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not decreasing (1 < -1.175)"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-1.1752011936438014d) + "'", number16.equals((-1.1752011936438014d)));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) -1, 1362265433);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm(104359824700L, (long) 2000574848);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 33);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) 100, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-338615436), (-1074790400));
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,074,790,401 and -1,074,790,400 are not strictly increasing (-338,615,436 >= null)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,074,790,401 and -1,074,790,400 are not strictly increasing (-338,615,436 >= null)"));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-386492543), 1274444589L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.45057218356539297d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection6, false);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.1752011936438014d), (java.lang.Number) (short) 1, (int) '#', orderDirection11, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        java.lang.String str15 = nonMonotonousSequenceException13.toString();
        int int16 = nonMonotonousSequenceException13.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.37340787437896594d + "'", number9.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not decreasing (1 < -1.175)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not decreasing (1 < -1.175)"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 35 + "'", int16 == 35);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(25);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (short) 100);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 0);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (short) 100);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger18);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 0);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 0);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger27);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 823869626L);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger30);
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (long) 0);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, (long) 0);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, bigInteger39);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, 32L);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, bigInteger42);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.881784197001252E-16d, (java.lang.Number) bigInteger43, 1748581109);
        try {
            java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, (-2000574869));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 2083567755L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.08356774E9f + "'", float1 == 2.08356774E9f);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1869155405));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1869155405L + "'", long1 == 1869155405L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-43331115536L), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1748581120, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 'a', 35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(25L, (long) 25);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        float float3 = org.apache.commons.math.util.MathUtils.round(2.00057485E9f, (-428686558), 7);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException12.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException5.getDirection();
        java.lang.Class<?> wildcardClass18 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.37340787437896594d + "'", number13.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.8623188722876839d + "'", number14.equals(0.8623188722876839d));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 2087196545L, 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray2 = new double[] {};
        double[] doubleArray7 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray7);
        double[] doubleArray12 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray2);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray21 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray21);
        double[] doubleArray27 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray27);
        double[] doubleArray29 = new double[] {};
        double[] doubleArray34 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray34);
        double[] doubleArray40 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray34);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray48 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray48);
        double[] doubleArray53 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray53);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray60 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray60);
        double[] doubleArray64 = new double[] {};
        double[] doubleArray69 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray64, doubleArray69);
        double[] doubleArray75 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray69, doubleArray75);
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray60, doubleArray75);
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray60);
        double double79 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 52.028838157314254d + "'", double62 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 7.7134543004380856d + "'", double63 == 7.7134543004380856d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 101.0d + "'", double77 == 101.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 101.0d + "'", double78 == 101.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.5515785828445496d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (double) (-6.6790291E12f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-2083567756L), 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.083567756E9d) + "'", double2 == (-2.083567756E9d));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 3.9512437185814275d, 0.19334632705655572d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 100);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger17);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 1869155502, 0, orderDirection26, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger20, (java.lang.Number) 820240826, 984308025, orderDirection26, true);
        int int31 = nonMonotonousSequenceException30.getIndex();
        java.lang.String str32 = nonMonotonousSequenceException30.toString();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 984308025 + "'", int31 == 984308025);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 984,308,024 and 984,308,025 are not strictly increasing (820,240,826 >= 1)" + "'", str32.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 984,308,024 and 984,308,025 are not strictly increasing (820,240,826 >= 1)"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        int int2 = org.apache.commons.math.util.MathUtils.pow(923521, (long) 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1807454463) + "'", int2 == (-1807454463));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1274444576, 923521);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-2087196570L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1806627613));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray10 = new int[] { 'a', (short) 100 };
        int[] intArray14 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray10);
        int[] intArray21 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray21);
        int[] intArray23 = null;
        try {
            int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1869155502 + "'", int15 == 1869155502);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 140.03570973148243d + "'", double22 == 140.03570973148243d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (-8.549647527652399E-18d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray33 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray33);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, 0.017453292519943295d);
        double[] doubleArray43 = new double[] { (-2.0d), 15.104412573075516d, 1L, 10.0d, 6.4509312816254912E16d };
        double[] doubleArray44 = new double[] {};
        double[] doubleArray49 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray49);
        double[] doubleArray55 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray49);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray43);
        double[] doubleArray59 = new double[] {};
        double[] doubleArray64 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        double[] doubleArray67 = new double[] {};
        double[] doubleArray72 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) 97L);
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray76);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray76);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 105.95753866525968d + "'", double27 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 118.14397995666135d + "'", double35 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 59.104412573075514d + "'", double58 == 59.104412573075514d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 52.028838157314254d + "'", double66 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 52.028838157314254d + "'", double74 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 46.90196078431373d + "'", double77 == 46.90196078431373d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.332250528400749d), 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-2087196672), (-3L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3L) + "'", long2 == (-3L));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray10 = new int[] { 'a', (short) 100 };
        int[] intArray14 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray10);
        int[] intArray19 = new int[] { 'a', (short) 100 };
        int[] intArray23 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray23);
        int[] intArray27 = new int[] { 'a', (short) 100 };
        int[] intArray31 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray27);
        int[] intArray38 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray38);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1869155502 + "'", int15 == 1869155502);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1869155502 + "'", int24 == 1869155502);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1869155502 + "'", int32 == 1869155502);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 140.03570973148243d + "'", double39 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 198 + "'", int40 == 198);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5479.9513580933635d, (java.lang.Number) 0L, 7);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 3, (long) (-2083567744));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1074790400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1784404547);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1869155502);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.672431920797983d, (java.lang.Number) 1.5515785828445499d, 2087196555, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException12.getPrevious();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        boolean boolean16 = nonMonotonousSequenceException12.getStrict();
        boolean boolean17 = nonMonotonousSequenceException12.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.37340787437896594d + "'", number13.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.8623188722876839d + "'", number14.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 2087196554);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-1.2194330274671845E142d), (double) 4L, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 3628800L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3628800.0f + "'", float1 == 3628800.0f);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896296018267969E13d + "'", double1 == 7.896296018267969E13d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1869155405L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(2087196554L, 970000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2088166554L + "'", long2 == 2088166554L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        double double1 = org.apache.commons.math.util.FastMath.rint(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 2087196555L, 1.8051424142832329d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Class<?> wildcardClass8 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.8623188722876839d + "'", number7.equals(0.8623188722876839d));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 2147483647);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2147483647L + "'", long1 == 2147483647L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1869155405));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963262598956d) + "'", double1 == (-1.5707963262598956d));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-3L), (float) 24L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 24.0f + "'", float2 == 24.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5707963255811124d, 4.440892098500627E-16d, (-0.6865874069985796d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) 4.944515159673684E42d, (int) (short) -1, orderDirection6, false);
        boolean boolean9 = nonMonotonousSequenceException8.getStrict();
        java.lang.Class<?> wildcardClass10 = nonMonotonousSequenceException8.getClass();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException8.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9367122197325302d, (java.lang.Number) (-3.8412897345910653E-4d), (-338615436), orderDirection12, true);
        java.lang.Number number15 = nonMonotonousSequenceException14.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-3.8412897345910653E-4d) + "'", number15.equals((-3.8412897345910653E-4d)));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-2000574869), (long) (-2087196570));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 823869626L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (byte) 10);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) 0);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 100);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) 0);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger28);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) (short) 100);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger31);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger16);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 197L);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 2000574869);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-11211.863579677765d), (java.lang.Number) 2000574869, 923521, orderDirection41, false);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger39);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        int int1 = org.apache.commons.math.util.FastMath.abs(2087196554);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2087196554 + "'", int1 == 2087196554);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(52L, 10000000000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 130000000000L + "'", long2 == 130000000000L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) '4', 33);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 1.3954144401702078d, (int) (byte) -1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection7, false);
        java.lang.Number number10 = nonMonotonousSequenceException9.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        java.lang.Number number12 = nonMonotonousSequenceException9.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.37340787437896594d + "'", number10.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.37340787437896594d + "'", number12.equals(0.37340787437896594d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.010194005022110007d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 251639124 + "'", int1 == 251639124);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) 'a', (-1074790400));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1748581106, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1748581107 + "'", int2 == 1748581107);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(197, 1748581109);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-75L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-75.0f) + "'", float2 == (-75.0f));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray12 = new int[] { (short) 0, 2087196554, (short) 0, '4' };
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray12);
        java.lang.Class<?> wildcardClass14 = intArray12.getClass();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-338615436) + "'", int13 == (-338615436));
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-3));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray2 = new double[] {};
        double[] doubleArray7 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray7);
        double[] doubleArray12 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray2);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(984308025, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 984308025 + "'", int2 == 984308025);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.0871964540000021E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.087196454E9d + "'", double1 == 2.087196454E9d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1984111311), 1076494336);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 52, 5151787258411483137L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-10.017874927409903d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17484490153629073d) + "'", double1 == (-0.17484490153629073d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 2087196555);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-428686558), 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray32 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray32);
        double[] doubleArray38 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray38);
        double[] doubleArray40 = new double[] {};
        double[] doubleArray45 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray45);
        double[] doubleArray51 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray60 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray38);
        java.lang.Class<?> wildcardClass64 = doubleArray38.getClass();
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 10L);
        double[] doubleArray67 = null;
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray66, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 105.95753866525968d + "'", double54 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 118.14397995666135d + "'", double62 == 118.14397995666135d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 7.848706567797013d + "'", double69 == 7.848706567797013d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 13L, (double) 24299020226L, 6.659487362394655d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        long long2 = org.apache.commons.math.util.FastMath.max((-44605560125L), 2515883113L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2515883113L + "'", long2 == 2515883113L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.5840734641020688d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5840734641020688d + "'", double2 == 0.5840734641020688d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 13);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 90, 1869155500L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16822399500L + "'", long2 == 16822399500L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0986122886681098d + "'", double1 == 1.0986122886681098d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 100, 2400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 35L, (-6.83225147413948E-39d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-3.3861544E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-6.6790291E12f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 10, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1784404547, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1784404547L + "'", long2 == 1784404547L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 1, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2000574869), 923521);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2039161963 + "'", int2 == 2039161963);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException12.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Number number16 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number17 = nonMonotonousSequenceException5.getArgument();
        boolean boolean18 = nonMonotonousSequenceException5.getStrict();
        boolean boolean19 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.37340787437896594d + "'", number13.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.8623188722876839d + "'", number14.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.8623188722876839d + "'", number16.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.37340787437896594d + "'", number17.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 0, (long) 101);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        double[] doubleArray5 = new double[] { (-2.0d), 15.104412573075516d, 1L, 10.0d, 6.4509312816254912E16d };
        double[] doubleArray6 = new double[] {};
        double[] doubleArray11 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray11);
        double[] doubleArray17 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray32 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray32);
        double[] doubleArray38 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray38);
        double[] doubleArray40 = new double[] {};
        double[] doubleArray45 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray45);
        double[] doubleArray51 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray38);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray25);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 100.00000000000001d);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        double[] doubleArray60 = new double[] {};
        double[] doubleArray65 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray65);
        double[] doubleArray71 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray71);
        double[] doubleArray73 = new double[] {};
        double[] doubleArray78 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray73, doubleArray78);
        double[] doubleArray84 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray78, doubleArray84);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray78);
        int int87 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        java.lang.Class<?> wildcardClass88 = doubleArray78.getClass();
        double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 105.95753866525968d + "'", double54 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 102.01732972022405d + "'", double59 == 102.01732972022405d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 2087196545 + "'", int87 == 2087196545);
        org.junit.Assert.assertNotNull(wildcardClass88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 52.84313725490198d + "'", double89 == 52.84313725490198d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 10000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10000.0d + "'", double1 == 10000.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray6 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray6);
        double[] doubleArray12 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray19 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray19);
        double[] doubleArray25 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray33 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray33);
        double[] doubleArray39 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray39);
        double[] doubleArray41 = new double[] {};
        double[] doubleArray46 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray46);
        double[] doubleArray52 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray52);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray46);
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double[] doubleArray56 = new double[] {};
        double[] doubleArray61 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray61);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray61);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray39);
        java.lang.Class<?> wildcardClass65 = doubleArray39.getClass();
        double[] doubleArray66 = new double[] {};
        double[] doubleArray71 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray71);
        double[] doubleArray77 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray71, doubleArray77);
        double[] doubleArray79 = new double[] {};
        double[] doubleArray84 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray79, doubleArray84);
        double[] doubleArray90 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray84, doubleArray90);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray77, doubleArray84);
        int int93 = org.apache.commons.math.util.MathUtils.hash(doubleArray84);
        java.lang.Class<?> wildcardClass94 = doubleArray84.getClass();
        double[] doubleArray96 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray84, (double) (-1074790400));
        double double97 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray84);
        try {
            double double98 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 105.95753866525968d + "'", double55 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 118.14397995666135d + "'", double63 == 118.14397995666135d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 2087196545 + "'", int93 == 2087196545);
        org.junit.Assert.assertNotNull(wildcardClass94);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 186.0d + "'", double97 == 186.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, (-1784404495));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(22.152234817017657d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.15223481701766d + "'", double1 == 22.15223481701766d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 6400L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.457200456011224d + "'", double1 == 9.457200456011224d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection6, false);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.1752011936438014d), (java.lang.Number) (short) 1, (int) '#', orderDirection11, false);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) 0);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 100);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) 0);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger28);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) (short) 100);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger31);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger35 = null;
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, (long) 0);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 0);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger40);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 823869626L);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, 0);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger43);
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) 0);
        java.math.BigInteger bigInteger50 = null;
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, (long) 0);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, bigInteger52);
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, 32L);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger55);
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, (long) 'a');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection67 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException69 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection67, false);
        java.lang.Number number70 = nonMonotonousSequenceException69.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection71 = nonMonotonousSequenceException69.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection72 = nonMonotonousSequenceException69.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException74 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.1752011936438014d), (java.lang.Number) (short) 1, (int) '#', orderDirection72, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException76 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger56, (java.lang.Number) 13L, (int) ' ', orderDirection72, false);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException76);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.37340787437896594d + "'", number9.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertTrue("'" + orderDirection67 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection67.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 0.37340787437896594d + "'", number70.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection71 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection71.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection72 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection72.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 100);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 100);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 0);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger23);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (short) 100);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger26);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) 0);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (long) 0);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger35);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 823869626L);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 0);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger38);
        java.math.BigInteger bigInteger42 = null;
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, (long) 0);
        java.math.BigInteger bigInteger45 = null;
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, (long) 0);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, bigInteger47);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, 32L);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, bigInteger50);
        java.math.BigInteger bigInteger52 = null;
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, (long) 0);
        java.math.BigInteger bigInteger55 = null;
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, (long) 0);
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, bigInteger57);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, bigInteger57);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger57);
        java.math.BigInteger bigInteger61 = null;
        java.math.BigInteger bigInteger63 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, (long) 0);
        java.math.BigInteger bigInteger64 = null;
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, (long) 0);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, bigInteger66);
        java.math.BigInteger bigInteger69 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, 32L);
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger63);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger69);
        org.junit.Assert.assertNotNull(bigInteger70);
    }
}

