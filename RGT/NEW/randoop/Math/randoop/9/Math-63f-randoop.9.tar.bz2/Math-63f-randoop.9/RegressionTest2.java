import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (short) 100, (-2087196569));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 3200L, 3628800, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-44605560125L), 36262448205L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8343111920L) + "'", long2 == (-8343111920L));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1869155405);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-2087196569), 1748581109);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double1 = org.apache.commons.math.util.FastMath.log10(6283429.007424238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.798196712620038d + "'", double1 == 6.798196712620038d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 52L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-2087196570), 97);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1274444576);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1274444576L + "'", long1 == 1274444576L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double2 = org.apache.commons.math.util.FastMath.min(1.1102230246251565E-16d, 0.9996159447946292d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1102230246251565E-16d + "'", double2 == 1.1102230246251565E-16d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(2087196545, (-2087196570));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(25);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 58.003605222980525d + "'", double1 == 58.003605222980525d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 2087196545);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.152234817017657d + "'", double1 == 22.152234817017657d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.748581109E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7811460950722924d) + "'", double1 == (-0.7811460950722924d));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 10, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10000000000L + "'", long2 == 10000000000L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.065817517094494E67d + "'", double1 == 8.065817517094494E67d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-3L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4422495703074083d) + "'", double1 == (-1.4422495703074083d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        int int1 = org.apache.commons.math.util.FastMath.abs((-2000574869));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000574869 + "'", int1 == 2000574869);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1869155502);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.8623188722876839d + "'", number7.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.37340787437896594d + "'", number10.equals(0.37340787437896594d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.5707936587522522d, 4.571025784632303d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.33099894188447926d + "'", double2 == 0.33099894188447926d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 2561, (-8343111920L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8343109359L) + "'", long2 == (-8343109359L));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 13, 1274444576L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1274444589L + "'", long2 == 1274444589L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.8691555020000002E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.313275103116924d) + "'", double1 == (-0.313275103116924d));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 1);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 197L);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(349.9541180407703d, 4.672431920797983d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray32 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray32);
        double[] doubleArray38 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray38);
        double[] doubleArray40 = new double[] {};
        double[] doubleArray45 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray45);
        double[] doubleArray51 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray60 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray38);
        java.lang.Class<?> wildcardClass64 = doubleArray38.getClass();
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 0.0d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection76 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException78 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection76, false);
        java.lang.Number number79 = nonMonotonousSequenceException78.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection80 = nonMonotonousSequenceException78.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection81 = nonMonotonousSequenceException78.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException83 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.1752011936438014d), (java.lang.Number) (short) 1, (int) '#', orderDirection81, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection84 = nonMonotonousSequenceException83.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException86 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9367122197325302d, (java.lang.Number) (-3L), (int) (byte) 0, orderDirection84, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection84, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 2 and 3 are not strictly decreasing (-1 <= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 105.95753866525968d + "'", double54 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 118.14397995666135d + "'", double62 == 118.14397995666135d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + orderDirection76 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection76.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number79 + "' != '" + 0.37340787437896594d + "'", number79.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection80 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection80.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection81 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection81.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection84 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection84.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-3));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.8184464592320668d) + "'", double1 == (-1.8184464592320668d));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-97.0f), (java.lang.Number) 0.16564994844358802d, (-97));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray7 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray12);
        double[] doubleArray18 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray31 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray25);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray18);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray41 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray41);
        double[] doubleArray45 = null;
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 105.95753866525968d + "'", double34 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.028838157314254d + "'", double43 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 118.14397995666135d + "'", double44 == 118.14397995666135d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        int int9 = nonMonotonousSequenceException5.getIndex();
        boolean boolean10 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.37340787437896594d + "'", number8.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.869155502E9d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1784404547 + "'", int1 == 1784404547);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 52, (long) 24);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(8.238696325112256E8d, 186.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 185.2123739719391d + "'", double2 == 185.2123739719391d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3628800);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3628800 + "'", int1 == 3628800);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 5151787258411483137L, (float) (-2000574848));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.00057485E9f) + "'", float2 == (-2.00057485E9f));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 35)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.8691555020000002E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 1, (long) 25);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25L + "'", long2 == 25L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 2561);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 50.60632371551998d + "'", double1 == 50.60632371551998d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double1 = org.apache.commons.math.util.FastMath.sin(186.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6020239375552833d) + "'", double1 == (-0.6020239375552833d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1074790400), (int) (byte) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 0L, (-2000574848));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1, 1748581109);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1748581108) + "'", int2 == (-1748581108));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 2.14748365E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray10 = new int[] { 'a', (short) 100 };
        int[] intArray14 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray10);
        int[] intArray21 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray21);
        int[] intArray23 = null;
        try {
            int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1869155502 + "'", int15 == 1869155502);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 140.03570973148243d + "'", double22 == 140.03570973148243d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double1 = org.apache.commons.math.util.FastMath.cosh(102.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.931324180688272E43d + "'", double1 == 9.931324180688272E43d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1839101630706465969L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-3L), (long) (-1869155405));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1869155402L + "'", long2 == 1869155402L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9036922050915067d) + "'", double1 == (-0.9036922050915067d));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-12.942477465750601d), (java.lang.Number) (-2087196494L), (int) '4');
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) (byte) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection18, false);
        java.lang.Number number21 = nonMonotonousSequenceException20.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException20.getDirection();
        java.lang.Number number23 = nonMonotonousSequenceException20.getArgument();
        int int24 = nonMonotonousSequenceException20.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection28, false);
        java.lang.Number number31 = nonMonotonousSequenceException30.getArgument();
        java.lang.Number number32 = nonMonotonousSequenceException30.getPrevious();
        nonMonotonousSequenceException20.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = nonMonotonousSequenceException30.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection34, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not decreasing (-1 < 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.37340787437896594d + "'", number21.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.37340787437896594d + "'", number23.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.37340787437896594d + "'", number31.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.8623188722876839d + "'", number32.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) -1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(2087196544, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2087196544 + "'", int2 == 2087196544);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        long long2 = org.apache.commons.math.util.FastMath.min(36262448205L, 984308025L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 984308025L + "'", long2 == 984308025L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        double double2 = org.apache.commons.math.util.FastMath.min(11013.232920103326d, (-1.1718061510556774d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1718061510556774d) + "'", double2 == (-1.1718061510556774d));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(10.0d, 1274444575, (-3));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(2, (-2000574848));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000574850 + "'", int2 == 2000574850);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.830253226062821d, 0.8065495107241175d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3142990116903395d + "'", double2 == 2.3142990116903395d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.147483648E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1290.1591550923501d + "'", double1 == 1290.1591550923501d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) Float.NaN);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 2561, 1.7688979526489026E30d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7688979526489026E30d + "'", double2 == 1.7688979526489026E30d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 12L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException12.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number17 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.37340787437896594d + "'", number13.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.8623188722876839d + "'", number14.equals(0.8623188722876839d));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.37340787437896594d + "'", number17.equals(0.37340787437896594d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 13, 1869155402L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24299020226L + "'", long2 == 24299020226L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.09786116982311284d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1130465247609600L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { 'a', (short) 100 };
        int[] intArray7 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray7);
        int[] intArray13 = new int[] { (short) 0, 2087196554, (short) 0, '4' };
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray13);
        try {
            int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1869155502 + "'", int8 == 1869155502);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-338615436) + "'", int14 == (-338615436));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double double1 = org.apache.commons.math.util.FastMath.floor(4.644483341943245d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 11, (double) 10L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        int int9 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection13, false);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        java.lang.Number number17 = nonMonotonousSequenceException15.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException15.getDirection();
        int int20 = nonMonotonousSequenceException15.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.37340787437896594d + "'", number8.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.37340787437896594d + "'", number16.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.8623188722876839d + "'", number17.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 31L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(13.0d, 0.0d, 0.5914186782181569d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1784404547);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-338615436), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 13, Double.NEGATIVE_INFINITY, 2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 803350394);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.03350394E8d + "'", double1 == 8.03350394E8d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) 4.944515159673684E42d, (int) (short) -1, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Class<?> wildcardClass7 = nonMonotonousSequenceException5.getClass();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 2.2250738585072014E-308d + "'", number8.equals(2.2250738585072014E-308d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.5906394885523198d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8051424142832329d + "'", double1 == 1.8051424142832329d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1076494336, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07649434E9f + "'", float2 == 1.07649434E9f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.3450413794473462d), 0.38535742648327137d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-8343109359L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1869155402L, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8691554019999998E9d + "'", double2 == 1.8691554019999998E9d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(100.53096491487338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.285668943044037E43d + "'", double1 == 2.285668943044037E43d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(605.1328448262083d, (-1869155405));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.198742177054674E287d + "'", double2 == 7.198742177054674E287d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) (-2.08719667E9f), 1076494336);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-3L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.049787068367863944d + "'", double1 == 0.049787068367863944d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.9036922050915067d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-10.017874927409903d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-11211.863579677765d) + "'", double1 == (-11211.863579677765d));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray33 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray33);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, 0.017453292519943295d);
        double[] doubleArray43 = new double[] { (-2.0d), 15.104412573075516d, 1L, 10.0d, 6.4509312816254912E16d };
        double[] doubleArray44 = new double[] {};
        double[] doubleArray49 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray49);
        double[] doubleArray55 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray49);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray43);
        double[] doubleArray59 = new double[] {};
        double[] doubleArray64 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray64);
        double[] doubleArray70 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray64, doubleArray70);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray64);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 105.95753866525968d + "'", double27 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 118.14397995666135d + "'", double35 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 59.104412573075514d + "'", double58 == 59.104412573075514d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2087196545 + "'", int72 == 2087196545);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1362265472);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1108.5465032429279d + "'", double1 == 1108.5465032429279d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double1 = org.apache.commons.math.util.FastMath.ulp(101.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-2.08719667E9f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 310L, 984308025);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray10 = new int[] { 'a', (short) 100 };
        int[] intArray14 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray10);
        int[] intArray19 = new int[] { 'a', (short) 100 };
        int[] intArray23 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray19);
        int[] intArray26 = new int[] {};
        int[] intArray29 = new int[] { 'a', (short) 100 };
        int[] intArray33 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray33);
        int[] intArray37 = new int[] { 'a', (short) 100 };
        int[] intArray41 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray41);
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray37);
        int[] intArray48 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray48);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray48);
        int[] intArray53 = new int[] { 'a', (short) 100 };
        int[] intArray57 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray57);
        int[] intArray61 = new int[] { 'a', (short) 100 };
        int[] intArray65 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray65);
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray61);
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray53);
        try {
            int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1869155502 + "'", int15 == 1869155502);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1869155502 + "'", int24 == 1869155502);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1869155502 + "'", int34 == 1869155502);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1869155502 + "'", int42 == 1869155502);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 140.03570973148243d + "'", double49 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1869155502 + "'", int58 == 1869155502);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1869155502 + "'", int66 == 1869155502);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) '4', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) 97L);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) (byte) 10);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray17 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray17);
        double[] doubleArray19 = new double[] {};
        double[] doubleArray24 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray24);
        double[] doubleArray30 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray30);
        double[] doubleArray32 = new double[] {};
        double[] doubleArray37 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray37);
        double[] doubleArray43 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray37);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray30);
        double[] doubleArray48 = new double[] {};
        double[] doubleArray53 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double double56 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray53);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) 0L);
        double[] doubleArray65 = new double[] { 8.238696325112256E8d, 2.087196554E9d, 3628800L, (-0.7853981633974483d), 0L, 1362265433 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(doubleArray58, doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.028838157314254d + "'", double7 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 105.95753866525968d + "'", double46 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 52.028838157314254d + "'", double55 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 118.14397995666135d + "'", double56 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 2.24391706499886E9d + "'", double66 == 2.24391706499886E9d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.784313725490195d + "'", double67 == 10.784313725490195d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 100);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger17);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 0);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) 0);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 823869626L);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger29);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (long) 0);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) 0);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, bigInteger38);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, 32L);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger41);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, (long) 'a');
        java.math.BigInteger bigInteger45 = null;
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, (long) 0);
        java.math.BigInteger bigInteger48 = null;
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, (long) 0);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, bigInteger50);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) (short) 100);
        java.math.BigInteger bigInteger54 = null;
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, (long) 0);
        java.math.BigInteger bigInteger57 = null;
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger57, (long) 0);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, bigInteger59);
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, (long) (short) 100);
        java.math.BigInteger bigInteger63 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, bigInteger62);
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, 0L);
        java.math.BigInteger bigInteger66 = null;
        java.math.BigInteger bigInteger68 = org.apache.commons.math.util.MathUtils.pow(bigInteger66, (long) 0);
        java.math.BigInteger bigInteger69 = null;
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger69, (long) 0);
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger68, bigInteger71);
        java.math.BigInteger bigInteger74 = org.apache.commons.math.util.MathUtils.pow(bigInteger68, 823869626L);
        java.math.BigInteger bigInteger76 = org.apache.commons.math.util.MathUtils.pow(bigInteger74, 0);
        java.math.BigInteger bigInteger77 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, bigInteger74);
        java.math.BigInteger bigInteger78 = null;
        java.math.BigInteger bigInteger80 = org.apache.commons.math.util.MathUtils.pow(bigInteger78, (long) 0);
        java.math.BigInteger bigInteger81 = null;
        java.math.BigInteger bigInteger83 = org.apache.commons.math.util.MathUtils.pow(bigInteger81, (long) 0);
        java.math.BigInteger bigInteger84 = org.apache.commons.math.util.MathUtils.pow(bigInteger80, bigInteger83);
        java.math.BigInteger bigInteger86 = org.apache.commons.math.util.MathUtils.pow(bigInteger84, 32L);
        java.math.BigInteger bigInteger87 = org.apache.commons.math.util.MathUtils.pow(bigInteger74, bigInteger86);
        java.math.BigInteger bigInteger88 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, bigInteger86);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger63);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger68);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigInteger74);
        org.junit.Assert.assertNotNull(bigInteger76);
        org.junit.Assert.assertNotNull(bigInteger77);
        org.junit.Assert.assertNotNull(bigInteger80);
        org.junit.Assert.assertNotNull(bigInteger83);
        org.junit.Assert.assertNotNull(bigInteger84);
        org.junit.Assert.assertNotNull(bigInteger86);
        org.junit.Assert.assertNotNull(bigInteger87);
        org.junit.Assert.assertNotNull(bigInteger88);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-2000574869), (-2087196570));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        int int2 = org.apache.commons.math.util.MathUtils.pow(52, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray6 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray6);
        double[] doubleArray12 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray19 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray19);
        double[] doubleArray25 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        java.lang.Class<?> wildcardClass29 = doubleArray19.getClass();
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1074790400));
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2087196545 + "'", int28 == 2087196545);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5395564933646284d + "'", double1 == 1.5395564933646284d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        float float2 = org.apache.commons.math.util.FastMath.max(2.14748365E9f, (float) (-1869155405));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.86915546E9f) + "'", float2 == (-1.86915546E9f));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 97, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.748581109E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        float float2 = org.apache.commons.math.util.MathUtils.round((-7.5722327E18f), 2147483647);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2147483647, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1362265433), 52L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2141433185 + "'", int2 == 2141433185);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.9512437185814275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.00000000000001d + "'", double1 == 52.00000000000001d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        float float2 = org.apache.commons.math.util.FastMath.max(32.0f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 3200L, 2.384185791015625E-7d, 13);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        int int2 = org.apache.commons.math.util.MathUtils.pow(24, 2000574869);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(2, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1362265433));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1748581106, 12L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1748581106L + "'", long2 == 1748581106L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) 'a', (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3104 + "'", int2 == 3104);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1074790400, (long) 2000574850);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43003972865228800L + "'", long2 == 43003972865228800L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) Float.POSITIVE_INFINITY, (double) (-2000574869));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 2000574869, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.00057485E9f + "'", float2 == 2.00057485E9f);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray10 = new int[] { 'a', (short) 100 };
        int[] intArray14 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray10);
        int[] intArray19 = new int[] { 'a', (short) 100 };
        int[] intArray23 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray23);
        int[] intArray27 = new int[] { 'a', (short) 100 };
        int[] intArray31 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray27);
        int[] intArray36 = new int[] { 'a', (short) 100 };
        int[] intArray40 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray40);
        int[] intArray45 = new int[] { 10, 10, 'a' };
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray40);
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray27);
        int[] intArray49 = null;
        try {
            int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1869155502 + "'", int15 == 1869155502);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1869155502 + "'", int24 == 1869155502);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1869155502 + "'", int32 == 1869155502);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1869155502 + "'", int41 == 1869155502);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.8691554150000048E9d + "'", double46 == 1.8691554150000048E9d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.869155502E9d + "'", double47 == 1.869155502E9d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.644483341943245d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.00000000000001d + "'", double1 == 52.00000000000001d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-2083567756L), (long) 984308025);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2050872462862041900L + "'", long2 == 2050872462862041900L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(2000574850, (-338615436));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(31.30685281944008d, (double) 1869155405, (-2.0d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 3628800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2736239505345667d) + "'", double1 == (-0.2736239505345667d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double1 = org.apache.commons.math.util.FastMath.tanh(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double double1 = org.apache.commons.math.util.FastMath.log(8.03350394E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.504301532899753d + "'", double1 == 20.504301532899753d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        int int2 = org.apache.commons.math.util.FastMath.max(2561, (-2087196570));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2561 + "'", int2 == 2561);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass13 = orderDirection12.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.672431920797983d, (java.lang.Number) 1.5515785828445499d, 2087196555, orderDirection12, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection19, false);
        java.lang.Number number22 = nonMonotonousSequenceException21.getArgument();
        java.lang.Number number23 = nonMonotonousSequenceException21.getPrevious();
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        java.lang.String str25 = nonMonotonousSequenceException15.toString();
        boolean boolean26 = nonMonotonousSequenceException15.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray28 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.37340787437896594d + "'", number8.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.37340787437896594d + "'", number22.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.8623188722876839d + "'", number23.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)" + "'", str25.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        double double1 = org.apache.commons.math.util.FastMath.acosh(6.798196712620038d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.60435069682451d + "'", double1 == 2.60435069682451d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1274444589L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.274444589E9d + "'", double1 == 1.274444589E9d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1076494336, (float) (-2000574848));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.00057485E9f) + "'", float2 == (-2.00057485E9f));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        int int2 = org.apache.commons.math.util.FastMath.max(25, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 3104, (-44605560125L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (int) (short) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(100.0d, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 50.0d + "'", double2 == 50.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 2087196555L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 100);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger17);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) 0);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger24);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 100);
        java.math.BigInteger bigInteger28 = null;
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (long) 0);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, bigInteger33);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) (short) 100);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger36);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0L);
        java.math.BigInteger bigInteger40 = null;
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) 0);
        java.math.BigInteger bigInteger43 = null;
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, (long) 0);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, bigInteger45);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 823869626L);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, 0);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger48);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger51);
        java.math.BigInteger bigInteger53 = null;
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, (long) 0);
        java.math.BigInteger bigInteger56 = null;
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, (long) 0);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, bigInteger58);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, 823869626L);
        java.math.BigInteger bigInteger63 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, 0);
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, (long) (byte) 10);
        java.math.BigInteger bigInteger66 = null;
        java.math.BigInteger bigInteger68 = org.apache.commons.math.util.MathUtils.pow(bigInteger66, (long) 0);
        java.math.BigInteger bigInteger69 = null;
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger69, (long) 0);
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger68, bigInteger71);
        java.math.BigInteger bigInteger74 = org.apache.commons.math.util.MathUtils.pow(bigInteger68, (long) (short) 100);
        java.math.BigInteger bigInteger75 = null;
        java.math.BigInteger bigInteger77 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, (long) 0);
        java.math.BigInteger bigInteger78 = null;
        java.math.BigInteger bigInteger80 = org.apache.commons.math.util.MathUtils.pow(bigInteger78, (long) 0);
        java.math.BigInteger bigInteger81 = org.apache.commons.math.util.MathUtils.pow(bigInteger77, bigInteger80);
        java.math.BigInteger bigInteger83 = org.apache.commons.math.util.MathUtils.pow(bigInteger77, (long) (short) 100);
        java.math.BigInteger bigInteger84 = org.apache.commons.math.util.MathUtils.pow(bigInteger68, bigInteger83);
        java.math.BigInteger bigInteger86 = org.apache.commons.math.util.MathUtils.pow(bigInteger68, 0L);
        java.math.BigInteger bigInteger87 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, bigInteger68);
        java.math.BigInteger bigInteger89 = org.apache.commons.math.util.MathUtils.pow(bigInteger68, 197L);
        java.math.BigInteger bigInteger90 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, bigInteger68);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger63);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger68);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigInteger74);
        org.junit.Assert.assertNotNull(bigInteger77);
        org.junit.Assert.assertNotNull(bigInteger80);
        org.junit.Assert.assertNotNull(bigInteger81);
        org.junit.Assert.assertNotNull(bigInteger83);
        org.junit.Assert.assertNotNull(bigInteger84);
        org.junit.Assert.assertNotNull(bigInteger86);
        org.junit.Assert.assertNotNull(bigInteger87);
        org.junit.Assert.assertNotNull(bigInteger89);
        org.junit.Assert.assertNotNull(bigInteger90);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(59.104412573075514d, (double) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 59049, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 59049.0f + "'", float2 == 59049.0f);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass13 = orderDirection12.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.672431920797983d, (java.lang.Number) 1.5515785828445499d, 2087196555, orderDirection12, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection19, false);
        java.lang.Number number22 = nonMonotonousSequenceException21.getArgument();
        java.lang.Number number23 = nonMonotonousSequenceException21.getPrevious();
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        java.lang.String str25 = nonMonotonousSequenceException15.toString();
        boolean boolean26 = nonMonotonousSequenceException15.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass32 = orderDirection31.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.672431920797983d, (java.lang.Number) 1.5515785828445499d, 2087196555, orderDirection31, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection38, false);
        java.lang.Number number41 = nonMonotonousSequenceException40.getArgument();
        java.lang.Number number42 = nonMonotonousSequenceException40.getPrevious();
        nonMonotonousSequenceException34.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException40);
        java.lang.String str44 = nonMonotonousSequenceException34.toString();
        boolean boolean45 = nonMonotonousSequenceException34.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException34);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.37340787437896594d + "'", number8.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.37340787437896594d + "'", number22.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.8623188722876839d + "'", number23.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)" + "'", str25.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection38.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 0.37340787437896594d + "'", number41.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.8623188722876839d + "'", number42.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)" + "'", str44.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.087196545E9d, 4.9E-324d, 1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        long long2 = org.apache.commons.math.util.MathUtils.pow(3628800L, (long) 1076494336);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10, (float) 2083567755L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.08356774E9f + "'", float2 == 2.08356774E9f);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        int int1 = org.apache.commons.math.util.MathUtils.sign(24);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(2, 2141433185);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double1 = org.apache.commons.math.util.FastMath.exp(847.3520979704383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double double2 = org.apache.commons.math.util.FastMath.min((-2.0d), 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.0d) + "'", double2 == (-2.0d));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection11, false);
        java.lang.Number number14 = nonMonotonousSequenceException13.getArgument();
        java.lang.Number number15 = nonMonotonousSequenceException13.getPrevious();
        int int16 = nonMonotonousSequenceException13.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException13.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection17, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (-1 <= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.028838157314254d + "'", double7 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.37340787437896594d + "'", number14.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0.8623188722876839d + "'", number15.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double double2 = org.apache.commons.math.util.FastMath.pow((-2.0d), 1.3954144401702078d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.6865874069985796d), (-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1869155402L, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.869155402E9d + "'", double2 == 1.869155402E9d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-2.08719667E9f));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2087196672L) + "'", long1 == (-2087196672L));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1274444575, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.3954144401702078d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.643262239596658d + "'", double1 == 5.643262239596658d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 3104, 2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.154434690031884d + "'", double2 == 2.154434690031884d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 24, 34393292800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 825439027200L + "'", long2 == 825439027200L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 0.0f, (double) (short) 10, 1.8691554150000048E9d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-8343109359L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        int int1 = org.apache.commons.math.util.MathUtils.hash(4.096083259363071d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-428686558) + "'", int1 == (-428686558));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 2561);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(3200L, (long) (-2087196569));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6679029020800L) + "'", long2 == (-6679029020800L));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.9977979834822049d), (java.lang.Number) 1274444575, 97);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 10000000000L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1594323));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-8343109359L), (-0.6865874069985796d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-2.08719667E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(800, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.23879450315858d + "'", double1 == 2.23879450315858d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1784404547, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 2087196554L, (-3), 1076494336);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.0000000000000002d, (double) (-3L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.283185307179586d) + "'", double2 == (-5.283185307179586d));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        int int1 = org.apache.commons.math.util.MathUtils.hash(9.931324180688272E43d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-987900782) + "'", int1 == (-987900782));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.1945716924276215d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(9.931324180688272E43d, (-0.6020239375552833d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.7201027852095638d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 186.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 186.0d + "'", double2 == 186.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 10000000000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray7 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray12);
        double[] doubleArray18 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray31 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray25);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray18);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) 0);
        java.math.BigInteger bigInteger39 = null;
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (long) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, bigInteger41);
        java.math.BigInteger bigInteger43 = null;
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, (long) 0);
        java.math.BigInteger bigInteger46 = null;
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (long) 0);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, bigInteger48);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, 823869626L);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, bigInteger45);
        java.lang.Class<?> wildcardClass53 = bigInteger45.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection65 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException67 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection65, false);
        java.lang.Number number68 = nonMonotonousSequenceException67.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection69 = nonMonotonousSequenceException67.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection70 = nonMonotonousSequenceException67.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException72 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.1752011936438014d), (java.lang.Number) (short) 1, (int) '#', orderDirection70, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException74 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 828429417848939265L, (java.lang.Number) 1274444576, 0, orderDirection70, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException76 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger45, (java.lang.Number) 52L, 3, orderDirection70, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection70, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 2 and 3 are not decreasing (-1 < 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 105.95753866525968d + "'", double34 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + orderDirection65 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection65.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + 0.37340787437896594d + "'", number68.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection69 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection69.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection70 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection70.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 2087196555);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.19214393877423605d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1757533153582116d + "'", double1 == 0.1757533153582116d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        double double1 = org.apache.commons.math.util.FastMath.exp((-1.8184464592320668d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16227766016837933d + "'", double1 == 0.16227766016837933d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray12 = new int[] { (short) 0, 2087196554, (short) 0, '4' };
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray12);
        int[] intArray14 = new int[] {};
        int[] intArray17 = new int[] { 'a', (short) 100 };
        int[] intArray21 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray21);
        int[] intArray25 = new int[] { 'a', (short) 100 };
        int[] intArray29 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray29);
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray25);
        int[] intArray36 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray36);
        int[] intArray41 = new int[] { 'a', (short) 100 };
        int[] intArray45 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray45);
        int[] intArray49 = new int[] { 'a', (short) 100 };
        int[] intArray53 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray53);
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray49);
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray41);
        try {
            double double57 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-338615436) + "'", int13 == (-338615436));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1869155502 + "'", int22 == 1869155502);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1869155502 + "'", int30 == 1869155502);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 140.03570973148243d + "'", double37 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1869155502 + "'", int46 == 1869155502);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1869155502 + "'", int54 == 1869155502);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray10 = new int[] { 'a', (short) 100 };
        int[] intArray14 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray10);
        int[] intArray19 = new int[] { 'a', (short) 100 };
        int[] intArray23 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray23);
        int[] intArray28 = new int[] { 10, 10, 'a' };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray23);
        int[] intArray33 = new int[] { 'a', (short) 100 };
        int[] intArray37 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray37);
        int[] intArray41 = new int[] { 'a', (short) 100 };
        int[] intArray45 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray45);
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray33, intArray41);
        int[] intArray50 = new int[] { 'a', (short) 100 };
        int[] intArray54 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray54);
        int[] intArray59 = new int[] { 10, 10, 'a' };
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray54);
        double double62 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray41);
        int[] intArray65 = new int[] { 'a', (short) 100 };
        int[] intArray69 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray69);
        int[] intArray73 = new int[] { 'a', (short) 100 };
        int[] intArray77 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray73, intArray77);
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray65, intArray73);
        int[] intArray82 = new int[] { 'a', (short) 100 };
        int[] intArray86 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray82, intArray86);
        int[] intArray91 = new int[] { 10, 10, 'a' };
        double double92 = org.apache.commons.math.util.MathUtils.distance(intArray86, intArray91);
        double double93 = org.apache.commons.math.util.MathUtils.distance(intArray73, intArray86);
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray73);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1869155502 + "'", int15 == 1869155502);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1869155502 + "'", int24 == 1869155502);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.8691554150000048E9d + "'", double29 == 1.8691554150000048E9d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.869155502E9d + "'", double30 == 1.869155502E9d);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1869155502 + "'", int38 == 1869155502);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1869155502 + "'", int46 == 1869155502);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1869155502 + "'", int55 == 1869155502);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.8691554150000048E9d + "'", double60 == 1.8691554150000048E9d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.869155502E9d + "'", double61 == 1.869155502E9d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1869155502 + "'", int70 == 1869155502);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1869155502 + "'", int78 == 1869155502);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1869155502 + "'", int87 == 1869155502);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 1.8691554150000048E9d + "'", double92 == 1.8691554150000048E9d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 1.869155502E9d + "'", double93 == 1.869155502E9d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1074790400);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(32, 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray10 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray10);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray17 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray17);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray26 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray26);
        double[] doubleArray32 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (byte) 10);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray35);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray42 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray42);
        double[] doubleArray47 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray47);
        double[] doubleArray49 = new double[] {};
        double[] doubleArray54 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray54);
        double[] doubleArray59 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray59);
        double[] doubleArray61 = new double[] {};
        double[] doubleArray66 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray66);
        double[] doubleArray70 = new double[] {};
        double[] doubleArray75 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray70, doubleArray75);
        double[] doubleArray81 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray75, doubleArray81);
        double[] doubleArray84 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) (byte) 10);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray84);
        double double86 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray59);
        try {
            double double87 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray59);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 52.028838157314254d + "'", double19 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 7.7134543004380856d + "'", double20 == 7.7134543004380856d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 52.028838157314254d + "'", double68 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 7.7134543004380856d + "'", double69 == 7.7134543004380856d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1362265433), 820240826);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1984111311) + "'", int2 == (-1984111311));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray31 = new double[] { 10.0d, 32.0f, 100.0f };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 105.95753866525968d + "'", double27 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 105.47037498748168d + "'", double33 == 105.47037498748168d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        double double1 = org.apache.commons.math.util.FastMath.abs((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        float float2 = org.apache.commons.math.util.MathUtils.round(1.07649434E9f, 800);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1074790400, (long) 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.5707963267948966d, (double) 34393292800L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        double double1 = org.apache.commons.math.util.FastMath.floor(8.238696325112256E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.23869632E8d + "'", double1 == 8.23869632E8d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(349.9541180407703d, 0.05235987755982989d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(10, 1748581109);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1748581119 + "'", int2 == 1748581119);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        long long2 = org.apache.commons.math.util.FastMath.max(2L, (long) 1869155405);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1869155405L + "'", long2 == 1869155405L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        int int2 = org.apache.commons.math.util.MathUtils.pow(2141433185, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 1274444576);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.087196544E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.748581109E9d, 1362265433);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.971379520483754E-196d) + "'", double2 == (-6.971379520483754E-196d));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) -1, 25L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int int2 = org.apache.commons.math.util.FastMath.min(10, 820240826);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.7811460950722924d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.2280208110551356d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 2087196545L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.45908763693682d + "'", double1 == 21.45908763693682d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 52, (double) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 197, (float) 33);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 33.0f + "'", float2 == 33.0f);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 24);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24L + "'", long1 == 24L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray10 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray10);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray17 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray17);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray26 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray26);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray33 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray33);
        double[] doubleArray39 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray39);
        double[] doubleArray41 = new double[] {};
        double[] doubleArray46 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray46);
        double[] doubleArray52 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray52);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray46);
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray39);
        double[] doubleArray57 = new double[] {};
        double[] doubleArray62 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray62);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray62);
        double[] doubleArray66 = new double[] {};
        double[] doubleArray67 = new double[] {};
        double[] doubleArray72 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray72);
        double[] doubleArray77 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double78 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray77);
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray67);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray66);
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 52.028838157314254d + "'", double19 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 7.7134543004380856d + "'", double20 == 7.7134543004380856d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 105.95753866525968d + "'", double55 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 52.028838157314254d + "'", double64 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 118.14397995666135d + "'", double65 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 186.0d + "'", double81 == 186.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1869155405, 1.344058570908106E43d, (double) (-7.5722327E18f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        double double1 = org.apache.commons.math.util.FastMath.acosh(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.589582900964765d + "'", double1 == 6.589582900964765d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 59049, 1.9377047211159066E-18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.3755168737479835d) + "'", double2 == (-0.3755168737479835d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.384185791015625E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3841857910155797E-7d + "'", double1 == 2.3841857910155797E-7d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4965075614664802d + "'", double1 == 3.4965075614664802d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray6 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray6);
        double[] doubleArray12 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (byte) 10);
        try {
            double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.049787068367863944d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.049745972512597096d + "'", double1 == 0.049745972512597096d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.610125138662288d + "'", double1 == 7.610125138662288d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double1 = org.apache.commons.math.util.FastMath.acos(6.798196712620038d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 1, 1748581106);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection6, false);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.1752011936438014d), (java.lang.Number) (short) 1, (int) '#', orderDirection11, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        java.lang.String str15 = nonMonotonousSequenceException13.toString();
        java.lang.Number number16 = nonMonotonousSequenceException13.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.37340787437896594d + "'", number9.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not decreasing (1 < -1.175)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not decreasing (1 < -1.175)"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (short) 1 + "'", number16.equals((short) 1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1594323));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1594324.0d) + "'", double1 == (-1594324.0d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        long long2 = org.apache.commons.math.util.MathUtils.pow(43003972865228800L, (long) 820240826);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.37340787437896594d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double3 = org.apache.commons.math.util.MathUtils.round(1.220703125E-4d, 24, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.220703125E-4d + "'", double3 == 1.220703125E-4d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        double double1 = org.apache.commons.math.util.FastMath.ceil(31.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 31.0d + "'", double1 == 31.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-6679029020800L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.25737558682330647d + "'", double1 == 0.25737558682330647d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.2280208110551356d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4144649729962215d + "'", double1 == 2.4144649729962215d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 11, (float) 3200L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3200.0f + "'", float2 == 3200.0f);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 984308025, 24299020226L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray10 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray10);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray17 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray17);
        double[] doubleArray22 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray22);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray29 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray29);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray38 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray38);
        double[] doubleArray44 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray44);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) (byte) 10);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray22);
        double[] doubleArray50 = new double[] {};
        double[] doubleArray55 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray55);
        double[] doubleArray60 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray60);
        double[] doubleArray62 = new double[] {};
        double[] doubleArray67 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray67);
        double[] doubleArray71 = new double[] {};
        double[] doubleArray76 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray76);
        double[] doubleArray82 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray82);
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, (double) (byte) 10);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray85);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray60);
        int int88 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 52.028838157314254d + "'", double31 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 7.7134543004380856d + "'", double32 == 7.7134543004380856d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 52.028838157314254d + "'", double69 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 7.7134543004380856d + "'", double70 == 7.7134543004380856d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 709077286 + "'", int88 == 709077286);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray13 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray13);
        double[] doubleArray19 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray19);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray26 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray26);
        double[] doubleArray32 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray26);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray26);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1L, (-1748581108));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 100);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger17);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) 0);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger24);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 100);
        java.math.BigInteger bigInteger28 = null;
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (long) 0);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, bigInteger33);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) (short) 100);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger36);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0L);
        java.math.BigInteger bigInteger40 = null;
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) 0);
        java.math.BigInteger bigInteger43 = null;
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, (long) 0);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, bigInteger45);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 823869626L);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, 0);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger48);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger51);
        java.math.BigInteger bigInteger53 = null;
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, (long) 0);
        java.math.BigInteger bigInteger56 = null;
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, (long) 0);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, bigInteger58);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, 823869626L);
        java.math.BigInteger bigInteger63 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, 0);
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, (long) (byte) 10);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger63);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger63);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger66);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray7 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray12);
        double[] doubleArray18 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray31 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray25);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray18);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray41 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray41);
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[] doubleArray51 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray51);
        double[] doubleArray56 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray46);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray45);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 105.95753866525968d + "'", double34 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.028838157314254d + "'", double43 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 118.14397995666135d + "'", double44 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 52, (long) 2000574850);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray2 = new double[] {};
        double[] doubleArray7 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray7);
        double[] doubleArray12 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray2);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray21 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray29 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 97L);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray21, doubleArray33);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray40 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray40);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray47 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray47);
        double[] doubleArray53 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray53);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray60 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray60);
        double[] doubleArray66 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray66);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray60);
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray53);
        double[] doubleArray71 = new double[] {};
        double[] doubleArray76 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double double79 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray76);
        double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray53);
        try {
            double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 52.028838157314254d + "'", double23 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 52.028838157314254d + "'", double31 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 46.90196078431373d + "'", double34 == 46.90196078431373d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 105.95753866525968d + "'", double69 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 52.028838157314254d + "'", double78 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 118.14397995666135d + "'", double79 == 118.14397995666135d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 101.90196078431373d + "'", double80 == 101.90196078431373d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        int int2 = org.apache.commons.math.util.MathUtils.pow(10, (long) 24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1593835520) + "'", int2 == (-1593835520));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        double double1 = org.apache.commons.math.util.FastMath.log(3.5976561054698672E16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 38.12164403950706d + "'", double1 == 38.12164403950706d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10L, (float) 825439027200L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.2543903E11f + "'", float2 == 8.2543903E11f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 823869626L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 0);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 823869626L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (byte) 10);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) 0);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger28);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) (short) 100);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) 0);
        java.math.BigInteger bigInteger35 = null;
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, (long) 0);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, bigInteger37);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (long) (short) 100);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger40);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger25);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger20);
        try {
            java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-2083567756L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2083567744) + "'", int1 == (-2083567744));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.2622917741667457E7d, 6.589582900964765d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.243257087183704E49d + "'", double2 == 3.243257087183704E49d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(186.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.638181696985855d + "'", double1 == 13.638181696985855d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-6679029020800L), (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-6.6790291E12f) + "'", float2 == (-6.6790291E12f));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection15, false);
        java.lang.Number number18 = nonMonotonousSequenceException17.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection22, false);
        java.lang.Number number25 = nonMonotonousSequenceException24.getArgument();
        java.lang.Number number26 = nonMonotonousSequenceException24.getPrevious();
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        java.lang.Number number28 = nonMonotonousSequenceException17.getPrevious();
        int int29 = nonMonotonousSequenceException17.getIndex();
        java.lang.Throwable[] throwableArray30 = nonMonotonousSequenceException17.getSuppressed();
        int int31 = nonMonotonousSequenceException17.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        java.lang.Number number33 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.37340787437896594d + "'", number8.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 0.373)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 0.373)"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.37340787437896594d + "'", number10.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.37340787437896594d + "'", number18.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0.37340787437896594d + "'", number25.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.8623188722876839d + "'", number26.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 0.8623188722876839d + "'", number28.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 0.37340787437896594d + "'", number33.equals(0.37340787437896594d));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 2087196555L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6428452021032915E7d + "'", double1 == 3.6428452021032915E7d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(2L, (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8623188722876839d, (java.lang.Number) (byte) 1, (-1984111311));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1362265433), 10.784313725490195d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 2147483647);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2L, 33.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 33.0f + "'", float2 == 33.0f);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        double double1 = org.apache.commons.math.util.FastMath.atan((-4.440892098500626E-16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.440892098500626E-16d) + "'", double1 == (-4.440892098500626E-16d));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(24);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        int int1 = org.apache.commons.math.util.FastMath.abs(803350394);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 803350394 + "'", int1 == 803350394);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 310L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 310L + "'", long1 == 310L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.087196545E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8406875782842027d + "'", double1 == 0.8406875782842027d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.995592469141819E14d + "'", double1 == 2.995592469141819E14d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.8691554019999998E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        int int2 = org.apache.commons.math.util.FastMath.max((int) ' ', 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray13 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 97L);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray17);
        double[] doubleArray19 = new double[] {};
        double[] doubleArray24 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray24);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray31 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray31);
        double[] doubleArray37 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray37);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray44 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray44);
        double[] doubleArray50 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray50);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray44);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray37);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray60 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray60);
        double[] doubleArray64 = null;
        double[] doubleArray65 = new double[] {};
        double[] doubleArray66 = new double[] {};
        double[] doubleArray71 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray71);
        double[] doubleArray76 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray65, doubleArray66);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray64, doubleArray66);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray64);
        double double81 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray37);
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 221206.6960033301d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.028838157314254d + "'", double7 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 52.028838157314254d + "'", double15 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 46.90196078431373d + "'", double18 == 46.90196078431373d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 105.95753866525968d + "'", double53 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 52.028838157314254d + "'", double62 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 118.14397995666135d + "'", double63 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 101.0d + "'", double81 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray83);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.672431920797983d, (java.lang.Number) 1.5515785828445499d, 2087196555, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException12.getPrevious();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException6.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.37340787437896594d + "'", number13.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.8623188722876839d + "'", number14.equals(0.8623188722876839d));
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1074790400), (-1362265433));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-308d + "'", double1 == 2.2250738585072014E-308d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1748581106);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1748581120 + "'", int1 == 1748581120);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(6.283185307179586d, (int) (short) 0, 3628800);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        double double1 = org.apache.commons.math.util.FastMath.acosh(10.784313725490195d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0690832749035044d + "'", double1 == 3.0690832749035044d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.3693300629462564d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.171418320584917d + "'", double1 == 1.171418320584917d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-6679029020800L), (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.880859375d + "'", double2 == 2.880859375d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        int int9 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection13, false);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        java.lang.Number number17 = nonMonotonousSequenceException15.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException5.getSuppressed();
        int int20 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number21 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.37340787437896594d + "'", number8.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.37340787437896594d + "'", number16.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.8623188722876839d + "'", number17.equals(0.8623188722876839d));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.8623188722876839d + "'", number21.equals(0.8623188722876839d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 0, (-75L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-75L) + "'", long2 == (-75L));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray7 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray12);
        double[] doubleArray18 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray31 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray25);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray18);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray41 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray41);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 0L);
        double[] doubleArray53 = new double[] { 8.238696325112256E8d, 2.087196554E9d, 3628800L, (-0.7853981633974483d), 0L, 1362265433 };
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 105.95753866525968d + "'", double34 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.028838157314254d + "'", double43 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 118.14397995666135d + "'", double44 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.24391706499886E9d + "'", double54 == 2.24391706499886E9d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        double double1 = org.apache.commons.math.util.FastMath.asinh(156.3608363030788d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.745323795375774d + "'", double1 == 5.745323795375774d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1274444575), 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1274444575) + "'", int2 == (-1274444575));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray32 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray32);
        double[] doubleArray37 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray37);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray44 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray44);
        double[] doubleArray48 = new double[] {};
        double[] doubleArray53 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray53);
        double[] doubleArray59 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray59);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray44);
        double[] doubleArray63 = new double[] {};
        double[] doubleArray68 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) 97L);
        double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 52.028838157314254d + "'", double46 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 7.7134543004380856d + "'", double47 == 7.7134543004380856d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 101.0d + "'", double61 == 101.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 101.0d + "'", double62 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 52.028838157314254d + "'", double70 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 118.14397995666135d + "'", double73 == 118.14397995666135d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 32L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 25L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number11 = nonMonotonousSequenceException5.getPrevious();
        int int12 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.37340787437896594d + "'", number8.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 0.373)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 0.373)"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.37340787437896594d + "'", number10.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.8623188722876839d + "'", number11.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-2087196569));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        double double1 = org.apache.commons.math.util.FastMath.abs(4.440892098500627E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500627E-16d + "'", double1 == 4.440892098500627E-16d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1, 1074790400);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(3, (int) (short) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 3628800, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3628800L + "'", long2 == 3628800L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.3450413794473462d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.332250528400749d) + "'", double1 == (-0.332250528400749d));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (-97));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1274444589L, (-44605560125L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-43331115536L) + "'", long2 == (-43331115536L));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        long long1 = org.apache.commons.math.util.FastMath.round(1.1752011936438018d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray6 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray6);
        double[] doubleArray12 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray19 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray19);
        double[] doubleArray25 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        java.lang.Class<?> wildcardClass29 = doubleArray19.getClass();
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1074790400));
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2087196545 + "'", int28 == 2087196545);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 100);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger17);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 1869155502, 0, orderDirection26, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger20, (java.lang.Number) 820240826, 984308025, orderDirection26, true);
        java.lang.Throwable[] throwableArray31 = nonMonotonousSequenceException30.getSuppressed();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray31);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.672431920797983d, (java.lang.Number) 1.5515785828445499d, 2087196555, orderDirection3, false);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(11, (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.9367122197325302d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9784426952056535d + "'", double1 == 0.9784426952056535d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        double double1 = org.apache.commons.math.util.FastMath.ulp(13.596393425240077d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.4337144412751482E29d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4337144412751486E29d + "'", double1 == 2.4337144412751486E29d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-97), 197);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 984308025L, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 98.66970252990723d + "'", double2 == 98.66970252990723d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(7.198742177054674E287d, 0, 1748581120);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 1.3954144401702078d, (int) (byte) -1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0L + "'", number5.equals(0L));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1074790400));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(800, (-3));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2400 + "'", int2 == 2400);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-24), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 5151787258411483137L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.711957920655017d + "'", double1 == 18.711957920655017d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 10000.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) '4', 1362265472);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) '4', 33);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray10 = new int[] { 'a', (short) 100 };
        int[] intArray14 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray10);
        int[] intArray19 = new int[] { 'a', (short) 100 };
        int[] intArray23 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray19);
        int[] intArray28 = new int[] { 'a', (short) 100 };
        int[] intArray32 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray28);
        int[] intArray35 = new int[] {};
        int[] intArray38 = new int[] { 'a', (short) 100 };
        int[] intArray42 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray42);
        int[] intArray46 = new int[] { 'a', (short) 100 };
        int[] intArray50 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray38, intArray46);
        int[] intArray57 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray57);
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray35, intArray57);
        int[] intArray60 = null;
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray60);
        try {
            int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1869155502 + "'", int15 == 1869155502);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1869155502 + "'", int24 == 1869155502);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1869155502 + "'", int33 == 1869155502);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1869155502 + "'", int43 == 1869155502);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1869155502 + "'", int51 == 1869155502);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 140.03570973148243d + "'", double58 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass7 = orderDirection6.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.672431920797983d, (java.lang.Number) 1.5515785828445499d, 2087196555, orderDirection6, false);
        java.lang.Class<?> wildcardClass10 = orderDirection6.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (-0.8657694832396586d), 984308025, orderDirection6, true);
        boolean boolean13 = nonMonotonousSequenceException12.getStrict();
        java.lang.String str14 = nonMonotonousSequenceException12.toString();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 984,308,024 and 984,308,025 are not strictly decreasing (-0.866 <= -1.571)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 984,308,024 and 984,308,025 are not strictly decreasing (-0.866 <= -1.571)"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 10);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 100);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger17);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 0);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) 0);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 823869626L);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger29);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (long) 0);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) 0);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, bigInteger38);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, 32L);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger41);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, (long) 'a');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection53, false);
        java.lang.Number number56 = nonMonotonousSequenceException55.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection57 = nonMonotonousSequenceException55.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = nonMonotonousSequenceException55.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException60 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.1752011936438014d), (java.lang.Number) (short) 1, (int) '#', orderDirection58, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException62 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger42, (java.lang.Number) 13L, (int) ' ', orderDirection58, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection63 = nonMonotonousSequenceException62.getDirection();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection53.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 0.37340787437896594d + "'", number56.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection57 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection57.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection58.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection63 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection63.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray32 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray32);
        double[] doubleArray38 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray38);
        double[] doubleArray40 = new double[] {};
        double[] doubleArray45 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray45);
        double[] doubleArray51 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray60 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray38);
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray70 = new double[] { (-2.0d), 15.104412573075516d, 1L, 10.0d, 6.4509312816254912E16d };
        double[] doubleArray71 = new double[] {};
        double[] doubleArray76 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray76);
        double[] doubleArray82 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray82);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray70, doubleArray76);
        double double85 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray70);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 197);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray87, (double) (-1593835520));
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 105.95753866525968d + "'", double54 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 118.14397995666135d + "'", double62 == 118.14397995666135d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 105.95753866525968d + "'", double64 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 102.0d + "'", double85 == 102.0d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { 'a', (short) 100 };
        int[] intArray7 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray7);
        int[] intArray11 = new int[] { 'a', (short) 100 };
        int[] intArray15 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray11);
        int[] intArray20 = new int[] { 'a', (short) 100 };
        int[] intArray24 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray20);
        try {
            double double27 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1869155502 + "'", int8 == 1869155502);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1869155502 + "'", int16 == 1869155502);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1869155502 + "'", int25 == 1869155502);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) 97L);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) (byte) 10);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.028838157314254d + "'", double7 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 52.028838157314254d + "'", double12 == 52.028838157314254d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 2087196555L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.45057218356539297d) + "'", double1 == (-0.45057218356539297d));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        int int2 = org.apache.commons.math.util.FastMath.min(13, 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        double double1 = org.apache.commons.math.util.FastMath.asin(13.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 197);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7988002500903407E85d + "'", double1 == 1.7988002500903407E85d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray13 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 97L);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray17);
        double[] doubleArray19 = new double[] {};
        double[] doubleArray24 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray24);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray31 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray31);
        double[] doubleArray37 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray37);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray44 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray44);
        double[] doubleArray50 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray50);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray44);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray37);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray60 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray60);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray37);
        java.lang.Class<?> wildcardClass65 = doubleArray37.getClass();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.028838157314254d + "'", double7 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 52.028838157314254d + "'", double15 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 46.90196078431373d + "'", double18 == 46.90196078431373d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 105.95753866525968d + "'", double53 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 52.028838157314254d + "'", double62 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 118.14397995666135d + "'", double63 == 118.14397995666135d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 101.90196078431373d + "'", double64 == 101.90196078431373d);
        org.junit.Assert.assertNotNull(wildcardClass65);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.0871964540000021E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 709077286);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 709077286L + "'", long1 == 709077286L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-3));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(59049);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 24, 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray33 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray33);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, 0.017453292519943295d);
        double[] doubleArray38 = new double[] {};
        double[] doubleArray43 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray43);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 105.95753866525968d + "'", double27 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 118.14397995666135d + "'", double35 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 52.028838157314254d + "'", double45 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 52.028838157314254d + "'", double46 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 52.028838157314254d + "'", double48 == 52.028838157314254d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) -1, 1748581106);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 2.08719654E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.64284518290467E7d + "'", double1 == 3.64284518290467E7d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(99.00000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.00000000000006d + "'", double1 == 99.00000000000006d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        int int2 = org.apache.commons.math.util.FastMath.min((-987900782), 3628800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-987900782) + "'", int2 == (-987900782));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.8691554150000048E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1231.8234603869537d + "'", double1 == 1231.8234603869537d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        double double1 = org.apache.commons.math.util.FastMath.sin(59.104412573075514d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5529060425059802d + "'", double1 == 0.5529060425059802d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        double double1 = org.apache.commons.math.util.FastMath.acos((-66.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.2676506002282294E31d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2124676738864984E29d + "'", double1 == 2.2124676738864984E29d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        int int2 = org.apache.commons.math.util.FastMath.min(97, 2087196555);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 6.589582900964765d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.7811460950722924d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3209274043819648d + "'", double1 == 1.3209274043819648d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 2L, (float) 24);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        int int2 = org.apache.commons.math.util.MathUtils.pow(2087196554, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 1748581109);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-2087196494L), (long) 25);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-52179912350L) + "'", long2 == (-52179912350L));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 100, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 1869155502, 0, orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1869155502 + "'", number6.equals(1869155502));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0d + "'", number7.equals(10.0d));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-3.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2490457723982544d) + "'", double1 == (-1.2490457723982544d));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        int int2 = org.apache.commons.math.util.FastMath.max(2087196555, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-14.750469787535078d) + "'", double1 == (-14.750469787535078d));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        long long1 = org.apache.commons.math.util.FastMath.round(1290.1591550923501d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1290L + "'", long1 == 1290L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-1.0f), (double) (-2.08719667E9f), 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-2000574848), 310L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2000575158L) + "'", long2 == (-2000575158L));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(67.19195918050319d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.197070158325058d + "'", double1 == 8.197070158325058d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.19214393877423605d, 1.9377047211159066E-18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.19214393877423605d + "'", double2 == 0.19214393877423605d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.05235987755982989d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05235987755982989d + "'", double2 == 0.05235987755982989d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 1290L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        int int2 = org.apache.commons.math.util.MathUtils.pow(197, 800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1730796417 + "'", int2 == 1730796417);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 828429417848939265L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2.718281828459045d, 800);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8125542464799953E241d + "'", double2 == 1.8125542464799953E241d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 36262448205L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 190427.01542848378d + "'", double1 == 190427.01542848378d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        double double2 = org.apache.commons.math.util.FastMath.max(2.087196554E9d, (double) (-2000574848));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.087196554E9d + "'", double2 == 2.087196554E9d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        double double1 = org.apache.commons.math.util.FastMath.log(50.60632371551998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9240765430997624d + "'", double1 == 3.9240765430997624d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-2087196570));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.8623188722876839d + "'", number8.equals(0.8623188722876839d));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        double double2 = org.apache.commons.math.util.FastMath.max(2.3841857910155797E-7d, 3.6428452021032915E7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.6428452021032915E7d + "'", double2 == 3.6428452021032915E7d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(970000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.5840734641020688d, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5840734641020688d + "'", double2 == 0.5840734641020688d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-2087196570), 1074790400);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-65L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-65) + "'", int1 == (-65));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.4419647419307422d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9962669164972646d + "'", double1 == 1.9962669164972646d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException12.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Number number16 = nonMonotonousSequenceException5.getPrevious();
        int int17 = nonMonotonousSequenceException5.getIndex();
        boolean boolean18 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) 4.944515159673684E42d, (int) (short) -1, orderDirection22, false);
        boolean boolean25 = nonMonotonousSequenceException24.getStrict();
        java.lang.Number number26 = nonMonotonousSequenceException24.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        java.lang.String str28 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.37340787437896594d + "'", number13.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.8623188722876839d + "'", number14.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.8623188722876839d + "'", number16.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 4.944515159673684E42d + "'", number26.equals(4.944515159673684E42d));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 0.373)" + "'", str28.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 0.373)"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 12.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20943951023931956d + "'", double1 == 0.20943951023931956d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.672431920797983d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.31729515068076936d, 1.1304652476096E15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3172951506807694d + "'", double2 == 0.3172951506807694d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.37340787437896594d + "'", number8.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 0.373)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 0.373)"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.37340787437896594d + "'", number10.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.4913616938342726d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.24391706499886E9d, (-0.9171523356672744d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6527863320724393E-9d + "'", double2 == 2.6527863320724393E-9d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        int int1 = org.apache.commons.math.util.MathUtils.sign(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1274444475), (-52179912350L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25L + "'", long2 == 25L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray6 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 97L);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (byte) 10);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 52.028838157314254d + "'", double8 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        double double1 = org.apache.commons.math.util.FastMath.tan(9.931324180688272E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.659487362394655d + "'", double1 == 6.659487362394655d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1869155502, 10.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.9977979834822049d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.4052136525933276d) + "'", double1 == (-3.4052136525933276d));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1748581106, 67.19195918050319d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7485811059999998E9d + "'", double2 == 1.7485811059999998E9d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray33 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray33);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, 0.017453292519943295d);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 105.95753866525968d + "'", double27 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 118.14397995666135d + "'", double35 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.01780538297710575d + "'", double38 == 0.01780538297710575d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-2083567744), 2.384185791015625E-7d, (-0.313275103116924d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '4', 1362265472);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass7 = orderDirection6.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.672431920797983d, (java.lang.Number) 1.5515785828445499d, 2087196555, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection13, false);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        java.lang.Number number17 = nonMonotonousSequenceException15.getPrevious();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.String str19 = nonMonotonousSequenceException9.toString();
        boolean boolean20 = nonMonotonousSequenceException9.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E31d, (java.lang.Number) 10L, 1362265472, orderDirection21, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.37340787437896594d + "'", number16.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.8623188722876839d + "'", number17.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 36262448205L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.6262449E10f + "'", float1 == 3.6262449E10f);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 11);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.9998000199980002d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.009997667086565265d + "'", double2 == 0.009997667086565265d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.9962669164972646d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.748682501726407d + "'", double1 == 3.748682501726407d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) 4.944515159673684E42d, (int) (short) -1, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Class<?> wildcardClass7 = nonMonotonousSequenceException5.getClass();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        int int9 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 1869155502);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5707963255811124d, (java.lang.Number) 99.00000000000006d, 1274444575, orderDirection3, false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(25L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25L + "'", long2 == 25L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3796077390275217d + "'", double1 == 0.3796077390275217d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        long long2 = org.apache.commons.math.util.FastMath.max(2L, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (short) 100);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 0);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (short) 100);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger18);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 0);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 0);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger27);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 823869626L);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger30);
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (long) 0);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, (long) 0);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, bigInteger39);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, 32L);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, bigInteger42);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.881784197001252E-16d, (java.lang.Number) bigInteger43, 1748581109);
        boolean boolean46 = nonMonotonousSequenceException45.getStrict();
        java.lang.Class<?> wildcardClass47 = nonMonotonousSequenceException45.getClass();
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(wildcardClass47);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1074790400, (long) 3628800);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6400L + "'", long2 == 6400L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        int int1 = org.apache.commons.math.util.FastMath.abs((-24));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-65));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 65L + "'", long1 == 65L);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.125899906842624E15d, (java.lang.Number) (-1074790400), 820240826);
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number4, (java.lang.Number) 11, 2000574869);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1074790400);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.24391706499886E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        long long1 = org.apache.commons.math.util.FastMath.abs((-44605560125L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 44605560125L + "'", long1 == 44605560125L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 2141433185, 10000000000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray7 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray12);
        double[] doubleArray18 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray31 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray25);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray18);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray41 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray41);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 0L);
        double[] doubleArray47 = new double[] {};
        double[] doubleArray52 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray52);
        double[] doubleArray58 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray58);
        double[] doubleArray60 = new double[] {};
        double[] doubleArray65 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray65);
        double[] doubleArray71 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray71);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray65);
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        double[] doubleArray75 = new double[] {};
        double[] doubleArray80 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray75, doubleArray80);
        double double82 = org.apache.commons.math.util.MathUtils.distance(doubleArray58, doubleArray80);
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray58);
        int int85 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 105.95753866525968d + "'", double34 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.028838157314254d + "'", double43 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 118.14397995666135d + "'", double44 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 105.95753866525968d + "'", double74 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 118.14397995666135d + "'", double82 == 118.14397995666135d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 105.95753866525968d + "'", double83 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 923521 + "'", int85 == 923521);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        long long2 = org.apache.commons.math.util.FastMath.min(10000000000L, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 100L, (-0.8390715290764524d), 11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.656854249492381d + "'", double1 == 5.656854249492381d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, 1748581120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1748581120 + "'", int2 == 1748581120);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1274444576);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 13L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1869155500L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0709472140366515E11d + "'", double1 == 1.0709472140366515E11d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 197L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        int int9 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection13, false);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        java.lang.Number number17 = nonMonotonousSequenceException15.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        boolean boolean19 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException5.getDirection();
        int int21 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.37340787437896594d + "'", number8.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.37340787437896594d + "'", number16.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.8623188722876839d + "'", number17.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-2087196494L), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 104359824700L + "'", long2 == 104359824700L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 0, 1748581106);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-2087196570), 1748581119);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-338615451) + "'", int2 == (-338615451));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 1076494336L, 2141433185, 1748581109);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.33045663069557313d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.33045663069557313d + "'", double1 == 0.33045663069557313d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        double double1 = org.apache.commons.math.util.FastMath.cos((-9.232311041260349E-39d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.274444589E9d, (int) '4', 197);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-2087196569), (long) (-1748581108));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2087196569L) + "'", long2 == (-2087196569L));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 12L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 104359824700L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.37111061746075d + "'", double1 == 25.37111061746075d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 2087196544);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.0690832749035044d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.069083274903504d + "'", double2 == 3.069083274903504d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray10 = new int[] { 'a', (short) 100 };
        int[] intArray14 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray10);
        int[] intArray19 = new int[] { 'a', (short) 100 };
        int[] intArray23 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray19);
        int[] intArray28 = new int[] { 'a', (short) 100 };
        int[] intArray32 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray32);
        int[] intArray36 = new int[] { 'a', (short) 100 };
        int[] intArray40 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray36);
        int[] intArray47 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray28);
        int[] intArray52 = new int[] { 'a', (short) 100 };
        int[] intArray56 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray52, intArray56);
        int[] intArray60 = new int[] { 'a', (short) 100 };
        int[] intArray64 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int65 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray64);
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray60);
        int[] intArray71 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double72 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray71);
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray71);
        int[] intArray76 = new int[] { 'a', (short) 100 };
        int[] intArray80 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int81 = org.apache.commons.math.util.MathUtils.distance1(intArray76, intArray80);
        int[] intArray85 = new int[] { 10, 10, 'a' };
        double double86 = org.apache.commons.math.util.MathUtils.distance(intArray80, intArray85);
        int int87 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray85);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1869155502 + "'", int15 == 1869155502);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1869155502 + "'", int24 == 1869155502);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1869155502 + "'", int33 == 1869155502);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1869155502 + "'", int41 == 1869155502);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 140.03570973148243d + "'", double48 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1869155502 + "'", int57 == 1869155502);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1869155502 + "'", int65 == 1869155502);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 140.03570973148243d + "'", double72 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 101 + "'", int73 == 101);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1869155502 + "'", int81 == 1869155502);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 1.8691554150000048E9d + "'", double86 == 1.8691554150000048E9d);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 90 + "'", int87 == 90);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1074790400));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        int int2 = org.apache.commons.math.util.FastMath.min(25, (-428686558));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-428686558) + "'", int2 == (-428686558));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 1);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 0);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (short) 100);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection24, false);
        java.lang.Number number27 = nonMonotonousSequenceException26.getArgument();
        java.lang.Number number28 = nonMonotonousSequenceException26.getPrevious();
        int int29 = nonMonotonousSequenceException26.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = nonMonotonousSequenceException26.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2087196545L, (java.lang.Number) bigInteger3, 1748581106, orderDirection30, false);
        java.lang.Throwable[] throwableArray33 = nonMonotonousSequenceException32.getSuppressed();
        java.lang.Throwable[] throwableArray34 = nonMonotonousSequenceException32.getSuppressed();
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 0.37340787437896594d + "'", number27.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 0.8623188722876839d + "'", number28.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(throwableArray34);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray33 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray33);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, 0.017453292519943295d);
        double[] doubleArray43 = new double[] { (-2.0d), 15.104412573075516d, 1L, 10.0d, 6.4509312816254912E16d };
        double[] doubleArray44 = new double[] {};
        double[] doubleArray49 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray49);
        double[] doubleArray55 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray49);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray43);
        double[] doubleArray59 = new double[] {};
        double[] doubleArray64 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        double[] doubleArray67 = new double[] {};
        double[] doubleArray72 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) 97L);
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray76);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray76);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray76);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (1.902 >= -1.902)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 105.95753866525968d + "'", double27 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 118.14397995666135d + "'", double35 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 59.104412573075514d + "'", double58 == 59.104412573075514d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 52.028838157314254d + "'", double66 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 52.028838157314254d + "'", double74 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 46.90196078431373d + "'", double77 == 46.90196078431373d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1748581106);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 3L, (float) 33);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 33.0f + "'", float2 == 33.0f);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        double double1 = org.apache.commons.math.util.FastMath.acos(8.23869632E8d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.3796077390275217d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4617111047443176d + "'", double1 == 0.4617111047443176d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        double double1 = org.apache.commons.math.util.FastMath.sinh(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 100);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger17);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 0);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) 0);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 823869626L);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger29);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 197);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 1362265433);
        try {
            java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (long) (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.672431920797983d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7356179359776243d + "'", double1 == 1.7356179359776243d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(8.197070158325058d, 22.041899743160855d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 1.8051424142832329d, 1.2676506002282294E31d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 923521);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.38280022413318d + "'", double1 == 97.38280022413318d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        int int9 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection13, false);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        java.lang.Number number17 = nonMonotonousSequenceException15.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException5.getDirection();
        boolean boolean21 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.37340787437896594d + "'", number8.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.37340787437896594d + "'", number16.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.8623188722876839d + "'", number17.equals(0.8623188722876839d));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray11 = new int[] { 'a', (short) 100 };
        int[] intArray15 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray15);
        int[] intArray19 = new int[] { 'a', (short) 100 };
        int[] intArray23 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray19);
        int[] intArray30 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double31 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray30);
        int[] intArray33 = null;
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray33);
        int[] intArray35 = new int[] {};
        int[] intArray38 = new int[] { 'a', (short) 100 };
        int[] intArray42 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray42);
        int[] intArray46 = new int[] { 'a', (short) 100 };
        int[] intArray50 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray38, intArray46);
        int[] intArray57 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray57);
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray35, intArray57);
        int[] intArray62 = new int[] { 'a', (short) 100 };
        int[] intArray66 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray66);
        int[] intArray70 = new int[] { 'a', (short) 100 };
        int[] intArray74 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray70, intArray74);
        int int76 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray70);
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray62);
        int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray62);
        try {
            double double79 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1869155502 + "'", int16 == 1869155502);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1869155502 + "'", int24 == 1869155502);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 140.03570973148243d + "'", double31 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1869155502 + "'", int43 == 1869155502);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1869155502 + "'", int51 == 1869155502);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 140.03570973148243d + "'", double58 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1869155502 + "'", int67 == 1869155502);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1869155502 + "'", int75 == 1869155502);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1290L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.91656999213594d + "'", double1 == 35.91656999213594d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1730796417, 0.01780538297710575d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.01780538297710575d + "'", double2 == 0.01780538297710575d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        java.lang.Class<?> wildcardClass8 = intArray6.getClass();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 100);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger17);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 0);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) 0);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 823869626L);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger29);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (long) 0);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) 0);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, bigInteger38);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, 32L);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger41);
        java.math.BigInteger bigInteger43 = null;
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, (long) 0);
        java.math.BigInteger bigInteger46 = null;
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (long) 0);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, bigInteger48);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, bigInteger48);
        java.lang.Class<?> wildcardClass51 = bigInteger50.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(wildcardClass51);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1624473515096265d) + "'", double1 == (-1.1624473515096265d));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 1.3954144401702078d, (int) (byte) -1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection7, false);
        java.lang.Number number10 = nonMonotonousSequenceException9.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException9.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        boolean boolean14 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.37340787437896594d + "'", number10.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.7201027852095638d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7839710796231095d + "'", double1 == 0.7839710796231095d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(5479.9513580933635d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.63026747506269d + "'", double1 == 17.63026747506269d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 90);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(9.332621544395286E157d, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 2087196545L, (-97), 33);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1748581120);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.369491427691418d + "'", double1 == 4.369491427691418d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-44605560125L), (long) 2400);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-44605562525L) + "'", long2 == (-44605562525L));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(2.995592469141819E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        double[] doubleArray5 = new double[] { (-2.0d), 15.104412573075516d, 1L, 10.0d, 6.4509312816254912E16d };
        double[] doubleArray6 = new double[] {};
        double[] doubleArray11 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray11);
        double[] doubleArray17 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray32 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray32);
        double[] doubleArray38 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray38);
        double[] doubleArray40 = new double[] {};
        double[] doubleArray45 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray45);
        double[] doubleArray51 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray38);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray25);
        double[] doubleArray57 = new double[] {};
        double[] doubleArray62 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray62);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double[] doubleArray65 = new double[] {};
        double[] doubleArray70 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray70);
        double[] doubleArray76 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray70, doubleArray76);
        double[] doubleArray78 = new double[] {};
        double[] doubleArray83 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray78, doubleArray83);
        double[] doubleArray89 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray83, doubleArray89);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray76, doubleArray83);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray83);
        try {
            double double93 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray83);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 105.95753866525968d + "'", double54 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-2083567744), (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) Float.NaN, (double) 1274444589L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) 10, (long) 1362265472);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }
}

