import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray24);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection30, false);
        java.lang.Number number33 = nonMonotonousSequenceException32.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = nonMonotonousSequenceException32.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection34, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 2 and 3 are not strictly decreasing (-1 <= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 0.37340787437896594d + "'", number33.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { 'a', (short) 100 };
        int[] intArray7 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray7);
        int[] intArray11 = new int[] { 'a', (short) 100 };
        int[] intArray15 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray11);
        int[] intArray20 = new int[] { 'a', (short) 100 };
        int[] intArray24 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray20);
        try {
            int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1869155502 + "'", int8 == 1869155502);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1869155502 + "'", int16 == 1869155502);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1869155502 + "'", int25 == 1869155502);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 100L, (int) '4');
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        float float2 = org.apache.commons.math.util.FastMath.max((float) ' ', 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 100, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.ceil(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1869155502, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 655.0701637690191d + "'", double2 == 655.0701637690191d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 10, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 3, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9913289158005998d + "'", double1 == 0.9913289158005998d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(32L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3200L + "'", long2 == 3200L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 2087196554, (long) 2087196554);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2087196554L + "'", long2 == 2087196554L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1274444575));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1274444575 + "'", int1 == 1274444575);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10000L, (float) 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-75L), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1839101630706465969L + "'", long2 == 1839101630706465969L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 10, 31L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 310L + "'", long2 == 310L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray7 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray12);
        double[] doubleArray18 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray31 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray25);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray18);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray41 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray41);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 0L);
        double[] doubleArray47 = new double[] {};
        double[] doubleArray52 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray60 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray60);
        double[] doubleArray66 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray66);
        double[] doubleArray68 = new double[] {};
        double[] doubleArray73 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray73);
        double[] doubleArray79 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray73, doubleArray79);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray73);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray73);
        double double83 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 105.95753866525968d + "'", double34 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.028838157314254d + "'", double43 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 118.14397995666135d + "'", double44 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 52.0d + "'", double83 == 52.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        float float2 = org.apache.commons.math.util.MathUtils.round(35.0f, 100);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double2 = org.apache.commons.math.util.FastMath.min(1.1752011936438014d, (double) 1274444575);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1752011936438014d + "'", double2 == 1.1752011936438014d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1869155502);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8691555020000002E9d + "'", double1 == 1.8691555020000002E9d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 32L);
        try {
            java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (-1869155405));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, (double) (-3L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        float float2 = org.apache.commons.math.util.FastMath.max((float) ' ', (float) (-7572232749006416511L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-7.5722327E18f) + "'", float2 == (-7.5722327E18f));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray31 = new double[] { 10.0d, 32.0f, 100.0f };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray39 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray39);
        double[] doubleArray44 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray34);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 105.95753866525968d + "'", double27 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-24));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.596393425240077d + "'", double1 == 13.596393425240077d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 1869155502);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1869155502 + "'", int2 == 1869155502);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) 97L);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[] doubleArray16 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray16);
        double[] doubleArray21 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray11);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray10);
        try {
            double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 1839101630706465969L);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.028838157314254d + "'", double7 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-2087196569), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-338615436), 2087196554);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        int int9 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.37340787437896594d + "'", number8.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int int1 = org.apache.commons.math.util.FastMath.round((-2.08719667E9f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2087196672) + "'", int1 == (-2087196672));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1839101630706465969L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0537276153510783E20d + "'", double1 == 1.0537276153510783E20d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 0L, 984308025);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.8189894035458565E-12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.220703125E-4d + "'", double1 == 1.220703125E-4d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9171523356672744d) + "'", double1 == (-0.9171523356672744d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) 4.944515159673684E42d, (int) (short) -1, orderDirection30, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection30, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not decreasing (-1 < 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        long long1 = org.apache.commons.math.util.FastMath.abs(1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.FastMath.log10((-8.549647527652399E-18d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(46.90196078431373d, (double) 10L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.asinh(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3693300629462564d + "'", double1 == 2.3693300629462564d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-3));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500627E-16d + "'", double1 == 4.440892098500627E-16d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.017453292519943295d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(2087196545);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 820240826);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.373407874378966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4526767286329852d + "'", double1 == 0.4526767286329852d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-2087196672), 2087196554);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 1, (-1869155405));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double1 = org.apache.commons.math.util.FastMath.log(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9512437185814275d + "'", double1 == 3.9512437185814275d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int int1 = org.apache.commons.math.util.MathUtils.sign(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(11013.232920103324d, 0.37340787437896594d, (double) (-3));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.4419647419307422d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.162133867853438d + "'", double1 == 1.162133867853438d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-8.549647527652399E-18d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 2087196545, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.087196545E9d + "'", double2 == 2.087196545E9d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(52.028838157314254d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7633556998775646d + "'", double2 == 1.7633556998775646d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        int int1 = org.apache.commons.math.util.MathUtils.hash(349.9541180407703d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1362265433 + "'", int1 == 1362265433);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-24), 0.373407874378966d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-23.999999999999996d) + "'", double2 == (-23.999999999999996d));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) 0, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(2087196555, 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 605.1328448262083d + "'", double2 == 605.1328448262083d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math.util.FastMath.atan(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double[] doubleArray5 = new double[] { (-2.0d), 15.104412573075516d, 1L, 10.0d, 6.4509312816254912E16d };
        double[] doubleArray6 = new double[] {};
        double[] doubleArray11 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray11);
        double[] doubleArray17 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray32 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray32);
        double[] doubleArray38 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray38);
        double[] doubleArray40 = new double[] {};
        double[] doubleArray45 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray45);
        double[] doubleArray51 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray38);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray25);
        double[] doubleArray57 = new double[] {};
        double[] doubleArray62 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray62);
        double[] doubleArray68 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray68);
        double[] doubleArray70 = new double[] {};
        double[] doubleArray75 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray70, doubleArray75);
        double[] doubleArray81 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray75, doubleArray81);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray75);
        double double84 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double[] doubleArray85 = new double[] {};
        double[] doubleArray90 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray85, doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray68, doubleArray90);
        try {
            double double93 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray68);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 105.95753866525968d + "'", double54 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 105.95753866525968d + "'", double84 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 118.14397995666135d + "'", double92 == 118.14397995666135d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1274444575, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1274444576 + "'", int2 == 1274444576);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 11L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19198621771937624d + "'", double1 == 0.19198621771937624d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-24), 2087196554);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.1752011936438018d, 2.154434690031884d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray6 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray13 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray13);
        double[] doubleArray19 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray19);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray26 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray26);
        double[] doubleArray32 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray26);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray19);
        try {
            double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 105.95753866525968d + "'", double35 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(2087196545, (-338615436));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1748581109 + "'", int2 == 1748581109);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.util.FastMath.log(605.1328448262083d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.405448012152209d + "'", double1 == 6.405448012152209d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 3628800L, (double) 10L, (double) (-75L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1869155502, (long) 2087196544);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.376224634367275d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2087196544, 2087196545);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(3, 11);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        long long1 = org.apache.commons.math.util.FastMath.abs(1839101630706465969L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1839101630706465969L + "'", long1 == 1839101630706465969L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9996159447946292d + "'", double1 == 0.9996159447946292d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-3L), 11);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-3.0f) + "'", float2 == (-3.0f));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-24));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.FastMath.log1p(95.643194047864d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.571025784632303d + "'", double1 == 4.571025784632303d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 3200L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.547473508864641E-13d + "'", double1 == 4.547473508864641E-13d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 11);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 11L + "'", long1 == 11L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double3 = org.apache.commons.math.util.MathUtils.round(1.4419647419307422d, (int) '4', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4419647419307422d + "'", double3 == 1.4419647419307422d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-23.999999999999996d), (double) 0, 11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9033391107665127d) + "'", double1 == (-0.9033391107665127d));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1839101630706465969L, 2087196544, 1748581109);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double1 = org.apache.commons.math.util.FastMath.sinh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-3), (float) 2087196545L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-3.0f) + "'", float2 == (-3.0f));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(984308025, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray32 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray32);
        double[] doubleArray38 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray38);
        double[] doubleArray40 = new double[] {};
        double[] doubleArray45 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray45);
        double[] doubleArray51 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray60 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray38);
        java.lang.Class<?> wildcardClass64 = doubleArray38.getClass();
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 10L);
        double[] doubleArray67 = new double[] {};
        double[] doubleArray72 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) 97L);
        double[] doubleArray77 = new double[] {};
        double[] doubleArray78 = new double[] {};
        double[] doubleArray83 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray78, doubleArray83);
        double[] doubleArray88 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray78, doubleArray88);
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray77, doubleArray78);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray72, doubleArray77);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray72);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 105.95753866525968d + "'", double54 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 118.14397995666135d + "'", double62 == 118.14397995666135d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 52.028838157314254d + "'", double74 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1869155405), (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray12 = new int[] { (short) 0, 2087196554, (short) 0, '4' };
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray12);
        int[] intArray14 = new int[] {};
        int[] intArray17 = new int[] { 'a', (short) 100 };
        int[] intArray21 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray21);
        int[] intArray25 = new int[] { 'a', (short) 100 };
        int[] intArray29 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray29);
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray25);
        int[] intArray36 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray36);
        try {
            double double39 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-338615436) + "'", int13 == (-338615436));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1869155502 + "'", int22 == 1869155502);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1869155502 + "'", int30 == 1869155502);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 140.03570973148243d + "'", double37 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double[] doubleArray5 = new double[] { (-2.0d), 15.104412573075516d, 1L, 10.0d, 6.4509312816254912E16d };
        double[] doubleArray6 = new double[] {};
        double[] doubleArray11 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray11);
        double[] doubleArray17 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray32 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray32);
        double[] doubleArray38 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray38);
        double[] doubleArray40 = new double[] {};
        double[] doubleArray45 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray45);
        double[] doubleArray51 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray38);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray25);
        double[] doubleArray57 = new double[] {};
        double[] doubleArray62 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray62);
        double[] doubleArray68 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray68);
        double[] doubleArray70 = new double[] {};
        double[] doubleArray75 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray70, doubleArray75);
        double[] doubleArray81 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray75, doubleArray81);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray75);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 105.95753866525968d + "'", double54 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-65L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-66.0d) + "'", double1 == (-66.0d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 10, 1274444576);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.19198621771937624d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4337144412751482E29d + "'", double2 == 2.4337144412751482E29d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.sin(8.238696325112256E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14111999894814825d + "'", double1 == 0.14111999894814825d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray7 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray12);
        double[] doubleArray18 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray31 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray25);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray18);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray41 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray41);
        double[] doubleArray45 = null;
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[] doubleArray52 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray52);
        double[] doubleArray57 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray47);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray47);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray45);
        double[] doubleArray62 = null;
        double[] doubleArray63 = new double[] {};
        double[] doubleArray64 = new double[] {};
        double[] doubleArray69 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray64, doubleArray69);
        double[] doubleArray74 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray74);
        double double76 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray63, doubleArray64);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray64);
        try {
            double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 105.95753866525968d + "'", double34 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.028838157314254d + "'", double43 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 118.14397995666135d + "'", double44 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 310L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 970000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 13);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 13L + "'", long1 == 13L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 197.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 984308025, 15.104412573075516d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 820240826);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-2087196569), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.9998000199980002d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9998000199980002d + "'", double2 == 0.9998000199980002d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.565720228261598d, (double) 2083567755L, (double) (-2087196569));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { 'a', (short) 100 };
        int[] intArray7 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray7);
        int[] intArray11 = new int[] { 'a', (short) 100 };
        int[] intArray15 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray11);
        int[] intArray20 = new int[] { 'a', (short) 100 };
        int[] intArray24 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray20);
        int[] intArray29 = new int[] { 'a', (short) 100 };
        int[] intArray33 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray33);
        int[] intArray37 = new int[] { 'a', (short) 100 };
        int[] intArray41 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray41);
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray37);
        int[] intArray48 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray48);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray29);
        int[] intArray53 = new int[] { 'a', (short) 100 };
        int[] intArray57 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray57);
        int[] intArray61 = new int[] { 'a', (short) 100 };
        int[] intArray65 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray65);
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray61);
        int[] intArray72 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray72);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray72);
        try {
            int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1869155502 + "'", int8 == 1869155502);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1869155502 + "'", int16 == 1869155502);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1869155502 + "'", int25 == 1869155502);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1869155502 + "'", int34 == 1869155502);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1869155502 + "'", int42 == 1869155502);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 140.03570973148243d + "'", double49 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1869155502 + "'", int58 == 1869155502);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1869155502 + "'", int66 == 1869155502);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 140.03570973148243d + "'", double73 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 101 + "'", int74 == 101);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) 2083567745L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.9998000199980002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.019999333373332137d + "'", double1 == 0.019999333373332137d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray11 = new int[] { 10, 10, 'a' };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray11);
        int[] intArray15 = new int[] { 'a', (short) 100 };
        int[] intArray19 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray19);
        int[] intArray23 = new int[] { 'a', (short) 100 };
        int[] intArray27 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray23);
        try {
            double double30 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.8691554150000048E9d + "'", double12 == 1.8691554150000048E9d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1869155502 + "'", int20 == 1869155502);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1869155502 + "'", int28 == 1869155502);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (byte) 100, 0.373407874378966d, (double) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray33 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray33);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray41 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray41);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray48 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray48);
        double[] doubleArray54 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray54);
        double[] doubleArray56 = new double[] {};
        double[] doubleArray61 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray61);
        double[] doubleArray67 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray67);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray61);
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray54);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 105.95753866525968d + "'", double27 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 118.14397995666135d + "'", double35 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 105.95753866525968d + "'", double70 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.019999333373332137d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1), (double) 310L, 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.162133867853438d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9176531586283022d + "'", double1 == 0.9176531586283022d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 2087196554L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.459087640769717d + "'", double1 == 21.459087640769717d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) -1, 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math.util.FastMath.asin(46.90196078431373d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.8189894035458565E-12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        long long2 = org.apache.commons.math.util.MathUtils.pow(2083567755L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray10 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray10);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray17 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray17);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray26 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray26);
        double[] doubleArray32 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray32);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 35)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 52.028838157314254d + "'", double19 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 7.7134543004380856d + "'", double20 == 7.7134543004380856d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 101.0d + "'", double34 == 101.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1748581109, 9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.748581109E9d + "'", double2 == 1.748581109E9d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray13 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray13);
        double[] doubleArray19 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray19);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray26 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray26);
        double[] doubleArray32 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray32);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.028838157314254d + "'", double7 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 118.14397995666135d + "'", double35 == 118.14397995666135d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1748581109, 1.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 52L, (double) 13);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.0d + "'", double2 == 13.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 25, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) -1, (-3L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 35.0f, 3.948148009134034E13d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double1 = org.apache.commons.math.util.FastMath.log10(6.405448012152209d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8065495107241175d + "'", double1 == 0.8065495107241175d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4018550223649424d + "'", double1 == 1.4018550223649424d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1362265433, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1362265433) + "'", int2 == (-1362265433));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-2087196569), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2087196570) + "'", int2 == (-2087196570));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(8.238696325112256E8d, 2.3693300629462564d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.8691555E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-75L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 97, (-1869155405));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1539251209787597E287d + "'", double2 == 1.1539251209787597E287d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-2087196569), (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6261589707L + "'", long2 == 6261589707L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1074790400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1074790400 + "'", int1 == 1074790400);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(101);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.425947759839367E159d + "'", double1 == 9.425947759839367E159d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.376224634367275d, (double) 2083567755L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 67.19195918050319d + "'", double2 == 67.19195918050319d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 0, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-8.549647527652399E-18d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2000574869) + "'", int1 == (-2000574869));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        float float1 = org.apache.commons.math.util.FastMath.abs(35.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        long long1 = org.apache.commons.math.util.FastMath.abs(6261589707L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6261589707L + "'", long1 == 6261589707L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.017874927409903d + "'", double1 == 10.017874927409903d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        int int1 = org.apache.commons.math.util.MathUtils.sign(101);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 1.3954144401702078d, (int) (byte) -1);
        java.lang.Throwable throwable4 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-3));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.0537276153510783E20d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0537276153510783E20d + "'", double1 == 1.0537276153510783E20d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-3), (float) 2087196554);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.08719654E9f + "'", float2 == 2.08719654E9f);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1869155502, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException12.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean17 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.37340787437896594d + "'", number13.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.8623188722876839d + "'", number14.equals(0.8623188722876839d));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1362265433);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        long long1 = org.apache.commons.math.util.FastMath.abs(2087196545L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2087196545L + "'", long1 == 2087196545L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.087196554E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.8691555E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 2087196554L, 8.238696325112256E8d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.5840734641020688d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010194005022110007d + "'", double1 == 0.010194005022110007d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 2.08719654E9f, (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.087196544E9d + "'", double2 == 2.087196544E9d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 6261589707L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double2 = org.apache.commons.math.util.FastMath.max(1.9377047211159066E-18d, 34.99999999999999d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.99999999999999d + "'", double2 == 34.99999999999999d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.asin(79.95135809336342d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.6503247124667075d), (double) 11, 31.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray7 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray12);
        double[] doubleArray18 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray31 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray25);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray18);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray41 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray41);
        double[] doubleArray45 = null;
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[] doubleArray52 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray52);
        double[] doubleArray57 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray47);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray47);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray45);
        double[] doubleArray68 = new double[] { 2.087196545E9d, 1, 53.982297150257104d, 0.19198621771937624d, 0.38535742648327137d, 1130465247609600L };
        try {
            double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 105.95753866525968d + "'", double34 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.028838157314254d + "'", double43 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 118.14397995666135d + "'", double44 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (byte) -1, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.math.util.FastMath.rint(52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 2L, 1748581109);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 2147483647, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.14748365E9f + "'", float2 == 2.14748365E9f);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        long long1 = org.apache.commons.math.util.FastMath.abs(2083567745L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2083567745L + "'", long1 == 2083567745L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1074790400));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 8.2386963E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963255811124d + "'", double1 == 1.5707963255811124d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.3608363030788d + "'", double1 == 156.3608363030788d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.547473508864641E-13d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.806217383937352E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.5906394885523198d, (double) 10000.0f, 1.4419647419307422d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.2280208110551356d, (-0.0d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double2 = org.apache.commons.math.util.MathUtils.log(52.028838157314254d, (-0.8657694832396586d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        java.lang.Class<?> wildcardClass28 = doubleArray18.getClass();
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (-1074790400));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection34, false);
        java.lang.Number number37 = nonMonotonousSequenceException36.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = nonMonotonousSequenceException36.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection38, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (-1 <= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2087196545 + "'", int27 == 2087196545);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 0.37340787437896594d + "'", number37.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection38.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 0);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 823869626L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger17 = null;
        try {
            java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(197);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 847.3520979704383d + "'", double1 == 847.3520979704383d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (-1274444478L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1274444478L) + "'", long2 == (-1274444478L));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        long long1 = org.apache.commons.math.util.FastMath.round(0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double1 = org.apache.commons.math.util.FastMath.acos(140.03570973148243d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-3), (-2087196570));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-338615436));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 31L, (-0.6865874069985796d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.41592653589793116d) + "'", double2 == (-0.41592653589793116d));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(95.643194047864d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5479.9513580933635d + "'", double1 == 5479.9513580933635d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-2000574869));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.19334632705655572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19214393877423605d + "'", double1 == 0.19214393877423605d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.log(0.9996159447946292d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.8412897345910653E-4d) + "'", double1 == (-3.8412897345910653E-4d));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.38535742648327137d, 984308025);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.4306130247196315E93d) + "'", double2 == (-6.4306130247196315E93d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1362265433));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.36226547E9f + "'", float1 == 1.36226547E9f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1362265433);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1362265472 + "'", int1 == 1362265472);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        long long2 = org.apache.commons.math.util.FastMath.max(2L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 2.14748365E9f, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.147483648E9d + "'", double2 == 2.147483648E9d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        float float1 = org.apache.commons.math.util.FastMath.abs(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        double double1 = org.apache.commons.math.util.FastMath.exp(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { 'a', (short) 100 };
        int[] intArray7 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray7);
        int[] intArray11 = new int[] { 'a', (short) 100 };
        int[] intArray15 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray11);
        int[] intArray20 = new int[] { 'a', (short) 100 };
        int[] intArray24 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray20);
        int[] intArray29 = new int[] { 'a', (short) 100 };
        int[] intArray33 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray33);
        int[] intArray37 = new int[] { 'a', (short) 100 };
        int[] intArray41 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray41);
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray37);
        int[] intArray48 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray48);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray29);
        try {
            int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1869155502 + "'", int8 == 1869155502);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1869155502 + "'", int16 == 1869155502);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1869155502 + "'", int25 == 1869155502);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1869155502 + "'", int34 == 1869155502);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1869155502 + "'", int42 == 1869155502);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 140.03570973148243d + "'", double49 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(10, 1869155502);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.9367122197325302d, 1.220703125E-4d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9367122197325302d + "'", double2 == 0.9367122197325302d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-0.0d), (int) (byte) 10, 1274444575);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.944515159673684E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double2 = org.apache.commons.math.util.FastMath.atan2(Double.POSITIVE_INFINITY, (double) 197.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (short) 0, 99.00000000000004d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.53096491487338d + "'", double2 == 100.53096491487338d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-3L), (long) 25);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(655.0701637690191d, (double) (byte) 10, 1.8691555E9d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-2000574869), (double) '#', (double) 2087196544);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double1 = org.apache.commons.math.util.FastMath.cosh(45685.84622177858d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray7 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray12);
        double[] doubleArray18 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray31 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray25);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray18);
        double[] doubleArray41 = new double[] { (-2.0d), 15.104412573075516d, 1L, 10.0d, 6.4509312816254912E16d };
        double[] doubleArray42 = new double[] {};
        double[] doubleArray47 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray47);
        double[] doubleArray53 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray47);
        double[] doubleArray56 = new double[] {};
        double[] doubleArray61 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray61);
        double[] doubleArray63 = new double[] {};
        double[] doubleArray68 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray68);
        double[] doubleArray74 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray68, doubleArray74);
        double[] doubleArray76 = new double[] {};
        double[] doubleArray81 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray76, doubleArray81);
        double[] doubleArray87 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray81, doubleArray87);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray81);
        double double90 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray74);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray61);
        double[] doubleArray94 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, 100.00000000000001d);
        double double95 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 105.95753866525968d + "'", double34 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 105.95753866525968d + "'", double90 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 118.14397995666135d + "'", double95 == 118.14397995666135d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 2087196544);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1958755298549142E11d + "'", double1 == 1.1958755298549142E11d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.1958755298549142E11d, (-4.898587196589413E-16d), 1.869155502E9d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        long long1 = org.apache.commons.math.util.FastMath.round(1.8691555E9d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1869155500L + "'", long1 == 1869155500L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1.36226547E9f, (double) 8.2386963E8f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1L), 2083567755L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2083567756L) + "'", long2 == (-2083567756L));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2087196554, (java.lang.Number) 101.0d, 197);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection12, false);
        java.lang.Number number15 = nonMonotonousSequenceException14.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException14.getDirection();
        java.lang.Number number17 = nonMonotonousSequenceException14.getArgument();
        java.lang.String str18 = nonMonotonousSequenceException14.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        java.lang.Number number20 = nonMonotonousSequenceException14.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException14.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.8623188722876839d + "'", number7.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0.37340787437896594d + "'", number15.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.37340787437896594d + "'", number17.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 0.373)" + "'", str18.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 0.373)"));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.8623188722876839d + "'", number20.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (int) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        int int2 = org.apache.commons.math.util.MathUtils.pow(3, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59049 + "'", int2 == 59049);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 6261589707L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) ' ', (long) 1074790400);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34393292800L + "'", long2 == 34393292800L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.9977979834822049d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1718061510556774d) + "'", double1 == (-1.1718061510556774d));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 197, (long) 101);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 197L + "'", long2 == 197L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-2087196569), (-75L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2087196494L) + "'", long2 == (-2087196494L));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-2000574869));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4440480933487433d) + "'", double1 == (-0.4440480933487433d));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double1 = org.apache.commons.math.util.FastMath.log1p(13.596393425240077d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.680774472529937d + "'", double1 == 2.680774472529937d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.8680959046605506d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1274444576, 2.147483648E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.274444576E9d + "'", double2 == 1.274444576E9d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 1130465247609600L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-2000574869), (java.lang.Number) Double.NaN, (-1362265433));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2000574869), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 1274444576);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1274444576 + "'", int2 == 1274444576);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double2 = org.apache.commons.math.util.MathUtils.round(100.0d, 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(820240826, (-2000574869));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 2147483647);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-2087196569));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963263157851d) + "'", double1 == (-1.5707963263157851d));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2087196545 + "'", int13 == 2087196545);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-7572232749006416511L), 1074790400);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5151787258411483137L + "'", long2 == 5151787258411483137L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 3628800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-2087196569), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Class<?> wildcardClass9 = orderDirection8.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double[] doubleArray5 = new double[] { (-2.0d), 15.104412573075516d, 1L, 10.0d, 6.4509312816254912E16d };
        double[] doubleArray6 = new double[] {};
        double[] doubleArray11 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray11);
        double[] doubleArray17 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray32 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray32);
        double[] doubleArray38 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray38);
        double[] doubleArray40 = new double[] {};
        double[] doubleArray45 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray45);
        double[] doubleArray51 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray38);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray25);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 100.00000000000001d);
        double[] doubleArray59 = null;
        try {
            double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 105.95753866525968d + "'", double54 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double double2 = org.apache.commons.math.util.FastMath.atan2(21.459087640769717d, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3913849194869165d + "'", double2 == 0.3913849194869165d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        int int1 = org.apache.commons.math.util.MathUtils.sign(2561);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.MathUtils.sign(4.440892098500627E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(197, 1362265472);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(25, (-1074790400));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-3), 1748581109);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1748581106 + "'", int2 == 1748581106);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) '4', (int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.087196554E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.8623188722876839d + "'", number7.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.8623188722876839d + "'", number10.equals(0.8623188722876839d));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        long long2 = org.apache.commons.math.util.FastMath.max((-3L), (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double2 = org.apache.commons.math.util.FastMath.max(1.274444576E9d, 0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.274444576E9d + "'", double2 == 1.274444576E9d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.8065495107241175d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5914186782181569d + "'", double1 == 0.5914186782181569d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 2087196554L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double1 = org.apache.commons.math.util.FastMath.cos(67.19195918050319d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3450413794473462d) + "'", double1 == (-0.3450413794473462d));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-2087196494L), 2083567755L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 0, 97);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 6261589707L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963266351928d + "'", double1 == 1.5707963266351928d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        int int1 = org.apache.commons.math.util.FastMath.abs(2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray6 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray6);
        double[] doubleArray12 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray19 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray19);
        double[] doubleArray25 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray29 = new double[] {};
        double[] doubleArray34 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray34);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 0.017453292519943295d);
        double[] doubleArray44 = new double[] { (-2.0d), 15.104412573075516d, 1L, 10.0d, 6.4509312816254912E16d };
        double[] doubleArray45 = new double[] {};
        double[] doubleArray50 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray50);
        double[] doubleArray56 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray50);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray44);
        try {
            double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 105.95753866525968d + "'", double28 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 118.14397995666135d + "'", double36 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 59.104412573075514d + "'", double59 == 59.104412573075514d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-8.549647527652399E-18d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.549647527652399E-18d) + "'", double1 == (-8.549647527652399E-18d));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 3L, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5d + "'", double2 == 1.5d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05235987755982989d + "'", double1 == 0.05235987755982989d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1362265472);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.FastMath.abs((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103324d + "'", double1 == 11013.232920103324d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 11, 34393292800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34393292800L + "'", long2 == 34393292800L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644483341943245d + "'", double1 == 4.644483341943245d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.14111999894814825d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.014111063212005658d + "'", double2 == 0.014111063212005658d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        int int2 = org.apache.commons.math.util.FastMath.min(197, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1130465247609600L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1304652476096E15d + "'", double1 == 1.1304652476096E15d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.7633556998775646d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.830253226062821d + "'", double1 == 2.830253226062821d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) '4', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray32 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray32);
        double[] doubleArray38 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray38);
        double[] doubleArray40 = new double[] {};
        double[] doubleArray45 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray45);
        double[] doubleArray51 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray60 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray38);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 820240826);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 105.95753866525968d + "'", double54 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 118.14397995666135d + "'", double62 == 118.14397995666135d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.99168E7d + "'", double1 == 3.99168E7d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1274444575, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 10L, 655.0701637690191d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1748581106, 2561);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, 2083567755L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2083567755L + "'", long2 == 2083567755L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        int int2 = org.apache.commons.math.util.FastMath.max(2147483647, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(32, 1869155502);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2087196672), 1362265433);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray7 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray12);
        double[] doubleArray18 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray31 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray25);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray18);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray41 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray41);
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[] doubleArray51 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray51);
        double[] doubleArray56 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray46);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray45);
        double[] doubleArray60 = new double[] {};
        double[] doubleArray65 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray65);
        double[] doubleArray71 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray71);
        double[] doubleArray73 = new double[] {};
        double[] doubleArray78 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray73, doubleArray78);
        double[] doubleArray84 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray78, doubleArray84);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray78);
        double double87 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray71);
        double double89 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 105.95753866525968d + "'", double34 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.028838157314254d + "'", double43 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 118.14397995666135d + "'", double44 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 105.95753866525968d + "'", double87 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 105.95753866525968d + "'", double89 == 105.95753866525968d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double2 = org.apache.commons.math.util.FastMath.max(1.5d, 4.547473508864641E-13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5d + "'", double2 == 1.5d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        int int1 = org.apache.commons.math.util.FastMath.abs(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 1.3954144401702078d, (int) (byte) -1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.99168E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 696679.5868600726d + "'", double1 == 696679.5868600726d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '#', (long) (-2087196570));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2087196570L) + "'", long2 == (-2087196570L));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 13L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076494336 + "'", int1 == 1076494336);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.4337144412751482E29d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 68.35753354431203d + "'", double1 == 68.35753354431203d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray2 = new double[] {};
        double[] doubleArray7 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray7);
        double[] doubleArray12 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray2);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray2);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 101, 1274444575);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (short) -1, (double) 2087196554, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(8.238696325112256E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.5906394885523198d, 4.806217383937352E-6d, (double) 2147483647);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double double1 = org.apache.commons.math.util.MathUtils.sign(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.5707963266351928d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.261589146124386E9d + "'", double1 == 6.261589146124386E9d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.087196544E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double2 = org.apache.commons.math.util.MathUtils.log(45685.84622177858d, 11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8674043350929254d + "'", double2 == 0.8674043350929254d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(100.00000000000001d, 4.944515159673684E42d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.00000000000003d + "'", double2 == 100.00000000000003d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.9996159447946292d, 2.147483648E9d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.8944584145355932d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.1539251209787597E287d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1539251209787597E287d + "'", double1 == 1.1539251209787597E287d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double double2 = org.apache.commons.math.util.FastMath.atan2(118.14397995666135d, 2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.552562677253157d + "'", double2 == 1.552562677253157d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) 'a', 1362265472);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(100, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9443504370351303d) + "'", double1 == (-0.9443504370351303d));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1362265433, (long) 984308025);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray11 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray18 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray24 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray32 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray32);
        double[] doubleArray38 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray38);
        double[] doubleArray40 = new double[] {};
        double[] doubleArray45 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray45);
        double[] doubleArray51 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray60 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray38);
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 13);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 105.95753866525968d + "'", double54 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 118.14397995666135d + "'", double62 == 118.14397995666135d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 105.95753866525968d + "'", double64 == 105.95753866525968d);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray10 = new int[] { 'a', (short) 100 };
        int[] intArray14 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray10);
        int[] intArray19 = new int[] { 'a', (short) 100 };
        int[] intArray23 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray23);
        int[] intArray27 = new int[] { 'a', (short) 100 };
        int[] intArray31 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray27);
        int[] intArray36 = new int[] { 'a', (short) 100 };
        int[] intArray40 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray40);
        int[] intArray45 = new int[] { 10, 10, 'a' };
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray40);
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray27);
        int[] intArray49 = new int[] {};
        int[] intArray52 = new int[] { 'a', (short) 100 };
        int[] intArray56 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray52, intArray56);
        int[] intArray60 = new int[] { 'a', (short) 100 };
        int[] intArray64 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int65 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray64);
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray60);
        int[] intArray71 = new int[] { (byte) 0, (-1), (-1869155405), (short) 10 };
        double double72 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray71);
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray49, intArray71);
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray71);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1869155502 + "'", int15 == 1869155502);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1869155502 + "'", int24 == 1869155502);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1869155502 + "'", int32 == 1869155502);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1869155502 + "'", int41 == 1869155502);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.8691554150000048E9d + "'", double46 == 1.8691554150000048E9d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.869155502E9d + "'", double47 == 1.869155502E9d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1869155502 + "'", int57 == 1869155502);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1869155502 + "'", int65 == 1869155502);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 140.03570973148243d + "'", double72 == 140.03570973148243d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 140.03570973148243d + "'", double74 == 140.03570973148243d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.8680959046605506d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 6261589707L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double1 = org.apache.commons.math.util.FastMath.sinh(101.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6535299896840334E43d + "'", double1 == 3.6535299896840334E43d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        long long2 = org.apache.commons.math.util.MathUtils.pow(52L, (long) 2087196545);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        double double1 = org.apache.commons.math.util.FastMath.tan(11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.5045996724326973d) + "'", double1 == (-2.5045996724326973d));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 10.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        float float1 = org.apache.commons.math.util.MathUtils.sign(32.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double1 = org.apache.commons.math.util.FastMath.asinh(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(31.30685281944008d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double double1 = org.apache.commons.math.util.FastMath.sinh(100.00000000000003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.344058570908106E43d + "'", double1 == 1.344058570908106E43d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        float float2 = org.apache.commons.math.util.FastMath.max(100.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(5151787258411483137L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.552562677253157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-3), (long) 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1594323) + "'", int2 == (-1594323));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        int int2 = org.apache.commons.math.util.FastMath.min((-1869155405), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1869155405) + "'", int2 == (-1869155405));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(970000L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0L, (double) 2087196555);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double[] doubleArray5 = new double[] { (-2.0d), 15.104412573075516d, 1L, 10.0d, 6.4509312816254912E16d };
        double[] doubleArray6 = new double[] {};
        double[] doubleArray11 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray11);
        double[] doubleArray17 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray11);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray32 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray32);
        double[] doubleArray38 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray38);
        double[] doubleArray40 = new double[] {};
        double[] doubleArray45 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray45);
        double[] doubleArray51 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray38);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray25);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 105.95753866525968d + "'", double54 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(34393292800L, (long) (-1869155405));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 36262448205L + "'", long2 == 36262448205L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3628800L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3628800 + "'", int1 == 3628800);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double1 = org.apache.commons.math.util.FastMath.cosh(11013.232920103326d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(10000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-126.0783456901072d), (double) (-2087196570), 46.90196078431373d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(6261589707L, (long) (-1869155405));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double double2 = org.apache.commons.math.util.FastMath.max(1.7266028267644384d, 2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.99822295029797d + "'", double2 == 2.99822295029797d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.31729515068076936d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.179672993975593d + "'", double1 == 18.179672993975593d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.5840734641020688d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8359028870534034d + "'", double1 == 0.8359028870534034d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 100);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger17);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 0);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) 0);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 823869626L);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger29);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (-0.4440480933487433d));
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.028838157314254d + "'", double7 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 52.028838157314254d + "'", double8 == 52.028838157314254d);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 100, (-1274444575));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1274444475) + "'", int2 == (-1274444475));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(11013.232920103326d, 1.8944584145355932d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(2087196544, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 605.1328446575607d + "'", double2 == 605.1328446575607d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double2 = org.apache.commons.math.util.FastMath.min(21.459087640769717d, 1.220703125E-4d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.220703125E-4d + "'", double2 == 1.220703125E-4d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 100);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger17);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 1869155502, 0, orderDirection26, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger20, (java.lang.Number) 820240826, 984308025, orderDirection26, true);
        boolean boolean31 = nonMonotonousSequenceException30.getStrict();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            int int2 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1274444575), 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-44605560125L) + "'", long2 == (-44605560125L));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-24));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6283429.007424238d + "'", double1 == 6283429.007424238d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double double1 = org.apache.commons.math.util.FastMath.log1p(59.104412573075514d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.096083259363071d + "'", double1 == 4.096083259363071d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) ' ', 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.9171523356672744d), (-0.6865874069985796d), 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        long long1 = org.apache.commons.math.util.MathUtils.sign(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(3628800);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.3450413794473462d), 0.0d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1362265433, 3628800);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 800);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-4.898587196589413E-16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.440892098500626E-16d) + "'", double1 == (-4.440892098500626E-16d));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1074790400, 10L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1869155502);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.041899743160855d + "'", double1 == 22.041899743160855d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.19214393877423605d, (double) 1869155502);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-12.942477465750601d) + "'", double2 == (-12.942477465750601d));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double double2 = org.apache.commons.math.util.FastMath.pow(11013.232920103324d, 4.096083259363071d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.5976561054698672E16d + "'", double2 == 3.5976561054698672E16d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) '#', (long) (-2087196672));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2087196637L) + "'", long2 == (-2087196637L));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        long long2 = org.apache.commons.math.util.MathUtils.pow(10L, (int) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(2L, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(Float.NaN);
        org.junit.Assert.assertEquals((float) float1, Float.NaN, 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 2147483647, (-7.5722327E18f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-7.5722327E18f) + "'", float2 == (-7.5722327E18f));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1869155405));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1869155405 + "'", int1 == 1869155405);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-97) + "'", int2 == (-97));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-3L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-10.017874927409903d) + "'", double1 == (-10.017874927409903d));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1076494336);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1076494336L + "'", long1 == 1076494336L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(31L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection12, false);
        java.lang.Number number15 = nonMonotonousSequenceException14.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException14.getDirection();
        java.lang.Number number17 = nonMonotonousSequenceException14.getArgument();
        java.lang.String str18 = nonMonotonousSequenceException14.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        java.lang.Number number20 = nonMonotonousSequenceException14.getPrevious();
        int int21 = nonMonotonousSequenceException14.getIndex();
        java.lang.Throwable[] throwableArray22 = nonMonotonousSequenceException14.getSuppressed();
        java.lang.String str23 = nonMonotonousSequenceException14.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.8623188722876839d + "'", number7.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0.37340787437896594d + "'", number15.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.37340787437896594d + "'", number17.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 0.373)" + "'", str18.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 0.373)"));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.8623188722876839d + "'", number20.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 0.373)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0.862 < 0.373)"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(2087196555, 2561);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 37413.75877729883d + "'", double2 == 37413.75877729883d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1074790400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 0L, (-1594323));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(800, 1869155405);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray13 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray13);
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double[] doubleArray16 = null;
        double double17 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray16);
        java.lang.Class<?> wildcardClass19 = doubleArray0.getClass();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1748581106, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1748581106L + "'", long2 == 1748581106L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 36262448205L, (float) 12L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 12.0f + "'", float2 == 12.0f);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double1 = org.apache.commons.math.util.FastMath.asin(9.332621544395286E157d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 1);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 197L);
        java.lang.Number number13 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection19, false);
        java.lang.Number number22 = nonMonotonousSequenceException21.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException21.getDirection();
        java.lang.Number number24 = nonMonotonousSequenceException21.getArgument();
        int int25 = nonMonotonousSequenceException21.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection29, false);
        java.lang.Number number32 = nonMonotonousSequenceException31.getArgument();
        java.lang.Number number33 = nonMonotonousSequenceException31.getPrevious();
        nonMonotonousSequenceException21.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException31.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number13, (java.lang.Number) (-7.5722327E18f), (int) (short) 10, orderDirection35, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.344058570908106E43d, (java.lang.Number) bigInteger11, (-97), orderDirection35, false);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.37340787437896594d + "'", number22.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.37340787437896594d + "'", number24.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.37340787437896594d + "'", number32.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 0.8623188722876839d + "'", number33.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1748581109);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 11L, (float) (-97));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-97.0f) + "'", float2 == (-97.0f));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.8680959046605506d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 803350394 + "'", int1 == 803350394);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 2087196555, 1231.8234794987286d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0871965549999998E9d + "'", double2 == 2.0871965549999998E9d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1), (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 68.35753354431203d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(3, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-24), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 10, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.33045663069557313d, 1.344058570908106E43d, 59049);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1748581109, 32.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.748581109E9d + "'", double2 == 1.748581109E9d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.37340787437896594d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.37340787437896594d + "'", double1 == 0.37340787437896594d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (-2087196672));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-7.5722327E18f), 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.5707963266351928d, 2087196545);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.232311041260349E-39d) + "'", double2 == (-9.232311041260349E-39d));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray5);
        double[] doubleArray7 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray12);
        double[] doubleArray18 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double[] doubleArray31 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray25);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray18);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray41 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray41);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 0L);
        double[] doubleArray53 = new double[] { 8.238696325112256E8d, 2.087196554E9d, 3628800L, (-0.7853981633974483d), 0L, 1362265433 };
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray53);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray60 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray60);
        double[] doubleArray66 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray66);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray66);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection72 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException74 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 1869155502, 0, orderDirection72, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53, orderDirection72, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (2,087,196,554 >= 3,628,800)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 105.95753866525968d + "'", double34 == 105.95753866525968d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.028838157314254d + "'", double43 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 118.14397995666135d + "'", double44 == 118.14397995666135d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.24391706499886E9d + "'", double54 == 2.24391706499886E9d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + orderDirection72 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection72.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1274444575), 1.2280208110551356d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2280208110551356d + "'", double2 == 1.2280208110551356d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 2.14748365E9f, 5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707936587522522d + "'", double2 == 1.5707936587522522d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1274444575));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-2000574869));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2000574848) + "'", int1 == (-2000574848));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray6 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray6);
        double[] doubleArray12 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray19 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray19);
        double[] doubleArray25 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray33 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray33);
        double[] doubleArray38 = new double[] { 1.5607966601082315d, 2.154434690031884d, 2.99822295029797d };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray38);
        double[] doubleArray40 = new double[] {};
        double[] doubleArray45 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray45);
        double[] doubleArray49 = new double[] {};
        double[] doubleArray54 = new double[] { (-1.0f), 1, (byte) -1, '4' };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray54);
        double[] doubleArray60 = new double[] { 100, '#', (short) -1, (short) 1 };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray45);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 52.028838157314254d + "'", double47 == 52.028838157314254d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 7.7134543004380856d + "'", double48 == 7.7134543004380856d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 101.0d + "'", double62 == 101.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 101.0d + "'", double63 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 1.4419647419307422d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.8680959046605506d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.325299925116821d + "'", double1 == 1.325299925116821d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (-24));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 1.2280208110551356d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) '#', (-2087196569));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.869155502E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2622917741667457E7d + "'", double1 == 3.2622917741667457E7d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(2087196555, 984308025);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 13);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-2000574848), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000574848 + "'", int2 == 2000574848);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.672431920797983d, (java.lang.Number) 1.5515785828445499d, 2087196555, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException12.getPrevious();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.String str16 = nonMonotonousSequenceException6.toString();
        boolean boolean17 = nonMonotonousSequenceException6.getStrict();
        java.lang.String str18 = nonMonotonousSequenceException6.toString();
        java.lang.Number number19 = nonMonotonousSequenceException6.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.37340787437896594d + "'", number13.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.8623188722876839d + "'", number14.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)" + "'", str18.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,087,196,554 and 2,087,196,555 are not decreasing (1.552 < 4.672)"));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1.5515785828445499d + "'", number19.equals(1.5515785828445499d));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-2000574848), (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        int[] intArray2 = new int[] { 'a', (short) 100 };
        int[] intArray6 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray6);
        int[] intArray12 = new int[] { (short) 0, 2087196554, (short) 0, '4' };
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray12);
        java.lang.Class<?> wildcardClass14 = intArray6.getClass();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1869155502 + "'", int7 == 1869155502);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-338615436) + "'", int13 == (-338615436));
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(59049, (-3));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.5840734641020688d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7933286322891924d + "'", double1 == 1.7933286322891924d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-2000574869), (float) 2087196555L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.00057485E9f) + "'", float2 == (-2.00057485E9f));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1869155405), (float) 2147483647);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.14748365E9f + "'", float2 == 2.14748365E9f);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { 'a', (short) 100 };
        int[] intArray7 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray7);
        int[] intArray11 = new int[] { 'a', (short) 100 };
        int[] intArray15 = new int[] { (-1869155405), (short) 100, (short) 1 };
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray11);
        try {
            int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1869155502 + "'", int8 == 1869155502);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1869155502 + "'", int16 == 1869155502);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 97L, (float) 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double1 = org.apache.commons.math.util.FastMath.acos(6.4509312816254912E16d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37340787437896594d, (java.lang.Number) 0.8623188722876839d, 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException12.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Number number16 = nonMonotonousSequenceException5.getPrevious();
        int int17 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.37340787437896594d + "'", number6.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.37340787437896594d + "'", number13.equals(0.37340787437896594d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.8623188722876839d + "'", number14.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.8623188722876839d + "'", number16.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }
}

