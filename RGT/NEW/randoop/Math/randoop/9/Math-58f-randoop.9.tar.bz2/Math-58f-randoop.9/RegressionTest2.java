import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter1 = new org.apache.commons.math.optimization.fitting.GaussianFitter(differentiableMultivariateVectorialOptimizer0);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = gaussianFitter1.getObservations();
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = gaussianFitter1.getObservations();
        gaussianFitter1.clearObservations();
        gaussianFitter1.addObservedPoint((double) (short) 1, Double.POSITIVE_INFINITY);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer14 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int15 = levenbergMarquardtOptimizer14.getEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker16 = levenbergMarquardtOptimizer14.getConvergenceChecker();
        int int17 = levenbergMarquardtOptimizer14.getMaxEvaluations();
        double double18 = levenbergMarquardtOptimizer14.getRMS();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter19 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer14);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer25 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int26 = levenbergMarquardtOptimizer25.getEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter27 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer25);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric28 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray35 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray39 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair41 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray35, doubleArray39, false);
        double[] doubleArray42 = parametric28.gradient(3.2710663101885897d, doubleArray39);
        double[] doubleArray48 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray52 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair54 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray48, doubleArray52, false);
        double[] doubleArray55 = vectorialPointValuePair54.getPoint();
        double[] doubleArray56 = gaussianFitter27.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric28, doubleArray55);
        double[] doubleArray62 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray66 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair68 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray62, doubleArray66, false);
        double[] doubleArray69 = vectorialPointValuePair68.getPoint();
        double[] doubleArray70 = vectorialPointValuePair68.getPointRef();
        double[] doubleArray74 = new double[] { 3349.571901633116d, (short) -1, (-1.0d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair76 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray70, doubleArray74, false);
        double[] doubleArray77 = gaussianFitter19.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric28, doubleArray70);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric78 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray85 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray89 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair91 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray85, doubleArray89, false);
        double[] doubleArray92 = parametric78.gradient(3.2710663101885897d, doubleArray89);
        try {
            double[] doubleArray93 = gaussianFitter1.fit(0, (org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric28, doubleArray92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray92);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) '#', (int) (short) -1);
        int int4 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException13 = new org.apache.commons.math.optimization.OptimizationException("", objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray10);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.ZeroException zeroException19 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats18);
        java.lang.Object[] objArray20 = zeroException19.getArguments();
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalStateException16, "", objArray20);
        java.lang.String str22 = mathException21.getPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.995215415969976d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8388762413257292d + "'", double1 == 0.8388762413257292d);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) (short) 100, (int) ' ');
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException7 = new org.apache.commons.math.exception.DimensionMismatchException((int) 'a', (int) (short) 1);
        int int8 = dimensionMismatchException7.getDimension();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray16 = mathException15.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) dimensionMismatchException7, "unable to orthogonalize matrix in {0} iterations", objArray16);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.192093037616374E-7d, objArray16);
        java.lang.Number number19 = maxCountExceededException18.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1.192093037616374E-7d + "'", number19.equals(1.192093037616374E-7d));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats1, (-1L), localizedFormats3, localizedFormats4 };
        org.apache.commons.math.optimization.OptimizationException optimizationException6 = new org.apache.commons.math.optimization.OptimizationException("denominator", objArray5);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer13 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter14 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer13);
        curveFitter14.clearObservations();
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = curveFitter14.getObservations();
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) weightedObservedPointArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        double double1 = org.apache.commons.math.util.FastMath.tanh(10.000001907348633d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958777085d + "'", double1 == 0.9999999958777085d);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.6108652381980153d, (java.lang.Number) 1.786706395136E12d, (java.lang.Number) 3.141592653589793d);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException8.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.786706395136E12d + "'", number5.equals(1.786706395136E12d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 3.141592653589793d + "'", number6.equals(3.141592653589793d));
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNull(localizable10);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        double double2 = org.apache.commons.math.util.FastMath.hypot(0.0d, 0.3518432295756951d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3518432295756951d + "'", double2 == 0.3518432295756951d);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 6, (java.lang.Number) 1.0d, (java.lang.Number) (short) -1);
        java.lang.Number number6 = outOfRangeException5.getLo();
        java.lang.Number number7 = outOfRangeException5.getHi();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException9 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats8);
        org.apache.commons.math.exception.util.Localizable localizable10 = nullArgumentException9.getSpecificPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.optimization.OptimizationException optimizationException24 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray22);
        org.apache.commons.math.optimization.OptimizationException optimizationException25 = new org.apache.commons.math.optimization.OptimizationException("", objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, (org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray22);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray22);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException31 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (int) (byte) 0, (int) (byte) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("hi!", objArray40);
        org.apache.commons.math.optimization.OptimizationException optimizationException42 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray40);
        org.apache.commons.math.optimization.OptimizationException optimizationException43 = new org.apache.commons.math.optimization.OptimizationException("", objArray40);
        java.lang.Object[] objArray49 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException43, "", objArray49);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException52 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) dimensionMismatchException31, (org.apache.commons.math.exception.util.Localizable) localizedFormats32, (org.apache.commons.math.exception.util.Localizable) localizedFormats33, objArray49);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("start position ({0})", objArray49);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable10, objArray49);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray49);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray49);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.6108652381980153d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.optimization.OptimizationException optimizationException17 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray15);
        org.apache.commons.math.optimization.OptimizationException optimizationException18 = new org.apache.commons.math.optimization.OptimizationException("", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray15);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("hi!", objArray25);
        java.lang.Object[] objArray27 = mathException26.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray27);
        java.lang.String str30 = convergenceException29.getPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "cannot normalize a zero norm vector" + "'", str30.equals("cannot normalize a zero norm vector"));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.6917615721593859d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7701235127579081d + "'", double1 == 0.7701235127579081d);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 6, (java.lang.Number) 1.0d, (java.lang.Number) (short) -1);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0d + "'", number5.equals(1.0d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) -1 + "'", number6.equals((short) -1));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(1.4E-45f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(2.993222846126381d, 2.0634370688955608d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.92978577723082d + "'", double2 == 0.92978577723082d);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter1 = new org.apache.commons.math.optimization.fitting.GaussianFitter(differentiableMultivariateVectorialOptimizer0);
        gaussianFitter1.addObservedPoint((double) 1L, (double) (byte) -1);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint5 = null;
        gaussianFitter1.addObservedPoint(weightedObservedPoint5);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray7 = gaussianFitter1.getObservations();
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = gaussianFitter1.getObservations();
        gaussianFitter1.addObservedPoint(0.8414709848078965d, (-0.5322988220742139d));
        org.junit.Assert.assertNotNull(weightedObservedPointArray7);
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.2676506002282294E31d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 37.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.apache.commons.math.analysis.function.Gaussian gaussian3 = new org.apache.commons.math.analysis.function.Gaussian(0.44807597941469024d, 1.3396159781079675d, 0.19627573656217087d);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException(localizable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) zeroException1);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (-1L), (double) 6.0f, (-0.9999999999999999d), 1.8420244994350716d, (double) (-1L));
        int int6 = levenbergMarquardtOptimizer5.getJacobianEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker7 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        double double8 = levenbergMarquardtOptimizer5.getChiSquare();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) 1);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        double double1 = org.apache.commons.math.util.FastMath.log(0.6962609014508692d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3620308304831553d) + "'", double1 == (-0.3620308304831553d));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        incrementor0.setMaximalCount(35);
        incrementor0.resetCount();
        incrementor0.incrementCount(0);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(Double.NaN, 99.99999999999999d, (-0.9999999999999999d));
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.46937855952831703d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.469378559528317d) + "'", double1 == (-0.469378559528317d));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker7 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        int int8 = levenbergMarquardtOptimizer5.getMaxEvaluations();
        double double9 = levenbergMarquardtOptimizer5.getRMS();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter10 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint(0.8657694832396586d, 1.786706395136E12d, (double) (-1.0f));
        double double15 = weightedObservedPoint14.getY();
        gaussianFitter10.addObservedPoint(weightedObservedPoint14);
        double double17 = weightedObservedPoint14.getWeight();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8657694832396586d + "'", double17 == 0.8657694832396586d);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(100, (int) (short) 10);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ALPHA;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.optimization.OptimizationException optimizationException10 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray8);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException(localizable1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray8);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException14 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (int) 'a', (int) 'a');
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable22 = mathException21.getSpecificPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer25 = null;
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter26 = new org.apache.commons.math.optimization.fitting.GaussianFitter(differentiableMultivariateVectorialOptimizer25);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray27 = gaussianFitter26.getObservations();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathException21, (org.apache.commons.math.exception.util.Localizable) localizedFormats23, localizable24, (java.lang.Object[]) weightedObservedPointArray27);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, (org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Object[]) weightedObservedPointArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ALPHA + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ALPHA));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNull(localizable22);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertNotNull(weightedObservedPointArray27);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter7 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        gaussianFitter7.addObservedPoint(0.0d, Double.NaN);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer16 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int17 = levenbergMarquardtOptimizer16.getEvaluations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer23 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int24 = levenbergMarquardtOptimizer23.getEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker25 = levenbergMarquardtOptimizer23.getConvergenceChecker();
        int int26 = levenbergMarquardtOptimizer23.getMaxEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker27 = levenbergMarquardtOptimizer23.getConvergenceChecker();
        levenbergMarquardtOptimizer16.setConvergenceChecker(vectorialPointValuePairConvergenceChecker27);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter29 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer16);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter30 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer16);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric31 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray38 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray42 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair44 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray38, doubleArray42, false);
        double[] doubleArray45 = vectorialPointValuePair44.getValueRef();
        double[] doubleArray46 = vectorialPointValuePair44.getValueRef();
        double[] doubleArray47 = vectorialPointValuePair44.getValueRef();
        double double48 = parametric31.value((double) (short) 1, doubleArray47);
        double[] doubleArray54 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray58 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair60 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray54, doubleArray58, false);
        double[] doubleArray61 = vectorialPointValuePair60.getPoint();
        double[] doubleArray62 = vectorialPointValuePair60.getPointRef();
        double[] doubleArray63 = vectorialPointValuePair60.getPointRef();
        double[] doubleArray64 = gaussianFitter30.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric31, doubleArray63);
        double[] doubleArray70 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray74 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair76 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray70, doubleArray74, false);
        double[] doubleArray77 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair78 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray70, doubleArray77);
        double[] doubleArray84 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray88 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair90 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray84, doubleArray88, false);
        double[] doubleArray91 = vectorialPointValuePair90.getValueRef();
        double[] doubleArray92 = vectorialPointValuePair90.getValueRef();
        double[] doubleArray93 = vectorialPointValuePair90.getValueRef();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair95 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray70, doubleArray93, true);
        double[] doubleArray96 = vectorialPointValuePair95.getPoint();
        try {
            double[] doubleArray97 = gaussianFitter7.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric31, doubleArray96);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 5 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker27);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.23501091433620364d + "'", double48 == 0.23501091433620364d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray96);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        double double1 = org.apache.commons.math.util.FastMath.expm1(36.40054944640259d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.435136490653474E15d + "'", double1 == 6.435136490653474E15d);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        double double7 = levenbergMarquardtOptimizer5.getChiSquare();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter8 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer14 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int15 = levenbergMarquardtOptimizer14.getEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker16 = levenbergMarquardtOptimizer14.getConvergenceChecker();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker19 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (-1L), (double) (short) 10);
        double double20 = simpleVectorialValueChecker19.getAbsoluteThreshold();
        levenbergMarquardtOptimizer14.setConvergenceChecker((org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair>) simpleVectorialValueChecker19);
        levenbergMarquardtOptimizer5.setConvergenceChecker((org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair>) simpleVectorialValueChecker19);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 10.0d + "'", double20 == 10.0d);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric0 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray7 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray11 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair13 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray7, doubleArray11, false);
        double[] doubleArray14 = vectorialPointValuePair13.getValueRef();
        double[] doubleArray15 = vectorialPointValuePair13.getValueRef();
        double[] doubleArray16 = vectorialPointValuePair13.getValueRef();
        double double17 = parametric0.value((double) (short) 1, doubleArray16);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric18 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray25 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray29 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair31 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray25, doubleArray29, false);
        double[] doubleArray32 = vectorialPointValuePair31.getValueRef();
        double[] doubleArray33 = vectorialPointValuePair31.getValueRef();
        double[] doubleArray34 = vectorialPointValuePair31.getValueRef();
        double double35 = parametric18.value((double) (short) 1, doubleArray34);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair36 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray34);
        double[] doubleArray37 = vectorialPointValuePair36.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.23501091433620364d + "'", double17 == 0.23501091433620364d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.23501091433620364d + "'", double35 == 0.23501091433620364d);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS));
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 4.61512051684126d, (java.lang.Number) 1023.0052296419631d, (java.lang.Number) 0.36787944117144233d);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.011398350868612364d);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH;
        org.apache.commons.math.exception.ConvergenceException convergenceException1 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("hi!", objArray12);
        org.apache.commons.math.optimization.OptimizationException optimizationException14 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray12);
        org.apache.commons.math.optimization.OptimizationException optimizationException15 = new org.apache.commons.math.optimization.OptimizationException("", objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray12);
        java.lang.Object[] objArray18 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException1, "hi!", objArray18);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.0d);
        java.lang.Number number23 = notStrictlyPositiveException22.getMin();
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException22);
        org.apache.commons.math.exception.util.Localizable localizable25 = notStrictlyPositiveException22.getSpecificPattern();
        java.lang.Object[] objArray26 = notStrictlyPositiveException22.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException19, "", objArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = convergenceException27.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0 + "'", number23.equals(0));
        org.junit.Assert.assertNull(localizable25);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNull(localizable28);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint((double) 4.7683716E-7f, 3.141592653589793d, 35.0d);
        double double4 = weightedObservedPoint3.getWeight();
        double double5 = weightedObservedPoint3.getX();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.76837158203125E-7d + "'", double4 == 4.76837158203125E-7d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.141592653589793d + "'", double5 == 3.141592653589793d);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0L, 4.7683716E-7f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.7683716E-7f + "'", float2 == 4.7683716E-7f);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.2676506002282294E31d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2676506002282294E31d + "'", double1 == 1.2676506002282294E31d);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.BETA;
        org.apache.commons.math.exception.ConvergenceException convergenceException5 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats4);
        org.apache.commons.math.exception.ZeroException zeroException6 = new org.apache.commons.math.exception.ZeroException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.optimization.OptimizationException optimizationException17 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray15);
        org.apache.commons.math.optimization.OptimizationException optimizationException18 = new org.apache.commons.math.optimization.OptimizationException("", objArray15);
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("hi!", objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException18, "", objArray24);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) zeroException6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray24);
        java.lang.Object[] objArray28 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray24);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalStateException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BETA + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount((-51));
        int int3 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.3518432295756951d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 21.0779393487549d);
        java.lang.Object[] objArray2 = tooManyEvaluationsException1.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        float float2 = org.apache.commons.math.util.FastMath.scalb(1.4E-45f, 2147483647);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats3, (-1L), localizedFormats5, localizedFormats6 };
        org.apache.commons.math.optimization.OptimizationException optimizationException8 = new org.apache.commons.math.optimization.OptimizationException("denominator", objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable1, objArray7);
        org.apache.commons.math.optimization.OptimizationException optimizationException10 = new org.apache.commons.math.optimization.OptimizationException("sample size ({0}) exceeds collection size ({1})", objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) (byte) 1, (int) '4');
        org.apache.commons.math.exception.util.Localizable localizable4 = dimensionMismatchException3.getGeneralPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.BETA;
        org.apache.commons.math.exception.ConvergenceException convergenceException6 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.ALPHA;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException(localizable7, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray14);
        java.lang.Object[] objArray18 = mathIllegalStateException17.getArguments();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("hi!", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getSpecificPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer29 = null;
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter30 = new org.apache.commons.math.optimization.fitting.GaussianFitter(differentiableMultivariateVectorialOptimizer29);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray31 = gaussianFitter30.getObservations();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException32 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathException25, (org.apache.commons.math.exception.util.Localizable) localizedFormats27, localizable28, (java.lang.Object[]) weightedObservedPointArray31);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException33 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Object[]) weightedObservedPointArray31);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalStateException17, "sample size ({0}) exceeds collection size ({1})", (java.lang.Object[]) weightedObservedPointArray31);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) dimensionMismatchException3, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) weightedObservedPointArray31);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.0d);
        java.lang.Number number38 = notStrictlyPositiveException37.getMin();
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException37);
        org.apache.commons.math.exception.util.Localizable localizable40 = notStrictlyPositiveException37.getSpecificPattern();
        org.apache.commons.math.optimization.OptimizationException optimizationException41 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) notStrictlyPositiveException37);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        java.lang.Object[] objArray48 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("hi!", objArray48);
        org.apache.commons.math.exception.util.Localizable localizable50 = mathException49.getSpecificPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer53 = null;
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter54 = new org.apache.commons.math.optimization.fitting.GaussianFitter(differentiableMultivariateVectorialOptimizer53);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray55 = gaussianFitter54.getObservations();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException56 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathException49, (org.apache.commons.math.exception.util.Localizable) localizedFormats51, localizable52, (java.lang.Object[]) weightedObservedPointArray55);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException57 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats42, (org.apache.commons.math.exception.util.Localizable) localizedFormats43, (java.lang.Object[]) weightedObservedPointArray55);
        org.apache.commons.math.exception.util.Localizable localizable58 = mathIllegalStateException57.getGeneralPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats59 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer60 = null;
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter61 = new org.apache.commons.math.optimization.fitting.GaussianFitter(differentiableMultivariateVectorialOptimizer60);
        gaussianFitter61.addObservedPoint((double) (short) 10, (double) 0, (-1.0d));
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray66 = gaussianFitter61.getObservations();
        org.apache.commons.math.exception.ConvergenceException convergenceException67 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats59, (java.lang.Object[]) weightedObservedPointArray66);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException37, localizable58, (java.lang.Object[]) weightedObservedPointArray66);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats69 = org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats70 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException71 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats70);
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats74 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        java.lang.Object[] objArray81 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException("hi!", objArray81);
        org.apache.commons.math.optimization.OptimizationException optimizationException83 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray81);
        org.apache.commons.math.optimization.OptimizationException optimizationException84 = new org.apache.commons.math.optimization.OptimizationException("", objArray81);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException85 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable73, (org.apache.commons.math.exception.util.Localizable) localizedFormats74, objArray81);
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nullArgumentException71, "", objArray81);
        org.apache.commons.math.exception.ConvergenceException convergenceException87 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats69, objArray81);
        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException(localizable58, objArray81);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats89 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM;
        java.lang.Object[] objArray90 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException91 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) convergenceException35, localizable58, (org.apache.commons.math.exception.util.Localizable) localizedFormats89, objArray90);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BETA + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ALPHA + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.ALPHA));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNull(localizable26);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertNotNull(weightedObservedPointArray31);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 0 + "'", number38.equals(0));
        org.junit.Assert.assertNull(localizable40);
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNull(localizable50);
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertNotNull(weightedObservedPointArray55);
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats59.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray66);
        org.junit.Assert.assertTrue("'" + localizedFormats69 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats69.equals(org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats70.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats74.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertTrue("'" + localizedFormats89 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM + "'", localizedFormats89.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM));
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 32, (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5516549825285468d + "'", double2 == 0.5516549825285468d);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.apache.commons.math.exception.ZeroException zeroException0 = new org.apache.commons.math.exception.ZeroException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("hi!", objArray12);
        org.apache.commons.math.optimization.OptimizationException optimizationException14 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray12);
        org.apache.commons.math.optimization.OptimizationException optimizationException15 = new org.apache.commons.math.optimization.OptimizationException("", objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray12);
        java.lang.Object[] objArray18 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) zeroException0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray18);
        java.lang.Number number20 = zeroException0.getArgument();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray28);
        org.apache.commons.math.optimization.OptimizationException optimizationException30 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray28);
        org.apache.commons.math.optimization.OptimizationException optimizationException31 = new org.apache.commons.math.optimization.OptimizationException("", objArray28);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        java.lang.Object[] objArray34 = new java.lang.Object[] {};
        org.apache.commons.math.exception.ConvergenceException convergenceException35 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) optimizationException31, (org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray34);
        org.apache.commons.math.exception.util.Localizable localizable37 = optimizationException31.getSpecificPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("hi!", objArray47);
        org.apache.commons.math.optimization.OptimizationException optimizationException49 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray47);
        org.apache.commons.math.optimization.OptimizationException optimizationException50 = new org.apache.commons.math.optimization.OptimizationException("", objArray47);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, (org.apache.commons.math.exception.util.Localizable) localizedFormats40, objArray47);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException52 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) optimizationException31, (org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray47);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats53 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats55 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException("hi!", objArray62);
        org.apache.commons.math.optimization.OptimizationException optimizationException64 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray62);
        org.apache.commons.math.optimization.OptimizationException optimizationException65 = new org.apache.commons.math.optimization.OptimizationException("", objArray62);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, (org.apache.commons.math.exception.util.Localizable) localizedFormats55, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats53, objArray62);
        java.lang.Object[] objArray68 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray62);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException69 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException0, (org.apache.commons.math.exception.util.Localizable) localizedFormats21, (org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray62);
        java.lang.Object[] objArray70 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray62);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0 + "'", number20.equals(0));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNull(localizable37);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + localizedFormats53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats55.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(objArray70);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (-1L), (double) (short) 10);
        double double3 = simpleVectorialValueChecker2.getRelativeThreshold();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker7 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (-1L), (double) (short) 10);
        double double8 = simpleVectorialValueChecker7.getRelativeThreshold();
        double[] doubleArray15 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray19 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair21 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray19, false);
        double[] doubleArray27 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray31 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair33 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray27, doubleArray31, false);
        boolean boolean34 = simpleVectorialValueChecker7.converged((int) (byte) 100, vectorialPointValuePair21, vectorialPointValuePair33);
        double[] doubleArray35 = vectorialPointValuePair33.getValueRef();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker38 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (-1L), (double) (short) 10);
        double double39 = simpleVectorialValueChecker38.getRelativeThreshold();
        double[] doubleArray46 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray50 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair52 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray46, doubleArray50, false);
        double[] doubleArray58 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray62 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair64 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray58, doubleArray62, false);
        boolean boolean65 = simpleVectorialValueChecker38.converged((int) (byte) 100, vectorialPointValuePair52, vectorialPointValuePair64);
        boolean boolean66 = simpleVectorialValueChecker2.converged((int) (byte) 0, vectorialPointValuePair33, vectorialPointValuePair64);
        double double67 = simpleVectorialValueChecker2.getAbsoluteThreshold();
        double double68 = simpleVectorialValueChecker2.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-1.0d) + "'", double39 == (-1.0d));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 10.0d + "'", double68 == 10.0d);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        java.lang.Object[] objArray4 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("hi!", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException5.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException5);
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getSpecificPattern();
        java.lang.Object[] objArray9 = convergenceException7.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        float float2 = org.apache.commons.math.util.FastMath.max(35.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        org.apache.commons.math.exception.ConvergenceException convergenceException1 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        java.lang.Object[] objArray10 = new java.lang.Object[] { localizedFormats6, (-1L), localizedFormats8, localizedFormats9 };
        org.apache.commons.math.optimization.OptimizationException optimizationException11 = new org.apache.commons.math.optimization.OptimizationException("denominator", objArray10);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(localizable4, objArray10);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) (-1.0d), objArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException14 = new org.apache.commons.math.optimization.OptimizationException("denominator", objArray10);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("cannot normalize a zero norm vector", objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.7081359096854514E-204d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7081359096854514E-204d + "'", double1 == 1.7081359096854514E-204d);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer12 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int13 = levenbergMarquardtOptimizer12.getEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker14 = levenbergMarquardtOptimizer12.getConvergenceChecker();
        int int15 = levenbergMarquardtOptimizer12.getMaxEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker16 = levenbergMarquardtOptimizer12.getConvergenceChecker();
        levenbergMarquardtOptimizer5.setConvergenceChecker(vectorialPointValuePairConvergenceChecker16);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter18 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker19 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        int int20 = levenbergMarquardtOptimizer5.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker16);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 32L, (double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.6108652381980153d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.optimization.OptimizationException optimizationException17 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray15);
        org.apache.commons.math.optimization.OptimizationException optimizationException18 = new org.apache.commons.math.optimization.OptimizationException("", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray15);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("hi!", objArray25);
        java.lang.Object[] objArray27 = mathException26.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray27);
        java.lang.Object[] objArray34 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("hi!", objArray34);
        org.apache.commons.math.exception.ConvergenceException convergenceException36 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray34);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer2 = null;
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter3 = new org.apache.commons.math.optimization.fitting.GaussianFitter(differentiableMultivariateVectorialOptimizer2);
        gaussianFitter3.addObservedPoint((double) (short) 10, (double) 0, (-1.0d));
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = gaussianFitter3.getObservations();
        org.apache.commons.math.exception.ConvergenceException convergenceException9 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) weightedObservedPointArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray16);
        java.lang.Object[] objArray18 = mathException17.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        java.lang.Object[] objArray27 = new java.lang.Object[] { localizedFormats23, (-1L), localizedFormats25, localizedFormats26 };
        org.apache.commons.math.optimization.OptimizationException optimizationException28 = new org.apache.commons.math.optimization.OptimizationException("denominator", objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathException17, localizable19, (org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray27);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) convergenceException9, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, (org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray27);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math.exception.ConvergenceException convergenceException35 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats34);
        java.lang.Object[] objArray36 = convergenceException35.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) convergenceException9, (org.apache.commons.math.exception.util.Localizable) localizedFormats32, (org.apache.commons.math.exception.util.Localizable) localizedFormats33, objArray36);
        org.apache.commons.math.exception.ConvergenceException convergenceException38 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray36);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException1 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.optimization.OptimizationException optimizationException13 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray11);
        org.apache.commons.math.optimization.OptimizationException optimizationException14 = new org.apache.commons.math.optimization.OptimizationException("", objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nullArgumentException1, "", objArray11);
        org.apache.commons.math.optimization.OptimizationException optimizationException17 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) nullArgumentException1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        org.apache.commons.math.exception.ZeroException zeroException19 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats18);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("hi!", objArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = mathException27.getSpecificPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer31 = null;
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter32 = new org.apache.commons.math.optimization.fitting.GaussianFitter(differentiableMultivariateVectorialOptimizer31);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray33 = gaussianFitter32.getObservations();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException34 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathException27, (org.apache.commons.math.exception.util.Localizable) localizedFormats29, localizable30, (java.lang.Object[]) weightedObservedPointArray33);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException35 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Object[]) weightedObservedPointArray33);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) nullArgumentException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Object[]) weightedObservedPointArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNull(localizable28);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertNotNull(weightedObservedPointArray33);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5585053606381855d + "'", double1 == 0.5585053606381855d);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test67");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 1, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test68");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer12 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int13 = levenbergMarquardtOptimizer12.getEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker14 = levenbergMarquardtOptimizer12.getConvergenceChecker();
        int int15 = levenbergMarquardtOptimizer12.getMaxEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker16 = levenbergMarquardtOptimizer12.getConvergenceChecker();
        levenbergMarquardtOptimizer5.setConvergenceChecker(vectorialPointValuePairConvergenceChecker16);
        double double18 = levenbergMarquardtOptimizer5.getRMS();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker16);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test69");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.81474976710656E14d, (java.lang.Number) (-1L), true);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test70");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 100, 1.544067997015931d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test71");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math.exception.ConvergenceException convergenceException1 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test72");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.optimization.OptimizationException optimizationException13 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray11);
        org.apache.commons.math.optimization.OptimizationException optimizationException14 = new org.apache.commons.math.optimization.OptimizationException("", objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray11);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.ZeroException zeroException20 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats19);
        java.lang.Object[] objArray21 = zeroException20.getArguments();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalStateException17, "", objArray21);
        java.lang.Object[] objArray23 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray21);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test73");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.7081359096854514E-204d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7081359096854518E-204d + "'", double1 == 1.7081359096854518E-204d);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test74");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) '#');
        incrementor0.incrementCount((-1023));
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test75");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION;
        org.apache.commons.math.exception.ConvergenceException convergenceException1 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer3 = null;
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter4 = new org.apache.commons.math.optimization.fitting.GaussianFitter(differentiableMultivariateVectorialOptimizer3);
        gaussianFitter4.addObservedPoint((double) (short) 10, (double) 0, (-1.0d));
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray9 = gaussianFitter4.getObservations();
        org.apache.commons.math.exception.ConvergenceException convergenceException10 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) weightedObservedPointArray9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray17);
        java.lang.Object[] objArray19 = mathException18.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        java.lang.Object[] objArray28 = new java.lang.Object[] { localizedFormats24, (-1L), localizedFormats26, localizedFormats27 };
        org.apache.commons.math.optimization.OptimizationException optimizationException29 = new org.apache.commons.math.optimization.OptimizationException("denominator", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray28);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathException18, localizable20, (org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray28);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) convergenceException10, (org.apache.commons.math.exception.util.Localizable) localizedFormats11, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray28);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math.exception.ConvergenceException convergenceException36 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats35);
        java.lang.Object[] objArray37 = convergenceException36.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) convergenceException10, (org.apache.commons.math.exception.util.Localizable) localizedFormats33, (org.apache.commons.math.exception.util.Localizable) localizedFormats34, objArray37);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray37);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertNotNull(objArray37);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test76");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        double double7 = levenbergMarquardtOptimizer5.getChiSquare();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter8 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        gaussianFitter8.clearObservations();
        gaussianFitter8.addObservedPoint((double) 10.000001f, 1.8420244994350716d);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray13 = gaussianFitter8.getObservations();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray13);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test77");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint((double) (short) 0, 0.0d, (double) '#');
        double double4 = weightedObservedPoint3.getY();
        double double5 = weightedObservedPoint3.getWeight();
        double double6 = weightedObservedPoint3.getX();
        double double7 = weightedObservedPoint3.getWeight();
        double double8 = weightedObservedPoint3.getWeight();
        double double9 = weightedObservedPoint3.getX();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 35.0d + "'", double4 == 35.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test78");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer2 = null;
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter3 = new org.apache.commons.math.optimization.fitting.GaussianFitter(differentiableMultivariateVectorialOptimizer2);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray4 = gaussianFitter3.getObservations();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0, "{0}", (java.lang.Object[]) weightedObservedPointArray4);
        java.lang.String str6 = convergenceException5.getPattern();
        java.lang.Throwable[] throwableArray7 = convergenceException5.getSuppressed();
        org.junit.Assert.assertNotNull(weightedObservedPointArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0}" + "'", str6.equals("{0}"));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test79");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int6 = levenbergMarquardtOptimizer5.getJacobianEvaluations();
        double double7 = levenbergMarquardtOptimizer5.getChiSquare();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter8 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test80");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker0 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double double1 = simpleVectorialValueChecker0.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-306d + "'", double1 == 2.2250738585072014E-306d);
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test81");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException1 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        java.lang.Object[] objArray2 = nullArgumentException1.getArguments();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test82");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.optimization.OptimizationException optimizationException2 = new org.apache.commons.math.optimization.OptimizationException("{0}", objArray1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        java.lang.Object[] objArray9 = new java.lang.Object[] { localizedFormats5, (-1L), localizedFormats7, localizedFormats8 };
        org.apache.commons.math.optimization.OptimizationException optimizationException10 = new org.apache.commons.math.optimization.OptimizationException("denominator", objArray9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.optimization.OptimizationException optimizationException24 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray22);
        org.apache.commons.math.optimization.OptimizationException optimizationException25 = new org.apache.commons.math.optimization.OptimizationException("", objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, (org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray22);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) optimizationException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test83");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test84");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.0d);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getSpecificPattern();
        org.apache.commons.math.optimization.OptimizationException optimizationException6 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) optimizationException6);
        java.lang.Throwable[] throwableArray8 = mathRuntimeException7.getSuppressed();
        org.apache.commons.math.optimization.OptimizationException optimizationException9 = new org.apache.commons.math.optimization.OptimizationException("{0}", (java.lang.Object[]) throwableArray8);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test85() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test85");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker7 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        int int8 = levenbergMarquardtOptimizer5.getMaxEvaluations();
        double double9 = levenbergMarquardtOptimizer5.getRMS();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter10 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray11 = gaussianFitter10.getObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer17 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int18 = levenbergMarquardtOptimizer17.getEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker19 = levenbergMarquardtOptimizer17.getConvergenceChecker();
        int int20 = levenbergMarquardtOptimizer17.getMaxEvaluations();
        double double21 = levenbergMarquardtOptimizer17.getRMS();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter22 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer17);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer28 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 10.0d, (double) 9.536743E-7f, (double) '#', (double) 10.000001f);
        int int29 = levenbergMarquardtOptimizer28.getEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter30 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer28);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric31 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray38 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray42 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair44 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray38, doubleArray42, false);
        double[] doubleArray45 = parametric31.gradient(3.2710663101885897d, doubleArray42);
        double[] doubleArray51 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray55 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair57 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray51, doubleArray55, false);
        double[] doubleArray58 = vectorialPointValuePair57.getPoint();
        double[] doubleArray59 = gaussianFitter30.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric31, doubleArray58);
        double[] doubleArray65 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray69 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair71 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray65, doubleArray69, false);
        double[] doubleArray72 = vectorialPointValuePair71.getPoint();
        double[] doubleArray73 = vectorialPointValuePair71.getPointRef();
        double[] doubleArray77 = new double[] { 3349.571901633116d, (short) -1, (-1.0d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair79 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray73, doubleArray77, false);
        double[] doubleArray80 = gaussianFitter22.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric31, doubleArray73);
        double[] doubleArray86 = new double[] { 1, '4', (short) 0, 'a', 100 };
        double[] doubleArray90 = new double[] { 1, (short) -1, 1.1752011936438014d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair92 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray86, doubleArray90, false);
        double[] doubleArray93 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair94 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray86, doubleArray93);
        double[] doubleArray95 = gaussianFitter10.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric31, doubleArray86);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(weightedObservedPointArray11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray95);
    }

    @Test
    public void test86() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test86");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 97.00001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267884806958816d + "'", double1 == 5.267884806958816d);
    }

    @Test
    public void test87() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test87");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        java.lang.Object[] objArray9 = new java.lang.Object[] { localizedFormats5, (-1L), localizedFormats7, localizedFormats8 };
        org.apache.commons.math.optimization.OptimizationException optimizationException10 = new org.apache.commons.math.optimization.OptimizationException("denominator", objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable3, objArray9);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) (-1.0d), objArray9);
        org.apache.commons.math.optimization.OptimizationException optimizationException13 = new org.apache.commons.math.optimization.OptimizationException("denominator", objArray9);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test88() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test88");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 0.17453292519943295d);
        org.apache.commons.math.exception.util.Localizable localizable2 = tooManyEvaluationsException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test89() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test89");
        double double2 = org.apache.commons.math.util.FastMath.hypot(4.61512051684126d, 2.2250738585072014E-306d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.61512051684126d + "'", double2 == 4.61512051684126d);
    }

    @Test
    public void test90() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test90");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) (byte) -1, 100);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS));
    }

    @Test
    public void test91() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test91");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getCount();
        int int3 = incrementor0.getCount();
        int int4 = incrementor0.getMaximalCount();
        int int5 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test92() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test92");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-6L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test93() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test93");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException5 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 35, (-1023));
        int int6 = dimensionMismatchException5.getDimension();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1023) + "'", int6 == (-1023));
    }

    @Test
    public void test94() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test94");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint(0.17453292519943295d, (double) 1.2676506E31f, 0.0d);
    }

    @Test
    public void test95() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test95");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer1 = null;
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter2 = new org.apache.commons.math.optimization.fitting.GaussianFitter(differentiableMultivariateVectorialOptimizer1);
        gaussianFitter2.addObservedPoint((double) (short) 10, (double) 0, (-1.0d));
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray7 = gaussianFitter2.getObservations();
        org.apache.commons.math.exception.ConvergenceException convergenceException8 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.0d);
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException10.getGeneralPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.optimization.OptimizationException optimizationException23 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray21);
        org.apache.commons.math.optimization.OptimizationException optimizationException24 = new org.apache.commons.math.optimization.OptimizationException("", objArray21);
        java.lang.Object[] objArray30 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException24, "", objArray30);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException33 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Number) 0.6108652381980153d, objArray30);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException34 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException8, localizable11, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray30);
        org.apache.commons.math.optimization.OptimizationException optimizationException35 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathIllegalStateException34);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray7);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test96() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test96");
        double double2 = org.apache.commons.math.util.FastMath.scalb(1.5707963267948397d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1415926535896794d + "'", double2 == 3.1415926535896794d);
    }

    @Test
    public void test97() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test97");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((-51.0d), (double) 6);
        double double3 = simpleVectorialValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-51.0d) + "'", double3 == (-51.0d));
    }

    @Test
    public void test98() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test98");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.4342944819032518d, (java.lang.Number) (byte) 1, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 0.6108652381980153d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.optimization.OptimizationException optimizationException23 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray21);
        org.apache.commons.math.optimization.OptimizationException optimizationException24 = new org.apache.commons.math.optimization.OptimizationException("", objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, (org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray21);
        java.lang.Object[] objArray31 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("hi!", objArray31);
        java.lang.Object[] objArray33 = mathException32.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException10, (org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray33);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.ALPHA;
        java.lang.Object[] objArray45 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("hi!", objArray45);
        org.apache.commons.math.optimization.OptimizationException optimizationException47 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray45);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException48 = new org.apache.commons.math.exception.MathIllegalStateException(localizable38, (org.apache.commons.math.exception.util.Localizable) localizedFormats39, objArray45);
        java.lang.Object[] objArray49 = mathIllegalStateException48.getArguments();
        org.apache.commons.math.optimization.OptimizationException optimizationException50 = new org.apache.commons.math.optimization.OptimizationException("function is not differentiable", objArray49);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_ONE_PREVIOUS_POINT;
        java.lang.Object[] objArray59 = new java.lang.Object[] { 0L, 1, 100.0d };
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException("hi!", objArray59);
        org.apache.commons.math.optimization.OptimizationException optimizationException61 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray59);
        org.apache.commons.math.optimization.OptimizationException optimizationException62 = new org.apache.commons.math.optimization.OptimizationException("", objArray59);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats63 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats64 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        java.lang.Object[] objArray65 = new java.lang.Object[] {};
        org.apache.commons.math.exception.ConvergenceException convergenceException66 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats64, objArray65);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) optimizationException62, (org.apache.commons.math.exception.util.Localizable) localizedFormats63, objArray65);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException68 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) optimizationException50, (org.apache.commons.math.exception.util.Localizable) localizedFormats51, (org.apache.commons.math.exception.util.Localizable) localizedFormats52, objArray65);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException69 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Number) 32L, objArray65);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, localizable5, objArray65);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray65);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ALPHA + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.ALPHA));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER + "'", localizedFormats51.equals(org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_ONE_PREVIOUS_POINT + "'", localizedFormats52.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_ONE_PREVIOUS_POINT));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertTrue("'" + localizedFormats63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats63.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats64 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats64.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
        org.junit.Assert.assertNotNull(objArray65);
    }
}

