import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(73.0d, 0.22919043450815735d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.567656742117295d + "'", double2 == 1.567656742117295d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 7.930067261567154E14d);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        randomDataGenerator5.reSeed();
//        double double11 = randomDataGenerator5.nextChiSquare((double) 10L);
//        double double14 = randomDataGenerator5.nextBeta(0.23621296409901363d, (double) '#');
//        double double16 = randomDataGenerator5.nextChiSquare(4.5916503662245255E10d);
//        double double19 = randomDataGenerator5.nextBeta((double) 3, 58.0019903315599d);
//        int int22 = randomDataGenerator5.nextSecureInt(85, 91);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 12.475659145295907d + "'", double11 == 12.475659145295907d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.284624380370703E-8d + "'", double14 == 3.284624380370703E-8d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.591689758997885E10d + "'", double16 == 4.591689758997885E10d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.03758570895856344d + "'", double19 == 0.03758570895856344d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 87 + "'", int22 == 87);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 122249082);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 32, (long) 60);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 60L + "'", long2 == 60L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math3.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        randomDataGenerator5.reSeed();
//        double double12 = randomDataGenerator5.nextWeibull(0.2179200458706742d, 3.7244046011365866d);
//        double double15 = randomDataGenerator5.nextWeibull(67.57542045537947d, (double) '4');
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.99211890308882E-6d + "'", double12 == 4.99211890308882E-6d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 51.5278454810413d + "'", double15 == 51.5278454810413d);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0.07277703f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 85);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int1 = org.apache.commons.math3.util.FastMath.round(0.07277703f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        try {
            org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(2.6881171418161356E43d, 5729.5779513082325d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (26,881,171,418,161,356,000,000,000,000,000,000,000,000,000) must be strictly less than upper bound (5,729.578)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution3 = new org.apache.commons.math3.distribution.UniformRealDistribution((-1.0d), (double) 0L, (double) (short) -1);
        boolean boolean4 = uniformRealDistribution3.isSupportLowerBoundInclusive();
        double double5 = uniformRealDistribution3.getNumericalVariance();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08333333333333333d + "'", double5 == 0.08333333333333333d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(11.857106227542126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 96);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 96 + "'", int1 == 96);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(1.13300909670996045E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.13300909670996058E18d + "'", double1 == 1.13300909670996058E18d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math3.special.Gamma.trigamma(3.0120109766461515E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.102267238516254E33d + "'", double1 == 1.102267238516254E33d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) 7.180704E8f, 5.605475678368494d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.180704E8d + "'", double2 == 7.180704E8d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) 'a', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.0d, (double) 1);
        double double3 = uniformRealDistribution2.getSupportUpperBound();
        double double4 = uniformRealDistribution2.getSupportUpperBound();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math3.special.Gamma.gamma(40.04519319891766d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.40853052162319E46d + "'", double1 == 2.40853052162319E46d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math3.special.Gamma.gamma(2.878762514980041d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7935922936138282d + "'", double1 == 1.7935922936138282d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double2 = org.apache.commons.math3.util.FastMath.log(0.24060429325792804d, 2.5271111700000036E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-13.581170437134261d) + "'", double2 == (-13.581170437134261d));
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextSecureInt(20, (int) 'a');
//        try {
//            int int8 = randomDataImpl0.nextInt(33, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (33) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 89 + "'", int5 == 89);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        double double1 = uniformRealDistribution0.getSupportLowerBound();
        double double3 = uniformRealDistribution0.cumulativeProbability((double) '#');
        double double5 = uniformRealDistribution0.cumulativeProbability(1.13300909670996058E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        double double4 = randomDataImpl0.nextExponential((double) '#');
//        randomDataImpl0.reSeed((long) 1);
//        try {
//            double double9 = randomDataImpl0.nextCauchy((-2.275948694363265E-5d), (-0.6206239346111186d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-0.621)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 24.66216116183221d + "'", double4 == 24.66216116183221d);
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(22026.465794806718d, 22025.465794806718d);
//        try {
//            double double6 = randomDataImpl0.nextUniform(0.01789962561529476d, 4.9E-324d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (0.018) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 36963.96450830522d + "'", double3 == 36963.96450830522d);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) (-1684074324264821833L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double4 = org.apache.commons.math3.special.Beta.logBeta(12.579105630001806d, 0.5403023058681398d, 0.2403534873896094d, 20);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.8611409112332922d) + "'", double4 == (-0.8611409112332922d));
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double4 = randomDataImpl0.nextUniform(0.0d, (double) (short) 100, true);
//        int int7 = randomDataImpl0.nextSecureInt(1, (int) (byte) 100);
//        org.apache.commons.math3.distribution.FDistribution fDistribution11 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
//        double double12 = fDistribution11.getSupportLowerBound();
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) fDistribution11);
//        double double14 = fDistribution11.getSupportLowerBound();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.493065556622483d + "'", double4 == 10.493065556622483d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 38 + "'", int7 == 38);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5d + "'", double13 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (-127));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 127L + "'", long1 == 127L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 1, (java.lang.Number) 3.661826586795296E-41d, (java.lang.Number) 100L);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray10 = numberIsTooLargeException9.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException4, localizable5, (java.lang.Object[]) throwableArray10);
        org.apache.commons.math3.exception.MathInternalError mathInternalError12 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        int int8 = randomDataImpl0.nextPascal((int) (short) 1, (double) (byte) 0);
//        double double11 = randomDataImpl0.nextCauchy((double) 16, Double.NaN);
//        long long14 = randomDataImpl0.nextLong((long) (-1), (long) 85);
//        randomDataImpl0.reSeedSecure((long) (byte) 10);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 55L + "'", long14 == 55L);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass2 = maxCountExceededException1.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException1, localizable3, objArray6);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = maxCountExceededException1.getContext();
        java.lang.Class<?> wildcardClass9 = maxCountExceededException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 1, (java.lang.Number) 3.661826586795296E-41d, (java.lang.Number) 100L);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getLo();
        java.lang.Number number6 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 3.661826586795296E-41d + "'", number4.equals(3.661826586795296E-41d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 3.661826586795296E-41d + "'", number5.equals(3.661826586795296E-41d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double4 = randomDataImpl0.nextUniform(0.0d, (double) (short) 100, true);
//        int int7 = randomDataImpl0.nextSecureInt(1, (int) (byte) 100);
//        org.apache.commons.math3.distribution.FDistribution fDistribution11 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
//        double double12 = fDistribution11.getSupportLowerBound();
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) fDistribution11);
//        double double16 = randomDataImpl0.nextGamma(1.7904931097838226d, 5729.5779513082325d);
//        int int19 = randomDataImpl0.nextSecureInt((int) (byte) 10, 312574995);
//        try {
//            int int22 = randomDataImpl0.nextInt(312574995, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (312,574,995) must be strictly less than upper bound (32)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 64.92956900495513d + "'", double4 == 64.92956900495513d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 14 + "'", int7 == 14);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3843.9032149331983d + "'", double16 == 3843.9032149331983d);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 70067968 + "'", int19 == 70067968);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(5.446130839245705d, 64.64335653228466d, (-2.356194490192345d));
        boolean boolean4 = fDistribution3.isSupportUpperBoundInclusive();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        double double9 = randomDataImpl0.nextT((double) (short) 1);
//        double double12 = randomDataImpl0.nextCauchy(0.23107014828793498d, (double) 7035070615930559438L);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.15355786007561786d) + "'", double9 == (-0.15355786007561786d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.4872900385144136E19d) + "'", double12 == (-1.4872900385144136E19d));
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.0000000000005d, 0.028192915962341632d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9722007956570669d + "'", double2 == 0.9722007956570669d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(0.22919043450815735d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22526000610152908d + "'", double1 == 0.22526000610152908d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) 22L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.584912845131592E9d + "'", double1 == 3.584912845131592E9d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math3.util.FastMath.acos(77.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 99328.0d, (java.lang.Number) (-0.09581311606133523d), (java.lang.Number) 59L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.03125d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03125d + "'", double2 == 0.03125d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        float float1 = org.apache.commons.math3.util.FastMath.ulp(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(126355559, 56, 126355559);
        double double4 = iterativeLegendreGaussIntegrator3.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-6d + "'", double4 == 1.0E-6d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(3, (double) (-1L), 0.0d);
        int int4 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = null;
        try {
            double double10 = iterativeLegendreGaussIntegrator3.integrate((int) (byte) 10, univariateFunction7, 3.7244046011365866d, 0.2229891714154522d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int int2 = org.apache.commons.math3.util.FastMath.max(3, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
        java.lang.Class<?> wildcardClass4 = intArray3.getClass();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 50);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
//        int int13 = randomDataGenerator5.nextPascal((int) (byte) 100, 0.7165313105737893d);
//        long long16 = randomDataGenerator5.nextSecureLong(0L, (long) 3);
//        int[] intArray19 = randomDataGenerator5.nextPermutation((int) '4', 20);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3L + "'", long16 == 3L);
//        org.junit.Assert.assertNotNull(intArray19);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math3.util.FastMath.rint(4.591689758997885E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.591689759E10d + "'", double1 == 4.591689759E10d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 61);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.064650843716541d + "'", double1 == 1.064650843716541d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 119.31169712162223d, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        boolean boolean3 = uniformRealDistribution2.isSupportConnected();
        double double5 = uniformRealDistribution2.cumulativeProbability(0.9093347211105907d);
        double double7 = uniformRealDistribution2.density(56.08352588738661d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math3.random.Well19937c well19937c0 = new org.apache.commons.math3.random.Well19937c();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c0);
        try {
            long long3 = randomDataGenerator1.nextPoisson((-1.4872900385144136E19d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-14,872,900,385,144,136,000)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 718070342, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 718070342L + "'", long2 == 718070342L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943298E-11d + "'", double1 == 1.7453292519943298E-11d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        boolean boolean4 = fDistribution3.isSupportUpperBoundInclusive();
        double double6 = fDistribution3.density(32.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.343603661293817E-4d + "'", double6 == 3.343603661293817E-4d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        long long2 = org.apache.commons.math3.util.FastMath.min(4491554327296166888L, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        double double4 = uniformRealDistribution2.density((double) 3);
        boolean boolean5 = uniformRealDistribution2.isSupportConnected();
        double double8 = uniformRealDistribution2.probability(0.23856920175694382d, (double) 3.12575008E8f);
        boolean boolean9 = uniformRealDistribution2.isSupportLowerBoundInclusive();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.22919043450815735d + "'", double8 == 0.22919043450815735d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math3.util.FastMath.log10(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14.899276870949834d + "'", double1 == 14.899276870949834d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(12.475659145295907d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3192870347648578d + "'", double1 == 2.3192870347648578d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(0.0d, (double) (short) -1, (double) 100, 58.0d);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double4 = org.apache.commons.math3.special.Beta.logBeta((-0.2619782247946564d), 1.5707963267948966d, 3.12575008E8d, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        well19937c1.setSeed(1);
        well19937c1.setSeed((int) (byte) 1);
        well19937c1.setSeed(18);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(23.17377526703116d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 0.24337046883404329d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 61, 99);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.593113932619261E176d + "'", double2 == 5.593113932619261E176d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
        randomDataImpl0.reSeedSecure((long) (short) 1);
        randomDataImpl0.reSeedSecure((long) 10);
        try {
            double double9 = randomDataImpl0.nextExponential(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double2 = org.apache.commons.math3.util.FastMath.min((-13.084024114284892d), (-0.6206239346111186d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-13.084024114284892d) + "'", double2 == (-13.084024114284892d));
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        double double7 = randomDataImpl0.nextChiSquare((double) 60L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 80 + "'", int5 == 80);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 44.15963849397288d + "'", double7 == 44.15963849397288d);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        java.lang.String str2 = randomDataGenerator0.nextSecureHexString(73);
//        try {
//            double double4 = randomDataGenerator0.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "fc022feb118bf1a5d0ed4749fd12f05756e6325976d28ff2dee03cb3ce8eafff0f96c5b9c" + "'", str2.equals("fc022feb118bf1a5d0ed4749fd12f05756e6325976d28ff2dee03cb3ce8eafff0f96c5b9c"));
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        double double5 = fDistribution3.density(0.0d);
        double double6 = fDistribution3.getDenominatorDegreesOfFreedom();
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        byte[] byteArray4 = new byte[] {};
        well19937c1.nextBytes(byteArray4);
        well19937c1.setSeed((long) 81);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataGenerator8.nextT(1.0E20d);
        try {
            double double13 = randomDataGenerator8.nextGaussian(2.3192870347648578d, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-4.175967833751397E-10d) + "'", double10 == (-4.175967833751397E-10d));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math3.util.FastMath.log10(22026.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.34293563488763d + "'", double1 == 4.34293563488763d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math3.special.Gamma.lanczos((double) 48);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2422139420990699d + "'", double1 == 1.2422139420990699d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        long long5 = well19937c4.nextLong();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        long long7 = well19937c4.nextLong();
        int int9 = well19937c4.nextInt(59);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4491554327296166888L + "'", long5 == 4491554327296166888L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1684074324264821833L) + "'", long7 == (-1684074324264821833L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 40 + "'", int9 == 40);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 22026.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        long long5 = well19937c4.nextLong();
        well19937c4.setSeed((long) 2147483647);
        long long8 = well19937c4.nextLong();
        boolean boolean9 = well19937c4.nextBoolean();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4491554327296166888L + "'", long5 == 4491554327296166888L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 7035070615930559438L + "'", long8 == 7035070615930559438L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100L, (java.lang.Number) 0, false);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator11 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(126355559, 56, 126355559);
        java.lang.Object[] objArray13 = new java.lang.Object[] { 4.9E-324d, 4.5916503662245255E10d, 56, 0.3678794411714424d };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray13);
        org.apache.commons.math3.exception.MathInternalError mathInternalError15 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray13);
        org.junit.Assert.assertNotNull(objArray13);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        int int8 = randomDataImpl0.nextPascal((int) (short) 1, (double) (byte) 0);
//        double double11 = randomDataImpl0.nextCauchy((double) 16, Double.NaN);
//        int[] intArray14 = randomDataImpl0.nextPermutation(100, 10);
//        try {
//            double double17 = randomDataImpl0.nextUniform((double) 56, 10.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (56) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 25 + "'", int5 == 25);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(intArray14);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
//        int int13 = randomDataGenerator5.nextPascal((int) (byte) 100, 0.7165313105737893d);
//        long long16 = randomDataGenerator5.nextSecureLong(0L, (long) 3);
//        randomDataGenerator5.reSeedSecure(7035070615930559438L);
//        randomDataGenerator5.reSeedSecure((long) (short) 100);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2L + "'", long16 == 2L);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-127));
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double4 = org.apache.commons.math3.special.Beta.logBeta(0.7474939987878148d, 1.72244886803960038E18d, 44.13962630585626d, 61);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(0.0012238168379059867d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0012238165324154726d + "'", double1 == 0.0012238165324154726d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        byte[] byteArray4 = new byte[] {};
        well19937c1.nextBytes(byteArray4);
        well19937c1.setSeed((long) 81);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        try {
            randomDataGenerator8.setSecureAlgorithm("7aadde7dee4af34c754db517fcf2da8f6e1e1b0ace91cd2f5613f3a3", "c");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: c");
        } catch (java.security.NoSuchProviderException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math3.special.Gamma.gamma((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math3.special.Gamma.digamma(128.70267574936713d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.853614950957945d + "'", double1 == 4.853614950957945d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double2 = org.apache.commons.math3.util.FastMath.min(7.93006726156716E14d, 5.265393921879147d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.265393921879147d + "'", double2 == 5.265393921879147d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(20, 0.0d, (double) 6);
        int int4 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        double double5 = iterativeLegendreGaussIntegrator3.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 56, 0.7057767406893092d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7057767406893092d + "'", double2 == 0.7057767406893092d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        double double5 = fDistribution3.density(0.2384666681235159d);
        double double6 = fDistribution3.getSupportLowerBound();
        double double8 = fDistribution3.probability(0.028192915962341632d);
        boolean boolean9 = fDistribution3.isSupportConnected();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05918987686027852d + "'", double5 == 0.05918987686027852d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(0.0d, 0.0d, 7.180704E8d, 56);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, 44.15963849397288d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(22025.465794806718d, 148.4131591025766d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22025.965811832077d + "'", double2 == 22025.965811832077d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        byte[] byteArray4 = new byte[] {};
        well19937c1.nextBytes(byteArray4);
        org.apache.commons.math3.distribution.FDistribution fDistribution9 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (short) 10, 6.598524091877789E-28d, 0.6244422900440489d);
        double double10 = fDistribution9.getNumericalMean();
        double double11 = fDistribution9.getDenominatorDegreesOfFreedom();
        double double13 = fDistribution9.probability((-2.8131219329264736d));
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 6.598524091877789E-28d + "'", double11 == 6.598524091877789E-28d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        long long5 = well19937c4.nextLong();
        well19937c4.setSeed((long) 2147483647);
        long long8 = well19937c4.nextLong();
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution12 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c4, 4.99211890308882E-6d, (-0.9180565165174799d), 0.027524864880781395d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-0.918)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4491554327296166888L + "'", long5 == 4491554327296166888L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 7035070615930559438L + "'", long8 == 7035070615930559438L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 3.837783919015451E-5d, (java.lang.Number) 0.16474260738292135d, (java.lang.Number) 1.081337814212361E12d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass9 = maxCountExceededException8.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException8, localizable10, objArray13);
        java.lang.Throwable[] throwableArray15 = maxCountExceededException8.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException4, localizable6, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.MathInternalError mathInternalError17 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.22526000610152908d, (java.lang.Number) (-16.756488356628626d), (java.lang.Number) 48);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) 20, (long) 126355559);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution((double) 56, 0.24348764167264014d, 6.598524091877789E-28d);
        boolean boolean4 = fDistribution3.isSupportUpperBoundInclusive();
        double double5 = fDistribution3.getDenominatorDegreesOfFreedom();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.24348764167264014d + "'", double5 == 0.24348764167264014d);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        org.apache.commons.math3.random.Well19937c well19937c3 = new org.apache.commons.math3.random.Well19937c((int) 'a');
//        well19937c3.setSeed((long) (short) 1);
//        well19937c3.clear();
//        well19937c3.clear();
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl8.reSeedSecure();
//        randomDataImpl8.reSeedSecure();
//        int int13 = randomDataImpl8.nextSecureInt(1, 100);
//        int int16 = randomDataImpl8.nextPascal((int) (short) 1, (double) (byte) 0);
//        double double19 = randomDataImpl8.nextCauchy((double) 16, Double.NaN);
//        int[] intArray22 = randomDataImpl8.nextPermutation(100, 10);
//        well19937c3.setSeed(intArray22);
//        well19937c1.setSeed(intArray22);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 37 + "'", int13 == 37);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(intArray22);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray4 = numberIsTooLargeException3.getSuppressed();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = numberIsTooLargeException3.getContext();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 1 is larger than the maximum (10)" + "'", str5.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 1 is larger than the maximum (10)"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(exceptionContext7);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 1, (java.lang.Number) 3.661826586795296E-41d, (java.lang.Number) 100L);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray9 = numberIsTooLargeException8.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException3, localizable4, (java.lang.Object[]) throwableArray9);
        java.lang.Number number11 = outOfRangeException3.getArgument();
        java.lang.Number number12 = outOfRangeException3.getArgument();
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 1 + "'", number11.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 1 + "'", number12.equals((byte) 1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
        int int13 = randomDataGenerator5.nextPascal((int) (byte) 100, 0.7165313105737893d);
        long long16 = randomDataGenerator5.nextSecureLong(0L, (long) 3);
        randomDataGenerator5.reSeedSecure(7035070615930559438L);
        double double21 = randomDataGenerator5.nextF((double) 91, 4.853614950957945d);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.5536110958808719d + "'", double21 == 0.5536110958808719d);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        int int8 = randomDataImpl0.nextPascal((int) (short) 1, (double) (byte) 0);
//        double double11 = randomDataImpl0.nextCauchy((double) 16, Double.NaN);
//        int[] intArray14 = randomDataImpl0.nextPermutation(100, 10);
//        org.apache.commons.math3.random.Well19937c well19937c15 = new org.apache.commons.math3.random.Well19937c(intArray14);
//        long long16 = well19937c15.nextLong();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 82 + "'", int5 == 82);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2966766435194824934L) + "'", long16 == (-2966766435194824934L));
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution3 = new org.apache.commons.math3.distribution.UniformRealDistribution((-1.0d), (double) 0L, (double) (short) -1);
        double double4 = uniformRealDistribution3.getNumericalMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.5d) + "'", double4 == (-0.5d));
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution3 = new org.apache.commons.math3.distribution.UniformRealDistribution((-1.0d), (double) 0L, (double) (short) -1);
//        double double4 = uniformRealDistribution3.sample();
//        boolean boolean5 = uniformRealDistribution3.isSupportUpperBoundInclusive();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.4405188159407418d) + "'", double4 == (-0.4405188159407418d));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution3 = new org.apache.commons.math3.distribution.UniformRealDistribution((double) 0.07277703f, (double) 61, (double) 2147483647);
//        double double5 = uniformRealDistribution3.cumulativeProbability(1.7904931097838226d);
//        double double6 = uniformRealDistribution3.sample();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.028192915962341632d + "'", double5 == 0.028192915962341632d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 43.11697526459103d + "'", double6 == 43.11697526459103d);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(0.7474939987878148d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7474939987878149d + "'", double1 == 0.7474939987878149d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0f, (-48.450227917950635d));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.99999994f + "'", float2 == 0.99999994f);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(0.24348764167264014d);
//        double double5 = randomDataImpl0.nextCauchy((double) 56, (double) 0.07277703f);
//        long long7 = randomDataImpl0.nextPoisson(0.24001511650651183d);
//        try {
//            int int10 = randomDataImpl0.nextSecureInt(2147483647, 82);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (2,147,483,647) must be strictly less than upper bound (82)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2742312022060336d + "'", double2 == 0.2742312022060336d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 55.80238696644744d + "'", double5 == 55.80238696644744d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 1.7453292519943298E-11d, (java.lang.Number) 122249082, (java.lang.Number) 58.0019903315599d);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 58.0019903315599d + "'", number5.equals(58.0019903315599d));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 0L);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
//        double double4 = uniformRealDistribution2.cumulativeProbability((double) 100.0f);
//        double double6 = uniformRealDistribution2.probability((double) 0.0f);
//        double double7 = uniformRealDistribution2.sample();
//        double double8 = uniformRealDistribution2.sample();
//        boolean boolean9 = uniformRealDistribution2.isSupportConnected();
//        double[] doubleArray11 = uniformRealDistribution2.sample(33);
//        boolean boolean12 = uniformRealDistribution2.isSupportLowerBoundInclusive();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.23772190230401874d + "'", double7 == 0.23772190230401874d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.23119711857826933d + "'", double8 == 0.23119711857826933d);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(doubleArray11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math3.distribution.FDistribution fDistribution2 = new org.apache.commons.math3.distribution.FDistribution(0.2179200458706742d, (double) 100);
        double double3 = fDistribution2.getNumeratorDegreesOfFreedom();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2179200458706742d + "'", double3 == 0.2179200458706742d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        well19937c1.setSeed(1);
        float float6 = well19937c1.nextFloat();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.27873123f + "'", float6 == 0.27873123f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double1 = org.apache.commons.math3.special.Gamma.gamma((double) 16L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.307674368E12d + "'", double1 == 1.307674368E12d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(22025.465794806718d, 2.2914625578099908d, 3.284624380370703E-8d, 0.2384666681235159d);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double3 = org.apache.commons.math3.special.Beta.regularizedBeta(3.6721338046390724E8d, (double) 91, 1.7935922936138282d);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(71, (double) 80, (double) (-2966766435194824934L));
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
//        int int13 = randomDataGenerator5.nextPascal((int) (byte) 100, 0.7165313105737893d);
//        long long16 = randomDataGenerator5.nextSecureLong(0L, (long) 3);
//        try {
//            int int19 = randomDataGenerator5.nextPascal(18, (double) 3L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 3 out of [0, 1] range");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(0.21792004587067423d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.21964895214310173d + "'", double1 == 0.21964895214310173d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math3.util.FastMath.cos(9.630671211899795E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999995362508959d + "'", double1 == 0.9999995362508959d);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(0.24348764167264014d);
//        double double5 = randomDataImpl0.nextCauchy((double) 56, (double) 0.07277703f);
//        double double7 = randomDataImpl0.nextChiSquare(0.03268622397329245d);
//        double double9 = randomDataImpl0.nextExponential((double) 100.0f);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7111548032056846d + "'", double2 == 0.7111548032056846d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 55.977452303140566d + "'", double5 == 55.977452303140566d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 146.2579397936004d + "'", double9 == 146.2579397936004d);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) (short) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math3.util.FastMath.tan(56.190433649118546d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.37438811526963783d) + "'", double1 == (-0.37438811526963783d));
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        randomDataGenerator5.reSeed();
//        double double11 = randomDataGenerator5.nextChiSquare((double) 10L);
//        double double14 = randomDataGenerator5.nextWeibull((double) 1L, 0.9726833128650032d);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 17.25696247521043d + "'", double11 == 17.25696247521043d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0834164190841447d + "'", double14 == 1.0834164190841447d);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass9 = maxCountExceededException8.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException8, localizable10, objArray13);
        java.lang.Throwable[] throwableArray15 = maxCountExceededException8.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException4, localizable6, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100L, (java.lang.Number) 0, false);
        mathIllegalStateException17.addSuppressed((java.lang.Throwable) numberIsTooLargeException21);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext23 = numberIsTooLargeException21.getContext();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(exceptionContext23);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        long long5 = well19937c4.nextLong();
        well19937c4.setSeed((long) 2147483647);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4491554327296166888L + "'", long5 == 4491554327296166888L);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
//        int int13 = randomDataGenerator5.nextPascal((int) (byte) 100, 0.7165313105737893d);
//        double double16 = randomDataGenerator5.nextBeta(0.03268622397329245d, (double) (byte) 1);
//        long long19 = randomDataGenerator5.nextSecureLong(0L, (long) 60);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 45L + "'", long19 == 45L);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(3, (double) (-1L), 0.0d);
        int int4 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        int int6 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        int int7 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        int int8 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        int int9 = iterativeLegendreGaussIntegrator3.getIterations();
        double double10 = iterativeLegendreGaussIntegrator3.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.013906638135586723d, (java.lang.Number) 20L, true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math3.random.Well19937c well19937c0 = new org.apache.commons.math3.random.Well19937c();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c0);
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution5 = new org.apache.commons.math3.distribution.UniformRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c0, (-1.324620071042733d), 0.24001511650651183d, 1.307674368E12d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double2 = org.apache.commons.math3.util.FastMath.min(0.2179200458706742d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2179200458706742d + "'", double2 == 0.2179200458706742d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        int int3 = well19937c1.nextInt((int) 'a');
        org.apache.commons.math3.distribution.FDistribution fDistribution7 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 93.10802672240492d, (double) (byte) 100, (double) (-1684074324264821833L));
        well19937c1.clear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
        int int13 = randomDataGenerator5.nextPascal((int) (byte) 100, 0.7165313105737893d);
        double double16 = randomDataGenerator5.nextGaussian((-0.6535930666047297d), 8.013933721922121E8d);
        try {
            java.lang.String str18 = randomDataGenerator5.nextHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.6721338046390724E8d + "'", double16 == 3.6721338046390724E8d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
        int int13 = randomDataGenerator5.nextPascal((int) (byte) 100, 0.7165313105737893d);
        double double16 = randomDataGenerator5.nextBeta(0.03268622397329245d, (double) (byte) 1);
        double double19 = randomDataGenerator5.nextF(0.2179200458706742d, 1.7904931097838226d);
        try {
            int int22 = randomDataGenerator5.nextBinomial((int) (short) 10, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: -1 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.8562349780076544d + "'", double19 == 1.8562349780076544d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) 71);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 71.0d + "'", double1 == 71.0d);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        randomDataGenerator5.reSeed();
//        double double11 = randomDataGenerator5.nextChiSquare((double) 10L);
//        double double14 = randomDataGenerator5.nextBeta(0.23621296409901363d, (double) '#');
//        double double16 = randomDataGenerator5.nextChiSquare(4.5916503662245255E10d);
//        double double19 = randomDataGenerator5.nextBeta((double) 3, 58.0019903315599d);
//        int int22 = randomDataGenerator5.nextSecureInt((int) '4', 60);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 9.687558616551694d + "'", double11 == 9.687558616551694d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.011390571024103315d + "'", double14 == 0.011390571024103315d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.5916499832824646E10d + "'", double16 == 4.5916499832824646E10d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.019204617149430826d + "'", double19 == 0.019204617149430826d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 58 + "'", int22 == 58);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) 56, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        well19937c1.clear();
        well19937c1.clear();
        double double6 = well19937c1.nextDouble();
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution10 = new org.apache.commons.math3.distribution.UniformRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (-27.52762722326611d), (-2.6188773144433135d), (double) 0);
        boolean boolean11 = well19937c1.nextBoolean();
        byte[] byteArray12 = null;
        try {
            well19937c1.nextBytes(byteArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.07277703352123166d + "'", double6 == 0.07277703352123166d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        double double7 = randomDataImpl0.nextExponential(12.475659145295907d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 67 + "'", int5 == 67);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.7517730109132135d + "'", double7 == 3.7517730109132135d);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double3 = org.apache.commons.math3.special.Beta.regularizedBeta((double) (byte) 1, (-0.09581311606133523d), (double) 1.1920929E-7f);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        try {
            double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(0.0d, (double) 6, (double) 67, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: Continued fraction convergents failed to converge (in less than 0 iterations) for value 0");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        randomDataGenerator5.reSeed();
//        double double11 = randomDataGenerator5.nextChiSquare((double) 10L);
//        double double14 = randomDataGenerator5.nextBeta(0.23621296409901363d, (double) '#');
//        double double16 = randomDataGenerator5.nextT(2239.8761611765112d);
//        randomDataGenerator5.reSeed();
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.284126738310577d + "'", double11 == 4.284126738310577d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 5.555307772686092E-4d + "'", double14 == 5.555307772686092E-4d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.18233050978721d + "'", double16 == 1.18233050978721d);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(0.24348764167264014d);
//        int int5 = randomDataImpl0.nextInt((-127), 43);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.051781674865737114d + "'", double2 == 0.051781674865737114d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-15) + "'", int5 == (-15));
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double6 = well19937c4.nextGaussian();
        well19937c4.setSeed(82);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.01789962561529476d + "'", double6 == 0.01789962561529476d);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(22026.465794806718d, 22025.465794806718d);
//        double double6 = randomDataImpl0.nextF((double) 56, 0.24348764167264014d);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-3176.100550954812d) + "'", double3 == (-3176.100550954812d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.044516317783695d + "'", double6 == 4.044516317783695d);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        double double5 = fDistribution3.density(0.2384666681235159d);
        try {
            double double7 = fDistribution3.inverseCumulativeProbability((double) 7.180704E8f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 718,070,400 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05918987686027852d + "'", double5 == 0.05918987686027852d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        double double4 = fDistribution3.getSupportLowerBound();
        double double6 = fDistribution3.cumulativeProbability(0.01789962561529476d);
        boolean boolean7 = fDistribution3.isSupportConnected();
        double double8 = fDistribution3.getNumeratorDegreesOfFreedom();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.8708515467349388d + "'", double6 == 0.8708515467349388d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.03125d + "'", double8 == 0.03125d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math3.util.FastMath.exp((-2.3513346877207577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09524195907292105d + "'", double1 == 0.09524195907292105d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 1.0834164190841447d, (java.lang.Number) 3.3200410216083988E16d, true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        well19937c1.clear();
        well19937c1.clear();
        double double6 = well19937c1.nextDouble();
        well19937c1.setSeed((long) 50);
        try {
            int int10 = well19937c1.nextInt((-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -127 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.07277703352123166d + "'", double6 == 0.07277703352123166d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.284624380370703E-8d, (double) 55L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator5 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) (byte) 10, (double) '4', 10.0d, (int) (short) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 100 is smaller than, or equal to, the minimum (100)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 127.0f, (java.lang.Number) (-2.3513346877207577d), true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException4.getContext();
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        double double4 = uniformRealDistribution2.density((double) 3);
        boolean boolean5 = uniformRealDistribution2.isSupportConnected();
        uniformRealDistribution2.reseedRandomGenerator((long) 71);
        uniformRealDistribution2.reseedRandomGenerator((long) 4);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double1 = org.apache.commons.math3.util.FastMath.signum((-13.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma((double) 0L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) (short) -1, (java.lang.Number) 1.4797575276974249d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.4797575276974249d + "'", number4.equals(1.4797575276974249d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        int int4 = randomDataImpl0.nextPascal((int) '#', (double) (short) 1);
        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution5 = null;
        try {
            int int6 = randomDataImpl0.nextInversionDeviate(integerDistribution5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double4 = randomDataImpl0.nextUniform(0.0d, (double) (short) 100, true);
//        int int7 = randomDataImpl0.nextSecureInt(1, (int) (byte) 100);
//        org.apache.commons.math3.distribution.FDistribution fDistribution11 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
//        double double12 = fDistribution11.getSupportLowerBound();
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) fDistribution11);
//        double double16 = randomDataImpl0.nextGamma(1.7904931097838226d, 5729.5779513082325d);
//        try {
//            double double19 = randomDataImpl0.nextGaussian(0.0d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 43.454258386971524d + "'", double4 == 43.454258386971524d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 92 + "'", int7 == 92);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5d + "'", double13 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4245.5139566516555d + "'", double16 == 4245.5139566516555d);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 1.1920929E-7f);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        double double1 = uniformRealDistribution0.getSupportUpperBound();
        try {
            double double4 = uniformRealDistribution0.probability(28.225929047830736d, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (28.226) must be less than or equal to upper endpoint (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 3.661826586795296E-41d);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(0.24348764167264014d);
//        double double5 = randomDataImpl0.nextCauchy((double) 56, (double) 0.07277703f);
//        long long7 = randomDataImpl0.nextPoisson(0.24001511650651183d);
//        try {
//            int int10 = randomDataImpl0.nextBinomial(11, (-2.275948694363265E-5d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: -0 out of [0, 1] range");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.15331101930951088d + "'", double2 == 0.15331101930951088d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 56.0826216909885d + "'", double5 == 56.0826216909885d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray4 = numberIsTooLargeException3.getSuppressed();
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 1, (java.lang.Number) 3.661826586795296E-41d, (java.lang.Number) 100L);
        org.apache.commons.math3.exception.util.Localizable localizable11 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray16 = numberIsTooLargeException15.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException10, localizable11, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable6, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException3, localizable5, (java.lang.Object[]) throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100L, (java.lang.Number) 0, false);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator10 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(126355559, 56, 126355559);
        java.lang.Object[] objArray12 = new java.lang.Object[] { 4.9E-324d, 4.5916503662245255E10d, 56, 0.3678794411714424d };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException3, localizable4, objArray12);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext14 = numberIsTooLargeException3.getContext();
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(exceptionContext14);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) 1.0E-6d, (java.lang.Number) (-1), false);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass11 = maxCountExceededException10.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException10, localizable12, objArray15);
        java.lang.Throwable[] throwableArray17 = maxCountExceededException10.getSuppressed();
        java.lang.Object[] objArray19 = new java.lang.Object[] { localizable3, "7aadde7dee4af34c754db517fcf2da8f6e1e1b0ace91cd2f5613f3a3", maxCountExceededException10, 0.0d };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable2, objArray19);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 0.07277703352123166d, objArray19);
        java.lang.Number number22 = maxCountExceededException21.getMax();
        java.lang.Number number23 = maxCountExceededException21.getMax();
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.07277703352123166d + "'", number22.equals(0.07277703352123166d));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.07277703352123166d + "'", number23.equals(0.07277703352123166d));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        byte[] byteArray4 = new byte[] {};
        well19937c1.nextBytes(byteArray4);
        well19937c1.setSeed((long) 81);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        well19937c1.setSeed(22L);
        org.junit.Assert.assertNotNull(byteArray4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        float float1 = org.apache.commons.math3.util.FastMath.ulp(7.0350707E18f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 5.4975581E11f + "'", float1 == 5.4975581E11f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 0.05872209840604111d);
        boolean boolean4 = notStrictlyPositiveException3.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 1, (java.lang.Number) 3.661826586795296E-41d, (java.lang.Number) 100L);
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray15 = numberIsTooLargeException14.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException9, localizable10, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) notStrictlyPositiveException3, localizable5, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, number1, (java.lang.Object[]) throwableArray15);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double2 = org.apache.commons.math3.special.Beta.logBeta(0.5426062697381586d, 3.661826586795296E-41d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 93.10802672240492d + "'", double2 == 93.10802672240492d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double5 = org.apache.commons.math3.special.Beta.regularizedBeta(45.88962247105999d, 0.5403023058681398d, (double) 81, (double) 38, 77);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        well19937c1.clear();
        well19937c1.setSeed((long) 3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math3.special.Gamma.trigamma(56.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.018017530612444158d + "'", double1 == 0.018017530612444158d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (byte) -1, (java.lang.Number) 56.13352067336168d, false);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        double double4 = randomDataImpl0.nextExponential((double) '#');
//        randomDataImpl0.reSeed((long) 1);
//        long long9 = randomDataImpl0.nextSecureLong(97L, (long) (byte) 100);
//        double double11 = randomDataImpl0.nextExponential(12.579105630001806d);
//        try {
//            long long13 = randomDataImpl0.nextPoisson((-10.263825850858487d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-10.264)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.204604027559068d + "'", double4 == 3.204604027559068d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 28.225929047830736d + "'", double11 == 28.225929047830736d);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma((double) 43);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 117.77188139974506d + "'", double1 == 117.77188139974506d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        double double5 = well19937c4.nextDouble();
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution9 = new org.apache.commons.math3.distribution.UniformRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c4, (double) 45L, (double) 57L, (-1.324620071042733d));
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.24348764167264014d + "'", double5 == 0.24348764167264014d);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double4 = randomDataImpl0.nextUniform(0.0d, (double) (short) 100, true);
//        randomDataImpl0.reSeed(0L);
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution9 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
//        double double11 = uniformRealDistribution9.cumulativeProbability((double) 100.0f);
//        double[] doubleArray13 = uniformRealDistribution9.sample((int) (short) 100);
//        boolean boolean14 = uniformRealDistribution9.isSupportLowerBoundInclusive();
//        double double17 = uniformRealDistribution9.cumulativeProbability((double) (-1.0f), 0.6244422900440489d);
//        double double18 = uniformRealDistribution9.sample();
//        double double19 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) uniformRealDistribution9);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 53.510665545555966d + "'", double4 == 53.510665545555966d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2222509155604381d + "'", double18 == 0.2222509155604381d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2379775930758377d + "'", double19 == 0.2379775930758377d);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
//        double double4 = uniformRealDistribution2.cumulativeProbability((double) 100.0f);
//        double double6 = uniformRealDistribution2.probability((double) 0.0f);
//        double double7 = uniformRealDistribution2.sample();
//        double double8 = uniformRealDistribution2.sample();
//        boolean boolean9 = uniformRealDistribution2.isSupportConnected();
//        double[] doubleArray11 = uniformRealDistribution2.sample(33);
//        double double12 = uniformRealDistribution2.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.22621709749899102d + "'", double7 == 0.22621709749899102d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.238375889485298d + "'", double8 == 0.238375889485298d);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(doubleArray11);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2254856645712168d + "'", double12 == 0.2254856645712168d);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        double double5 = fDistribution3.density(0.0d);
        double double7 = fDistribution3.inverseCumulativeProbability((double) 1L);
        double double8 = fDistribution3.getNumericalMean();
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) Double.POSITIVE_INFINITY);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = notStrictlyPositiveException1.getContext();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: ∞ is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: ∞ is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        java.lang.String str2 = randomDataGenerator0.nextSecureHexString(73);
//        java.lang.String str4 = randomDataGenerator0.nextHexString(40);
//        double double7 = randomDataGenerator0.nextUniform((double) (-1.0f), 0.018017530612444158d);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "68e72f7dd8df657d98cc61181653da381bf03af53bd4025df669607f3706a51f704065c46" + "'", str2.equals("68e72f7dd8df657d98cc61181653da381bf03af53bd4025df669607f3706a51f704065c46"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "c33a9ac88ad8385da60571bc7b50b0ef51801a14" + "'", str4.equals("c33a9ac88ad8385da60571bc7b50b0ef51801a14"));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.2148242820630653d) + "'", double7 == (-0.2148242820630653d));
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double1 = org.apache.commons.math3.util.FastMath.log10(87.04944075434122d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9397659853547422d + "'", double1 == 1.9397659853547422d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        try {
            double double1 = org.apache.commons.math3.special.Gamma.invGamma1pm1(148.4131591025766d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 148.413 is larger than the maximum (1.5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray3);
        well19937c5.clear();
        well19937c5.clear();
        double double8 = well19937c5.nextDouble();
        long long9 = well19937c5.nextLong();
        int int11 = well19937c5.nextInt(48);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator12 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c5);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.24348764167264014d + "'", double8 == 0.24348764167264014d);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1684074324264821833L) + "'", long9 == (-1684074324264821833L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 21 + "'", int11 == 21);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double1 = org.apache.commons.math3.util.FastMath.exp((-2.275948694363265E-5d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999772407720515d + "'", double1 == 0.9999772407720515d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math3.util.FastMath.tan(1.0000000000005d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246566151d + "'", double1 == 1.5574077246566151d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray3);
        well19937c5.clear();
        well19937c5.clear();
        well19937c5.setSeed((long) (byte) 0);
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution13 = new org.apache.commons.math3.distribution.UniformRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c5, (-0.6535930666047297d), (double) 10, 0.22610909338272647d);
        double double14 = uniformRealDistribution13.getSupportLowerBound();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.6535930666047297d) + "'", double14 == (-0.6535930666047297d));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double2 = org.apache.commons.math3.util.FastMath.pow((-0.6535930666047297d), 403.4287934927351d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        double double4 = randomDataImpl0.nextUniform(0.3678794411714424d, (double) 20);
//        try {
//            double double7 = randomDataImpl0.nextUniform(1.13300909670996045E18d, 0.3678794411714424d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (1,133,009,096,709,960,450) must be strictly less than upper bound (0.368)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.747536992600937d + "'", double4 == 4.747536992600937d);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (-2.6188773144433135d), (java.lang.Number) 0.2179200458706742d, number3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) 24, 67);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.541775E21f + "'", float2 == 3.541775E21f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double1 = org.apache.commons.math3.util.FastMath.atan((-48.450227917950635d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5501595190922537d) + "'", double1 == (-1.5501595190922537d));
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double4 = randomDataImpl0.nextUniform(0.0d, (double) (short) 100, true);
//        int int7 = randomDataImpl0.nextSecureInt(1, (int) (byte) 100);
//        org.apache.commons.math3.distribution.FDistribution fDistribution11 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
//        double double12 = fDistribution11.getSupportLowerBound();
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) fDistribution11);
//        boolean boolean14 = fDistribution11.isSupportUpperBoundInclusive();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 47.892363911087756d + "'", double4 == 47.892363911087756d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 66 + "'", int7 == 66);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.apache.commons.math3.util.FastMath.asin(0.027524864880781395d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027528341622601194d + "'", double1 == 0.027528341622601194d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math3.distribution.FDistribution fDistribution2 = new org.apache.commons.math3.distribution.FDistribution((double) 81, (double) 48);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
//        int int13 = randomDataGenerator5.nextPascal((int) (byte) 100, 0.7165313105737893d);
//        long long16 = randomDataGenerator5.nextSecureLong(0L, (long) 3);
//        randomDataGenerator5.reSeedSecure(7035070615930559438L);
//        double double21 = randomDataGenerator5.nextWeibull((double) 0.23953891f, 5.834138592669901d);
//        try {
//            int int25 = randomDataGenerator5.nextHypergeometric(16, 58, 312574995);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (58) must be less than or equal to population size (16)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3L + "'", long16 == 3L);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0011485186126948502d + "'", double21 == 0.0011485186126948502d);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution((double) 56, 0.24348764167264014d, 6.598524091877789E-28d);
        boolean boolean4 = fDistribution3.isSupportUpperBoundInclusive();
        double double5 = fDistribution3.getNumeratorDegreesOfFreedom();
        double double7 = fDistribution3.probability(0.10311988393098495d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 56.0d + "'", double5 == 56.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        boolean boolean4 = fDistribution3.isSupportUpperBoundInclusive();
        boolean boolean5 = fDistribution3.isSupportLowerBoundInclusive();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0.03758570895856344d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        byte[] byteArray4 = new byte[] {};
        well19937c1.nextBytes(byteArray4);
        well19937c1.setSeed((long) 81);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long11 = randomDataGenerator8.nextLong((long) 38, (long) 718070342);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 70179130L + "'", long11 == 70179130L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.24347462284355983d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.24347462284355983d + "'", double2 == 0.24347462284355983d);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (short) 1);
//        double double7 = randomDataImpl0.nextExponential((double) 100);
//        try {
//            double double10 = randomDataImpl0.nextBeta((-17200.126683381d), 0.2403534873896094d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.942, 0.058]");
//        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "c" + "'", str5.equals("c"));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 7.684563296781269d + "'", double7 == 7.684563296781269d);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.464757906675863d + "'", double1 == 3.464757906675863d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 148.4131591025766d);
        java.lang.Throwable[] throwableArray2 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        randomDataGenerator5.reSeed();
//        double double11 = randomDataGenerator5.nextChiSquare((double) 10L);
//        double double13 = randomDataGenerator5.nextChiSquare((double) ' ');
//        double double17 = randomDataGenerator5.nextUniform(4.2351647362715017E-22d, 3.284624380370703E-8d, false);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.906297287631721d + "'", double11 == 10.906297287631721d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 28.30300809411261d + "'", double13 == 28.30300809411261d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.6879543251589974E-8d + "'", double17 == 1.6879543251589974E-8d);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math3.util.FastMath.tan(12.497188253987535d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.06929294560400244d) + "'", double1 == (-0.06929294560400244d));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double1 = org.apache.commons.math3.special.Gamma.gamma(0.24347462284355983d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.728404883531992d + "'", double1 == 3.728404883531992d);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        int int8 = randomDataImpl0.nextPascal((int) (short) 1, (double) (byte) 0);
//        org.apache.commons.math3.distribution.FDistribution fDistribution12 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
//        double double14 = fDistribution12.density(0.0d);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) fDistribution12);
//        double double18 = randomDataImpl0.nextGaussian(3.728404883531992d, 1.569169089538853d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 86 + "'", int5 == 86);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.182416792540378d + "'", double18 == 2.182416792540378d);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) 1.0E-6d, (java.lang.Number) (-1), false);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass11 = maxCountExceededException10.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException10, localizable12, objArray15);
        java.lang.Throwable[] throwableArray17 = maxCountExceededException10.getSuppressed();
        java.lang.Object[] objArray19 = new java.lang.Object[] { localizable3, "7aadde7dee4af34c754db517fcf2da8f6e1e1b0ace91cd2f5613f3a3", maxCountExceededException10, 0.0d };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable2, objArray19);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, objArray19);
        org.apache.commons.math3.exception.MathInternalError mathInternalError22 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray19);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        long long5 = well19937c4.nextLong();
        long long6 = well19937c4.nextLong();
        double double7 = well19937c4.nextDouble();
        long long8 = well19937c4.nextLong();
        int[] intArray12 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c13 = new org.apache.commons.math3.random.Well19937c(intArray12);
        org.apache.commons.math3.random.Well19937c well19937c14 = new org.apache.commons.math3.random.Well19937c(intArray12);
        org.apache.commons.math3.random.Well19937c well19937c15 = new org.apache.commons.math3.random.Well19937c(intArray12);
        org.apache.commons.math3.random.Well19937c well19937c16 = new org.apache.commons.math3.random.Well19937c(intArray12);
        well19937c4.setSeed(intArray12);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4491554327296166888L + "'", long5 == 4491554327296166888L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1684074324264821833L) + "'", long6 == (-1684074324264821833L));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7025604821240949d + "'", double7 == 0.7025604821240949d);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2240823540069896689L + "'", long8 == 2240823540069896689L);
        org.junit.Assert.assertNotNull(intArray12);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        randomDataGenerator5.reSeed();
//        double double11 = randomDataGenerator5.nextChiSquare((double) 58);
//        try {
//            long long14 = randomDataGenerator5.nextLong((long) (short) 100, (long) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (100) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 64.02298587470229d + "'", double11 == 64.02298587470229d);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        double double10 = randomDataImpl0.nextBeta((double) 25L, (double) 67);
//        int int13 = randomDataImpl0.nextSecureInt(60, 86);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.24149562957042367d + "'", double10 == 0.24149562957042367d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 65 + "'", int13 == 65);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(3, (double) (-1L), 0.0d);
        int int4 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        int int6 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        double double7 = iterativeLegendreGaussIntegrator3.getAbsoluteAccuracy();
        int int8 = iterativeLegendreGaussIntegrator3.getIterations();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction10 = null;
        try {
            double double13 = iterativeLegendreGaussIntegrator3.integrate(99, univariateFunction10, (double) 0, 117.77188139974506d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution3 = new org.apache.commons.math3.distribution.UniformRealDistribution((-1.0d), (double) 0L, (double) (short) -1);
        double double5 = uniformRealDistribution3.density((double) 50);
        double double6 = uniformRealDistribution3.getSupportUpperBound();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        well19937c1.clear();
        well19937c1.clear();
        double double6 = well19937c1.nextDouble();
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution10 = new org.apache.commons.math3.distribution.UniformRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (-27.52762722326611d), (-2.6188773144433135d), (double) 0);
        double double11 = uniformRealDistribution10.sample();
        boolean boolean12 = uniformRealDistribution10.isSupportLowerBoundInclusive();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.07277703352123166d + "'", double6 == 0.07277703352123166d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-19.183332790707222d) + "'", double11 == (-19.183332790707222d));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(3, (double) (-1L), 0.0d);
        int int4 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        int int6 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        double double7 = iterativeLegendreGaussIntegrator3.getAbsoluteAccuracy();
        int int8 = iterativeLegendreGaussIntegrator3.getIterations();
        int int9 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double11 = randomDataGenerator5.nextWeibull(58.0d, 6.545233034006089E42d);
        double double14 = randomDataGenerator5.nextWeibull((double) 21, 3.4387790803606046d);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 6.644475589308464E42d + "'", double11 == 6.644475589308464E42d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.470482653780048d + "'", double14 == 3.470482653780048d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) 7035070615930559438L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math3.util.FastMath.floor((-232.6990966796875d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-233.0d) + "'", double1 == (-233.0d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(126355559, 56, 126355559);
        int int4 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 56 + "'", int4 == 56);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        int[] intArray8 = randomDataImpl0.nextPermutation(43, 4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
//        org.junit.Assert.assertNotNull(intArray8);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double double1 = org.apache.commons.math3.util.FastMath.abs(0.8708515467349388d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8708515467349388d + "'", double1 == 0.8708515467349388d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        int int1 = org.apache.commons.math3.util.FastMath.abs(73);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 73 + "'", int1 == 73);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        int int1 = org.apache.commons.math3.util.FastMath.abs(80);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 80 + "'", int1 == 80);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 3.541775E21f, 5.350998724046218E-109d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        long long5 = well19937c4.nextLong();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator6.nextT(1.5707963267948966d);
        long long10 = randomDataGenerator6.nextPoisson(0.22024271386553707d);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4491554327296166888L + "'", long5 == 4491554327296166888L);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.2914625578099908d + "'", double8 == 2.2914625578099908d);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        boolean boolean3 = uniformRealDistribution2.isSupportConnected();
        double double5 = uniformRealDistribution2.density((double) 18);
        double double6 = uniformRealDistribution2.getNumericalMean();
        boolean boolean7 = uniformRealDistribution2.isSupportLowerBoundInclusive();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.23275761289493113d + "'", double6 == 0.23275761289493113d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double2 = org.apache.commons.math3.util.FastMath.log(0.3014751110330475d, 0.2229891714154522d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2514989114749102d + "'", double2 == 1.2514989114749102d);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        well19937c5.clear();
//        well19937c5.clear();
//        double double8 = well19937c5.nextDouble();
//        long long9 = well19937c5.nextLong();
//        int int11 = well19937c5.nextInt(48);
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double16 = randomDataImpl12.nextUniform(0.0d, (double) (short) 100, true);
//        int[] intArray19 = randomDataImpl12.nextPermutation(99, 20);
//        well19937c5.setSeed(intArray19);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.24348764167264014d + "'", double8 == 0.24348764167264014d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1684074324264821833L) + "'", long9 == (-1684074324264821833L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 21 + "'", int11 == 21);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 87.20433733705224d + "'", double16 == 87.20433733705224d);
//        org.junit.Assert.assertNotNull(intArray19);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextPascal(0, 0.013906638135586723d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of successes (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 5.265393921879147d, (java.lang.Number) 0.23856920175694382d, true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        well19937c1.clear();
        well19937c1.clear();
        double double6 = well19937c1.nextDouble();
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution10 = new org.apache.commons.math3.distribution.UniformRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (-27.52762722326611d), (-2.6188773144433135d), (double) 0);
        boolean boolean11 = uniformRealDistribution10.isSupportConnected();
        try {
            double double13 = uniformRealDistribution10.inverseCumulativeProbability(87.20433733705224d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 87.204 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.07277703352123166d + "'", double6 == 0.07277703352123166d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        double double4 = randomDataImpl0.nextExponential((double) '#');
//        randomDataImpl0.reSeed((long) 1);
//        long long9 = randomDataImpl0.nextLong((long) 10, 97L);
//        try {
//            double double12 = randomDataImpl0.nextGamma((-19.183332790707222d), (double) 1.0000001f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-19.183)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 211.2391578918761d + "'", double4 == 211.2391578918761d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 16L + "'", long9 == 16L);
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
//        double double4 = uniformRealDistribution2.cumulativeProbability((double) 100.0f);
//        double double6 = uniformRealDistribution2.probability((double) 0.0f);
//        double double7 = uniformRealDistribution2.sample();
//        double double8 = uniformRealDistribution2.sample();
//        boolean boolean9 = uniformRealDistribution2.isSupportConnected();
//        double double11 = uniformRealDistribution2.cumulativeProbability((double) 4491554327296166888L);
//        double double13 = uniformRealDistribution2.density((-0.8390715290764524d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.23327962784583867d + "'", double7 == 0.23327962784583867d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.22560263393993338d + "'", double8 == 0.22560263393993338d);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(5.555307772686092E-4d, 1.0285681724852862d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double double1 = org.apache.commons.math3.util.FastMath.exp(0.8014761040992063d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2288284843703874d + "'", double1 == 2.2288284843703874d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double double1 = org.apache.commons.math3.special.Gamma.lanczos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.94631867978169d + "'", double1 == 32.94631867978169d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double3 = org.apache.commons.math3.special.Beta.regularizedBeta((double) 21, (double) 21, 0.0d);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(1.13300909670996045E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9774739192635664E16d + "'", double1 == 1.9774739192635664E16d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.16299078079570548d) + "'", double1 == (-0.16299078079570548d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        byte[] byteArray4 = new byte[] {};
        well19937c1.nextBytes(byteArray4);
        well19937c1.setSeed((long) 81);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataGenerator8.reSeedSecure();
        int int13 = randomDataGenerator8.nextHypergeometric(18, 0, 3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str3 = randomDataImpl0.nextSecureHexString((int) '4');
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString((int) (short) 10);
//        double double8 = randomDataImpl0.nextUniform((double) 1.0f, 23.17377526703116d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c32d987249ee6ad238a68e305b5cd23a55ba80bc0eb91afd8d21" + "'", str3.equals("c32d987249ee6ad238a68e305b5cd23a55ba80bc0eb91afd8d21"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "80e65c7099" + "'", str5.equals("80e65c7099"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.9106889997190555d + "'", double8 == 3.9106889997190555d);
//    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
//        double double4 = uniformRealDistribution2.cumulativeProbability((double) 100.0f);
//        double double6 = uniformRealDistribution2.probability((double) 0.0f);
//        double double7 = uniformRealDistribution2.sample();
//        double double8 = uniformRealDistribution2.sample();
//        boolean boolean9 = uniformRealDistribution2.isSupportConnected();
//        double double11 = uniformRealDistribution2.cumulativeProbability((double) 4491554327296166888L);
//        boolean boolean12 = uniformRealDistribution2.isSupportConnected();
//        double double14 = uniformRealDistribution2.density(93.10802672240492d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.23884390652255244d + "'", double7 == 0.23884390652255244d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.22520605899161322d + "'", double8 == 0.22520605899161322d);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass9 = maxCountExceededException8.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException8, localizable10, objArray13);
        java.lang.Throwable[] throwableArray15 = maxCountExceededException8.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException4, localizable6, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100L, (java.lang.Number) 0, false);
        mathIllegalStateException17.addSuppressed((java.lang.Throwable) numberIsTooLargeException21);
        java.lang.Number number23 = numberIsTooLargeException21.getMax();
        org.apache.commons.math3.exception.MathInternalError mathInternalError24 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException21);
        java.lang.Number number25 = numberIsTooLargeException21.getMax();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0 + "'", number23.equals(0));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0 + "'", number25.equals(0));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        long long5 = well19937c4.nextLong();
        well19937c4.setSeed((long) 2147483647);
        well19937c4.setSeed(0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4491554327296166888L + "'", long5 == 4491554327296166888L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 56, (double) 22);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 55.999996f + "'", float2 == 55.999996f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 100.00001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.615120592379816d + "'", double1 == 4.615120592379816d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException(number0, number1, (java.lang.Number) 1.0f);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 1, (java.lang.Number) 3.661826586795296E-41d, (java.lang.Number) 100L);
        java.lang.Number number8 = outOfRangeException7.getHi();
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100L + "'", number8.equals(100L));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(2.878762514980041d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.86801882306957d + "'", double1 == 8.86801882306957d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        byte[] byteArray4 = new byte[] {};
        well19937c1.nextBytes(byteArray4);
        well19937c1.setSeed((long) 81);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataGenerator8.nextT(1.0E20d);
        int int14 = randomDataGenerator8.nextHypergeometric((int) ' ', 10, 10);
        long long17 = randomDataGenerator8.nextLong((long) 29, (long) (short) 100);
        try {
            double double19 = randomDataGenerator8.nextExponential(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-4.175967833751397E-10d) + "'", double10 == (-4.175967833751397E-10d));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 57L + "'", long17 == 57L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        int int2 = org.apache.commons.math3.util.FastMath.min(87, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87 + "'", int2 == 87);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math3.special.Gamma.gamma(4.5916503662245255E10d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        int int8 = randomDataImpl0.nextPascal((int) (short) 1, (double) (byte) 0);
//        double double11 = randomDataImpl0.nextCauchy((double) 16, Double.NaN);
//        randomDataImpl0.reSeedSecure((long) 20);
//        double double16 = randomDataImpl0.nextGaussian((double) 3.12575008E8f, (double) 24);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.125750627323276E8d + "'", double16 == 3.125750627323276E8d);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(4.59164579563705E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.591645795637051E10d + "'", double1 == 4.591645795637051E10d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Number number4 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math3.exception.OutOfRangeException(number4, number5, (java.lang.Number) 1.0f);
        org.apache.commons.math3.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException7, localizable8, objArray9);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) outOfRangeException7);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 8.319325075937657d, (java.lang.Number) 1.6879543251589974E-8d, false);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        double double4 = randomDataImpl0.nextExponential((double) '#');
//        randomDataImpl0.reSeed((long) 1);
//        long long9 = randomDataImpl0.nextSecureLong(97L, (long) (byte) 100);
//        double double11 = randomDataImpl0.nextExponential(12.579105630001806d);
//        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution12 = null;
//        try {
//            int int13 = randomDataImpl0.nextInversionDeviate(integerDistribution12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.91062954786034d + "'", double4 == 52.91062954786034d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 98L + "'", long9 == 98L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 28.225929047830736d + "'", double11 == 28.225929047830736d);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 59);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 73, 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 73.0d + "'", double2 == 73.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 0.9722007956570669d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        well19937c1.clear();
        well19937c1.clear();
        org.apache.commons.math3.random.Well19937c well19937c7 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c7.setSeed((long) (short) 1);
        byte[] byteArray10 = new byte[] {};
        well19937c7.nextBytes(byteArray10);
        well19937c1.nextBytes(byteArray10);
        org.junit.Assert.assertNotNull(byteArray10);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeed();
        randomDataImpl0.reSeed();
        int int7 = randomDataImpl0.nextHypergeometric((int) '4', (int) (short) 10, 30);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 56.13352067336168d, (java.lang.Number) 0.10160160602240308d, (java.lang.Number) (-8.496519887386446d));
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-8.496519887386446d) + "'", number5.equals((-8.496519887386446d)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-8.496519887386446d) + "'", number6.equals((-8.496519887386446d)));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        double double5 = fDistribution3.density(0.2384666681235159d);
        double double6 = fDistribution3.getDenominatorDegreesOfFreedom();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05918987686027852d + "'", double5 == 0.05918987686027852d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        double double4 = uniformRealDistribution2.cumulativeProbability((double) 100.0f);
        double double6 = uniformRealDistribution2.cumulativeProbability((double) (-1684074324264821833L));
        double double7 = uniformRealDistribution2.getNumericalMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.23275761289493113d + "'", double7 == 0.23275761289493113d);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        int int8 = randomDataGenerator5.nextSecureInt(56, 2147483647);
//        randomDataGenerator5.reSeed();
//        try {
//            int int12 = randomDataGenerator5.nextBinomial((int) '4', 59.86013540096972d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 59.86 out of [0, 1] range");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1596156093 + "'", int8 == 1596156093);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 100.0f);
        java.lang.Throwable[] throwableArray5 = notStrictlyPositiveException4.getSuppressed();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (-0.2619782247946564d), (java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double double1 = org.apache.commons.math3.util.FastMath.tan((-232.6990966796875d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.22492212024837238d) + "'", double1 == (-0.22492212024837238d));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.22024271386553707d, (java.lang.Number) 4.0855068415443306E76d, true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        double double4 = uniformRealDistribution2.cumulativeProbability((double) 100.0f);
        double double6 = uniformRealDistribution2.probability((double) 0.0f);
        double double7 = uniformRealDistribution2.getNumericalMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.23275761289493113d + "'", double7 == 0.23275761289493113d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 4491554327296166888L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 61 + "'", int1 == 61);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double3 = org.apache.commons.math3.special.Beta.regularizedBeta(99328.0d, 0.10160160602240308d, (double) 43);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 26L, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 26.0f + "'", float2 == 26.0f);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double1 = org.apache.commons.math3.util.FastMath.cos(1.5574077246566151d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01338820214696304d + "'", double1 == 0.01338820214696304d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        int int1 = org.apache.commons.math3.util.FastMath.abs(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        int int4 = randomDataImpl0.nextPascal((int) '#', (double) (short) 1);
//        double double6 = randomDataImpl0.nextT(9.98337712458582d);
//        try {
//            long long9 = randomDataImpl0.nextLong((long) (short) 100, (long) 91);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (100) must be strictly less than upper bound (91)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.7402878433933876d) + "'", double6 == (-0.7402878433933876d));
//    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
//        double double4 = uniformRealDistribution2.cumulativeProbability((double) 100.0f);
//        double double6 = uniformRealDistribution2.probability((double) 0.0f);
//        double double7 = uniformRealDistribution2.sample();
//        double double8 = uniformRealDistribution2.sample();
//        boolean boolean9 = uniformRealDistribution2.isSupportConnected();
//        double double11 = uniformRealDistribution2.cumulativeProbability((double) 4491554327296166888L);
//        boolean boolean12 = uniformRealDistribution2.isSupportConnected();
//        double double13 = uniformRealDistribution2.getSupportUpperBound();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2276638119374038d + "'", double7 == 0.2276638119374038d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.22682551705464196d + "'", double8 == 0.22682551705464196d);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.24348764167264014d + "'", double13 == 0.24348764167264014d);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray4 = numberIsTooLargeException3.getSuppressed();
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass8 = maxCountExceededException7.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException7, localizable9, objArray12);
        java.lang.Throwable[] throwableArray14 = maxCountExceededException7.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException3, localizable5, (java.lang.Object[]) throwableArray14);
        java.lang.Number number16 = numberIsTooLargeException3.getMax();
        java.lang.Number number17 = numberIsTooLargeException3.getMax();
        org.apache.commons.math3.exception.util.Localizable localizable18 = null;
        org.apache.commons.math3.exception.util.Localizable localizable19 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) 100.0f);
        java.lang.Throwable[] throwableArray22 = notStrictlyPositiveException21.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException3, localizable18, (java.lang.Object[]) throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 10.0f + "'", number16.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 10.0f + "'", number17.equals(10.0f));
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 66);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(28.225929047830736d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.3750562963423603d + "'", double1 == 3.3750562963423603d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(126355559, 56, 126355559);
        int int4 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        double double5 = iterativeLegendreGaussIntegrator3.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 56 + "'", int4 == 56);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-15d + "'", double5 == 1.0E-15d);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        java.lang.String str2 = randomDataGenerator0.nextSecureHexString(73);
//        java.lang.String str4 = randomDataGenerator0.nextHexString(40);
//        try {
//            long long6 = randomDataGenerator0.nextPoisson((-2.356194490192345d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-2.356)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "139d4ad48c18ac809fbae3d1935454bfd3fa1b1e2c67c6739f4dfc8c3457f056b112ffabb" + "'", str2.equals("139d4ad48c18ac809fbae3d1935454bfd3fa1b1e2c67c6739f4dfc8c3457f056b112ffabb"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "06baf8eba038c372dbc3559027709835cb3bdc2e" + "'", str4.equals("06baf8eba038c372dbc3559027709835cb3bdc2e"));
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        double double5 = fDistribution3.density(0.2384666681235159d);
        double double6 = fDistribution3.getSupportLowerBound();
        double double7 = fDistribution3.getDenominatorDegreesOfFreedom();
        double double8 = fDistribution3.sample();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05918987686027852d + "'", double5 == 0.05918987686027852d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 70179130L, (float) 11);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 11.0f + "'", float2 == 11.0f);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        double double9 = randomDataImpl0.nextT((double) (short) 1);
//        double double12 = randomDataImpl0.nextGamma((double) 26L, 3.12575008E8d);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.1903185929953589d) + "'", double9 == (-0.1903185929953589d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.008535791711451E10d + "'", double12 == 1.008535791711451E10d);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double1 = org.apache.commons.math3.util.FastMath.floor((-241.92960784799652d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-242.0d) + "'", double1 == (-242.0d));
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        long long10 = randomDataImpl0.nextLong((long) 20, (long) 48);
//        double double13 = randomDataImpl0.nextCauchy(4.99211890308882E-6d, (double) 1.0f);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 20L + "'", long10 == 20L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.21259949607356607d) + "'", double13 == (-0.21259949607356607d));
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(5.593113932619261E176d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution((double) 20L, (double) 718070342L, 0.3014751110330475d);
        double double5 = fDistribution3.cumulativeProbability(0.2276638119374038d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.3270584366882363E-4d + "'", double5 == 1.3270584366882363E-4d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(126355559, 56, 126355559);
        int int4 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getIterations();
        int int6 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 56 + "'", int4 == 56);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 56 + "'", int6 == 56);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double4 = randomDataImpl0.nextUniform(0.0d, (double) (short) 100, true);
//        int[] intArray7 = randomDataImpl0.nextPermutation(99, 20);
//        java.lang.Class<?> wildcardClass8 = randomDataImpl0.getClass();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 94.81609052299689d + "'", double4 == 94.81609052299689d);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 96);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(1.5120404274924428d, 0.0d, (double) 22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        double double5 = well19937c4.nextDouble();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.24348764167264014d + "'", double5 == 0.24348764167264014d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(43.11697526459103d, (double) 59L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 43.116975264591034d + "'", double2 == 43.116975264591034d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(126355559, 56, 126355559);
        double double4 = iterativeLegendreGaussIntegrator3.getAbsoluteAccuracy();
        int int5 = iterativeLegendreGaussIntegrator3.getEvaluations();
        int int6 = iterativeLegendreGaussIntegrator3.getIterations();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        double double4 = uniformRealDistribution2.cumulativeProbability((double) 100.0f);
        double[] doubleArray6 = uniformRealDistribution2.sample((int) (short) 100);
        double double7 = uniformRealDistribution2.getNumericalMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.23275761289493113d + "'", double7 == 0.23275761289493113d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double double1 = org.apache.commons.math3.util.FastMath.abs(44.15963849397288d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 44.15963849397288d + "'", double1 == 44.15963849397288d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        double double4 = fDistribution3.getNumericalMean();
        boolean boolean5 = fDistribution3.isSupportConnected();
        double double6 = fDistribution3.getNumericalMean();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
//        boolean boolean3 = uniformRealDistribution2.isSupportConnected();
//        double double5 = uniformRealDistribution2.density((double) 18);
//        double double6 = uniformRealDistribution2.getNumericalMean();
//        double double7 = uniformRealDistribution2.sample();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.23275761289493113d + "'", double6 == 0.23275761289493113d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.23211588225729657d + "'", double7 == 0.23211588225729657d);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) 96);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 96.0d + "'", double1 == 96.0d);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        int int8 = randomDataImpl0.nextPascal((int) (short) 1, (double) (byte) 0);
//        double double11 = randomDataImpl0.nextCauchy((double) 16, Double.NaN);
//        randomDataImpl0.reSeedSecure((long) 20);
//        randomDataImpl0.reSeed((long) 71);
//        try {
//            double double18 = randomDataImpl0.nextCauchy(58.0019903315599d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 29 + "'", int5 == 29);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double5 = org.apache.commons.math3.special.Beta.regularizedBeta(5.350998724046218E-109d, (double) 97L, 9.247803848687706E-13d, 5.834138592669901d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        well19937c1.setSeed(1);
        well19937c1.setSeed((int) (byte) 1);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double9 = well19937c1.nextDouble();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2787313252014696d + "'", double9 == 0.2787313252014696d);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test319");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        randomDataGenerator5.reSeed();
//        double double11 = randomDataGenerator5.nextChiSquare((double) 10L);
//        double double14 = randomDataGenerator5.nextGaussian((double) (short) 1, (double) 1.0f);
//        int int17 = randomDataGenerator5.nextBinomial(16, 0.0d);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 23.563474213351903d + "'", double11 == 23.563474213351903d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.4696669916295375d + "'", double14 == 1.4696669916295375d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta((double) 25L, (double) 100L, 1.4797575276974249d, 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math3.util.FastMath.sin(5.446130839245705d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7426738593385617d) + "'", double1 == (-0.7426738593385617d));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (-13.0d), (java.lang.Number) 0.018017530612444158d, false);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test323");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str3 = randomDataImpl0.nextSecureHexString((int) '4');
//        try {
//            int[] intArray6 = randomDataImpl0.nextPermutation(58, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (0");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b9473eded34aedba159a651640e6b553450ef8c0f2c2b126daed" + "'", str3.equals("b9473eded34aedba159a651640e6b553450ef8c0f2c2b126daed"));
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        randomDataGenerator5.reSeed();
//        randomDataGenerator5.reSeedSecure((long) (short) 1);
//        double double10 = randomDataGenerator5.nextExponential(43.11697526459103d);
//        try {
//            int[] intArray13 = randomDataGenerator5.nextPermutation(0, 82);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: permutation size (82) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 18.10072311835013d + "'", double10 == 18.10072311835013d);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution5 = new org.apache.commons.math3.distribution.UniformRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (-4.175967833751397E-10d), (double) 25L, 3.661826586795296E-41d);
        well19937c1.setSeed((long) 85);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException(number0, (java.lang.Number) 4.728296005937471d, (java.lang.Number) 22026.465794806718d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 4.728296005937471d + "'", number4.equals(4.728296005937471d));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        double double5 = fDistribution3.density(0.0d);
        double double7 = fDistribution3.inverseCumulativeProbability((double) 1L);
        fDistribution3.reseedRandomGenerator(4491554327296166888L);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-0.037799108653239086d), (java.lang.Number) (short) -1, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str3 = randomDataImpl0.nextSecureHexString((int) '4');
//        double double5 = randomDataImpl0.nextT(0.5772156649015329d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3c6ad96c0f46d8228a97ceb6f7ee65bdb3bf4f5a8e3419b59e6f" + "'", str3.equals("3c6ad96c0f46d8228a97ceb6f7ee65bdb3bf4f5a8e3419b59e6f"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 12.339275523059706d + "'", double5 == 12.339275523059706d);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 58);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3323.1552117587744d + "'", double1 == 3323.1552117587744d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 1, (java.lang.Number) 3.661826586795296E-41d, (java.lang.Number) 100L);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-0.037799108653239086d), (java.lang.Number) (short) -1, true);
        java.lang.Number number10 = numberIsTooSmallException9.getArgument();
        outOfRangeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        boolean boolean12 = numberIsTooSmallException9.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 3.661826586795296E-41d + "'", number4.equals(3.661826586795296E-41d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 3.661826586795296E-41d + "'", number5.equals(3.661826586795296E-41d));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-0.037799108653239086d) + "'", number10.equals((-0.037799108653239086d)));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }
}

