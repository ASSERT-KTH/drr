import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double3 = org.apache.commons.math3.special.Beta.regularizedBeta((double) (byte) 10, (double) 0.0f, (double) '#');
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) (-1L), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 1, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((double) (-1L), 100.0d, (double) 1L, (int) (byte) 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) (byte) 1, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) (-1), (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double5 = org.apache.commons.math3.special.Beta.regularizedBeta((double) 100L, (double) 1, (double) 100L, 0.0d, (int) (byte) -1);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.apache.commons.math3.analysis.integration.BaseAbstractUnivariateIntegrator.DEFAULT_MIN_ITERATIONS_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) (byte) 10, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(22026.465794806718d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((double) (short) -1, (double) 'a', 0.0d, (int) (byte) 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (byte) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        try {
            long long2 = randomDataImpl0.nextPoisson((double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int2 = org.apache.commons.math3.util.FastMath.max(3, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 0, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        try {
            int int5 = randomDataImpl0.nextHypergeometric(100, (int) (short) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of samples (-1)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        try {
            int int6 = well19937c4.nextInt((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test020");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.22202758411722212d + "'", double0 == 0.22202758411722212d);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution1 = null;
        try {
            int int2 = randomDataImpl0.nextInversionDeviate(integerDistribution1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double0 = org.apache.commons.math3.distribution.AbstractRealDistribution.SOLVER_DEFAULT_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-6d + "'", double0 == 1.0E-6d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.00000000000001d + "'", double1 == 32.00000000000001d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3678794411714424d + "'", double1 == 0.3678794411714424d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(0.0d, 0.22202758411722212d, (-0.0d), 3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 1L, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math3.special.Gamma.digamma(0.3678794411714424d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.8131219329264736d) + "'", double1 == (-2.8131219329264736d));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((double) '#', (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.661826586795296E-41d + "'", double2 == 3.661826586795296E-41d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) (byte) -1, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray4 = numberIsTooLargeException3.getSuppressed();
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass8 = maxCountExceededException7.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException7, localizable9, objArray12);
        java.lang.Throwable[] throwableArray14 = maxCountExceededException7.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException3, localizable5, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext16 = numberIsTooLargeException3.getContext();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(exceptionContext16);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str3 = randomDataImpl0.nextSecureHexString((int) '4');
//        try {
//            long long5 = randomDataImpl0.nextPoisson((double) (-1.0f));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-1)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "d8ce744e7b2f8624e6a74d9fa79fdb0d21451e0dba67d4c740dd" + "'", str3.equals("d8ce744e7b2f8624e6a74d9fa79fdb0d21451e0dba67d4c740dd"));
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
        try {
            int int7 = randomDataImpl0.nextHypergeometric((int) (short) -1, (int) (byte) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double2 = org.apache.commons.math3.util.FastMath.max(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) (short) -1, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeedSecure();
        try {
            double double5 = randomDataImpl0.nextUniform(32.00000000000001d, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (32) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double0 = org.apache.commons.math3.analysis.integration.BaseAbstractUnivariateIntegrator.DEFAULT_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-15d + "'", double0 == 1.0E-15d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double0 = org.apache.commons.math3.special.Gamma.LANCZOS_G;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 4.7421875d + "'", double0 == 4.7421875d);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str3 = randomDataImpl0.nextSecureHexString((int) '4');
//        try {
//            long long6 = randomDataImpl0.nextSecureLong((long) (byte) 10, (long) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "64689fd755cfb1f1660ed8d1a4edbb17d17170d56cb93a7b318f" + "'", str3.equals("64689fd755cfb1f1660ed8d1a4edbb17d17170d56cb93a7b318f"));
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        try {
            randomDataImpl0.setSecureAlgorithm("hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str3 = randomDataImpl0.nextSecureHexString((int) '4');
//        try {
//            int[] intArray6 = randomDataImpl0.nextPermutation(0, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: permutation size (32) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a5f739a00720381a41a35948f0dcc5c1d507968e5dc711fc0fca" + "'", str3.equals("a5f739a00720381a41a35948f0dcc5c1d507968e5dc711fc0fca"));
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        long long1 = org.apache.commons.math3.util.FastMath.abs((-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str3 = randomDataImpl0.nextSecureHexString((int) '4');
//        try {
//            double double5 = randomDataImpl0.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "16e0efaaab967532a7352bea66cd7080d472763b2719488a50d6" + "'", str3.equals("16e0efaaab967532a7352bea66cd7080d472763b2719488a50d6"));
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(3, (double) (-1L), 0.0d);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        try {
            double double8 = iterativeLegendreGaussIntegrator3.integrate((int) (byte) -1, univariateFunction5, (-2.8131219329264736d), 3.661826586795296E-41d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (byte) 1, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        try {
//            double double7 = randomDataImpl0.nextExponential((double) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 40 + "'", int5 == 40);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double2 = org.apache.commons.math3.special.Beta.logBeta((double) (short) 0, (double) 'a');
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math3.special.Gamma.lanczos((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7244046011365866d + "'", double1 == 3.7244046011365866d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        try {
            int int4 = randomDataImpl0.nextSecureInt(56, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (56) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math3.special.Gamma.invGamma1pm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution3 = new org.apache.commons.math3.distribution.UniformRealDistribution((double) (short) 10, 0.0d, 22025.465794806718d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 1, (java.lang.Number) 3.661826586795296E-41d, (java.lang.Number) 100L);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray9 = numberIsTooLargeException8.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException3, localizable4, (java.lang.Object[]) throwableArray9);
        java.lang.Number number11 = outOfRangeException3.getArgument();
        java.lang.Number number12 = outOfRangeException3.getLo();
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 1 + "'", number11.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 3.661826586795296E-41d + "'", number12.equals(3.661826586795296E-41d));
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str3 = randomDataImpl0.nextSecureHexString((int) '4');
//        try {
//            long long6 = randomDataImpl0.nextLong((long) (byte) 1, (long) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (1) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "03ee6a4158f6d30ba10bae858cd891109ee286692e077fe2f801" + "'", str3.equals("03ee6a4158f6d30ba10bae858cd891109ee286692e077fe2f801"));
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math3.util.FastMath.floor(58.0019903315599d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 58.0d + "'", double1 == 58.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            double double1 = org.apache.commons.math3.special.Gamma.logGamma1p((double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 10 is larger than the maximum (1.5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100L, (java.lang.Number) 0, false);
        java.lang.Class<?> wildcardClass4 = numberIsTooLargeException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        try {
            double double4 = randomDataImpl0.nextWeibull((double) '4', 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0000001f + "'", float1 == 1.0000001f);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass2 = maxCountExceededException1.getClass();
        java.lang.Number number3 = maxCountExceededException1.getMax();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 1 + "'", number3.equals(1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 5, 0.24348764167264014d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4797575276974249d + "'", double2 == 1.4797575276974249d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.0d, (-0.0d), (double) 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        double double4 = uniformRealDistribution2.density((double) 3);
        try {
            double double7 = uniformRealDistribution2.probability((double) 100L, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (100) must be less than or equal to upper endpoint (10)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        try {
            double double8 = randomDataGenerator5.nextWeibull((double) 0.0f, 0.24348764167264014d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        try {
            double double4 = randomDataImpl0.nextWeibull(100.0d, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 0, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        try {
            long long10 = randomDataGenerator5.nextPoisson((double) (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-127)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        randomDataGenerator5.reSeed();
        try {
            double double12 = randomDataGenerator5.nextGaussian((double) (-1.0f), (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.000004f + "'", float1 == 52.000004f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double2 = org.apache.commons.math3.special.Beta.logBeta((double) (short) 10, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-27.52762722326611d) + "'", double2 == (-27.52762722326611d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(3.7244046011365866d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.7244046011365866d + "'", double2 == 3.7244046011365866d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double2 = org.apache.commons.math3.util.FastMath.pow(32.0d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03125d + "'", double2 == 0.03125d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(1.0E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000005d + "'", double1 == 1.0000000000005d);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(22026.465794806718d, 22025.465794806718d);
//        try {
//            long long6 = randomDataImpl0.nextSecureLong((long) ' ', (long) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (32) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 54682.47897848455d + "'", double3 == 54682.47897848455d);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((double) '#', 4.7421875d, 22026.465794806718d, 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math3.util.FastMath.asin(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeedSecure();
        try {
            int[] intArray5 = randomDataImpl0.nextPermutation((-127), (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: permutation size (35) exceeds permuation domain (-127)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        try {
            double double4 = randomDataImpl0.nextCauchy(119.57133787457882d, (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math3.util.FastMath.asin(1.4797575276974249d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double3 = org.apache.commons.math3.special.Beta.regularizedBeta((double) 10L, 0.0d, 0.3678794411714424d);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) 'a', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99328.0d + "'", double2 == 99328.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double0 = org.apache.commons.math3.distribution.FDistribution.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(0.24348764167264014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2179200458706742d + "'", double1 == 0.2179200458706742d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(0.24348764167264014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6244422900440489d + "'", double1 == 0.6244422900440489d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((-2239.8761611765112d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-13.084024114284892d) + "'", double1 == (-13.084024114284892d));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double11 = randomDataGenerator5.nextGaussian(119.31169712162223d, 0.36787944117144233d);
        try {
            int int14 = randomDataGenerator5.nextSecureInt(0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 119.57133787457882d + "'", double11 == 119.57133787457882d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
        try {
            double double6 = randomDataImpl0.nextGaussian(10.0d, (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(number0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
        randomDataImpl0.reSeedSecure((long) (short) 1);
        try {
            int int8 = randomDataImpl0.nextZipf((int) (byte) 100, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: exponent (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str3 = randomDataImpl0.nextSecureHexString((int) '4');
//        java.lang.String str5 = randomDataImpl0.nextHexString(56);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "fd5e975fc4e2918ecf01a28ddd6097f668d136c4c91e9fec017b" + "'", str3.equals("fd5e975fc4e2918ecf01a28ddd6097f668d136c4c91e9fec017b"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "7aadde7dee4af34c754db517fcf2da8f6e1e1b0ace91cd2f5613f3a3" + "'", str5.equals("7aadde7dee4af34c754db517fcf2da8f6e1e1b0ace91cd2f5613f3a3"));
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            double double4 = org.apache.commons.math3.special.Beta.regularizedBeta((double) 1, (double) 56, 1.0000000000005d, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: Continued fraction convergents failed to converge (in less than -1 iterations) for value 0");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math3.util.FastMath.asin(0.23621296409901363d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2384666681235159d + "'", double1 == 0.2384666681235159d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        long long2 = org.apache.commons.math3.util.FastMath.max(100L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        randomDataGenerator5.reSeed();
//        long long9 = randomDataGenerator5.nextSecureLong((long) (short) 10, (long) ' ');
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 25L + "'", long9 == 25L);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math3.util.FastMath.abs((-2239.8761611765112d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2239.8761611765112d + "'", double1 == 2239.8761611765112d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double1 = org.apache.commons.math3.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma1p(0.07277703352123166d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.037799108653239086d) + "'", double1 == (-0.037799108653239086d));
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(0.24348764167264014d);
//        try {
//            double double4 = randomDataImpl0.nextT((double) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.16448664296013477d + "'", double2 == 0.16448664296013477d);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        try {
            double double1 = org.apache.commons.math3.special.Gamma.invGamma1pm1(2.6881171418161356E43d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 26,881,171,418,161,356,000,000,000,000,000,000,000,000,000 is larger than the maximum (1.5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        long long1 = org.apache.commons.math3.util.FastMath.round((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math3.util.FastMath.signum(99328.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double3 = org.apache.commons.math3.special.Beta.regularizedBeta(1.5707963267948966d, 4.5916503662245255E10d, (double) (-1L));
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.0E-6d, (java.lang.Number) (-1), false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
        try {
            long long5 = randomDataImpl0.nextPoisson(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 4.5916503662245255E10d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        double double4 = uniformRealDistribution2.density((double) 3);
        try {
            double double7 = uniformRealDistribution2.cumulativeProbability((double) (short) 10, (double) 1.0000001f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (10) must be less than or equal to upper endpoint (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((-1.0d), (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.356194490192345d) + "'", double2 == (-2.356194490192345d));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeed();
        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution3 = null;
        try {
            int int4 = randomDataImpl0.nextInversionDeviate(integerDistribution3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 148.4131591025766d + "'", double1 == 148.4131591025766d);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(22026.465794806718d, 22025.465794806718d);
//        try {
//            int int6 = randomDataImpl0.nextSecureInt((int) '4', (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (52) must be strictly less than upper bound (52)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 36294.37152501356d + "'", double3 == 36294.37152501356d);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 148.4131591025766d, number1, false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int2 = org.apache.commons.math3.util.FastMath.max(3, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math3.special.Gamma.digamma((double) (-127));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        long long1 = org.apache.commons.math3.util.FastMath.round(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math3.util.FastMath.floor(0.2384666681235159d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double4 = org.apache.commons.math3.special.Beta.logBeta((double) 100L, (double) 1, 1.5707963267948966d, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-4.605170185988072d) + "'", double4 == (-4.605170185988072d));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100.0f);
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) notStrictlyPositiveException2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
        try {
            long long13 = randomDataGenerator5.nextLong((long) '4', 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (52) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (short) 100, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        randomDataGenerator5.reSeed();
        try {
            double double9 = randomDataGenerator5.nextGamma((-0.037799108653239086d), (double) 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-0.038)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(22026.465794806718d, 22025.465794806718d);
//        double double6 = randomDataImpl0.nextF((double) 56, 0.24348764167264014d);
//        try {
//            int int9 = randomDataImpl0.nextInt((int) '#', (-127));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (35) must be strictly less than upper bound (-127)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 17725.935568831872d + "'", double3 == 17725.935568831872d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.11294215769086617d + "'", double6 == 0.11294215769086617d);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 100L, true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(1.0000001f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        long long2 = org.apache.commons.math3.util.FastMath.min(10L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(0.24348764167264014d);
//        try {
//            int int5 = randomDataImpl0.nextSecureInt(96, 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (96) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2861210589472174d + "'", double2 == 0.2861210589472174d);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        long long2 = org.apache.commons.math3.util.FastMath.max(4491554327296166888L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4491554327296166888L + "'", long2 == 4491554327296166888L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution2 = null;
        try {
            int int3 = randomDataImpl0.nextInversionDeviate(integerDistribution2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(4.5916503662245255E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 24.550090446321256d + "'", double1 == 24.550090446321256d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        randomDataGenerator5.reSeed();
        try {
            double double12 = randomDataGenerator5.nextWeibull(0.0d, (double) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            double double4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(4.5916503662245255E10d, 45.88962247105999d, 32.0d, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (-1) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        try {
            int int11 = randomDataGenerator5.nextPascal((int) (byte) 10, (double) 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 5 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        double double4 = fDistribution3.getSupportLowerBound();
        double double5 = fDistribution3.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(0.2179200458706742d, 3.7244046011365866d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.21792004587067423d + "'", double2 == 0.21792004587067423d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(3, (double) (-1L), 0.0d);
        int int4 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        int int6 = iterativeLegendreGaussIntegrator3.getIterations();
        int int7 = iterativeLegendreGaussIntegrator3.getIterations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double5 = org.apache.commons.math3.special.Beta.regularizedBeta((-13.084024114284892d), (double) 5, 0.36787944117144233d, 0.0d, (int) (short) 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7165313105737893d + "'", double1 == 0.7165313105737893d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0000001f, (java.lang.Number) 1, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) 1L, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double4 = randomDataImpl0.nextUniform(0.0d, (double) (short) 100, true);
//        int int7 = randomDataImpl0.nextSecureInt(1, (int) (byte) 100);
//        try {
//            double double10 = randomDataImpl0.nextCauchy(10.0d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 98.86815544983658d + "'", double4 == 98.86815544983658d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 45 + "'", int7 == 45);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.3678794411714424d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) (short) 0, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double1 = org.apache.commons.math3.util.FastMath.atan(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
        try {
            randomDataGenerator5.setSecureAlgorithm("7aadde7dee4af34c754db517fcf2da8f6e1e1b0ace91cd2f5613f3a3", "fd5e975fc4e2918ecf01a28ddd6097f668d136c4c91e9fec017b");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: fd5e975fc4e2918ecf01a28ddd6097f668d136c4c91e9fec017b");
        } catch (java.security.NoSuchProviderException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.22202758411722212d, 58.0d, 10.0d, (int) 'a');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.598524091877789E-28d + "'", double4 == 6.598524091877789E-28d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) 4491554327296166888L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        double double4 = fDistribution3.getSupportLowerBound();
        try {
            double double7 = fDistribution3.cumulativeProbability((double) 96, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (96) must be less than or equal to upper endpoint (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        try {
            double double1 = org.apache.commons.math3.special.Gamma.invGamma1pm1((-2.356194490192345d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -2.356 is smaller than the minimum (-0.5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) (-1L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        double double4 = uniformRealDistribution2.density((double) 3);
        try {
            double double7 = uniformRealDistribution2.cumulativeProbability((double) '4', 0.3678794411714424d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (52) must be less than or equal to upper endpoint (0.368)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        boolean boolean6 = well19937c4.nextBoolean();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
        try {
            double double13 = randomDataGenerator5.nextCauchy(0.2384666681235159d, (-2.8131219329264736d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-2.813)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double4 = randomDataImpl0.nextUniform(0.0d, (double) (short) 100, true);
//        try {
//            double double7 = randomDataImpl0.nextBeta(6.545233034006089E42d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.874, 0.126]");
//        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 33.58571138901909d + "'", double4 == 33.58571138901909d);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator5 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(16, (double) (byte) 0, 0.0d, (-1), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass7 = maxCountExceededException6.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException6, localizable8, objArray11);
        java.lang.Throwable[] throwableArray13 = maxCountExceededException6.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable2, localizable3, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, number1, (java.lang.Object[]) throwableArray13);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (short) 10, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeed();
        try {
            double double4 = randomDataImpl0.nextExponential((-2.6188773144433135d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-2.619)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double2 = org.apache.commons.math3.util.FastMath.log(32.00000000000001d, 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.9863137138648344d) + "'", double2 == (-3.9863137138648344d));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        well19937c1.clear();
        well19937c1.clear();
        int int6 = well19937c1.nextInt();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 312574995 + "'", int6 == 312574995);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 96, (java.lang.Number) Double.POSITIVE_INFINITY, true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) -1, number1, false);
        org.apache.commons.math3.exception.MathInternalError mathInternalError4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) numberIsTooSmallException3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
        randomDataGenerator5.reSeedSecure((long) 3);
        try {
            double double15 = randomDataGenerator5.nextBeta(Double.NEGATIVE_INFINITY, 0.6931471805599453d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.703, 0.297]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(10.0d, (-1.0d), 1.0E-6d, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        int int8 = randomDataImpl0.nextPascal((int) (short) 1, (double) (byte) 0);
//        try {
//            double double11 = randomDataImpl0.nextUniform(99328.0d, (double) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (99,328) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 90 + "'", int5 == 90);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.0d, (java.lang.Number) 0.3678794411714424d, false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError2 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((double) (byte) 0, 119.31169712162223d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double3 = org.apache.commons.math3.special.Beta.regularizedBeta(0.6244422900440489d, (double) '4', 22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        double double4 = uniformRealDistribution2.cumulativeProbability((double) 100.0f);
        double double5 = uniformRealDistribution2.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.22202758411722212d + "'", double5 == 0.22202758411722212d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        try {
            double double4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(10.0d, 0.5403023058681398d, (double) (byte) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (-1) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double2 = org.apache.commons.math3.special.Beta.logBeta(0.6931471805599453d, (-2.8131219329264736d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
//        double double4 = uniformRealDistribution2.cumulativeProbability((double) 100.0f);
//        double double6 = uniformRealDistribution2.probability((double) 0.0f);
//        double double7 = uniformRealDistribution2.sample();
//        try {
//            double double10 = uniformRealDistribution2.probability((double) 5, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (5) must be less than or equal to upper endpoint (0)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.23411941417924353d + "'", double7 == 0.23411941417924353d);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double4 = org.apache.commons.math3.special.Beta.logBeta((-27.52762722326611d), 56.00588752486902d, 10.0d, (-127));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        double double5 = fDistribution3.density(0.2384666681235159d);
        double double6 = fDistribution3.getNumericalMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05918987686027852d + "'", double5 == 0.05918987686027852d);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma(4.5916503662245255E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.081337814212361E12d + "'", double1 == 1.081337814212361E12d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        randomDataGenerator5.reSeed();
        randomDataGenerator5.reSeedSecure();
        try {
            int int13 = randomDataGenerator5.nextBinomial(126355559, 2.6881171418161356E43d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 26,881,171,418,161,356,000,000,000,000,000,000,000,000,000 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math3.util.FastMath.atan(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(22026.465794806718d, 22025.465794806718d);
//        double double6 = randomDataImpl0.nextF((double) 56, 0.24348764167264014d);
//        try {
//            long long9 = randomDataImpl0.nextSecureLong((long) (short) 100, 25L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (100) must be strictly less than upper bound (25)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-23792.31019486756d) + "'", double3 == (-23792.31019486756d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 50061.764470356226d + "'", double6 == 50061.764470356226d);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 4491554327296166888L, number2, true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass2 = maxCountExceededException1.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException1, localizable3, objArray6);
        java.lang.Number number8 = maxCountExceededException1.getMax();
        java.lang.Throwable throwable9 = null;
        try {
            maxCountExceededException1.addSuppressed(throwable9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1 + "'", number8.equals(1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double1 = org.apache.commons.math3.special.Gamma.invGamma1pm1(0.24348764167264014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10160160602240308d + "'", double1 == 0.10160160602240308d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        long long5 = well19937c4.nextLong();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        try {
            int int9 = randomDataGenerator6.nextPascal(2147483647, (-27.52762722326611d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: -27.528 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4491554327296166888L + "'", long5 == 4491554327296166888L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        try {
            org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution3 = new org.apache.commons.math3.distribution.UniformRealDistribution(58.0019903315599d, (-4.605170185988072d), (-0.037799108653239086d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (58.002) must be strictly less than upper bound (-4.605)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        double double4 = uniformRealDistribution2.cumulativeProbability((double) 100.0f);
        double double6 = uniformRealDistribution2.probability((double) 0.0f);
        double[] doubleArray8 = uniformRealDistribution2.sample(100);
        try {
            double double11 = uniformRealDistribution2.cumulativeProbability((double) 56, (-0.037799108653239086d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (56) must be less than or equal to upper endpoint (-0.038)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 100L, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E20d + "'", double2 == 1.0E20d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double1 = org.apache.commons.math3.util.FastMath.exp(2239.8761611765112d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) (short) 0, (-0.9999999999999999d), 0.0d);
        double double4 = iterativeLegendreGaussIntegrator3.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        int int3 = well19937c1.nextInt((int) 'a');
        int[] intArray7 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        well19937c1.setSeed(intArray7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(58.0d, 32.0d, 3.7244046011365866d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double4 = randomDataImpl0.nextUniform(0.0d, (double) (short) 100, true);
//        double double6 = randomDataImpl0.nextChiSquare((double) (byte) 1);
//        try {
//            int int9 = randomDataImpl0.nextBinomial((int) '4', (double) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 61.71606299149135d + "'", double4 == 61.71606299149135d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.20573644920825312d + "'", double6 == 0.20573644920825312d);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.21792004587067423d, 0.7165313105737893d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9093347211105907d + "'", double2 == 0.9093347211105907d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((-13.084024114284892d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-13.0d) + "'", double1 == (-13.0d));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 119.31169712162223d, (java.lang.Number) 52.000004f, (java.lang.Number) 0.9188096140161933d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (short) 10, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((-2.8131219329264736d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) 10L, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math3.special.Gamma.invGamma1pm1(0.9188096140161933d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03268622397329245d + "'", double1 == 0.03268622397329245d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        boolean boolean5 = well19937c4.nextBoolean();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(56, (-127), (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -127 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        boolean boolean1 = uniformRealDistribution0.isSupportLowerBoundInclusive();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass9 = maxCountExceededException8.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException8, localizable10, objArray13);
        java.lang.Throwable[] throwableArray15 = maxCountExceededException8.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException4, localizable6, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext18 = mathIllegalStateException17.getContext();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(exceptionContext18);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(0.2179200458706742d, (double) 10, 1.0E-9d, (double) 20);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0120109766461515E-17d + "'", double4 == 3.0120109766461515E-17d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((double) 1.1920929E-7f, (double) 25L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.376388310887451E-20d + "'", double2 == 6.376388310887451E-20d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) (-127), (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 127.0f + "'", float2 == 127.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
        randomDataImpl0.reSeedSecure((long) (short) 1);
        try {
            int int8 = randomDataImpl0.nextPascal(3, 22026.465794806718d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 22,026.466 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        well19937c1.clear();
        float float5 = well19937c1.nextFloat();
        well19937c1.setSeed((long) (byte) -1);
        float float8 = well19937c1.nextFloat();
        long long9 = well19937c1.nextLong();
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.07277703f + "'", float5 == 0.07277703f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.23953891f + "'", float8 == 0.23953891f);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1722448868039600408L) + "'", long9 == (-1722448868039600408L));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeed();
        try {
            randomDataImpl0.setSecureAlgorithm("hi!", "org.apache.commons.math3.exception.NumberIsTooLargeException: 1 is larger than the maximum (10)");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math3.exception.NumberIsTooLargeException: 1 is larger than the maximum (10)");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double4 = org.apache.commons.math3.special.Beta.logBeta(Double.POSITIVE_INFINITY, (double) ' ', (double) (byte) 100, (int) '#');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        int int8 = randomDataGenerator5.nextSecureInt(56, 2147483647);
//        try {
//            int int12 = randomDataGenerator5.nextHypergeometric((int) (short) -1, 20, 43);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-1)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 760168364 + "'", int8 == 760168364);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta((double) 1, (double) 100L, (double) (short) 100, (double) 73);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        int int7 = well19937c4.nextInt((int) '#');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 22 + "'", int7 == 22);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math3.special.Gamma.gamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double0 = org.apache.commons.math3.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        double double4 = randomDataImpl0.nextExponential((double) '#');
//        try {
//            double double8 = randomDataImpl0.nextUniform(95.99024473023697d, (-4.605170185988072d), false);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (95.99) must be strictly less than upper bound (-4.605)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 18.794812523752867d + "'", double4 == 18.794812523752867d);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.36787944117144233d + "'", double2 == 0.36787944117144233d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int int0 = org.apache.commons.math3.analysis.integration.BaseAbstractUnivariateIntegrator.DEFAULT_MAX_ITERATIONS_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2147483647 + "'", int0 == 2147483647);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(3, (double) (-1L), 0.0d);
        int int4 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        double double5 = iterativeLegendreGaussIntegrator3.getAbsoluteAccuracy();
        double double6 = iterativeLegendreGaussIntegrator3.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) 312574995);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.12575008E8f + "'", float1 == 3.12575008E8f);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math3.random.RandomGenerator randomGenerator0 = null;
        try {
            org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution4 = new org.apache.commons.math3.distribution.UniformRealDistribution(randomGenerator0, (double) (byte) 10, (double) 0L, (double) 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) 1, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) 16);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution((double) 96, (-4.605170185988072d), (double) (-1684074324264821833L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-4.605)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double1 = org.apache.commons.math3.util.FastMath.exp(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        int int8 = randomDataGenerator5.nextSecureInt(56, 2147483647);
//        try {
//            int[] intArray11 = randomDataGenerator5.nextPermutation(16, 56);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: permutation size (56) exceeds permuation domain (16)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 516941050 + "'", int8 == 516941050);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        boolean boolean3 = uniformRealDistribution2.isSupportConnected();
        double double5 = uniformRealDistribution2.cumulativeProbability(0.9093347211105907d);
        double double7 = uniformRealDistribution2.density(0.21792004587067423d);
        double double9 = uniformRealDistribution2.cumulativeProbability(4.9E-324d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math3.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math3.util.FastMath.abs(4.7421875d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.7421875d + "'", double1 == 4.7421875d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        try {
            org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(10.0d, 9.630671211899795E-4d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10) must be strictly less than upper bound (0.001)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0000001f + "'", float1 == 1.0000001f);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str3 = randomDataImpl0.nextSecureHexString((int) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) (short) 100);
//        try {
//            double double9 = randomDataImpl0.nextF((-2.6188773144433135d), (double) 10L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-2.619)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1434af8d648ebf0bd101eefcb7d4faecf77c35a3b8839821fd2a" + "'", str3.equals("1434af8d648ebf0bd101eefcb7d4faecf77c35a3b8839821fd2a"));
//        org.junit.Assert.assertNotNull(intArray6);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(0.24348764167264014d);
//        double double5 = randomDataImpl0.nextCauchy((double) 56, (double) 0.07277703f);
//        double double8 = randomDataImpl0.nextGamma(99328.0d, (double) 10);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.027524864880781395d + "'", double2 == 0.027524864880781395d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 56.13352067336168d + "'", double5 == 56.13352067336168d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 999121.8061817774d + "'", double8 == 999121.8061817774d);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(0.6295433018518722d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(3.0120109766461515E-17d, (double) 5, 0.0d, 55);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 61, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(4.59164579563705E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.013933721922121E8d + "'", double1 == 8.013933721922121E8d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        float float2 = org.apache.commons.math3.util.FastMath.copySign(1.0f, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(3, (double) (-1L), 0.0d);
        int int4 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        int int6 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        int int7 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        int int8 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 0.23953891f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6206239346111186d) + "'", double1 == (-0.6206239346111186d));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 1, (java.lang.Number) 3.661826586795296E-41d, (java.lang.Number) 100L);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getLo();
        java.lang.Throwable throwable6 = null;
        try {
            outOfRangeException3.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 3.661826586795296E-41d + "'", number4.equals(3.661826586795296E-41d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 3.661826586795296E-41d + "'", number5.equals(3.661826586795296E-41d));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0000001f, (java.lang.Number) 1, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1 + "'", number4.equals(1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        double double4 = fDistribution3.getSupportLowerBound();
        double double5 = fDistribution3.getDenominatorDegreesOfFreedom();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(718070342);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double5 = org.apache.commons.math3.special.Beta.regularizedBeta((double) 0L, 5.777369773044773d, 0.0d, 0.21792004587067423d, (-1));
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(9.630671211899795E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0842021724855044E-19d + "'", double1 == 1.0842021724855044E-19d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeedSecure();
        try {
            int[] intArray5 = randomDataImpl0.nextPermutation(96, 312574995);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: permutation size (312,574,995) exceeds permuation domain (96)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(0.03125d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7904931097838226d + "'", double1 == 1.7904931097838226d);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        int int8 = randomDataImpl0.nextSecureInt((int) (byte) 10, 100);
//        try {
//            int[] intArray11 = randomDataImpl0.nextPermutation(56, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: permutation size (100) exceeds permuation domain (56)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 41 + "'", int8 == 41);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeed((long) 100);
        try {
            int int6 = randomDataImpl0.nextPascal((int) '#', 99328.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 99,328 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(0.22202758411722212d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22024271386553707d + "'", double1 == 0.22024271386553707d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (-4.605170185988072d), (java.lang.Number) 2147483647, true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math3.distribution.FDistribution fDistribution2 = new org.apache.commons.math3.distribution.FDistribution(24.550090446321256d, 0.2179200458706742d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) ' ', (double) 100, (-2239.8761611765112d));
        int int4 = iterativeLegendreGaussIntegrator3.getIterations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math3.util.FastMath.atan(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707509268651654d + "'", double1 == 1.5707509268651654d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(number0, (java.lang.Number) (short) -1, false);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (-1)" + "'", str4.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (-1)"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) '4', (-0.0d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double11 = randomDataGenerator5.nextGaussian(119.31169712162223d, 0.36787944117144233d);
        try {
            long long13 = randomDataGenerator5.nextPoisson((-0.037799108653239086d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-0.038)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 119.57133787457882d + "'", double11 == 119.57133787457882d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math3.random.Well19937c well19937c0 = new org.apache.commons.math3.random.Well19937c();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 97L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
        try {
            double double6 = randomDataImpl0.nextGamma(0.22202758411722212d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 77);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        randomDataGenerator5.reSeed();
//        double double12 = randomDataGenerator5.nextWeibull(0.2179200458706742d, 3.7244046011365866d);
//        try {
//            double double15 = randomDataGenerator5.nextWeibull(0.33499450848006207d, (-2.8131219329264736d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-2.813)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.025784907884473313d + "'", double12 == 0.025784907884473313d);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.158638853279167d + "'", double1 == 4.158638853279167d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        long long5 = well19937c4.nextLong();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        try {
            int int10 = randomDataGenerator6.nextHypergeometric(1, 20, 81);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (20) must be less than or equal to population size (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4491554327296166888L + "'", long5 == 4491554327296166888L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        try {
            double double11 = randomDataGenerator5.nextGamma(0.0d, 1.5707509268651654d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        randomDataGenerator5.reSeed();
        randomDataGenerator5.reSeed();
        try {
            int[] intArray10 = randomDataGenerator5.nextPermutation((int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (0");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((-13.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.3513346877207577d) + "'", double1 == (-2.3513346877207577d));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math3.util.FastMath.acos((-2239.8761611765112d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 403.4287934927351d + "'", double1 == 403.4287934927351d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 1, (java.lang.Number) 3.661826586795296E-41d, (java.lang.Number) 100L);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray9 = numberIsTooLargeException8.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException3, localizable4, (java.lang.Object[]) throwableArray9);
        org.apache.commons.math3.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException3, localizable11, objArray12);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass9 = maxCountExceededException8.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException8, localizable10, objArray13);
        java.lang.Throwable[] throwableArray15 = maxCountExceededException8.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException4, localizable6, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100L, (java.lang.Number) 0, false);
        mathIllegalStateException17.addSuppressed((java.lang.Throwable) numberIsTooLargeException21);
        boolean boolean23 = numberIsTooLargeException21.getBoundIsAllowed();
        org.apache.commons.math3.exception.MathInternalError mathInternalError24 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException21);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double4 = randomDataImpl0.nextUniform(0.0d, (double) (short) 100, true);
//        int int7 = randomDataImpl0.nextSecureInt(1, (int) (byte) 100);
//        org.apache.commons.math3.distribution.FDistribution fDistribution11 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
//        double double12 = fDistribution11.getSupportLowerBound();
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) fDistribution11);
//        long long16 = randomDataImpl0.nextSecureLong((long) (-1), (long) 18);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 41.64541731179294d + "'", double4 == 41.64541731179294d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 71 + "'", int7 == 71);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 11L + "'", long16 == 11L);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double3 = org.apache.commons.math3.special.Beta.regularizedBeta(1.0E-6d, (double) 100L, (double) 'a');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        try {
            org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution3 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.0d, 0.0d, 119.57133787457882d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        double double4 = randomDataImpl0.nextExponential((double) '#');
//        randomDataImpl0.reSeed((long) 1);
//        try {
//            double double9 = randomDataImpl0.nextUniform((double) 5, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (5) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 17.255125752982504d + "'", double4 == 17.255125752982504d);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 7.552320366736548d, (java.lang.Number) 99328.0d, true);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        double double4 = randomDataImpl0.nextExponential((double) '#');
//        try {
//            int int8 = randomDataImpl0.nextHypergeometric(10, (int) 'a', 71);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (97) must be less than or equal to population size (10)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 64.62825654098816d + "'", double4 == 64.62825654098816d);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double double1 = org.apache.commons.math3.special.Gamma.trigamma(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.878762514980041d + "'", double1 == 2.878762514980041d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        double double1 = org.apache.commons.math3.special.Gamma.digamma(0.10160160602240308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-10.263825850858487d) + "'", double1 == (-10.263825850858487d));
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        int int8 = randomDataImpl0.nextPascal((int) (short) 1, (double) (byte) 0);
//        double double11 = randomDataImpl0.nextCauchy((double) 16, Double.NaN);
//        randomDataImpl0.reSeedSecure((long) 20);
//        java.lang.String str15 = randomDataImpl0.nextHexString((int) (short) 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 22 + "'", int5 == 22);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "c" + "'", str15.equals("c"));
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        int int8 = randomDataGenerator5.nextSecureInt(56, 2147483647);
//        try {
//            int int12 = randomDataGenerator5.nextHypergeometric((int) '4', 126355559, 6);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (126,355,559) must be less than or equal to population size (52)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1526114620 + "'", int8 == 1526114620);
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        double double4 = randomDataImpl0.nextExponential((double) '#');
//        try {
//            double double8 = randomDataImpl0.nextUniform(1.5707963267948966d, 0.5403023058681398d, true);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (1.571) must be strictly less than upper bound (0.54)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 80.64813177556611d + "'", double4 == 80.64813177556611d);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(96, (int) (byte) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(0.6244422900440489d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        randomDataGenerator5.reSeed();
//        double double11 = randomDataGenerator5.nextChiSquare((double) 10L);
//        double double14 = randomDataGenerator5.nextBeta(0.23621296409901363d, (double) '#');
//        try {
//            int int18 = randomDataGenerator5.nextHypergeometric(73, (int) 'a', (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of samples (-1)");
//        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 9.462420095758905d + "'", double11 == 9.462420095758905d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        try {
            double double1 = org.apache.commons.math3.special.Gamma.logGamma1p(56.13352067336168d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 56.134 is larger than the maximum (1.5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        try {
            double double1 = org.apache.commons.math3.special.Gamma.logGamma1p(3.7410061210199634d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 3.741 is larger than the maximum (1.5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 6.376388310887451E-20d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.4E-45f + "'", float2 == 1.4E-45f);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) (-1722448868039600408L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.72244886803960038E18d + "'", double1 == 1.72244886803960038E18d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double double1 = org.apache.commons.math3.util.FastMath.sin(99328.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2619782247946564d) + "'", double1 == (-0.2619782247946564d));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(0.2384666681235159d, (double) 0L, 9.98337712458582d, (double) 55);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        long long5 = well19937c4.nextLong();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        try {
            double double9 = randomDataGenerator6.nextCauchy(0.21792004587067423d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4491554327296166888L + "'", long5 == 4491554327296166888L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double1 = org.apache.commons.math3.util.FastMath.exp((-4.605170185988072d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010000000000000191d + "'", double1 == 0.010000000000000191d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        boolean boolean3 = uniformRealDistribution2.isSupportConnected();
        double double5 = uniformRealDistribution2.cumulativeProbability(0.9093347211105907d);
        double double7 = uniformRealDistribution2.density((double) 56);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        well19937c1.clear();
        well19937c1.clear();
        double double6 = well19937c1.nextDouble();
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution10 = new org.apache.commons.math3.distribution.UniformRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (-27.52762722326611d), (-2.6188773144433135d), (double) 0);
        double double11 = well19937c1.nextDouble();
        double double12 = well19937c1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.07277703352123166d + "'", double6 == 0.07277703352123166d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.33499450848006207d + "'", double11 == 0.33499450848006207d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.74353241141009d + "'", double12 == 1.74353241141009d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math3.util.FastMath.log((-2.3513346877207577d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0.22202758411722212d, (java.lang.Number) (byte) 10, (java.lang.Number) 0.12336904722135343d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.12336904722135343d + "'", number4.equals(0.12336904722135343d));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) 718070342, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.35304030208E11d + "'", double2 == 7.35304030208E11d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        double double2 = uniformRealDistribution0.probability(10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double1 = org.apache.commons.math3.special.Gamma.digamma(0.12336904722135343d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.496519887386446d) + "'", double1 == (-8.496519887386446d));
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double4 = randomDataImpl0.nextUniform(0.0d, (double) (short) 100, true);
//        try {
//            int int7 = randomDataImpl0.nextPascal((int) ' ', (double) 11L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 11 out of [0, 1] range");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 70.60267964958942d + "'", double4 == 70.60267964958942d);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        double double4 = uniformRealDistribution2.cumulativeProbability((double) 100.0f);
        double[] doubleArray6 = uniformRealDistribution2.sample((int) (short) 100);
        boolean boolean7 = uniformRealDistribution2.isSupportLowerBoundInclusive();
        double double9 = uniformRealDistribution2.probability((double) 0.23953891f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        randomDataGenerator5.reSeed();
//        double double11 = randomDataGenerator5.nextChiSquare((double) 10L);
//        double double13 = randomDataGenerator5.nextChiSquare((double) ' ');
//        try {
//            long long16 = randomDataGenerator5.nextSecureLong((long) 61, (long) 61);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (61) must be strictly less than upper bound (61)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 6.213874312781928d + "'", double11 == 6.213874312781928d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 29.706761436984905d + "'", double13 == 29.706761436984905d);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        boolean boolean3 = uniformRealDistribution2.isSupportConnected();
        double double5 = uniformRealDistribution2.cumulativeProbability(0.9093347211105907d);
        double double7 = uniformRealDistribution2.cumulativeProbability(1.5707509268651654d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double4 = randomDataImpl0.nextUniform(0.0d, (double) (short) 100, true);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        try {
//            int int9 = randomDataImpl0.nextBinomial(20, (double) 5);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 5 out of [0, 1] range");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 31.58672001446201d + "'", double4 == 31.58672001446201d);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass4 = maxCountExceededException3.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException3, localizable5, objArray8);
        java.lang.Throwable[] throwableArray10 = maxCountExceededException3.getSuppressed();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 58.0d, (java.lang.Object[]) throwableArray10);
        java.lang.Number number12 = maxCountExceededException11.getMax();
        java.lang.Number number13 = maxCountExceededException11.getMax();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 58.0d + "'", number12.equals(58.0d));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 58.0d + "'", number13.equals(58.0d));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(3.94319959666758E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9431995946238426E-5d + "'", double1 == 3.9431995946238426E-5d);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        double double4 = randomDataImpl0.nextExponential((double) '#');
//        try {
//            int[] intArray7 = randomDataImpl0.nextPermutation((int) (byte) 1, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: permutation size (32) exceeds permuation domain (1)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 19.747562056856587d + "'", double4 == 19.747562056856587d);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta((double) (short) 1, 1.74353241141009d, (-2.356194490192345d), (double) 52.000004f);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 1, (java.lang.Number) 3.661826586795296E-41d, (java.lang.Number) 100L);
        java.lang.String str4 = outOfRangeException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 1 out of [0, 100] range" + "'", str4.equals("org.apache.commons.math3.exception.OutOfRangeException: 1 out of [0, 100] range"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double1 = org.apache.commons.math3.util.FastMath.acos(56.190433649118546d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((-0.6206239346111186d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) 61, (-1722448868039600408L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1722448868039600408L) + "'", long2 == (-1722448868039600408L));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        long long5 = well19937c4.nextLong();
        well19937c4.setSeed((long) 2147483647);
        double double8 = well19937c4.nextGaussian();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4491554327296166888L + "'", long5 == 4491554327296166888L);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.324620071042733d) + "'", double8 == (-1.324620071042733d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) 126355559);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.347757568224782d + "'", double1 == 19.347757568224782d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(119.57133787457882d, 0.24337046883404329d, 4.9E-324d, (double) (byte) -1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
        int int13 = randomDataGenerator5.nextPascal((int) (byte) 100, 0.7165313105737893d);
        double double16 = randomDataGenerator5.nextBeta(0.03268622397329245d, (double) (byte) 1);
        try {
            double double19 = randomDataGenerator5.nextF(0.0d, 0.6931471805599453d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(3, (double) (-1L), 0.0d);
        int int4 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        int int6 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        double double7 = iterativeLegendreGaussIntegrator3.getAbsoluteAccuracy();
        int int8 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        double double9 = iterativeLegendreGaussIntegrator3.getAbsoluteAccuracy();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction11 = null;
        try {
            double double14 = iterativeLegendreGaussIntegrator3.integrate((int) (short) 100, univariateFunction11, (double) 10.0f, (double) 718070342);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 0.5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math3.util.FastMath.exp(5.777369773044773d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 322.9087491846179d + "'", double1 == 322.9087491846179d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math3.special.Gamma.digamma(148.4131591025766d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.996627243155801d + "'", double1 == 4.996627243155801d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
        double double12 = randomDataGenerator5.nextT((double) 16);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.5426062697381586d + "'", double12 == 0.5426062697381586d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 20);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double2 = org.apache.commons.math3.util.FastMath.min(1.74353241141009d, 0.3678794411714424d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3678794411714424d + "'", double2 == 0.3678794411714424d);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        double double9 = randomDataImpl0.nextT((double) (short) 1);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.5663321581939567d) + "'", double9 == (-1.5663321581939567d));
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
        try {
            double double13 = randomDataGenerator5.nextWeibull(0.0d, 33.97851105680891d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        double double5 = fDistribution3.density(0.0d);
        double double6 = fDistribution3.sample();
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.0d, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        double double5 = fDistribution3.density(0.0d);
        double double6 = fDistribution3.getNumeratorDegreesOfFreedom();
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.03125d + "'", double6 == 0.03125d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) (-1));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
        int int13 = randomDataGenerator5.nextPascal((int) (byte) 100, 0.7165313105737893d);
        int[] intArray16 = randomDataGenerator5.nextPermutation((int) (short) 100, (int) '#');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) 77);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 77.0d + "'", double1 == 77.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double1 = org.apache.commons.math3.util.FastMath.acos(0.05872209840604111d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5120404274924428d + "'", double1 == 1.5120404274924428d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((-4.605170185988072d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9899999999999998d) + "'", double1 == (-0.9899999999999998d));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(24.550090446321256d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int int2 = org.apache.commons.math3.util.FastMath.min(18, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 312574995, 3.661826586795296E-41d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        double double9 = randomDataImpl0.nextT((double) (short) 1);
//        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution10 = null;
//        try {
//            int int11 = randomDataImpl0.nextInversionDeviate(integerDistribution10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.39762932452378463d) + "'", double9 == (-0.39762932452378463d));
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        float float2 = org.apache.commons.math3.util.FastMath.max(0.07277703f, (float) 48);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 48.0f + "'", float2 == 48.0f);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
        int int13 = randomDataGenerator5.nextPascal((int) (byte) 100, 0.7165313105737893d);
        double double16 = randomDataGenerator5.nextBeta(0.03268622397329245d, (double) (byte) 1);
        try {
            int int19 = randomDataGenerator5.nextInt((int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (32) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) (byte) 1, Double.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, number1, (java.lang.Number) (byte) 100, (java.lang.Number) 3.9431995946238426E-5d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        int int4 = randomDataImpl0.nextPascal((int) '#', (double) (short) 1);
        try {
            double double7 = randomDataImpl0.nextGamma((double) 42, (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator5 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(59, 2.878762514980041d, (double) 0.23953891f, 0, 43);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass2 = maxCountExceededException1.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException1, localizable3, objArray6);
        java.lang.Throwable[] throwableArray8 = maxCountExceededException1.getSuppressed();
        org.apache.commons.math3.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException1, localizable9, objArray10);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray10);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double4 = randomDataImpl0.nextUniform(0.0d, (double) (short) 100, true);
//        int int7 = randomDataImpl0.nextSecureInt(1, (int) (byte) 100);
//        org.apache.commons.math3.distribution.FDistribution fDistribution11 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
//        double double12 = fDistribution11.getSupportLowerBound();
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) fDistribution11);
//        int int16 = randomDataImpl0.nextInt(0, (int) (short) 1);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 11.857106227542126d + "'", double4 == 11.857106227542126d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 43 + "'", int7 == 43);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
        randomDataGenerator5.reSeedSecure((long) 3);
        try {
            long long15 = randomDataGenerator5.nextSecureLong(100L, (long) 20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (100) must be strictly less than upper bound (20)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma(0.12336904722135343d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.033187308418798d + "'", double1 == 2.033187308418798d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double1 = org.apache.commons.math3.util.FastMath.tan(0.2384666681235159d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.24309215362903655d + "'", double1 == 0.24309215362903655d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 7035070615930559438L, (float) 25L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.0350707E18f + "'", float2 == 7.0350707E18f);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 11L, 0.01789962561529476d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.569169089538853d + "'", double2 == 1.569169089538853d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math3.special.Gamma.digamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        double double4 = well19937c1.nextDouble();
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution8 = new org.apache.commons.math3.distribution.UniformRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (-2.6188773144433135d), (double) 3.12575008E8f, (-2.8131219329264736d));
        try {
            double[] doubleArray10 = uniformRealDistribution8.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of samples (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.07277703352123166d + "'", double4 == 0.07277703352123166d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma(45.88962247105999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 128.70267574936713d + "'", double1 == 128.70267574936713d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        double double4 = well19937c1.nextDouble();
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution8 = new org.apache.commons.math3.distribution.UniformRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (-2.6188773144433135d), (double) 3.12575008E8f, (-2.8131219329264736d));
        double double9 = uniformRealDistribution8.getSupportUpperBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.07277703352123166d + "'", double4 == 0.07277703352123166d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.12575008E8d + "'", double9 == 3.12575008E8d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((double) 43, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999997424084d + "'", double2 == 0.9999999997424084d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, 0.24348764167264014d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 6);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        boolean boolean4 = fDistribution3.isSupportUpperBoundInclusive();
        double double5 = fDistribution3.getDenominatorDegreesOfFreedom();
        double double6 = fDistribution3.getNumericalMean();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma1p(3.9431995946238426E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.275948694363265E-5d) + "'", double1 == (-2.275948694363265E-5d));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100L, (java.lang.Number) 0, false);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator11 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(126355559, 56, 126355559);
        java.lang.Object[] objArray13 = new java.lang.Object[] { 4.9E-324d, 4.5916503662245255E10d, 56, 0.3678794411714424d };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray13);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray13);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double1 = org.apache.commons.math3.special.Gamma.gamma(3.0120109766461515E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.3200410216083988E16d + "'", double1 == 3.3200410216083988E16d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta((double) 1.0f, 4.5916503662245255E10d, 3.837783919015451E-5d, 3.7873579346816575d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.05872209840604111d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double double1 = org.apache.commons.math3.util.FastMath.sin((-0.037799108653239086d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.037790108241021206d) + "'", double1 == (-0.037790108241021206d));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException2 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass3 = maxCountExceededException2.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException2, localizable4, objArray7);
        java.lang.Throwable[] throwableArray9 = maxCountExceededException2.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray9);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = mathIllegalArgumentException10.getContext();
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (-2.8131219329264736d));
        mathIllegalArgumentException10.addSuppressed((java.lang.Throwable) notStrictlyPositiveException13);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(exceptionContext11);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 56);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        double double9 = randomDataImpl0.nextT((double) (short) 1);
//        try {
//            double double12 = randomDataImpl0.nextBeta(3.7244046011365866d, (-2.275948694363265E-5d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.751, 0.249]");
//        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9861080646017657d + "'", double9 == 0.9861080646017657d);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        float float1 = org.apache.commons.math3.util.FastMath.signum(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
        randomDataImpl0.reSeedSecure((long) (short) 1);
        try {
            long long8 = randomDataImpl0.nextSecureLong((long) 126355559, (-1722448868039600408L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (126,355,559) must be strictly less than upper bound (-1,722,448,868,039,600,408)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        randomDataGenerator5.reSeed();
//        double double11 = randomDataGenerator5.nextChiSquare((double) 10L);
//        double double14 = randomDataGenerator5.nextBeta(0.23621296409901363d, (double) '#');
//        double double17 = randomDataGenerator5.nextCauchy(0.05918987686027852d, 27.58299774743538d);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 12.579105630001806d + "'", double11 == 12.579105630001806d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0012238168379059867d + "'", double14 == 0.0012238168379059867d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-48.450227917950635d) + "'", double17 == (-48.450227917950635d));
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math3.util.FastMath.acos((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        int int2 = org.apache.commons.math3.util.FastMath.max(16, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double double1 = org.apache.commons.math3.util.FastMath.log10(0.22202758411722212d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6535930666047297d) + "'", double1 == (-0.6535930666047297d));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(3, (double) (-1L), 0.0d);
        int int4 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        int int6 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        double double7 = iterativeLegendreGaussIntegrator3.getAbsoluteAccuracy();
        double double8 = iterativeLegendreGaussIntegrator3.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (short) 1);
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        int int8 = randomDataImpl0.nextSecureInt((int) (byte) 10, 100);
//        try {
//            double double11 = randomDataImpl0.nextCauchy((double) (-1.0f), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 44 + "'", int5 == 44);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double3 = org.apache.commons.math3.special.Beta.regularizedBeta(59.86013540096972d, (double) 'a', 12.579105630001806d);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        double double4 = randomDataImpl0.nextUniform(0.3678794411714424d, (double) 20);
//        try {
//            long long7 = randomDataImpl0.nextSecureLong((long) 48, 11L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (48) must be strictly less than upper bound (11)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 11.524382150145263d + "'", double4 == 11.524382150145263d);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double double2 = org.apache.commons.math3.special.Beta.logBeta((double) 10L, 4.591680058139221E10d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-232.6990966796875d) + "'", double2 == (-232.6990966796875d));
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        double double9 = randomDataImpl0.nextT((double) (short) 1);
//        try {
//            double double12 = randomDataImpl0.nextGamma(0.0d, 1.5707509268651654d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-2.953822634591067d) + "'", double9 == (-2.953822634591067d));
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        double double5 = well19937c4.nextDouble();
        well19937c4.clear();
        double double7 = well19937c4.nextGaussian();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.24348764167264014d + "'", double5 == 0.24348764167264014d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7057767406893092d + "'", double7 == 0.7057767406893092d);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        randomDataGenerator5.reSeed();
//        double double12 = randomDataGenerator5.nextWeibull(0.2179200458706742d, 3.7244046011365866d);
//        int int15 = randomDataGenerator5.nextInt(55, 61);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 7.532689071894598d + "'", double12 == 7.532689071894598d);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 59 + "'", int15 == 59);
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        double double4 = uniformRealDistribution2.cumulativeProbability((double) 100.0f);
        double[] doubleArray6 = uniformRealDistribution2.sample((int) (short) 100);
        boolean boolean7 = uniformRealDistribution2.isSupportLowerBoundInclusive();
        try {
            double double10 = uniformRealDistribution2.cumulativeProbability(0.24001511650651183d, (-2.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (0.24) must be less than or equal to upper endpoint (-2)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double double5 = org.apache.commons.math3.special.Beta.regularizedBeta(0.07277703352123166d, 0.7025604821240949d, 0.5772156649015329d, 0.21792004587067423d, 3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.10311988393098495d + "'", double5 == 0.10311988393098495d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        double double5 = well19937c4.nextDouble();
        well19937c4.clear();
        double double7 = well19937c4.nextDouble();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.24348764167264014d + "'", double5 == 0.24348764167264014d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9087061452935035d + "'", double7 == 0.9087061452935035d);
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        int int8 = randomDataImpl0.nextSecureInt((int) (byte) 10, 100);
//        randomDataImpl0.reSeedSecure((long) 43);
//        try {
//            double double13 = randomDataImpl0.nextUniform((double) 4491554327296166888L, (double) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (4,491,554,327,296,166,900) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 82 + "'", int8 == 82);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.93006726156716E14d + "'", double1 == 7.93006726156716E14d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException(number0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double1 = org.apache.commons.math3.util.FastMath.floor(0.10160160602240308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        try {
            int int12 = randomDataGenerator5.nextHypergeometric((int) (short) 0, 77, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (-2.8131219329264736d));
        java.lang.Throwable[] throwableArray2 = notStrictlyPositiveException1.getSuppressed();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double2 = org.apache.commons.math3.special.Beta.logBeta(3.661826586795296E-41d, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 93.10802672240492d + "'", double2 == 93.10802672240492d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 33);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 33.000004f + "'", float1 == 33.000004f);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextSecureInt(20, (int) 'a');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(96);
//        try {
//            long long9 = randomDataImpl0.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 85 + "'", int5 == 85);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "73e581a4d7a14f7f0ca71de7ced98062b08d6d4c6d63857d31ad8b7d70bb72a106ead288846724283899a4ad1fa6ad12" + "'", str7.equals("73e581a4d7a14f7f0ca71de7ced98062b08d6d4c6d63857d31ad8b7d70bb72a106ead288846724283899a4ad1fa6ad12"));
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double2 = org.apache.commons.math3.util.FastMath.min(Double.NEGATIVE_INFINITY, 67.57542045537947d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        randomDataGenerator5.reSeed();
//        double double11 = randomDataGenerator5.nextChiSquare((double) 10L);
//        double double13 = randomDataGenerator5.nextChiSquare((double) ' ');
//        double double16 = randomDataGenerator5.nextF(0.6295433018518722d, (double) 4);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 12.319051132276686d + "'", double11 == 12.319051132276686d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 33.20718722417985d + "'", double13 == 33.20718722417985d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.16326867113596238d + "'", double16 == 0.16326867113596238d);
//    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double4 = randomDataImpl0.nextUniform(0.0d, (double) (short) 100, true);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        double double10 = randomDataImpl0.nextUniform((double) 2147483647, (double) 7035070615930559438L, false);
//        randomDataImpl0.reSeedSecure((long) 22);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 93.35352269175077d + "'", double4 == 93.35352269175077d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.00488766716866125E18d + "'", double10 == 2.00488766716866125E18d);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        try {
            int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: permutation size (35) exceeds permuation domain (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double4 = randomDataImpl0.nextUniform(0.0d, (double) (short) 100, true);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        double double9 = randomDataImpl0.nextGaussian(Double.NaN, 24.550090446321256d);
//        double double12 = randomDataImpl0.nextGamma((double) 100.0f, 322.9087491846179d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.265393921879147d + "'", double4 == 5.265393921879147d);
//        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 32565.154024260602d + "'", double12 == 32565.154024260602d);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double1 = org.apache.commons.math3.util.FastMath.floor(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.0d + "'", double1 == 22026.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double2 = org.apache.commons.math3.util.FastMath.pow(5.605475678368494d, 0.7165313105737893d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.4387790803606046d + "'", double2 == 3.4387790803606046d);
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(22026.465794806718d, 22025.465794806718d);
//        double double5 = randomDataImpl0.nextExponential((double) '#');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-17200.126683381d) + "'", double3 == (-17200.126683381d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 23.17377526703116d + "'", double5 == 23.17377526703116d);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double4 = randomDataImpl0.nextUniform(0.0d, (double) (short) 100, true);
//        int int7 = randomDataImpl0.nextSecureInt(1, (int) (byte) 100);
//        org.apache.commons.math3.distribution.FDistribution fDistribution11 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
//        double double12 = fDistribution11.getSupportLowerBound();
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) fDistribution11);
//        double double16 = randomDataImpl0.nextGamma(1.7904931097838226d, 5729.5779513082325d);
//        try {
//            java.lang.String str18 = randomDataImpl0.nextHexString((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (-1)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 80.31339086363825d + "'", double4 == 80.31339086363825d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 72 + "'", int7 == 72);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5d + "'", double13 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3775.4566632136757d + "'", double16 == 3775.4566632136757d);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double1 = org.apache.commons.math3.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        double double4 = fDistribution3.getNumericalMean();
        boolean boolean5 = fDistribution3.isSupportConnected();
        double double6 = fDistribution3.getNumericalVariance();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double1 = org.apache.commons.math3.util.FastMath.exp(3.7873579346816575d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 44.13962630585626d + "'", double1 == 44.13962630585626d);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        int int8 = randomDataImpl0.nextPascal((int) (short) 1, (double) (byte) 0);
//        org.apache.commons.math3.distribution.FDistribution fDistribution12 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
//        double double14 = fDistribution12.density(0.0d);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) fDistribution12);
//        try {
//            double double18 = randomDataImpl0.nextGamma(0.24337046883404329d, (-0.037790108241021206d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-0.038)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 91 + "'", int5 == 91);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        randomDataGenerator5.reSeed();
        randomDataGenerator5.reSeedSecure((long) 312574995);
        org.junit.Assert.assertNotNull(intArray3);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextSecureInt(20, (int) 'a');
//        try {
//            randomDataImpl0.setSecureAlgorithm("a443ff91b830552e007e8bdc80789941", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 50 + "'", int5 == 50);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass2 = maxCountExceededException1.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException1, localizable3, objArray6);
        java.lang.Number number8 = maxCountExceededException1.getMax();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = maxCountExceededException1.getContext();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1 + "'", number8.equals(1));
        org.junit.Assert.assertNotNull(exceptionContext9);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution((double) (byte) 0, (double) '4');
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) 59);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double1 = org.apache.commons.math3.special.Gamma.gamma(58.0019903315599d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0855068415443306E76d + "'", double1 == 4.0855068415443306E76d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 59, (java.lang.Number) 0.21792004587067423d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.21792004587067423d + "'", number4.equals(0.21792004587067423d));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 718070342);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.180704E8f + "'", float1 == 7.180704E8f);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        double double4 = randomDataImpl0.nextExponential((double) '#');
//        randomDataImpl0.reSeed((long) 1);
//        long long9 = randomDataImpl0.nextSecureLong(97L, (long) (byte) 100);
//        try {
//            int int13 = randomDataImpl0.nextHypergeometric(0, 16, 85);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 27.18406759267038d + "'", double4 == 27.18406759267038d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
//    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        int int5 = randomDataImpl0.nextSecureInt(1, 100);
//        int int8 = randomDataImpl0.nextSecureInt((int) (byte) 10, 100);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) ' ');
//        double double13 = randomDataImpl0.nextUniform(3.9431995946238426E-5d, (double) 7035070615930559438L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 50 + "'", int5 == 50);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 91 + "'", int8 == 91);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "d7d83f7cb7e80461c4bcb96c06cec74e" + "'", str10.equals("d7d83f7cb7e80461c4bcb96c06cec74e"));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.13300909670996045E18d + "'", double13 == 1.13300909670996045E18d);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 48.0f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double double1 = org.apache.commons.math3.special.Gamma.trigamma(1.081337814212361E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.247803848687706E-13d + "'", double1 == 9.247803848687706E-13d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double1 = org.apache.commons.math3.special.Gamma.lanczos((double) 91);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1256315975300648d + "'", double1 == 1.1256315975300648d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double2 = org.apache.commons.math3.util.FastMath.max(1.0842021724855044E-19d, (double) 73);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 73.0d + "'", double2 == 73.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.0d, (double) 1);
        double double4 = uniformRealDistribution2.density(5.605475678368494d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(0.2384666681235159d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0285681724852862d + "'", double1 == 1.0285681724852862d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution3 = new org.apache.commons.math3.distribution.UniformRealDistribution((-1.5663321581939567d), 0.028192915962341632d, 56.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathIllegalStateException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 100.0f);
        java.lang.Throwable[] throwableArray6 = notStrictlyPositiveException5.getSuppressed();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable1, (java.lang.Number) 0.22024271386553707d, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        boolean boolean4 = fDistribution3.isSupportUpperBoundInclusive();
        double double5 = fDistribution3.getSupportUpperBound();
        double double6 = fDistribution3.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) 'a');
        well19937c1.setSeed((long) (short) 1);
        double double4 = well19937c1.nextDouble();
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution8 = new org.apache.commons.math3.distribution.UniformRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (-2.6188773144433135d), (double) 3.12575008E8f, (-2.8131219329264736d));
        double double9 = well19937c1.nextDouble();
        well19937c1.setSeed((long) 22);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.07277703352123166d + "'", double4 == 0.07277703352123166d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.33499450848006207d + "'", double9 == 0.33499450848006207d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double double3 = org.apache.commons.math3.special.Beta.regularizedBeta((-0.6206239346111186d), 73.0d, (-2.0d));
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(0.24348764167264014d);
//        double double5 = randomDataImpl0.nextCauchy((double) 56, (double) 0.07277703f);
//        double double7 = randomDataImpl0.nextChiSquare(0.03268622397329245d);
//        try {
//            int[] intArray10 = randomDataImpl0.nextPermutation(81, 85);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: permutation size (85) exceeds permuation domain (81)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2832963541346377d + "'", double2 == 0.2832963541346377d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 56.24559722741538d + "'", double5 == 56.24559722741538d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(0.23107014828793498d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.239344268360759d + "'", double1 == 13.239344268360759d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) '4', (int) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.34187181E17f + "'", float2 == 2.34187181E17f);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(0.12336904722135343d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49781586933391875d + "'", double1 == 0.49781586933391875d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(19.347757568224782d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5271111700000036E8d + "'", double1 == 2.5271111700000036E8d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(0.03125d, (double) 1L, (double) 5);
        boolean boolean4 = fDistribution3.isSupportConnected();
        double double5 = fDistribution3.getNumeratorDegreesOfFreedom();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.03125d + "'", double5 == 0.03125d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) ' ', (double) 100, (-2239.8761611765112d));
        double double4 = iterativeLegendreGaussIntegrator3.getAbsoluteAccuracy();
        int int5 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        int int6 = iterativeLegendreGaussIntegrator3.getEvaluations();
        int int7 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-2239.8761611765112d) + "'", double4 == (-2239.8761611765112d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double10 = randomDataGenerator5.nextChiSquare((double) 100.0f);
        int int13 = randomDataGenerator5.nextPascal((int) (byte) 100, 0.7165313105737893d);
        double double16 = randomDataGenerator5.nextBeta(0.03268622397329245d, (double) (byte) 1);
        double double19 = randomDataGenerator5.nextBeta(148.4131591025766d, 58.0019903315599d);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.31169712162223d + "'", double10 == 119.31169712162223d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.7474939987878148d + "'", double19 == 0.7474939987878148d);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        double double4 = randomDataImpl0.nextExponential((double) '#');
//        double double7 = randomDataImpl0.nextF(0.22202758411722212d, 115.35132074025435d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.603505962267805d + "'", double4 == 5.603505962267805d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 5.834138592669901d + "'", double7 == 5.834138592669901d);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(3.1983025682022693E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.2351647362715017E-22d + "'", double1 == 4.2351647362715017E-22d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        boolean boolean3 = uniformRealDistribution2.isSupportLowerBoundInclusive();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        double double4 = uniformRealDistribution2.density((double) 3);
        boolean boolean5 = uniformRealDistribution2.isSupportConnected();
        double double7 = uniformRealDistribution2.cumulativeProbability(0.24290142399449977d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9726833128650032d + "'", double7 == 0.9726833128650032d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, 0.0d, 9.98337712458582d, (int) (short) -1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution((double) 56, 0.24348764167264014d, 6.598524091877789E-28d);
        double double4 = fDistribution3.getDenominatorDegreesOfFreedom();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.24348764167264014d + "'", double4 == 0.24348764167264014d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Class<?> wildcardClass9 = maxCountExceededException8.getClass();
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 100L, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException8, localizable10, objArray13);
        java.lang.Throwable[] throwableArray15 = maxCountExceededException8.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException4, localizable6, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100L, (java.lang.Number) 0, false);
        mathIllegalStateException17.addSuppressed((java.lang.Throwable) numberIsTooLargeException21);
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError23 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) mathIllegalStateException17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        long long5 = well19937c4.nextLong();
//        well19937c4.setSeed((long) 2147483647);
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl8.reSeedSecure();
//        randomDataImpl8.reSeedSecure();
//        int int13 = randomDataImpl8.nextSecureInt(1, 100);
//        int int16 = randomDataImpl8.nextPascal((int) (short) 1, (double) (byte) 0);
//        double double19 = randomDataImpl8.nextCauchy((double) 16, Double.NaN);
//        int[] intArray22 = randomDataImpl8.nextPermutation(100, 10);
//        well19937c4.setSeed(intArray22);
//        well19937c4.clear();
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4491554327296166888L + "'", long5 == 4491554327296166888L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32 + "'", int13 == 32);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(intArray22);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double2 = org.apache.commons.math3.util.FastMath.max(0.23856920175694382d, (double) 7.180704E8f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.180704E8d + "'", double2 == 7.180704E8d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double1 = org.apache.commons.math3.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        int[] intArray3 = new int[] { (short) 0, 1, 10 };
//        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
//        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
//        randomDataGenerator5.reSeed();
//        double double11 = randomDataGenerator5.nextChiSquare((double) 10L);
//        double double14 = randomDataGenerator5.nextGaussian((double) 11L, 95.99024473023697d);
//        double double16 = randomDataGenerator5.nextExponential(138.7387638377017d);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.319325075937657d + "'", double11 == 8.319325075937657d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-16.756488356628626d) + "'", double14 == (-16.756488356628626d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 69.24249049081537d + "'", double16 == 69.24249049081537d);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.01789962561529476d, 56.13352067336168d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4237092918649077E-28d + "'", double2 == 1.4237092918649077E-28d);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
//        double double3 = uniformRealDistribution2.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.24347462284355983d + "'", double3 == 0.24347462284355983d);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(73.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 73.0d + "'", double2 == 73.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double double0 = org.apache.commons.math3.analysis.integration.BaseAbstractUnivariateIntegrator.DEFAULT_RELATIVE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-6d + "'", double0 == 1.0E-6d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        double double11 = randomDataGenerator5.nextGaussian(119.31169712162223d, 0.36787944117144233d);
        int int14 = randomDataGenerator5.nextZipf(22, 0.7474939987878148d);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 119.57133787457882d + "'", double11 == 119.57133787457882d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(40.04519319891766d, 0.03125d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.350998724046218E-109d + "'", double2 == 5.350998724046218E-109d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        int[] intArray3 = new int[] { (short) 0, 1, 10 };
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c4);
        double double8 = randomDataGenerator5.nextUniform(0.0d, 2.6881171418161356E43d);
        randomDataGenerator5.reSeed();
        randomDataGenerator5.reSeedSecure();
        try {
            java.lang.String str12 = randomDataGenerator5.nextHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.545233034006089E42d + "'", double8 == 6.545233034006089E42d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(3.94319959666758E-5d, 2.5271111700000036E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.94319959666758E-5d + "'", double2 == 3.94319959666758E-5d);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 10);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        long long10 = randomDataImpl0.nextLong((long) 20, (long) 48);
//        int int13 = randomDataImpl0.nextZipf(3, (double) (short) 100);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 26L + "'", long10 == 26L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double double2 = org.apache.commons.math3.special.Beta.logBeta(22026.0d, 32.00000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-241.92960784799652d) + "'", double2 == (-241.92960784799652d));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(0.23008508979394976d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22610909338272647d + "'", double1 == 0.22610909338272647d);
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(0.24348764167264014d);
//        double double5 = randomDataImpl0.nextCauchy((double) 56, (double) 0.07277703f);
//        try {
//            int[] intArray8 = randomDataImpl0.nextPermutation(56, 99);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: permutation size (99) exceeds permuation domain (56)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2366699375552484d + "'", double2 == 0.2366699375552484d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 56.03113745883201d + "'", double5 == 56.03113745883201d);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.22202758411722212d, 0.24348764167264014d);
        double double4 = uniformRealDistribution2.cumulativeProbability((double) 100.0f);
        double[] doubleArray6 = uniformRealDistribution2.sample((int) (short) 100);
        boolean boolean7 = uniformRealDistribution2.isSupportLowerBoundInclusive();
        double double8 = uniformRealDistribution2.getNumericalVariance();
        boolean boolean9 = uniformRealDistribution2.isSupportConnected();
        try {
            double double11 = uniformRealDistribution2.inverseCumulativeProbability(22026.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 22,026 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.837783919015451E-5d + "'", double8 == 3.837783919015451E-5d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        double double4 = randomDataImpl0.nextExponential((double) '#');
//        randomDataImpl0.reSeed((long) 1);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0136164113726673d + "'", double4 == 1.0136164113726673d);
//    }
//}

